package com.htsoft.oa;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class FlowConstants
{
  public static Map<Object, Class> FIELD_TYPE_MAP = new HashMap();
  public static final String SIGN_VOTE_TYPE = "signVoteType";
  public static final String TO_PARENT_PATH = "toParentPath";
  public static final String DUE_DATE = "dueDate";

  static
  {
    FIELD_TYPE_MAP.put("java.lang.String", String.class);
    FIELD_TYPE_MAP.put("java.lang.Long", Long.class);
    FIELD_TYPE_MAP.put("java.lang.Integer", Integer.class);
    FIELD_TYPE_MAP.put("java.lang.Short", Short.class);
    FIELD_TYPE_MAP.put("java.lang.Float", Float.class);
    FIELD_TYPE_MAP.put("java.lang.Double", Double.class);
    FIELD_TYPE_MAP.put("java.util.Date", Date.class);
    FIELD_TYPE_MAP.put("String", String.class);
    FIELD_TYPE_MAP.put("Long", Long.class);
    FIELD_TYPE_MAP.put("Integer", Integer.class);
    FIELD_TYPE_MAP.put("Short", Short.class);
    FIELD_TYPE_MAP.put("Float", Float.class);
    FIELD_TYPE_MAP.put("Double", Double.class);
    FIELD_TYPE_MAP.put("Date", Date.class);
    FIELD_TYPE_MAP.put("String", String.class);
    FIELD_TYPE_MAP.put("long", Long.class);
    FIELD_TYPE_MAP.put("int", Integer.class);
    FIELD_TYPE_MAP.put("short", Short.class);
    FIELD_TYPE_MAP.put("float", Float.class);
    FIELD_TYPE_MAP.put("double", Double.class);
    FIELD_TYPE_MAP.put("tinyint", Integer.class);
    FIELD_TYPE_MAP.put("smallint", Integer.class);
    FIELD_TYPE_MAP.put("mediumint", Integer.class);
    FIELD_TYPE_MAP.put("int", Integer.class);
    FIELD_TYPE_MAP.put("bigint", Long.class);
    FIELD_TYPE_MAP.put("float", Float.class);
    FIELD_TYPE_MAP.put("double", Double.class);
    FIELD_TYPE_MAP.put("char", String.class);
    FIELD_TYPE_MAP.put("varchar", String.class);
    FIELD_TYPE_MAP.put("tinytext ", String.class);
    FIELD_TYPE_MAP.put("text", String.class);
    FIELD_TYPE_MAP.put("mediumtext", String.class);
    FIELD_TYPE_MAP.put("longtext", String.class);
    FIELD_TYPE_MAP.put("blob", String.class);
    FIELD_TYPE_MAP.put("longblob", String.class);
    FIELD_TYPE_MAP.put("date", Date.class);
    FIELD_TYPE_MAP.put("time", Date.class);
    FIELD_TYPE_MAP.put("datetime", Date.class);
    FIELD_TYPE_MAP.put("timestamp", Date.class);
    FIELD_TYPE_MAP.put("TINYINT", Integer.class);
    FIELD_TYPE_MAP.put("SMALLINT", Integer.class);
    FIELD_TYPE_MAP.put("MEDIUMINT", Integer.class);
    FIELD_TYPE_MAP.put("INT", Integer.class);
    FIELD_TYPE_MAP.put("BIGINT", Long.class);
    FIELD_TYPE_MAP.put("FLOAT", Float.class);
    FIELD_TYPE_MAP.put("DOUBLE", Double.class);
    FIELD_TYPE_MAP.put("CHAR", String.class);
    FIELD_TYPE_MAP.put("VARCHAR", String.class);
    FIELD_TYPE_MAP.put("TINYTEXT ", String.class);
    FIELD_TYPE_MAP.put("TEXT", String.class);
    FIELD_TYPE_MAP.put("MEDIUMTEXT", String.class);
    FIELD_TYPE_MAP.put("LONGTEXT", String.class);
    FIELD_TYPE_MAP.put("BLOB", String.class);
    FIELD_TYPE_MAP.put("LONGBLOB", String.class);
    FIELD_TYPE_MAP.put("DATE", Date.class);
    FIELD_TYPE_MAP.put("TIME", Date.class);
    FIELD_TYPE_MAP.put("DATETIME", Date.class);
    FIELD_TYPE_MAP.put("TIMESTAMP", Date.class);
    FIELD_TYPE_MAP.put("decimal", Double.class);
    FIELD_TYPE_MAP.put("DECIMAL", Double.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.FlowConstants
 * JD-Core Version:    0.6.0
 */