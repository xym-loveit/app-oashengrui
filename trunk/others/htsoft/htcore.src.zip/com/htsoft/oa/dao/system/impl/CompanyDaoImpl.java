package com.htsoft.oa.dao.system.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.system.CompanyDao;
import com.htsoft.oa.model.system.Company;
import java.util.List;

public class CompanyDaoImpl extends BaseDaoImpl<Company>
  implements CompanyDao
{
  public CompanyDaoImpl()
  {
    super(Company.class);
  }

  public List<Company> findCompany()
  {
    String str = "from Company c";
    return findByHql(str);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.impl.CompanyDaoImpl
 * JD-Core Version:    0.6.0
 */