package com.htsoft.oa.dao.flow;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.flow.FormDefMapping;
import java.util.List;

public abstract interface FormDefMappingDao extends BaseDao<FormDefMapping>
{
  public abstract FormDefMapping getByDeployId(String paramString);

  public abstract FormDefMapping findByDefId(Long paramLong);

  public abstract List<FormDefMapping> getByFormDef(Long paramLong);
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.FormDefMappingDao
 * JD-Core Version:    0.6.0
 */