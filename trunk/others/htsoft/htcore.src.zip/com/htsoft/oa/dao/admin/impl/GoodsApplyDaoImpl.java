package com.htsoft.oa.dao.admin.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.admin.GoodsApplyDao;
import com.htsoft.oa.model.admin.GoodsApply;

public class GoodsApplyDaoImpl extends BaseDaoImpl<GoodsApply>
  implements GoodsApplyDao
{
  public GoodsApplyDaoImpl()
  {
    super(GoodsApply.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.impl.GoodsApplyDaoImpl
 * JD-Core Version:    0.6.0
 */