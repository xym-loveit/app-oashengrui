package com.htsoft.oa.dao.system.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.system.IndexDisplayDao;
import com.htsoft.oa.model.system.IndexDisplay;
import java.util.List;

public class IndexDisplayDaoImpl extends BaseDaoImpl<IndexDisplay>
  implements IndexDisplayDao
{
  public IndexDisplayDaoImpl()
  {
    super(IndexDisplay.class);
  }

  public List<IndexDisplay> findByUser(Long paramLong)
  {
    String str = "from IndexDisplay vo where vo.appUser.userId=?";
    return findByHql(str, new Object[] { paramLong });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.impl.IndexDisplayDaoImpl
 * JD-Core Version:    0.6.0
 */