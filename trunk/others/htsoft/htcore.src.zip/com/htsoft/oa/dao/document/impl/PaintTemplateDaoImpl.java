package com.htsoft.oa.dao.document.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.document.PaintTemplateDao;
import com.htsoft.oa.model.document.PaintTemplate;
import java.util.List;

public class PaintTemplateDaoImpl extends BaseDaoImpl<PaintTemplate>
  implements PaintTemplateDao
{
  public PaintTemplateDaoImpl()
  {
    super(PaintTemplate.class);
  }

  public List<PaintTemplate> getByKey(String paramString)
  {
    String str = "from PaintTemplate pt where pt.templateKey=?";
    return findByHql(str, new Object[] { paramString });
  }

  public List<PaintTemplate> getByKeyExceptId(String paramString, Long paramLong)
  {
    String str = "from PaintTemplate pt where pt.templateKey=? and pt.ptemplateId!=?";
    return findByHql(str, new Object[] { paramString, paramLong });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.document.impl.PaintTemplateDaoImpl
 * JD-Core Version:    0.6.0
 */