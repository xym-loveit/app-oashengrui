package com.htsoft.oa.dao.hrm.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.hrm.JobDao;
import com.htsoft.oa.model.hrm.Job;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.logging.Log;
import org.hibernate.Query;
import org.hibernate.Session;

public class JobDaoImpl extends BaseDaoImpl<Job>
  implements JobDao
{
  public JobDaoImpl()
  {
    super(Job.class);
  }

  public List<Job> findByDep(Long paramLong)
  {
    String str = "from Job vo where vo.jobId=?";
    Object[] arrayOfObject = { paramLong };
    return findByHql(str, arrayOfObject);
  }

  public List<Job> findByCondition(Long paramLong)
  {
    StringBuffer localStringBuffer = new StringBuffer("select j from Job j where j.delFlag = 0 and j.parentId = ? ");
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(paramLong);
    return findByHql(localStringBuffer.toString(), localArrayList.toArray());
  }

  public void edit(Job paramJob)
  {
    String str = "update Job set jobName=?,memo=?,delFlag=? where jobId = ?";
    Query localQuery = getSession().createQuery(str);
    localQuery.setString(0, paramJob.getJobName());
    localQuery.setString(1, paramJob.getMemo());
    localQuery.setShort(2, paramJob.getDelFlag().shortValue());
    localQuery.setLong(3, paramJob.getJobId().longValue());
    this.logger.debug("JobDao中[修改岗位信息jobName,memo,delFlag]：" + str);
    localQuery.executeUpdate();
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.hrm.impl.JobDaoImpl
 * JD-Core Version:    0.6.0
 */