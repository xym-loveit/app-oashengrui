package com.htsoft.oa.dao.flow.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.flow.TaskSignDao;
import com.htsoft.oa.model.flow.TaskSign;

public class TaskSignDaoImpl extends BaseDaoImpl<TaskSign>
  implements TaskSignDao
{
  public TaskSignDaoImpl()
  {
    super(TaskSign.class);
  }

  public TaskSign findByAssignId(Long paramLong)
  {
    String str = "from TaskSign ts where ts.proUserAssign.assignId=? ";
    return (TaskSign)findUnique(str, new Object[] { paramLong });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.impl.TaskSignDaoImpl
 * JD-Core Version:    0.6.0
 */