package com.htsoft.oa.dao.system.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.system.TypeKeyDao;
import com.htsoft.oa.model.system.TypeKey;

public class TypeKeyDaoImpl extends BaseDaoImpl<TypeKey>
  implements TypeKeyDao
{
  public TypeKeyDaoImpl()
  {
    super(TypeKey.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.impl.TypeKeyDaoImpl
 * JD-Core Version:    0.6.0
 */