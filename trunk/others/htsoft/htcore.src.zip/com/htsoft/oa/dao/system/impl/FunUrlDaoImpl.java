package com.htsoft.oa.dao.system.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.system.FunUrlDao;
import com.htsoft.oa.model.system.FunUrl;

public class FunUrlDaoImpl extends BaseDaoImpl<FunUrl>
  implements FunUrlDao
{
  public FunUrlDaoImpl()
  {
    super(FunUrl.class);
  }

  public FunUrl getByPathFunId(String paramString, Long paramLong)
  {
    String str = "from FunUrl fu where fu.urlPath=? and fu.appFunction.functionId=? ";
    return (FunUrl)findUnique(str, new Object[] { paramString, paramLong });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.impl.FunUrlDaoImpl
 * JD-Core Version:    0.6.0
 */