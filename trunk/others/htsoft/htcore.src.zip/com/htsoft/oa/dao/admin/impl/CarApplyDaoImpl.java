package com.htsoft.oa.dao.admin.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.admin.CarApplyDao;
import com.htsoft.oa.model.admin.CarApply;

public class CarApplyDaoImpl extends BaseDaoImpl<CarApply>
  implements CarApplyDao
{
  public CarApplyDaoImpl()
  {
    super(CarApply.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.impl.CarApplyDaoImpl
 * JD-Core Version:    0.6.0
 */