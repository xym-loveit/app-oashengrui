package com.htsoft.oa.dao.flow.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.flow.ProcessRunDao;
import com.htsoft.oa.model.flow.ProcessRun;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.StringUtils;

public class ProcessRunDaoImpl extends BaseDaoImpl<ProcessRun>
  implements ProcessRunDao
{
  public ProcessRunDaoImpl()
  {
    super(ProcessRun.class);
  }

  public ProcessRun getByPiId(String paramString)
  {
    String str = "from ProcessRun pr where pr.piId=?";
    return (ProcessRun)findUnique(str, new Object[] { paramString });
  }

  public List<ProcessRun> getByDefId(Long paramLong, PagingBean paramPagingBean)
  {
    String str = " from ProcessRun pr where pr.proDefinition.defId=? ";
    return findByHql(str, new Object[] { paramLong }, paramPagingBean);
  }

  public List<ProcessRun> getByUserIdSubject(Long paramLong, String paramString, PagingBean paramPagingBean)
  {
    ArrayList localArrayList = new ArrayList();
    String str = "select pr from ProcessRun as pr join pr.processForms as pf where pf.creatorId=? group by pr.runId order by pr.createtime desc";
    localArrayList.add(paramLong);
    if (StringUtils.isNotEmpty(paramString))
    {
      str = str + " and pr.subject like ?";
      localArrayList.add("%" + paramString + "%");
    }
    return findByHql(str, localArrayList.toArray(), paramPagingBean);
  }

  public boolean checkRun(Long paramLong)
  {
    String str = "select r from ProcessRun r where r.proDefinition.defId = ?";
    Object[] arrayOfObject = { paramLong };
    List localList = findByHql(str, arrayOfObject);
    return (localList != null) && (localList.size() > 0);
  }

  public List<ProcessRun> getProcessRunning(Long paramLong)
  {
    String str = "from ProcessRun r where r.proDefinition.defId = ? and r.runStatus=1";
    Object[] arrayOfObject = { paramLong };
    return findByHql(str, arrayOfObject);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.impl.ProcessRunDaoImpl
 * JD-Core Version:    0.6.0
 */