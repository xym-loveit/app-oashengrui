package com.htsoft.oa.dao.system.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.system.GlobalTypeDao;
import com.htsoft.oa.model.system.AppRole;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.Department;
import com.htsoft.oa.model.system.GlobalType;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class GlobalTypeDaoImpl extends BaseDaoImpl<GlobalType>
  implements GlobalTypeDao
{
  public GlobalTypeDaoImpl()
  {
    super(GlobalType.class);
  }

  public List<GlobalType> getByParentIdCatKey(Long paramLong, String paramString)
  {
    String str = " from GlobalType gt where gt.parentId = ? and gt.catKey = ? order by gt.sn asc";
    return findByHql(str, new Object[] { paramLong, paramString });
  }

  public Integer getCountsByParentId(Long paramLong)
  {
    ArrayList localArrayList = new ArrayList();
    String str = " select count(proTypeId) from GlobalType gt ";
    if ((paramLong != null) && (paramLong.longValue() != 0L))
    {
      str = str + " where gt.parentId=?";
      localArrayList.add(paramLong);
    }
    else
    {
      str = str + " where gt.parentId is null";
    }
    Object localObject = findUnique(str, localArrayList.toArray());
    return new Integer(localObject.toString());
  }

  public List<GlobalType> getByParentId(Long paramLong)
  {
    ArrayList localArrayList = new ArrayList();
    String str = " from GlobalType gt ";
    if ((paramLong != null) && (paramLong.longValue() != 0L))
    {
      str = str + " where gt.parentId=?";
      localArrayList.add(paramLong);
    }
    else
    {
      str = str + " where gt.parentId is null";
    }
    return findByHql(str, localArrayList.toArray());
  }

  public List<GlobalType> getByPath(String paramString)
  {
    String str = " from GlobalType gt where gt.path like ?";
    return findByHql(str, new Object[] { paramString + "%" });
  }

  public GlobalType findByTypeName(String paramString)
  {
    String str = " from GlobalType gt where gt.typeName = ?";
    List localList = findByHql(str, new Object[] { paramString });
    if (localList.size() > 0)
      return (GlobalType)localList.get(0);
    return null;
  }

  public List<GlobalType> getByParentIdCatKeyUserId(Long paramLong1, String paramString, Long paramLong2)
  {
    String str = " from GlobalType gt where gt.parentId = ? and gt.catKey = ? and gt.userId=?";
    return findByHql(str, new Object[] { paramLong1, paramString, paramLong2 });
  }

  public List<GlobalType> getByRightsCatKey(AppUser paramAppUser, String paramString)
  {
    String str1 = "%," + paramAppUser.getUserId() + ",%";
    String str2 = "%," + paramAppUser.getDepartment().getDepId() + ",%";
    ArrayList localArrayList = new ArrayList();
    StringBuffer localStringBuffer = new StringBuffer("select gt from ProDefRights pr right join pr.globalType gt  where gt.catKey = ? and (pr.userIds like ?  or pr.depIds like ? ");
    localArrayList.add(paramString);
    localArrayList.add(str1);
    localArrayList.add(str2);
    Set localSet = paramAppUser.getRoles();
    Iterator localIterator = localSet.iterator();
    while (localIterator.hasNext())
    {
      AppRole localAppRole = (AppRole)localIterator.next();
      localStringBuffer.append("or pr.roleIds like ? ");
      String str3 = "%," + localAppRole.getRoleId() + ",%";
      localArrayList.add(str3);
    }
    localStringBuffer.append(")");
    return findByHql(localStringBuffer.toString(), localArrayList.toArray());
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.impl.GlobalTypeDaoImpl
 * JD-Core Version:    0.6.0
 */