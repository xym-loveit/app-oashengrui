package com.htsoft.oa.dao.info.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.info.ShortMessageDao;
import com.htsoft.oa.model.info.ShortMessage;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.commons.lang.StringUtils;

public class ShortMessageDaoImpl extends BaseDaoImpl<ShortMessage>
  implements ShortMessageDao
{
  public ShortMessageDaoImpl()
  {
    super(ShortMessage.class);
  }

  public List<ShortMessage> findAll(Long paramLong, PagingBean paramPagingBean)
  {
    String str = "from ShortMessage vo where vo.senderId=?";
    Object[] arrayOfObject = { paramLong };
    return findByHql(str, arrayOfObject, paramPagingBean);
  }

  public List<ShortMessage> findByUser(Long paramLong)
  {
    String str = "from ShortMessage vo where vo.senderId=?";
    Object[] arrayOfObject = { paramLong };
    return findByHql(str, arrayOfObject);
  }

  public List searchShortMessage(Long paramLong, ShortMessage paramShortMessage, Date paramDate1, Date paramDate2, PagingBean paramPagingBean, Short paramShort)
  {
    ArrayList localArrayList = new ArrayList();
    StringBuffer localStringBuffer = new StringBuffer("select vo1,vo2 from InMessage vo1,ShortMessage vo2 where vo1.shortMessage=vo2 and vo1.delFlag=0 and vo1.userId=? ");
    localArrayList.add(paramLong);
    if (paramShort != null)
    {
      localStringBuffer.append("and vo1.readFlag=?");
      localArrayList.add(paramShort);
    }
    if (paramShortMessage != null)
    {
      if (paramShortMessage.getMsgType() != null)
      {
        localStringBuffer.append(" and vo2.msgType=?");
        localArrayList.add(paramShortMessage.getMsgType());
      }
      if (StringUtils.isNotEmpty(paramShortMessage.getSender()))
      {
        localStringBuffer.append(" and vo2.sender=?");
        localArrayList.add(paramShortMessage.getSender());
      }
    }
    if (paramDate2 != null)
    {
      localStringBuffer.append("and vo2.sendTime <= ?");
      localArrayList.add(paramDate2);
    }
    if (paramDate1 != null)
    {
      localStringBuffer.append("and vo2.sendTime >= ?");
      localArrayList.add(paramDate1);
    }
    localStringBuffer.append(" order by vo2.sendTime desc");
    return findByHql(localStringBuffer.toString(), localArrayList.toArray(), paramPagingBean);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.info.impl.ShortMessageDaoImpl
 * JD-Core Version:    0.6.0
 */