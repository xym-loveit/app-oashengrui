package com.htsoft.oa.dao.flow.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.flow.HistoryTaskDao;
import java.util.List;
import org.jbpm.pvm.internal.history.model.HistoryTaskImpl;
import org.jbpm.pvm.internal.history.model.HistoryTaskInstanceImpl;

public class HistoryTaskDaoImpl extends BaseDaoImpl<HistoryTaskInstanceImpl>
  implements HistoryTaskDao
{
  public HistoryTaskDaoImpl()
  {
    super(HistoryTaskImpl.class);
  }

  public List<HistoryTaskInstanceImpl> getByPiIdAssigneeOutcome(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    String str = "from HistoryTaskInstanceImpl hti where hti.executionId=? and hti.historyTask.assignee=? and hti.activityName=? and hti.transitionName=?";
    return findByHql(str, new Object[] { paramString1, paramString2, paramString3, paramString4 });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.impl.HistoryTaskDaoImpl
 * JD-Core Version:    0.6.0
 */