package com.htsoft.oa.dao.hrm.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.hrm.SalaryItemDao;
import com.htsoft.oa.model.hrm.SalaryItem;
import java.util.List;
import org.apache.commons.lang.StringUtils;

public class SalaryItemDaoImpl extends BaseDaoImpl<SalaryItem>
  implements SalaryItemDao
{
  public SalaryItemDaoImpl()
  {
    super(SalaryItem.class);
  }

  public List<SalaryItem> getAllExcludeId(String paramString, PagingBean paramPagingBean)
  {
    String str = "from SalaryItem ";
    if (StringUtils.isNotEmpty(paramString))
      str = str + "where salaryItemId not in(" + paramString + ")";
    return findByHql(str, null, paramPagingBean);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.hrm.impl.SalaryItemDaoImpl
 * JD-Core Version:    0.6.0
 */