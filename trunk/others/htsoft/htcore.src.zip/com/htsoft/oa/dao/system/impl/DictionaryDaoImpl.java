package com.htsoft.oa.dao.system.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.system.DictionaryDao;
import com.htsoft.oa.model.system.Dictionary;
import java.sql.SQLException;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class DictionaryDaoImpl extends BaseDaoImpl<Dictionary>
  implements DictionaryDao
{
  public DictionaryDaoImpl()
  {
    super(Dictionary.class);
  }

  public List<String> getAllItems()
  {
    return (List)getHibernateTemplate().execute(new HibernateCallback()
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Query localQuery = paramSession.createQuery("select itemName from Dictionary group by itemName");
        return localQuery.list();
      }
    });
  }

  public List<String> getAllByItemName(String paramString)
  {
    return (List)getHibernateTemplate().execute(new HibernateCallback(paramString)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Query localQuery = paramSession.createQuery("select itemValue from Dictionary where itemName=?");
        localQuery.setString(0, this.val$itemName);
        return localQuery.list();
      }
    });
  }

  public List<Dictionary> getByItemName(String paramString)
  {
    return (List)getHibernateTemplate().execute(new HibernateCallback(paramString)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Query localQuery = paramSession.createQuery(" from Dictionary where itemName=?");
        localQuery.setString(0, this.val$itemName);
        return localQuery.list();
      }
    });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.impl.DictionaryDaoImpl
 * JD-Core Version:    0.6.0
 */