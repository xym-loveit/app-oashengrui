package com.htsoft.oa.dao.document.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.document.SealDao;
import com.htsoft.oa.model.document.Seal;

public class SealDaoImpl extends BaseDaoImpl<Seal>
  implements SealDao
{
  public SealDaoImpl()
  {
    super(Seal.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.document.impl.SealDaoImpl
 * JD-Core Version:    0.6.0
 */