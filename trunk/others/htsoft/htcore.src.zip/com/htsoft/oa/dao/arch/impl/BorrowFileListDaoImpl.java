package com.htsoft.oa.dao.arch.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.arch.BorrowFileListDao;
import com.htsoft.oa.model.arch.BorrowFileList;

public class BorrowFileListDaoImpl extends BaseDaoImpl<BorrowFileList>
  implements BorrowFileListDao
{
  public BorrowFileListDaoImpl()
  {
    super(BorrowFileList.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.arch.impl.BorrowFileListDaoImpl
 * JD-Core Version:    0.6.0
 */