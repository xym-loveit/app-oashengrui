package com.htsoft.oa.dao.document.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.document.DocPrivilegeDao;
import com.htsoft.oa.model.document.DocPrivilege;
import com.htsoft.oa.model.system.AppRole;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.Department;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.List<Ljava.lang.Integer;>;
import java.util.Set;

public class DocPrivilegeDaoImpl extends BaseDaoImpl<DocPrivilege>
  implements DocPrivilegeDao
{
  public DocPrivilegeDaoImpl()
  {
    super(DocPrivilege.class);
  }

  public List<DocPrivilege> getAll(DocPrivilege paramDocPrivilege, Long paramLong, PagingBean paramPagingBean)
  {
    StringBuffer localStringBuffer = new StringBuffer("from DocPrivilege vo where 1=1");
    ArrayList localArrayList = new ArrayList();
    if (paramLong != null)
    {
      localStringBuffer.append(" and vo.docFolder.folderId=?");
      localArrayList.add(paramLong);
    }
    if (paramDocPrivilege != null)
    {
      if (paramDocPrivilege.getUdrName() != null)
      {
        localStringBuffer.append(" and vo.udrName=?");
        localArrayList.add(paramDocPrivilege.getUdrName());
      }
      if (paramDocPrivilege.getFlag() != null)
      {
        localStringBuffer.append(" and vo.flag=?");
        localArrayList.add(paramDocPrivilege.getFlag());
      }
    }
    return findByHql(localStringBuffer.toString(), localArrayList.toArray(), paramPagingBean);
  }

  public List<DocPrivilege> getByPublic(DocPrivilege paramDocPrivilege, Long paramLong)
  {
    StringBuffer localStringBuffer = new StringBuffer("from DocPrivilege vo where 1=1");
    return findByHql(localStringBuffer.toString());
  }

  public List<Integer> getRightsByFolder(AppUser paramAppUser, Long paramLong)
  {
    ArrayList localArrayList1 = new ArrayList();
    ArrayList localArrayList2 = new ArrayList();
    StringBuffer localStringBuffer = new StringBuffer("from DocPrivilege vo where vo.docFolder.folderId=?");
    localArrayList2.add(paramLong);
    localStringBuffer.append(" and (");
    if (paramAppUser != null)
    {
      localStringBuffer.append("(vo.udrId=? and vo.flag=1)");
      localArrayList2.add(Integer.valueOf(Integer.parseInt(paramAppUser.getUserId().toString())));
    }
    if (paramAppUser.getDepartment() != null)
    {
      localStringBuffer.append(" or (vo.udrId=? and vo.flag=2)");
      localArrayList2.add(Integer.valueOf(Integer.parseInt(paramAppUser.getDepartment().getDepId().toString())));
    }
    Object localObject2;
    Object localObject3;
    if ((paramAppUser.getRoles() != null) && (paramAppUser.getRoles().size() > 0))
    {
      localObject1 = paramAppUser.getRoles();
      localObject2 = new StringBuffer();
      localObject3 = ((Set)localObject1).iterator();
      while (((Iterator)localObject3).hasNext())
        ((StringBuffer)localObject2).append(((AppRole)((Iterator)localObject3).next()).getRoleId() + ",");
      if (((Set)localObject1).size() > 0)
        ((StringBuffer)localObject2).deleteCharAt(((StringBuffer)localObject2).length() - 1);
      if (localObject2 != null)
        localStringBuffer.append(" or (vo.udrId in (" + localObject2 + ") and vo.flag=3)");
    }
    localStringBuffer.append(" )");
    Object localObject1 = findByHql(localStringBuffer.toString(), localArrayList2.toArray());
    if (localObject1 != null)
    {
      localObject2 = ((List)localObject1).iterator();
      while (((Iterator)localObject2).hasNext())
      {
        localObject3 = (DocPrivilege)((Iterator)localObject2).next();
        localArrayList1.add(((DocPrivilege)localObject3).getRights());
      }
    }
    return (List<Integer>)(List<Integer>)(List<Integer>)localArrayList1;
  }

  public Integer getRightsByDocument(AppUser paramAppUser, Long paramLong)
  {
    ArrayList localArrayList = new ArrayList();
    StringBuffer localStringBuffer = new StringBuffer("select pr from Document doc,DocFolder docF,DocPrivilege pr where doc.docFolder=docF and pr.docFolder=docF and pr.rights>0 and doc.docId=?");
    localArrayList.add(paramLong);
    localStringBuffer.append(" and (");
    if (paramAppUser != null)
    {
      localStringBuffer.append("(pr.udrId=? and pr.flag=1)");
      localArrayList.add(Integer.valueOf(Integer.parseInt(paramAppUser.getUserId().toString())));
    }
    if (paramAppUser.getDepartment() != null)
    {
      localStringBuffer.append(" or (pr.udrId=? and pr.flag=2)");
      localArrayList.add(Integer.valueOf(Integer.parseInt(paramAppUser.getDepartment().getDepId().toString())));
    }
    Iterator localIterator;
    if ((paramAppUser.getRoles() != null) && (paramAppUser.getRoles().size() > 0))
    {
      localObject1 = paramAppUser.getRoles();
      localObject2 = new StringBuffer();
      localIterator = ((Set)localObject1).iterator();
      while (localIterator.hasNext())
        ((StringBuffer)localObject2).append(((AppRole)localIterator.next()).getRoleId() + ",");
      if (((Set)localObject1).size() > 0)
        ((StringBuffer)localObject2).deleteCharAt(((StringBuffer)localObject2).length() - 1);
      if (localObject2 != null)
        localStringBuffer.append(" or (pr.udrId in (" + localObject2 + ") and pr.flag=3)");
    }
    localStringBuffer.append(" )");
    Object localObject1 = findByHql(localStringBuffer.toString(), localArrayList.toArray());
    Object localObject2 = Integer.valueOf(0);
    if (localObject1 != null)
    {
      localIterator = ((List)localObject1).iterator();
      while (localIterator.hasNext())
      {
        DocPrivilege localDocPrivilege = (DocPrivilege)localIterator.next();
        localObject2 = Integer.valueOf(((Integer)localObject2).intValue() | localDocPrivilege.getRights().intValue());
      }
    }
    return (Integer)(Integer)localObject2;
  }

  public Integer countPrivilege()
  {
    String str = "from DocPrivilege pr";
    List localList = findByHql(str);
    return Integer.valueOf(localList.size());
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.document.impl.DocPrivilegeDaoImpl
 * JD-Core Version:    0.6.0
 */