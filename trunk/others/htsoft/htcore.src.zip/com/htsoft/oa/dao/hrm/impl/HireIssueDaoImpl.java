package com.htsoft.oa.dao.hrm.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.hrm.HireIssueDao;
import com.htsoft.oa.model.hrm.HireIssue;

public class HireIssueDaoImpl extends BaseDaoImpl<HireIssue>
  implements HireIssueDao
{
  public HireIssueDaoImpl()
  {
    super(HireIssue.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.hrm.impl.HireIssueDaoImpl
 * JD-Core Version:    0.6.0
 */