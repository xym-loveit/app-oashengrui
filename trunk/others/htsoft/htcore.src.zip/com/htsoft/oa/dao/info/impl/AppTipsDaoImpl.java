package com.htsoft.oa.dao.info.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.info.AppTipsDao;
import com.htsoft.oa.model.info.AppTips;
import java.util.List;

public class AppTipsDaoImpl extends BaseDaoImpl<AppTips>
  implements AppTipsDao
{
  public AppTipsDaoImpl()
  {
    super(AppTips.class);
  }

  public List<AppTips> findByName(String paramString)
  {
    String str = "from AppTips vo where vo.tipsName=?";
    return findByHql(str, new Object[] { paramString });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.info.impl.AppTipsDaoImpl
 * JD-Core Version:    0.6.0
 */