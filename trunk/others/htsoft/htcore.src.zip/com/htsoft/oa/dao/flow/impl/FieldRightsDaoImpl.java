package com.htsoft.oa.dao.flow.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.flow.FieldRightsDao;
import com.htsoft.oa.model.flow.FieldRights;
import java.util.List;

public class FieldRightsDaoImpl extends BaseDaoImpl<FieldRights>
  implements FieldRightsDao
{
  public FieldRightsDaoImpl()
  {
    super(FieldRights.class);
  }

  public List<FieldRights> getByMappingFieldTaskName(Long paramLong1, Long paramLong2, String paramString)
  {
    String str = "from FieldRights vo where vo.formField.fieldId=? and vo.mappingId=? and vo.taskName=?";
    return findByHql(str, new Object[] { paramLong2, paramLong1, paramString });
  }

  public List<FieldRights> getByMappingIdAndTaskName(Long paramLong, String paramString)
  {
    String str = "from FieldRights vo where vo.mappingId=? and vo.taskName=?";
    return findByHql(str, new Object[] { paramLong, paramString });
  }

  public List<FieldRights> getByMappingId(Long paramLong)
  {
    String str = "from FieldRights vo where vo.mappingId=?";
    return findByHql(str, new Object[] { paramLong });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.impl.FieldRightsDaoImpl
 * JD-Core Version:    0.6.0
 */