package com.htsoft.oa.dao.hrm.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.hrm.EmpProfileDao;
import com.htsoft.oa.model.hrm.EmpProfile;
import java.sql.SQLException;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class EmpProfileDaoImpl extends BaseDaoImpl<EmpProfile>
  implements EmpProfileDao
{
  public EmpProfileDaoImpl()
  {
    super(EmpProfile.class);
  }

  public boolean checkProfileNo(String paramString)
  {
    Long localLong = (Long)getHibernateTemplate().execute(new HibernateCallback(paramString)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Query localQuery = paramSession.createQuery("select count(*) from EmpProfile ep where ep.profileNo = ?");
        localQuery.setString(0, this.val$profileNo);
        return localQuery.uniqueResult();
      }
    });
    return localLong.longValue() == 0L;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.hrm.impl.EmpProfileDaoImpl
 * JD-Core Version:    0.6.0
 */