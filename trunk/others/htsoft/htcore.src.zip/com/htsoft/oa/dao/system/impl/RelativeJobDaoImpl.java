package com.htsoft.oa.dao.system.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.system.RelativeJobDao;
import com.htsoft.oa.model.system.RelativeJob;
import java.util.List;
import org.apache.commons.logging.Log;
import org.hibernate.Query;
import org.hibernate.Session;

public class RelativeJobDaoImpl extends BaseDaoImpl<RelativeJob>
  implements RelativeJobDao
{
  public RelativeJobDaoImpl()
  {
    super(RelativeJob.class);
  }

  public void remove(Long paramLong)
  {
    String str = "delete from RelativeJob r where r.path like ? ";
    Query localQuery = getSession().createQuery(str);
    localQuery.setString(0, ((RelativeJob)get(paramLong)).getPath() + "%");
    this.logger.debug(str);
    localQuery.executeUpdate();
  }

  public List<RelativeJob> findByParentId(Long paramLong)
  {
    String str = "select r from RelativeJob r where r.parent = ? ";
    Object[] arrayOfObject = { paramLong };
    return findByHql(str, arrayOfObject);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.impl.RelativeJobDaoImpl
 * JD-Core Version:    0.6.0
 */