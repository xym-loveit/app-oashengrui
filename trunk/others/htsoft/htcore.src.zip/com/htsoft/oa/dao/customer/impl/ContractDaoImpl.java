package com.htsoft.oa.dao.customer.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.customer.ContractDao;
import com.htsoft.oa.model.customer.Contract;

public class ContractDaoImpl extends BaseDaoImpl<Contract>
  implements ContractDao
{
  public ContractDaoImpl()
  {
    super(Contract.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.customer.impl.ContractDaoImpl
 * JD-Core Version:    0.6.0
 */