package com.htsoft.oa.dao.admin.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.admin.ConfAttendDao;
import com.htsoft.oa.model.admin.ConfAttend;

public class ConfAttendDaoImpl extends BaseDaoImpl<ConfAttend>
  implements ConfAttendDao
{
  public ConfAttendDaoImpl()
  {
    super(ConfAttend.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.impl.ConfAttendDaoImpl
 * JD-Core Version:    0.6.0
 */