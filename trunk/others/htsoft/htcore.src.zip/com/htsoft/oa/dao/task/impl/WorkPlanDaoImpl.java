package com.htsoft.oa.dao.task.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.task.WorkPlanDao;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.Department;
import com.htsoft.oa.model.task.WorkPlan;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import org.apache.commons.lang.StringUtils;

public class WorkPlanDaoImpl extends BaseDaoImpl<WorkPlan>
  implements WorkPlanDao
{
  public WorkPlanDaoImpl()
  {
    super(WorkPlan.class);
  }

  public List<WorkPlan> findByDepartment(WorkPlan paramWorkPlan, AppUser paramAppUser, PagingBean paramPagingBean)
  {
    StringBuffer localStringBuffer1 = new StringBuffer();
    ArrayList localArrayList = new ArrayList();
    if (!paramAppUser.getRights().contains("__ALL"))
    {
      localStringBuffer1.append("select distinct wp from WorkPlan wp,PlanAttend pa where pa.workPlan=wp and wp.status=1 and wp.isPersonal=0 and ((pa.appUser.userId=? and pa.isDep=0)");
      Department localDepartment = paramAppUser.getDepartment();
      localArrayList.add(paramAppUser.getUserId());
      if (localDepartment != null)
      {
        String str = localDepartment.getPath();
        if (StringUtils.isNotEmpty(str))
        {
          StringBuffer localStringBuffer2 = new StringBuffer(str.replace(".", ","));
          localStringBuffer2.deleteCharAt(localStringBuffer2.length() - 1);
          localStringBuffer1.append(" or (pa.department.depId in (" + localStringBuffer2.toString() + ") and pa.isDep=1)");
        }
      }
      localStringBuffer1.append(")");
    }
    else
    {
      localStringBuffer1.append("select wp from WorkPlan wp where wp.status=1 and wp.isPersonal=0");
    }
    if (paramWorkPlan != null)
    {
      if (StringUtils.isNotEmpty(paramWorkPlan.getPlanName()))
      {
        localStringBuffer1.append(" and wp.planName like ?");
        localArrayList.add("%" + paramWorkPlan.getPlanName() + "%");
      }
      if (StringUtils.isNotEmpty(paramWorkPlan.getPrincipal()))
      {
        localStringBuffer1.append(" and wp.principal like ?");
        localArrayList.add("%" + paramWorkPlan.getPrincipal() + "%");
      }
      if (paramWorkPlan.getTypeName() != null)
      {
        localStringBuffer1.append(" and wp.typeName like ?");
        localArrayList.add("%" + paramWorkPlan.getTypeName() + "%");
      }
    }
    return findByHql(localStringBuffer1.toString(), localArrayList.toArray(), paramPagingBean);
  }

  public List<WorkPlan> sendWorkPlanTime()
  {
    String str1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
    String str2 = "select wp from WorkPlan wp where wp.isPersonal=1 and  wp.endTime <=" + str1;
    return findByHql(str2);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.task.impl.WorkPlanDaoImpl
 * JD-Core Version:    0.6.0
 */