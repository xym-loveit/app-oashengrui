package com.htsoft.oa.dao.task.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.task.AppointmentDao;
import com.htsoft.oa.model.task.Appointment;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AppointmentDaoImpl extends BaseDaoImpl<Appointment>
  implements AppointmentDao
{
  public AppointmentDaoImpl()
  {
    super(Appointment.class);
  }

  public List<Appointment> showAppointmentByUserId(Long paramLong, PagingBean paramPagingBean)
  {
    ArrayList localArrayList = new ArrayList();
    Calendar localCalendar = Calendar.getInstance();
    StringBuffer localStringBuffer = new StringBuffer("select vo from Appointment vo where vo.appUser.userId=? and vo.startTime > ? order by vo.startTime ASC");
    localArrayList.add(paramLong);
    localArrayList.add(localCalendar.getTime());
    return findByHql(localStringBuffer.toString(), localArrayList.toArray(), paramPagingBean);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.task.impl.AppointmentDaoImpl
 * JD-Core Version:    0.6.0
 */