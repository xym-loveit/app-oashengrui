package com.htsoft.oa.dao.system.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.system.FileAttachDao;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.FileAttach;
import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.logging.Log;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class FileAttachDaoImpl extends BaseDaoImpl<FileAttach>
  implements FileAttachDao
{
  public FileAttachDaoImpl()
  {
    super(FileAttach.class);
  }

  public void removeByPath(String paramString)
  {
    getHibernateTemplate().execute(new HibernateCallback(paramString)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Query localQuery = paramSession.createQuery("delete from FileAttach fa where fa.filePath = ?");
        localQuery.setString(0, this.val$filePath);
        return Integer.valueOf(localQuery.executeUpdate());
      }
    });
  }

  public FileAttach getByPath(String paramString)
  {
    String str = "from FileAttach fa where fa.filePath = ?";
    return (FileAttach)findUnique(str, new Object[] { paramString });
  }

  public List<FileAttach> fileList(PagingBean paramPagingBean, String paramString, boolean paramBoolean)
  {
    Long localLong = ContextUtil.getCurrentUser().getUserId();
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(localLong);
    String str = "select f from FileAttach f where (f.delFlag = 0 or f.delFlag is null) and f.creatorId = ? ";
    if ((paramString != null) && (!paramString.equals("")))
    {
      str = str + " and f.fileType like ? ";
      localArrayList.add(paramString + "%");
    }
    if (!paramBoolean)
      str = str + "and f.ext in('jpg','gif','jpeg','png','bmp','JPG','GIF','JPEG','PNG','BPM') ";
    str = str + "order by f.createtime DESC ";
    this.logger.debug("FileAttach：" + str);
    return findByHql(str, localArrayList.toArray(), paramPagingBean);
  }

  public List<FileAttach> fileList(String paramString)
  {
    Long localLong = ContextUtil.getCurrentUser().getUserId();
    ArrayList localArrayList = new ArrayList();
    String str = "select f from FileAttach f where (f.delFlag =0 or f.delFlag is null) and f.creatorId = ? and ";
    localArrayList.add(localLong);
    if (!paramString.isEmpty())
    {
      str = str + "f.fileType like ? ";
      localArrayList.add(paramString);
    }
    str = str + "order by f.createtime DESC ";
    this.logger.debug(str);
    return findByHql(str, localArrayList.toArray());
  }

  public void remove(Long paramLong)
  {
    FileAttach localFileAttach = (FileAttach)get(paramLong);
    localFileAttach.setDelFlag(Integer.valueOf(1));
    save(localFileAttach);
    File localFile = new File(localFileAttach.getFilePath());
    if (localFile.exists())
      localFile.delete();
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.impl.FileAttachDaoImpl
 * JD-Core Version:    0.6.0
 */