package com.htsoft.oa.dao.admin.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.admin.BookSnDao;
import com.htsoft.oa.model.admin.BookSn;
import java.util.List;

public class BookSnDaoImpl extends BaseDaoImpl<BookSn>
  implements BookSnDao
{
  public BookSnDaoImpl()
  {
    super(BookSn.class);
  }

  public List<BookSn> findByBookId(Long paramLong)
  {
    Object[] arrayOfObject = { paramLong };
    return findByHql("from BookSn b where b.book.bookId=?", arrayOfObject);
  }

  public List<BookSn> findBorrowByBookId(Long paramLong)
  {
    Object[] arrayOfObject = { paramLong };
    return findByHql("from BookSn b where b.book.bookId=? and b.status=0", arrayOfObject);
  }

  public List<BookSn> findReturnByBookId(Long paramLong)
  {
    Object[] arrayOfObject = { paramLong };
    return findByHql("from BookSn b where b.book.bookId=? and b.status=1", arrayOfObject);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.impl.BookSnDaoImpl
 * JD-Core Version:    0.6.0
 */