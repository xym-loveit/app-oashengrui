package com.htsoft.oa.dao.communicate.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.communicate.OutMailDao;
import com.htsoft.oa.model.communicate.OutMail;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class OutMailDaoImpl extends BaseDaoImpl<OutMail>
  implements OutMailDao
{
  public OutMailDaoImpl()
  {
    super(OutMail.class);
  }

  public List<OutMail> findByFolderId(Long paramLong)
  {
    String str = "from OutMail where folderId = ?";
    return findByHql(str, new Object[] { paramLong });
  }

  public Long CountByFolderId(Long paramLong)
  {
    String str = "select count(*) from OutMail where folderId =" + paramLong;
    return (Long)getHibernateTemplate().find(str).get(0);
  }

  public Map getUidByUserId(Long paramLong)
  {
    String str1 = "select om.uid from OutMail om where om.userId =" + paramLong;
    List localList = getHibernateTemplate().find(str1);
    HashMap localHashMap = new HashMap();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      String str2 = (String)localIterator.next();
      localHashMap.put(str2, "Y");
    }
    return localHashMap;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.communicate.impl.OutMailDaoImpl
 * JD-Core Version:    0.6.0
 */