package com.htsoft.oa.dao.admin.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.admin.BookBorRetDao;
import com.htsoft.oa.model.admin.BookBorRet;
import java.util.List;

public class BookBorRetDaoImpl extends BaseDaoImpl<BookBorRet>
  implements BookBorRetDao
{
  public BookBorRetDaoImpl()
  {
    super(BookBorRet.class);
  }

  public BookBorRet getByBookSnId(Long paramLong)
  {
    String str = "from BookBorRet bookBorRet where bookBorRet.bookSn.bookSnId=?";
    Object[] arrayOfObject = { paramLong };
    return (BookBorRet)findByHql(str, arrayOfObject).get(0);
  }

  public List<BookBorRet> getBorrowInfo(PagingBean paramPagingBean)
  {
    String str = "select bookBorRet from BookBorRet bookBorRet,BookSn bookSn where bookBorRet.bookSn.bookSnId=bookSn.bookSnId and bookSn.status=1";
    return findByHql(str, null, paramPagingBean);
  }

  public List<BookBorRet> getReturnInfo(PagingBean paramPagingBean)
  {
    String str = "select bookBorRet from BookBorRet bookBorRet,BookSn bookSn where bookBorRet.bookSn.bookSnId=bookSn.bookSnId and bookSn.status=0";
    return findByHql(str, null, paramPagingBean);
  }

  public Long getBookBorRetId(Long paramLong)
  {
    String str = "from BookBorRet vo where vo.bookSn.bookSnId=?";
    Object[] arrayOfObject = { paramLong };
    List localList = findByHql(str, arrayOfObject);
    if (localList.size() == 1)
      return ((BookBorRet)localList.get(0)).getRecordId();
    return null;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.impl.BookBorRetDaoImpl
 * JD-Core Version:    0.6.0
 */