package com.htsoft.oa.dao.document;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.document.PaintTemplate;
import java.util.List;

public abstract interface PaintTemplateDao extends BaseDao<PaintTemplate>
{
  public abstract List<PaintTemplate> getByKey(String paramString);

  public abstract List<PaintTemplate> getByKeyExceptId(String paramString, Long paramLong);
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.document.PaintTemplateDao
 * JD-Core Version:    0.6.0
 */