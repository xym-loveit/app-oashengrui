package com.htsoft.oa.dao.system.impl;

import com.htsoft.core.Constants;
import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.system.DepUsersDao;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.DepUsers;
import com.htsoft.oa.model.system.Department;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.logging.Log;

public class DepUsersDaoImpl extends BaseDaoImpl<DepUsers>
  implements DepUsersDao
{
  public DepUsersDaoImpl()
  {
    super(DepUsers.class);
  }

  public List<DepUsers> findByDepartment(String paramString, PagingBean paramPagingBean)
  {
    ArrayList localArrayList = new ArrayList();
    String str = new String();
    if ("0.".equals(paramString))
    {
      str = "select DISTINCT vo3 from Department vo1,DepUsers vo3,AppUser vo2 where 1=1 and vo3.appUser=vo2 and vo3.department=vo1 and vo2.delFlag = ? order by  vo3.sn,vo1.depId";
      localArrayList.add(Constants.FLAG_UNDELETED);
    }
    else
    {
      str = "select DISTINCT vo3 from Department vo1,AppUser vo2,DepUsers vo3 where 1=1 and vo3.appUser=vo2 and vo3.department=vo1 and vo1.path like ? and vo2.delFlag = ? order by  vo3.sn,vo1.depId";
      localArrayList.add(paramString + "%");
      localArrayList.add(Constants.FLAG_UNDELETED);
    }
    return findByHql(str, localArrayList.toArray(), paramPagingBean);
  }

  public List<DepUsers> search(String paramString, DepUsers paramDepUsers, PagingBean paramPagingBean)
  {
    ArrayList localArrayList = new ArrayList();
    StringBuffer localStringBuffer = new StringBuffer();
    if ("0.".equals(paramString))
    {
      localStringBuffer.append("select DISTINCT vo3 from Department vo1,DepUsers vo3,AppUser vo2 where 1=1 and vo3.appUser=vo2 and vo3.department=vo1 and vo2.delFlag = ? ");
      localArrayList.add(Constants.FLAG_UNDELETED);
    }
    else
    {
      localStringBuffer.append("select DISTINCT vo3 from Department vo1,AppUser vo2,DepUsers vo3 where 1=1 and vo3.appUser=vo2 and vo3.department=vo1 and vo1.path like ? and vo2.delFlag = ? ");
      localArrayList.add(paramString + "%");
      localArrayList.add(Constants.FLAG_UNDELETED);
    }
    if ((paramDepUsers != null) && (paramDepUsers.getAppUser() != null))
    {
      String str1 = paramDepUsers.getAppUser().getUsername();
      if ((str1 != null) && (!str1.equals("")))
      {
        localStringBuffer.append("and vo2.username like ? ");
        localArrayList.add(str1 + "%");
      }
      String str2 = paramDepUsers.getAppUser().getFullname();
      if ((str2 != null) && (!str2.equals("")))
      {
        localStringBuffer.append("and vo2.fullname like ? ");
        localArrayList.add(str2 + "%");
      }
      Short localShort = paramDepUsers.getIsMain();
      if ((localShort != null) && (!localShort.equals("")))
      {
        localStringBuffer.append("and vo3.isMain >= ? ");
        localArrayList.add(localShort);
      }
    }
    localStringBuffer.append("order by  vo3.sn,vo1.depId");
    this.logger.debug("自定义DepUserDaoImpl:" + localStringBuffer.toString());
    return findByHql(localStringBuffer.toString(), localArrayList.toArray(), paramPagingBean);
  }

  public List<DepUsers> findByUserIdDep(Long paramLong)
  {
    String str = "select d from DepUsers d where d.appUser.userId = ? order by d.sn asc";
    return findByHql(str, new Object[] { paramLong });
  }

  public Boolean existsDep(Long paramLong1, Long paramLong2)
  {
    String str = "select d from DepUsers d where d.appUser.userId = ? and d.isMain = 1 and d.depUserId not in(?) ";
    Object[] arrayOfObject = { paramLong2, paramLong1 };
    List localList = findByHql(str, arrayOfObject);
    return Boolean.valueOf((localList != null) && (localList.size() > 0));
  }

  public String add(DepUsers paramDepUsers)
  {
    String str1 = "{success:true,msg:'操作数据成功！'}";
    String str2 = "select d from DepUsers d where d.appUser.userId = ? and d.department.depId = ? ";
    Object[] arrayOfObject = { paramDepUsers.getAppUser().getUserId(), paramDepUsers.getDepartment().getDepId() };
    List localList = findByHql(str2, arrayOfObject);
    if ((localList != null) && (localList.size() > 0))
      str1 = "{failure:true,msg:'对不起，该用户[" + paramDepUsers.getAppUser().getUsername() + "]已经加入该部门[" + paramDepUsers.getDepartment().getDepName() + "]！'}";
    else
      save(paramDepUsers);
    return str1;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.impl.DepUsersDaoImpl
 * JD-Core Version:    0.6.0
 */