package com.htsoft.oa.dao.admin;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.admin.InStock;

public abstract interface InStockDao extends BaseDao<InStock>
{
  public abstract Integer findInCountByBuyId(Long paramLong);
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.InStockDao
 * JD-Core Version:    0.6.0
 */