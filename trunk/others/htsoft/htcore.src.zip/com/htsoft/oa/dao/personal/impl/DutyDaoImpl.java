package com.htsoft.oa.dao.personal.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.personal.DutyDao;
import com.htsoft.oa.model.personal.Duty;
import java.util.Date;
import java.util.List;

public class DutyDaoImpl extends BaseDaoImpl<Duty>
  implements DutyDao
{
  public DutyDaoImpl()
  {
    super(Duty.class);
  }

  public List<Duty> getUserDutyByTime(Long paramLong, Date paramDate1, Date paramDate2)
  {
    String str = "from Duty dy where dy.appUser.userId=? and ((dy.startTime<=? and dy.endTime>=?) or (dy.startTime<=? and dy.endTime>=?))";
    return findByHql(str, new Object[] { paramLong, paramDate1, paramDate1, paramDate2, paramDate2 });
  }

  public List<Duty> getCurUserDuty(Long paramLong)
  {
    String str = "from Duty dy where dy.appUser.userId=? and dy.startTime<=? and dy.endTime>=?";
    Date localDate = new Date();
    return findByHql(str, new Object[] { paramLong, localDate, localDate });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.personal.impl.DutyDaoImpl
 * JD-Core Version:    0.6.0
 */