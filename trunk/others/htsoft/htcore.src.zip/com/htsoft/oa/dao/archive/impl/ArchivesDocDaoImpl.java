package com.htsoft.oa.dao.archive.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.archive.ArchivesDocDao;
import com.htsoft.oa.model.archive.ArchivesDoc;
import java.util.List;

public class ArchivesDocDaoImpl extends BaseDaoImpl<ArchivesDoc>
  implements ArchivesDocDao
{
  public ArchivesDocDaoImpl()
  {
    super(ArchivesDoc.class);
  }

  public List<ArchivesDoc> findByAid(Long paramLong)
  {
    String str = "from ArchivesDoc vo where vo.archives.archivesId=?";
    Object[] arrayOfObject = { paramLong };
    return findByHql(str, arrayOfObject);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.archive.impl.ArchivesDocDaoImpl
 * JD-Core Version:    0.6.0
 */