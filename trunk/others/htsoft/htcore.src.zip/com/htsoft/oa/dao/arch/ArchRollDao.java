package com.htsoft.oa.dao.arch;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.arch.ArchRoll;

public abstract interface ArchRollDao extends BaseDao<ArchRoll>
{
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.arch.ArchRollDao
 * JD-Core Version:    0.6.0
 */