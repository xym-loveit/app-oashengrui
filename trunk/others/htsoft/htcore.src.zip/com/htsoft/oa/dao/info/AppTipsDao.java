package com.htsoft.oa.dao.info;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.info.AppTips;
import java.util.List;

public abstract interface AppTipsDao extends BaseDao<AppTips>
{
  public abstract List<AppTips> findByName(String paramString);
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.info.AppTipsDao
 * JD-Core Version:    0.6.0
 */