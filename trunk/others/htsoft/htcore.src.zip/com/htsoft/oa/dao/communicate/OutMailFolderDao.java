package com.htsoft.oa.dao.communicate;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.communicate.OutMailFolder;
import java.util.List;

public abstract interface OutMailFolderDao extends BaseDao<OutMailFolder>
{
  public abstract List<OutMailFolder> getAllUserFolderByParentId(Long paramLong1, Long paramLong2);

  public abstract List<OutMailFolder> getUserFolderByParentId(Long paramLong1, Long paramLong2);

  public abstract List<OutMailFolder> getFolderLikePath(String paramString);
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.communicate.OutMailFolderDao
 * JD-Core Version:    0.6.0
 */