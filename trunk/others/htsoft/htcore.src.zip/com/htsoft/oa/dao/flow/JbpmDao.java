package com.htsoft.oa.dao.flow;

public abstract interface JbpmDao
{
  public abstract String getDefXmlByDeployId(String paramString);

  public abstract void wirteDefXml(String paramString1, String paramString2);
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.JbpmDao
 * JD-Core Version:    0.6.0
 */