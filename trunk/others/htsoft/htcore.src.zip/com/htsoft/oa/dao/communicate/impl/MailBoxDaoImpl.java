package com.htsoft.oa.dao.communicate.impl;

import com.htsoft.core.Constants;
import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.communicate.MailBoxDao;
import com.htsoft.oa.model.communicate.MailBox;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class MailBoxDaoImpl extends BaseDaoImpl<MailBox>
  implements MailBoxDao
{
  public MailBoxDaoImpl()
  {
    super(MailBox.class);
  }

  public Long CountByFolderId(Long paramLong)
  {
    String str = "select count(*) from MailBox where folderId =" + paramLong;
    Query localQuery = getSession().createQuery(str);
    return (Long)getHibernateTemplate().find(str).get(0);
  }

  public List<MailBox> findByFolderId(Long paramLong)
  {
    String str = "from MailBox where folderId = ?";
    return findByHql(str, new Object[] { paramLong });
  }

  public List<MailBox> findBySearch(String paramString, PagingBean paramPagingBean)
  {
    ArrayList localArrayList = new ArrayList();
    StringBuffer localStringBuffer = new StringBuffer("from MailBox mb where mb.delFlag = ? and mb.appUser.userId =?");
    localArrayList.add(Constants.FLAG_UNDELETED);
    localArrayList.add(ContextUtil.getCurrentUserId());
    if (StringUtils.isNotEmpty(paramString))
    {
      localStringBuffer.append(" and (mb.mail.subject like ? or mb.mail.content like ?)");
      localArrayList.add("%" + paramString + "%");
      localArrayList.add("%" + paramString + "%");
    }
    localStringBuffer.append(" order by mb.sendTime desc");
    return findByHql(localStringBuffer.toString(), localArrayList.toArray(), paramPagingBean);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.communicate.impl.MailBoxDaoImpl
 * JD-Core Version:    0.6.0
 */