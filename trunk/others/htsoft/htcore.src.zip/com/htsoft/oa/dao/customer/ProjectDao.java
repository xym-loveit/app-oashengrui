package com.htsoft.oa.dao.customer;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.customer.Project;

public abstract interface ProjectDao extends BaseDao<Project>
{
  public abstract boolean checkProjectNo(String paramString);
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.customer.ProjectDao
 * JD-Core Version:    0.6.0
 */