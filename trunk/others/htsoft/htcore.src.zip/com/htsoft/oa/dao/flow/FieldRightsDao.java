package com.htsoft.oa.dao.flow;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.flow.FieldRights;
import java.util.List;

public abstract interface FieldRightsDao extends BaseDao<FieldRights>
{
  public abstract List<FieldRights> getByMappingFieldTaskName(Long paramLong1, Long paramLong2, String paramString);

  public abstract List<FieldRights> getByMappingIdAndTaskName(Long paramLong, String paramString);

  public abstract List<FieldRights> getByMappingId(Long paramLong);
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.FieldRightsDao
 * JD-Core Version:    0.6.0
 */