package com.htsoft.oa.dao.flow.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.flow.ProDefRightsDao;
import com.htsoft.oa.model.flow.ProDefRights;
import java.util.List;

public class ProDefRightsDaoImpl extends BaseDaoImpl<ProDefRights>
  implements ProDefRightsDao
{
  public ProDefRightsDaoImpl()
  {
    super(ProDefRights.class);
  }

  public ProDefRights findByDefId(Long paramLong)
  {
    String str = "from ProDefRights pd where pd.proDefinition.defId = ?";
    List localList = findByHql(str, new Object[] { paramLong });
    if (localList.size() > 0)
      return (ProDefRights)localList.get(0);
    return new ProDefRights();
  }

  public ProDefRights findByTypeId(Long paramLong)
  {
    String str = "from ProDefRights pd where pd.globalType.proTypeId = ?";
    List localList = findByHql(str, new Object[] { paramLong });
    if (localList.size() > 0)
      return (ProDefRights)localList.get(0);
    return new ProDefRights();
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.impl.ProDefRightsDaoImpl
 * JD-Core Version:    0.6.0
 */