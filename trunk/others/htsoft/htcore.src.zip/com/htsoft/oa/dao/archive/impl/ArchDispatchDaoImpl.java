package com.htsoft.oa.dao.archive.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.archive.ArchDispatchDao;
import com.htsoft.oa.model.archive.ArchDispatch;
import com.htsoft.oa.model.system.AppRole;
import com.htsoft.oa.model.system.AppUser;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class ArchDispatchDaoImpl extends BaseDaoImpl<ArchDispatch>
  implements ArchDispatchDao
{
  public ArchDispatchDaoImpl()
  {
    super(ArchDispatch.class);
  }

  public List<ArchDispatch> findByUser(AppUser paramAppUser, PagingBean paramPagingBean)
  {
    Iterator localIterator = paramAppUser.getRoles().iterator();
    StringBuffer localStringBuffer1 = new StringBuffer();
    while (localIterator.hasNext())
    {
      if (localStringBuffer1.length() > 0)
        localStringBuffer1.append(",");
      localStringBuffer1.append(((AppRole)localIterator.next()).getRoleId().toString());
    }
    StringBuffer localStringBuffer2 = new StringBuffer("from ArchDispatch vo where vo.archUserType=2 and vo.isRead=0 and (vo.userId=?");
    if (localStringBuffer1.length() > 0)
      localStringBuffer2.append(" or vo.disRoleId in (" + localStringBuffer1 + ")");
    localStringBuffer2.append(") order by vo.dispatchId desc");
    Object[] arrayOfObject = { paramAppUser.getUserId() };
    return findByHql(localStringBuffer2.toString(), arrayOfObject, paramPagingBean);
  }

  public List<ArchDispatch> findRecordByArc(Long paramLong)
  {
    String str = "from ArchDispatch vo where (vo.archUserType=0 or vo.archUserType=1) and vo.archives.archivesId=?";
    Object[] arrayOfObject = { paramLong };
    return findByHql(str, arrayOfObject);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.archive.impl.ArchDispatchDaoImpl
 * JD-Core Version:    0.6.0
 */