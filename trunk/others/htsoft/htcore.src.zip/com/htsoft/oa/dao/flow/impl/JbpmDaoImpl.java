package com.htsoft.oa.dao.flow.impl;

import com.htsoft.oa.dao.flow.JbpmDao;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.annotation.Resource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.AbstractLobCreatingPreparedStatementCallback;
import org.springframework.jdbc.core.support.AbstractLobStreamingResultSetExtractor;
import org.springframework.jdbc.support.lob.DefaultLobHandler;
import org.springframework.jdbc.support.lob.LobCreator;
import org.springframework.jdbc.support.lob.LobHandler;
import org.springframework.util.FileCopyUtils;

public class JbpmDaoImpl
  implements JbpmDao
{
  private Log logger = LogFactory.getLog(JbpmDaoImpl.class);

  @Resource
  private JdbcTemplate jdbcTemplate;

  public String getDefXmlByDeployId(String paramString)
  {
    String str1 = "select * from JBPM4_LOB where NAME_= ? and DEPLOYMENT_= ? ";
    DefaultLobHandler localDefaultLobHandler = new DefaultLobHandler();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    String str2 = null;
    try
    {
      this.jdbcTemplate.query(str1, new Object[] { "process.jpdl.xml", paramString }, new AbstractLobStreamingResultSetExtractor(localDefaultLobHandler, localByteArrayOutputStream)
      {
        public void streamData(ResultSet paramResultSet)
          throws SQLException, IOException
        {
          FileCopyUtils.copy(this.val$lobHandler.getBlobAsBinaryStream(paramResultSet, "BLOB_VALUE_"), this.val$contentOs);
        }
      });
      str2 = new String(localByteArrayOutputStream.toByteArray(), "UTF-8");
    }
    catch (Exception localException)
    {
      this.logger.debug(localException.getMessage());
    }
    return str2;
  }

  public void wirteDefXml(String paramString1, String paramString2)
  {
    try
    {
      DefaultLobHandler localDefaultLobHandler = new DefaultLobHandler();
      byte[] arrayOfByte = paramString2.getBytes("UTF-8");
      String str = "update JBPM4_LOB set BLOB_VALUE_=? where NAME_= ? and DEPLOYMENT_= ? ";
      this.jdbcTemplate.execute(str, new AbstractLobCreatingPreparedStatementCallback(localDefaultLobHandler, arrayOfByte, paramString1)
      {
        protected void setValues(PreparedStatement paramPreparedStatement, LobCreator paramLobCreator)
          throws SQLException, DataAccessException
        {
          paramLobCreator.setBlobAsBytes(paramPreparedStatement, 1, this.val$btyesXml);
          paramPreparedStatement.setString(2, "process.jpdl.xml");
          paramPreparedStatement.setString(3, this.val$deployId);
        }
      });
    }
    catch (Exception localException)
    {
    }
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.impl.JbpmDaoImpl
 * JD-Core Version:    0.6.0
 */