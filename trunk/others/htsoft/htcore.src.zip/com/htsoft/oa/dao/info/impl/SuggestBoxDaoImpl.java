package com.htsoft.oa.dao.info.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.info.SuggestBoxDao;
import com.htsoft.oa.model.info.SuggestBox;

public class SuggestBoxDaoImpl extends BaseDaoImpl<SuggestBox>
  implements SuggestBoxDao
{
  public SuggestBoxDaoImpl()
  {
    super(SuggestBox.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.info.impl.SuggestBoxDaoImpl
 * JD-Core Version:    0.6.0
 */