package com.htsoft.oa.dao.flow.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.flow.ProHandleCompDao;
import com.htsoft.oa.model.flow.ProHandleComp;
import java.util.List;

public class ProHandleCompDaoImpl extends BaseDaoImpl<ProHandleComp>
  implements ProHandleCompDao
{
  public ProHandleCompDaoImpl()
  {
    super(ProHandleComp.class);
  }

  public List<ProHandleComp> getByDeployIdActivityName(String paramString1, String paramString2)
  {
    String str = "from ProHandleComp phc where phc.deployId=? and phc.activityName=?";
    return findByHql(str, new Object[] { paramString1, paramString2 });
  }

  public List<ProHandleComp> getByDeployIdActivityNameHandleType(String paramString1, String paramString2, Short paramShort)
  {
    String str = "from ProHandleComp phc where phc.deployId=? and phc.activityName=? and phc.handleType=?";
    return findByHql(str, new Object[] { paramString1, paramString2, paramShort });
  }

  public ProHandleComp getProHandleComp(String paramString1, String paramString2, String paramString3)
  {
    String str = "from ProHandleComp phc where phc.deployId=? and phc.activityName=? and eventName=? ";
    return (ProHandleComp)findUnique(str, new Object[] { paramString1, paramString2, paramString3 });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.impl.ProHandleCompDaoImpl
 * JD-Core Version:    0.6.0
 */