package com.htsoft.oa.dao.communicate.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.communicate.MailFolderDao;
import com.htsoft.oa.model.communicate.MailFolder;
import java.util.List;

public class MailFolderDaoImpl extends BaseDaoImpl<MailFolder>
  implements MailFolderDao
{
  public MailFolderDaoImpl()
  {
    super(MailFolder.class);
  }

  public List<MailFolder> getUserFolderByParentId(Long paramLong1, Long paramLong2)
  {
    String str = "from MailFolder mf where mf.appUser.userId=? and parentId=?";
    return findByHql(str, new Object[] { paramLong1, paramLong2 });
  }

  public List<MailFolder> getAllUserFolderByParentId(Long paramLong1, Long paramLong2)
  {
    String str = "from MailFolder mf where mf.appUser.userId=? and parentId=? or userId is null";
    return findByHql(str, new Object[] { paramLong1, paramLong2 });
  }

  public List<MailFolder> getFolderLikePath(String paramString)
  {
    String str = "from MailFolder mf where mf.path like ?";
    return findByHql(str, new Object[] { paramString + '%' });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.communicate.impl.MailFolderDaoImpl
 * JD-Core Version:    0.6.0
 */