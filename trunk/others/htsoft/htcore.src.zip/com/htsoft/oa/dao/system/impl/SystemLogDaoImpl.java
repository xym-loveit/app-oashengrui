package com.htsoft.oa.dao.system.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.system.SystemLogDao;
import com.htsoft.oa.model.system.SystemLog;

public class SystemLogDaoImpl extends BaseDaoImpl<SystemLog>
  implements SystemLogDao
{
  public SystemLogDaoImpl()
  {
    super(SystemLog.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.impl.SystemLogDaoImpl
 * JD-Core Version:    0.6.0
 */