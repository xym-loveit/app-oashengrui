package com.htsoft.oa.dao.archive.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.archive.DocHistoryDao;
import com.htsoft.oa.model.archive.DocHistory;

public class DocHistoryDaoImpl extends BaseDaoImpl<DocHistory>
  implements DocHistoryDao
{
  public DocHistoryDaoImpl()
  {
    super(DocHistory.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.archive.impl.DocHistoryDaoImpl
 * JD-Core Version:    0.6.0
 */