package com.htsoft.oa.dao.system;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.system.TypeKey;

public abstract interface TypeKeyDao extends BaseDao<TypeKey>
{
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.TypeKeyDao
 * JD-Core Version:    0.6.0
 */