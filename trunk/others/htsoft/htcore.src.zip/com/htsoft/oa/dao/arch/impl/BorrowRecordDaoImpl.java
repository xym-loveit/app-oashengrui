package com.htsoft.oa.dao.arch.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.arch.BorrowRecordDao;
import com.htsoft.oa.model.arch.BorrowRecord;

public class BorrowRecordDaoImpl extends BaseDaoImpl<BorrowRecord>
  implements BorrowRecordDao
{
  public BorrowRecordDaoImpl()
  {
    super(BorrowRecord.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.arch.impl.BorrowRecordDaoImpl
 * JD-Core Version:    0.6.0
 */