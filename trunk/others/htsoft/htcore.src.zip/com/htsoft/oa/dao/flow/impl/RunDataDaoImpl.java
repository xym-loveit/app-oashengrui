package com.htsoft.oa.dao.flow.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.flow.RunDataDao;
import com.htsoft.oa.model.flow.RunData;
import java.util.List;

public class RunDataDaoImpl extends BaseDaoImpl<RunData>
  implements RunDataDao
{
  public RunDataDaoImpl()
  {
    super(RunData.class);
  }

  public RunData getByRunIdFieldName(Long paramLong, String paramString)
  {
    String str = "from RunData rd where rd.processRun.runId=? and rd.fieldName=?";
    return (RunData)findUnique(str, new Object[] { paramLong, paramString });
  }

  public List<RunData> getByRunId(Long paramLong)
  {
    String str = "from RunData rd where rd.processRun.runId=?";
    return findByHql(str, new Object[] { paramLong });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.impl.RunDataDaoImpl
 * JD-Core Version:    0.6.0
 */