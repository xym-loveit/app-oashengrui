package com.htsoft.oa.dao.communicate.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.communicate.SmsHistoryDao;
import com.htsoft.oa.model.communicate.SmsHistory;

public class SmsHistoryDaoImpl extends BaseDaoImpl<SmsHistory>
  implements SmsHistoryDao
{
  public SmsHistoryDaoImpl()
  {
    super(SmsHistory.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.communicate.impl.SmsHistoryDaoImpl
 * JD-Core Version:    0.6.0
 */