package com.htsoft.oa.dao.personal.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.personal.ErrandsRegisterDao;
import com.htsoft.oa.model.personal.ErrandsRegister;

public class ErrandsRegisterDaoImpl extends BaseDaoImpl<ErrandsRegister>
  implements ErrandsRegisterDao
{
  public ErrandsRegisterDaoImpl()
  {
    super(ErrandsRegister.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.personal.impl.ErrandsRegisterDaoImpl
 * JD-Core Version:    0.6.0
 */