package com.htsoft.oa.dao.flow.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.flow.FormFieldDao;
import com.htsoft.oa.model.flow.FormField;
import java.util.List;

public class FormFieldDaoImpl extends BaseDaoImpl<FormField>
  implements FormFieldDao
{
  public FormFieldDaoImpl()
  {
    super(FormField.class);
  }

  public FormField find(Long paramLong, Short paramShort)
  {
    String str = "from FormField ff where ff.formTable.tableId=? and ff.isFlowTitle=? ";
    return (FormField)findUnique(str, new Object[] { paramLong, paramShort });
  }

  public List<FormField> getByForeignTableAndKey(String paramString1, String paramString2)
  {
    String str = "select formField from FormField formField where formField.foreignTable=? and formField.foreignKey=?";
    Object[] arrayOfObject = { paramString1, paramString2 };
    List localList = findByHql(str, arrayOfObject);
    return localList;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.impl.FormFieldDaoImpl
 * JD-Core Version:    0.6.0
 */