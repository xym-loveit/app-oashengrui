package com.htsoft.oa.dao.admin.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.admin.OfficeGoodsDao;
import com.htsoft.oa.model.admin.OfficeGoods;
import java.util.List;

public class OfficeGoodsDaoImpl extends BaseDaoImpl<OfficeGoods>
  implements OfficeGoodsDao
{
  public OfficeGoodsDaoImpl()
  {
    super(OfficeGoods.class);
  }

  public List<OfficeGoods> findByWarm()
  {
    String str = "from OfficeGoods vo where ((vo.stockCounts<=vo.warnCounts and vo.isWarning=1) or (vo.stockCounts<=0))";
    return findByHql(str);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.impl.OfficeGoodsDaoImpl
 * JD-Core Version:    0.6.0
 */