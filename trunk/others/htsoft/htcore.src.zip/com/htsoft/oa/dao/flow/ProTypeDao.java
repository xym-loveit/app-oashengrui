package com.htsoft.oa.dao.flow;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.flow.ProType;

public abstract interface ProTypeDao extends BaseDao<ProType>
{
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.ProTypeDao
 * JD-Core Version:    0.6.0
 */