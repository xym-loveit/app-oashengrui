package com.htsoft.oa.dao.communicate.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.communicate.PhoneBookDao;
import com.htsoft.oa.model.communicate.PhoneBook;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.StringUtils;

public class PhoneBookDaoImpl extends BaseDaoImpl<PhoneBook>
  implements PhoneBookDao
{
  public PhoneBookDaoImpl()
  {
    super(PhoneBook.class);
  }

  public List<PhoneBook> sharedPhoneBooks(String paramString1, String paramString2, PagingBean paramPagingBean)
  {
    StringBuffer localStringBuffer = new StringBuffer("select pb from PhoneBook pb,PhoneGroup pg where pb.phoneGroup=pg and (pg.isShared=1 or pb.isShared=1)");
    ArrayList localArrayList = new ArrayList();
    if (StringUtils.isNotEmpty(paramString1))
    {
      localStringBuffer.append(" and pb.fullname like ?");
      localArrayList.add("%" + paramString1 + "%");
    }
    if (StringUtils.isNotEmpty(paramString2))
    {
      localStringBuffer.append(" and pb.appUser.fullname like ?");
      localArrayList.add("%" + paramString2 + "%");
    }
    return findByHql(localStringBuffer.toString(), localArrayList.toArray(), paramPagingBean);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.communicate.impl.PhoneBookDaoImpl
 * JD-Core Version:    0.6.0
 */