package com.htsoft.oa.dao.customer.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.customer.CusLinkmanDao;
import com.htsoft.oa.model.customer.CusLinkman;
import java.sql.SQLException;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class CusLinkmanDaoImpl extends BaseDaoImpl<CusLinkman>
  implements CusLinkmanDao
{
  public CusLinkmanDaoImpl()
  {
    super(CusLinkman.class);
  }

  public boolean checkMainCusLinkman(Long paramLong1, Long paramLong2)
  {
    StringBuffer localStringBuffer = new StringBuffer("select count(*) from CusLinkman  cl where cl.isPrimary = 1 and cl.customer.customerId =? ");
    if (paramLong2 != null)
      localStringBuffer.append("and cl.linkmanId != ? ");
    Long localLong = (Long)getHibernateTemplate().execute(new HibernateCallback(localStringBuffer, paramLong1, paramLong2)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Query localQuery = paramSession.createQuery(this.val$hql.toString());
        localQuery.setLong(0, this.val$customerId.longValue());
        if (this.val$linkmanId != null)
          localQuery.setLong(1, this.val$linkmanId.longValue());
        return localQuery.uniqueResult();
      }
    });
    return localLong.longValue() == 0L;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.customer.impl.CusLinkmanDaoImpl
 * JD-Core Version:    0.6.0
 */