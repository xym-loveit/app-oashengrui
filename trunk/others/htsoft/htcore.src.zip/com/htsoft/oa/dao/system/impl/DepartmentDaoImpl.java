package com.htsoft.oa.dao.system.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.system.DepartmentDao;
import com.htsoft.oa.model.system.Department;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.StringUtils;

public class DepartmentDaoImpl extends BaseDaoImpl<Department>
  implements DepartmentDao
{
  public DepartmentDaoImpl()
  {
    super(Department.class);
  }

  public List<Department> findByParentId(Long paramLong)
  {
    Object[] arrayOfObject = { paramLong };
    return findByHql("from Department d where d.parentId=?", arrayOfObject);
  }

  public List<Department> findByVo(Department paramDepartment, PagingBean paramPagingBean)
  {
    ArrayList localArrayList = new ArrayList();
    String str = "from Department vo where 1=1";
    if (StringUtils.isNotEmpty(paramDepartment.getDepName()))
    {
      str = str + " and vo.depName like ?";
      localArrayList.add("%" + paramDepartment.getDepName() + "%");
    }
    if (StringUtils.isNotEmpty(paramDepartment.getDepDesc()))
    {
      str = str + " and vo.depDesc=?";
      localArrayList.add("%" + paramDepartment.getDepDesc() + "%");
    }
    return findByHql(str, localArrayList.toArray(), paramPagingBean);
  }

  public List<Department> findByDepName(String paramString)
  {
    String str = "from Department vo where vo.depName=?";
    String[] arrayOfString = { paramString };
    return findByHql(str, arrayOfString);
  }

  public List<Department> findByPath(String paramString)
  {
    String str = "from Department vo where vo.path like ?";
    String[] arrayOfString = { paramString + "%" };
    return findByHql(str, arrayOfString);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.impl.DepartmentDaoImpl
 * JD-Core Version:    0.6.0
 */