package com.htsoft.oa.dao.system.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.system.DiaryDao;
import com.htsoft.oa.model.system.Diary;
import java.util.List;

public class DiaryDaoImpl extends BaseDaoImpl<Diary>
  implements DiaryDao
{
  public DiaryDaoImpl()
  {
    super(Diary.class);
  }

  public List<Diary> getSubDiary(String paramString, PagingBean paramPagingBean)
  {
    String str = "from Diary vo where vo.appUser.userId in (" + paramString + ") and vo.diaryType=1";
    return findByHql(str, null, paramPagingBean);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.impl.DiaryDaoImpl
 * JD-Core Version:    0.6.0
 */