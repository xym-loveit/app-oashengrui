package com.htsoft.oa.dao.flow.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.flow.ProcessModuleDao;
import com.htsoft.oa.model.flow.ProcessModule;
import java.util.List;

public class ProcessModuleDaoImpl extends BaseDaoImpl<ProcessModule>
  implements ProcessModuleDao
{
  public ProcessModuleDaoImpl()
  {
    super(ProcessModule.class);
  }

  public ProcessModule getByKey(String paramString)
  {
    String str = "from ProcessModule pm where pm.modulekey=?";
    List localList = findByHql(str, new Object[] { paramString });
    if (localList.size() > 0)
      return (ProcessModule)localList.get(0);
    return null;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.impl.ProcessModuleDaoImpl
 * JD-Core Version:    0.6.0
 */