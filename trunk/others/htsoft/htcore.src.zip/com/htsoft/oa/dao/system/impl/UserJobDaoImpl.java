package com.htsoft.oa.dao.system.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.system.UserJobDao;
import com.htsoft.oa.model.hrm.Job;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.UserJob;
import java.util.List;
import org.apache.commons.logging.Log;

public class UserJobDaoImpl extends BaseDaoImpl<UserJob>
  implements UserJobDao
{
  public UserJobDaoImpl()
  {
    super(UserJob.class);
  }

  public Boolean IsExistsjob(Long paramLong1, Long paramLong2)
  {
    StringBuffer localStringBuffer = new StringBuffer("select u from UserJob u where u.isMain = 1 and u.appUser.userId = ? ");
    if ((paramLong1 != null) && (!paramLong1.equals("")))
      localStringBuffer.append("and u.userJobId not in(" + paramLong1 + ") ");
    Object[] arrayOfObject = { paramLong2 };
    List localList = findByHql(localStringBuffer.toString(), arrayOfObject);
    this.logger.debug("自定义[UserJobImpl]:" + localStringBuffer);
    return Boolean.valueOf((localList != null) && (localList.size() > 0));
  }

  public List<UserJob> findByUserIdJobs(Long paramLong)
  {
    String str = "select u from UserJob u where u.appUser.userId = ? ";
    Object[] arrayOfObject = { paramLong };
    return findByHql(str, arrayOfObject);
  }

  public String add(UserJob paramUserJob)
  {
    String str1 = "{success:true,msg:'数据操作成功！'}";
    String str2 = "select u from UserJob u where u.appUser.userId = ? and u.job.jobId = ? ";
    Object[] arrayOfObject = { paramUserJob.getAppUser().getUserId(), paramUserJob.getJob().getJobId() };
    List localList = findByHql(str2, arrayOfObject);
    if ((localList != null) && (localList.size() > 0))
      str1 = "{failure:true,msg:'对不起，该用户[" + paramUserJob.getAppUser().getUsername() + "]已经添加了该职位[" + paramUserJob.getJob().getJobName() + "]！'}";
    else
      save(paramUserJob);
    return str1;
  }

  public List<Long> getUserIdsByJobId(Long paramLong)
  {
    String str = "select u.appUser.userId from UserJob u where u.job.jobId=?";
    List localList = findByHql(str, new Object[] { paramLong });
    return localList;
  }

  public List<AppUser> getUsersByJobId(Long paramLong)
  {
    String str = "select u.appUser from UserJob u where u.job.jobId=?";
    List localList = findByHql(str, new Object[] { paramLong });
    return localList;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.impl.UserJobDaoImpl
 * JD-Core Version:    0.6.0
 */