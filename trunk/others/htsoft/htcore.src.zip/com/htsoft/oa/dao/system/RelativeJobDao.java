package com.htsoft.oa.dao.system;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.system.RelativeJob;
import java.util.List;

public abstract interface RelativeJobDao extends BaseDao<RelativeJob>
{
  public abstract List<RelativeJob> findByParentId(Long paramLong);
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.RelativeJobDao
 * JD-Core Version:    0.6.0
 */