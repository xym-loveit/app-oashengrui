package com.htsoft.oa.dao.archive.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.archive.ArchHastenDao;
import com.htsoft.oa.model.archive.ArchHasten;
import java.util.Date;
import java.util.List;

public class ArchHastenDaoImpl extends BaseDaoImpl<ArchHasten>
  implements ArchHastenDao
{
  public ArchHastenDaoImpl()
  {
    super(ArchHasten.class);
  }

  public Date getLeastRecordByUser(Long paramLong)
  {
    String str = "from ArchHasten vo where vo.archives.archivesId=? order by vo.createtime desc";
    List localList = findByHql(str, new Object[] { paramLong });
    if (localList.size() > 0)
      return ((ArchHasten)localList.get(0)).getCreatetime();
    return null;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.archive.impl.ArchHastenDaoImpl
 * JD-Core Version:    0.6.0
 */