package com.htsoft.oa.dao.hrm.impl;

import com.htsoft.core.Constants;
import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.hrm.StandSalaryDao;
import com.htsoft.oa.model.hrm.StandSalary;
import java.sql.SQLException;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class StandSalaryDaoImpl extends BaseDaoImpl<StandSalary>
  implements StandSalaryDao
{
  public StandSalaryDaoImpl()
  {
    super(StandSalary.class);
  }

  public boolean checkStandNo(String paramString)
  {
    Long localLong = (Long)getHibernateTemplate().execute(new HibernateCallback(paramString)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Query localQuery = paramSession.createQuery("select count(*) from StandSalary ss where ss.standardNo = ?");
        localQuery.setString(0, this.val$standardNo);
        return localQuery.uniqueResult();
      }
    });
    return localLong.longValue() == 0L;
  }

  public List<StandSalary> findByPassCheck()
  {
    String str = "from StandSalary vo where vo.status=?";
    Object[] arrayOfObject = { Constants.FLAG_PASS };
    return findByHql(str, arrayOfObject);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.hrm.impl.StandSalaryDaoImpl
 * JD-Core Version:    0.6.0
 */