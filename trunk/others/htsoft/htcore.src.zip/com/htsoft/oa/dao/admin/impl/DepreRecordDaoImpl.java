package com.htsoft.oa.dao.admin.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.admin.DepreRecordDao;
import com.htsoft.oa.model.admin.DepreRecord;
import java.util.Date;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;

public class DepreRecordDaoImpl extends BaseDaoImpl<DepreRecord>
  implements DepreRecordDao
{
  public DepreRecordDaoImpl()
  {
    super(DepreRecord.class);
  }

  public Date findMaxDate(Long paramLong)
  {
    String str = "select max(vo.calTime) from DepreRecord vo where vo.fixedAssets.assetsId=?";
    Query localQuery = getSession().createQuery(str);
    localQuery.setLong(0, paramLong.longValue());
    Date localDate = (Date)localQuery.list().get(0);
    return localDate;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.impl.DepreRecordDaoImpl
 * JD-Core Version:    0.6.0
 */