package com.htsoft.oa.dao.task.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.task.PlanTypeDao;
import com.htsoft.oa.model.task.PlanType;

public class PlanTypeDaoImpl extends BaseDaoImpl<PlanType>
  implements PlanTypeDao
{
  public PlanTypeDaoImpl()
  {
    super(PlanType.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.task.impl.PlanTypeDaoImpl
 * JD-Core Version:    0.6.0
 */