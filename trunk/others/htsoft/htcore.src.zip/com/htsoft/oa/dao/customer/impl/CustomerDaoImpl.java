package com.htsoft.oa.dao.customer.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.customer.CustomerDao;
import com.htsoft.oa.model.customer.Customer;
import java.sql.SQLException;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class CustomerDaoImpl extends BaseDaoImpl<Customer>
  implements CustomerDao
{
  public CustomerDaoImpl()
  {
    super(Customer.class);
  }

  public boolean checkCustomerNo(String paramString)
  {
    Long localLong = (Long)getHibernateTemplate().execute(new HibernateCallback(paramString)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Query localQuery = paramSession.createQuery("select count(*) from Customer c where c.customerNo = ?");
        localQuery.setString(0, this.val$customerNo);
        return localQuery.uniqueResult();
      }
    });
    return localLong.longValue() == 0L;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.customer.impl.CustomerDaoImpl
 * JD-Core Version:    0.6.0
 */