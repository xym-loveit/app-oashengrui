package com.htsoft.oa.dao.admin.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.admin.BookDao;
import com.htsoft.oa.model.admin.Book;
import java.util.List;

public class BookDaoImpl extends BaseDaoImpl<Book>
  implements BookDao
{
  public BookDaoImpl()
  {
    super(Book.class);
  }

  public List<Book> findByTypeId(Long paramLong, PagingBean paramPagingBean)
  {
    Object[] arrayOfObject = { paramLong };
    return findByHql("from Book b where b.bookType.typeId=?", arrayOfObject, paramPagingBean);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.impl.BookDaoImpl
 * JD-Core Version:    0.6.0
 */