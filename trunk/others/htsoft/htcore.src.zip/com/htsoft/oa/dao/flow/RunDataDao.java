package com.htsoft.oa.dao.flow;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.flow.RunData;
import java.util.List;

public abstract interface RunDataDao extends BaseDao<RunData>
{
  public abstract RunData getByRunIdFieldName(Long paramLong, String paramString);

  public abstract List<RunData> getByRunId(Long paramLong);
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.RunDataDao
 * JD-Core Version:    0.6.0
 */