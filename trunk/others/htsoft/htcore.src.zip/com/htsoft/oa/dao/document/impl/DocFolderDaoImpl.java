package com.htsoft.oa.dao.document.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.document.DocFolderDao;
import com.htsoft.oa.model.document.DocFolder;
import java.util.List;

public class DocFolderDaoImpl extends BaseDaoImpl<DocFolder>
  implements DocFolderDao
{
  public DocFolderDaoImpl()
  {
    super(DocFolder.class);
  }

  public List<DocFolder> getUserFolderByParentId(Long paramLong1, Long paramLong2)
  {
    String str = "from DocFolder df where df.isShared=0 and df.appUser.userId=? and parentId=?";
    return findByHql(str, new Object[] { paramLong1, paramLong2 });
  }

  public List<DocFolder> getFolderLikePath(String paramString)
  {
    String str = "from DocFolder df where df.path like ?";
    return findByHql(str, new Object[] { paramString + '%' });
  }

  public List<DocFolder> getPublicFolderByParentId(Long paramLong)
  {
    String str = "from DocFolder df where df.isShared=1 and df.parentId=? ";
    return findByHql(str, new Object[] { paramLong });
  }

  public List<DocFolder> findByParentId(Long paramLong)
  {
    String str = "from DocFolder df where df.parentId=?";
    return findByHql(str, new Object[] { paramLong });
  }

  public List<DocFolder> findByUserAndName(Long paramLong, String paramString)
  {
    String str = "from DocFolder df where df.isShared=0 and df.appUser.userId=? and df.folderName like ?";
    return findByHql(str, new Object[] { paramLong, "%" + paramString + "%" });
  }

  public List<DocFolder> getOnlineFolderByParentId(Long paramLong)
  {
    String str = "from DocFolder df where df.isShared=2 and df.parentId=? ";
    return findByHql(str, new Object[] { paramLong });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.document.impl.DocFolderDaoImpl
 * JD-Core Version:    0.6.0
 */