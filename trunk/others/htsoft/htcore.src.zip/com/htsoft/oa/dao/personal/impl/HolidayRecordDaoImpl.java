package com.htsoft.oa.dao.personal.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.personal.HolidayRecordDao;
import com.htsoft.oa.model.personal.HolidayRecord;

public class HolidayRecordDaoImpl extends BaseDaoImpl<HolidayRecord>
  implements HolidayRecordDao
{
  public HolidayRecordDaoImpl()
  {
    super(HolidayRecord.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.personal.impl.HolidayRecordDaoImpl
 * JD-Core Version:    0.6.0
 */