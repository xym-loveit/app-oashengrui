package com.htsoft.oa.dao.archive;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.archive.ArchivesDep;

public abstract interface ArchivesDepDao extends BaseDao<ArchivesDep>
{
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.archive.ArchivesDepDao
 * JD-Core Version:    0.6.0
 */