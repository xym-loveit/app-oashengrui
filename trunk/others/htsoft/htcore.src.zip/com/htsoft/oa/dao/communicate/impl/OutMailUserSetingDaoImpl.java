package com.htsoft.oa.dao.communicate.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.communicate.OutMailUserSetingDao;
import com.htsoft.oa.model.communicate.OutMailUserSeting;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class OutMailUserSetingDaoImpl extends BaseDaoImpl<OutMailUserSeting>
  implements OutMailUserSetingDao
{
  public OutMailUserSetingDaoImpl()
  {
    super(OutMailUserSeting.class);
  }

  public OutMailUserSeting getByLoginId(Long paramLong)
  {
    String str = "select a from OutMailUserSeting a where a.appUser.userId =" + paramLong;
    List localList = getHibernateTemplate().find(str);
    return (localList != null) && (localList.size() > 0) ? (OutMailUserSeting)localList.get(0) : null;
  }

  public List findByUserAll()
  {
    String str = "select au,vo from OutMailUserSeting au right join au.appUser vo where vo.delFlag = 0";
    return findByHql(str);
  }

  public List<OutMailUserSeting> findByUserAll(String paramString, PagingBean paramPagingBean)
  {
    ArrayList localArrayList = new ArrayList();
    String str = "select au from OutMailUserSeting au right join au.appUser vo where vo.delFlag = 0";
    if (StringUtils.isNotEmpty(paramString))
    {
      str = str + "and vo.fullname like ?";
      localArrayList.add("%" + paramString + "%");
    }
    return findByHql(str, localArrayList.toArray(), paramPagingBean);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.communicate.impl.OutMailUserSetingDaoImpl
 * JD-Core Version:    0.6.0
 */