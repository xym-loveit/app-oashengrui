package com.htsoft.oa.dao.arch;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.arch.RollFileList;

public abstract interface RollFileListDao extends BaseDao<RollFileList>
{
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.arch.RollFileListDao
 * JD-Core Version:    0.6.0
 */