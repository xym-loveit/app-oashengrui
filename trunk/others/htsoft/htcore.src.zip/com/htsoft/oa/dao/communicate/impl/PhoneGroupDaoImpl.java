package com.htsoft.oa.dao.communicate.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.communicate.PhoneGroupDao;
import com.htsoft.oa.model.communicate.PhoneGroup;
import java.util.List;

public class PhoneGroupDaoImpl extends BaseDaoImpl<PhoneGroup>
  implements PhoneGroupDao
{
  public PhoneGroupDaoImpl()
  {
    super(PhoneGroup.class);
  }

  public Integer findLastSn(Long paramLong)
  {
    String str = "select max(sn) from PhoneGroup vo where vo.isPublic=0 and vo.appUser.userId=?";
    Object[] arrayOfObject = { paramLong };
    List localList = findByHql(str, arrayOfObject);
    return (Integer)localList.get(0);
  }

  public PhoneGroup findBySn(Integer paramInteger, Long paramLong)
  {
    String str = "select vo from PhoneGroup vo where vo.isPublic=0 and vo.appUser.userId=? and vo.sn=?";
    Object[] arrayOfObject = { paramLong, paramInteger };
    List localList = findByHql(str, arrayOfObject);
    return (PhoneGroup)localList.get(0);
  }

  public List<PhoneGroup> findBySnUp(Integer paramInteger, Long paramLong)
  {
    String str = "from PhoneGroup vo where vo.isPublic=0 and vo.appUser.userId=? and vo.sn<?";
    Object[] arrayOfObject = { paramLong, paramInteger };
    return findByHql(str, arrayOfObject);
  }

  public List<PhoneGroup> findBySnDown(Integer paramInteger, Long paramLong)
  {
    String str = "from PhoneGroup vo where vo.isPublic=0 and vo.appUser.userId=? and vo.sn>?";
    Object[] arrayOfObject = { paramLong, paramInteger };
    return findByHql(str, arrayOfObject);
  }

  public List<PhoneGroup> getAll(Long paramLong)
  {
    String str = "from PhoneGroup vo where vo.isPublic=0 and vo.appUser.userId=? order by vo.sn asc";
    Object[] arrayOfObject = { paramLong };
    return findByHql(str, arrayOfObject);
  }

  public PhoneGroup findPublicBySn(Integer paramInteger)
  {
    String str = "select vo from PhoneGroup vo where vo.isPublic=1 and vo.sn=?";
    Object[] arrayOfObject = { paramInteger };
    List localList = findByHql(str, arrayOfObject);
    return (PhoneGroup)localList.get(0);
  }

  public List<PhoneGroup> findPublicBySnDown(Integer paramInteger)
  {
    String str = "from PhoneGroup vo where vo.isPublic=1 and vo.sn>?";
    Object[] arrayOfObject = { paramInteger };
    return findByHql(str, arrayOfObject);
  }

  public List<PhoneGroup> findPublicBySnUp(Integer paramInteger)
  {
    String str = "from PhoneGroup vo where vo.isPublic=1 and vo.sn<?";
    Object[] arrayOfObject = { paramInteger };
    return findByHql(str, arrayOfObject);
  }

  public Integer findPublicLastSn()
  {
    String str = "select max(sn) from PhoneGroup vo where vo.isPublic=1";
    List localList = findByHql(str);
    return (Integer)localList.get(0);
  }

  public List<PhoneGroup> getPublicAll()
  {
    String str = "from PhoneGroup vo where vo.isPublic=1 order by vo.sn asc";
    return findByHql(str);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.communicate.impl.PhoneGroupDaoImpl
 * JD-Core Version:    0.6.0
 */