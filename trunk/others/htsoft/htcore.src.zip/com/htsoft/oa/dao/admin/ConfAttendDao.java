package com.htsoft.oa.dao.admin;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.admin.ConfAttend;

public abstract interface ConfAttendDao extends BaseDao<ConfAttend>
{
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.ConfAttendDao
 * JD-Core Version:    0.6.0
 */