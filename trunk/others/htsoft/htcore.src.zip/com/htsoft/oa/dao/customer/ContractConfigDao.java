package com.htsoft.oa.dao.customer;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.customer.ContractConfig;

public abstract interface ContractConfigDao extends BaseDao<ContractConfig>
{
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.customer.ContractConfigDao
 * JD-Core Version:    0.6.0
 */