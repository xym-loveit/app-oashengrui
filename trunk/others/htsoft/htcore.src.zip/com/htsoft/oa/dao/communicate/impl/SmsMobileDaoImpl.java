package com.htsoft.oa.dao.communicate.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.communicate.SmsMobileDao;
import com.htsoft.oa.model.communicate.SmsMobile;
import java.util.List;

public class SmsMobileDaoImpl extends BaseDaoImpl<SmsMobile>
  implements SmsMobileDao
{
  public SmsMobileDaoImpl()
  {
    super(SmsMobile.class);
  }

  public List<SmsMobile> getNeedToSend()
  {
    String str = "from SmsMobile sm where sm.status = ? order by sm.sendTime desc";
    Object[] arrayOfObject = { SmsMobile.STATUS_NOT_SENDED };
    return findByHql(str, arrayOfObject);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.communicate.impl.SmsMobileDaoImpl
 * JD-Core Version:    0.6.0
 */