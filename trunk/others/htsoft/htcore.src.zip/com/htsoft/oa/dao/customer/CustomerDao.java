package com.htsoft.oa.dao.customer;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.customer.Customer;

public abstract interface CustomerDao extends BaseDao<Customer>
{
  public abstract boolean checkCustomerNo(String paramString);
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.customer.CustomerDao
 * JD-Core Version:    0.6.0
 */