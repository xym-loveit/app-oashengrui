package com.htsoft.oa.dao.flow.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.flow.TaskSignDataDao;
import com.htsoft.oa.model.flow.TaskSignData;
import java.util.List;

public class TaskSignDataDaoImpl extends BaseDaoImpl<TaskSignData>
  implements TaskSignDataDao
{
  public TaskSignDataDaoImpl()
  {
    super(TaskSignData.class);
  }

  public Long getVoteCounts(String paramString, Short paramShort)
  {
    String str = "select count(dataId) from TaskSignData tsd where tsd.taskId=? and tsd.isAgree=?";
    Object localObject = findUnique(str, new Object[] { paramString, paramShort });
    return new Long(localObject.toString());
  }

  public List<TaskSignData> getByTaskId(String paramString)
  {
    String str = "from TaskSignData tsd where tsd.taskId=?";
    return findByHql(str, new Object[] { paramString });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.impl.TaskSignDataDaoImpl
 * JD-Core Version:    0.6.0
 */