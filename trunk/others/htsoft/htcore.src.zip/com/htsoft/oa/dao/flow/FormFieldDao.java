package com.htsoft.oa.dao.flow;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.flow.FormField;
import java.util.List;

public abstract interface FormFieldDao extends BaseDao<FormField>
{
  public abstract FormField find(Long paramLong, Short paramShort);

  public abstract List<FormField> getByForeignTableAndKey(String paramString1, String paramString2);
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.FormFieldDao
 * JD-Core Version:    0.6.0
 */