package com.htsoft.oa.dao.system.impl;

import com.htsoft.core.Constants;
import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.system.AppUserDao;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.Department;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.List<Lcom.htsoft.oa.model.system.AppUser;>;
import java.util.Set;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.security.userdetails.UserDetails;
import org.springframework.security.userdetails.UserDetailsService;
import org.springframework.security.userdetails.UsernameNotFoundException;

public class AppUserDaoImpl extends BaseDaoImpl<AppUser>
  implements AppUserDao, UserDetailsService
{
  public AppUserDaoImpl()
  {
    super(AppUser.class);
  }

  public AppUser findByUserName(String paramString)
  {
    String str1 = "from AppUser au where au.username=?";
    Object[] arrayOfObject = { paramString };
    List localList = findByHql(str1, arrayOfObject);
    AppUser localAppUser = null;
    if (localList.size() != 0)
      localAppUser = (AppUser)localList.get(0);
    String str2 = "select count(vo.userId) from AppUser vo ";
    Object localObject = findUnique(str2, null);
    if (new Long(localObject.toString()).longValue() > 25L)
      localAppUser.setStatus(Short.valueOf(0));
    return localAppUser;
  }

  public UserDetails loadUserByUsername(String paramString)
    throws UsernameNotFoundException, DataAccessException
  {
    AppUser localAppUser = (AppUser)getHibernateTemplate().execute(new HibernateCallback(paramString)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        String str = "from AppUser ap where ap.username=? and ap.delFlag = ?";
        Query localQuery = paramSession.createQuery(str);
        localQuery.setString(0, this.val$username);
        localQuery.setShort(1, Constants.FLAG_UNDELETED.shortValue());
        AppUser localAppUser = null;
        localAppUser = (AppUser)localQuery.uniqueResult();
        if (localAppUser != null)
        {
          Hibernate.initialize(localAppUser.getRoles());
          Hibernate.initialize(localAppUser.getDepartment());
          localAppUser.initMenuRights();
        }
        return localAppUser;
      }
    });
    String str = "select count(vo.userId) from AppUser vo ";
    Object localObject = findUnique(str, null);
    if (new Long(localObject.toString()).longValue() > 25L)
      localAppUser.setStatus(Short.valueOf(0));
    return localAppUser;
  }

  public List findByDepartment(String paramString, PagingBean paramPagingBean)
  {
    ArrayList localArrayList = new ArrayList();
    String str = new String();
    if ("0.".equals(paramString))
    {
      str = "from AppUser vo2 where vo2.delFlag = ?";
      localArrayList.add(Constants.FLAG_UNDELETED);
    }
    else
    {
      str = "select distinct au from AppUser au where au.department.path like ? and au.delFlag=? ";
      localArrayList.add(paramString + "%");
      localArrayList.add(Constants.FLAG_UNDELETED);
    }
    return findByHql(str, localArrayList.toArray(), paramPagingBean);
  }

  public List findByDepartment(Department paramDepartment)
  {
    String str = "select vo2 from Department vo1,AppUser vo2 where vo1=vo2.department and vo1.path like ? and vo2.delFlag = ?";
    Object[] arrayOfObject = { paramDepartment.getPath() + "%", Constants.FLAG_UNDELETED };
    return findByHql(str, arrayOfObject);
  }

  public List findByRole(Long paramLong)
  {
    String str = "select vo from AppUser vo join vo.roles roles where roles.roleId=? and vo.delFlag = ?";
    Object[] arrayOfObject = { paramLong, Constants.FLAG_UNDELETED };
    return findByHql(str, arrayOfObject);
  }

  public List findByRole(Long paramLong, PagingBean paramPagingBean)
  {
    String str = "select vo from AppUser vo join vo.roles roles where roles.roleId=? and vo.delFlag = ?";
    Object[] arrayOfObject = { paramLong, Constants.FLAG_UNDELETED };
    return findByHql(str, arrayOfObject, paramPagingBean);
  }

  public List<AppUser> findByDepartment(String paramString)
  {
    String str = "select vo2 from Department vo1,AppUser vo2 where vo1.depId=vo2.depId and vo1.path like ? and vo2.delFlag =?";
    Object[] arrayOfObject = { paramString + "%", Constants.FLAG_UNDELETED };
    return findByHql(str, arrayOfObject);
  }

  public List findByRoleId(Long paramLong)
  {
    String str = "select vo from AppUser vo join vo.roles as roles where roles.roleId=? and vo.delFlag =?";
    return findByHql(str, new Object[] { paramLong, Constants.FLAG_UNDELETED });
  }

  public List findByUserIds(Long[] paramArrayOfLong)
  {
    String str = "select vo from AppUser vo where vo.delFlag=? ";
    if ((paramArrayOfLong == null) || (paramArrayOfLong.length == 0))
      return null;
    str = str + " where vo.userId in (";
    int i = 0;
    for (Long localLong : paramArrayOfLong)
    {
      if (i++ > 0)
        str = str + ",";
      str = str + "?";
    }
    str = str + " )";
    return findByHql(str, new Object[] { Constants.FLAG_UNDELETED, paramArrayOfLong });
  }

  public List<AppUser> findSubAppUser(String paramString, Set<Long> paramSet, PagingBean paramPagingBean)
  {
    String str = "";
    if (paramSet.size() > 0)
    {
      localObject = paramSet.iterator();
      localStringBuffer = new StringBuffer();
      while (((Iterator)localObject).hasNext())
        localStringBuffer.append(((Long)((Iterator)localObject).next()).toString() + ",");
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
      str = localStringBuffer.toString();
    }
    Object localObject = new ArrayList();
    StringBuffer localStringBuffer = new StringBuffer();
    if (paramString != null)
    {
      localStringBuffer.append("select vo2 from Department vo1,AppUser vo2 where vo1=vo2.department ");
      localStringBuffer.append(" and vo1.path like ?");
      ((List)localObject).add(paramString + "%");
    }
    else
    {
      localStringBuffer.append("from AppUser vo2 where 1=1 ");
    }
    if (str != "")
      localStringBuffer.append(" and vo2.userId not in (" + str + ")");
    localStringBuffer.append(" and vo2.delFlag = ?");
    ((List)localObject).add(Constants.FLAG_UNDELETED);
    return (List<AppUser>)findByHql(localStringBuffer.toString(), ((List)localObject).toArray(), paramPagingBean);
  }

  public List<AppUser> findSubAppUserByRole(Long paramLong, Set<Long> paramSet, PagingBean paramPagingBean)
  {
    String str = "";
    if (paramSet.size() > 0)
    {
      localObject1 = paramSet.iterator();
      localObject2 = new StringBuffer();
      while (((Iterator)localObject1).hasNext())
        ((StringBuffer)localObject2).append(((Long)((Iterator)localObject1).next()).toString() + ",");
      ((StringBuffer)localObject2).deleteCharAt(((StringBuffer)localObject2).length() - 1);
      str = ((StringBuffer)localObject2).toString();
    }
    Object localObject1 = new StringBuffer("select vo from AppUser vo join vo.roles roles where roles.roleId=?");
    Object localObject2 = new ArrayList();
    ((List)localObject2).add(paramLong);
    if (str != "")
      ((StringBuffer)localObject1).append(" and vo.userId not in (" + str + ")");
    ((StringBuffer)localObject1).append(" and vo.delFlag =?");
    ((List)localObject2).add(Constants.FLAG_UNDELETED);
    return (List<AppUser>)(List<AppUser>)findByHql(((StringBuffer)localObject1).toString(), ((List)localObject2).toArray(), paramPagingBean);
  }

  public List<AppUser> findByDepId(Long paramLong)
  {
    String str = "from AppUser vo where vo.delFlag=0 and vo.department.depId=?";
    Object[] arrayOfObject = { paramLong };
    return findByHql(str, arrayOfObject);
  }

  public List<AppUser> findUsersByRoleIds(String paramString)
  {
    if (StringUtils.isEmpty(paramString))
      return new ArrayList();
    String str = "select distinct au from AppUser as au join au.roles as roles where roles.roleId in (" + paramString + ") and au.delFlag =?";
    return findByHql(str, new Object[] { Constants.FLAG_UNDELETED });
  }

  public List<AppUser> findRelativeUsersByUserId(Long paramLong, Short paramShort)
  {
    StringBuffer localStringBuffer = new StringBuffer("select u.jobUser from RelativeUser u where u.appUser.userId = ? ");
    int i = (paramShort != null) && (paramShort.shortValue() < 3) ? 1 : 0;
    if (i != 0)
      localStringBuffer.append("and u.isSuper = ? ");
    Query localQuery = getSession().createQuery(localStringBuffer.toString());
    localQuery.setLong(0, paramLong.longValue());
    if (i != 0)
      localQuery.setShort(1, paramShort.shortValue());
    this.logger.debug("我的下属查询：" + localStringBuffer.toString());
    return localQuery.list();
  }

  public List<AppUser> findByDepartment(String paramString1, String paramString2, PagingBean paramPagingBean)
  {
    ArrayList localArrayList = new ArrayList();
    StringBuffer localStringBuffer = new StringBuffer("");
    if ("0.".equals(paramString1))
    {
      localStringBuffer.append("from AppUser vo2 where vo2.delFlag = ? ");
      localArrayList.add(Constants.FLAG_UNDELETED);
    }
    else
    {
      localStringBuffer.append("select DISTINCT vo2 from Department vo1,AppUser vo2,DepUsers vo3 where 1=1 and vo3.appUser=vo2 and vo3.department=vo1 and vo1.path like ? and vo2.delFlag = ? ");
      localArrayList.add(paramString1 + "%");
      localArrayList.add(Constants.FLAG_UNDELETED);
    }
    if ((paramString2 != null) && (!paramString2.equals("")))
    {
      localStringBuffer.append("and vo2.userId in (?) ");
      localArrayList.add(paramString2);
    }
    localStringBuffer.append("order by vo3.sn ");
    this.logger.debug("自定义AppUserDaoImpl : " + localStringBuffer.toString());
    return findByHql(localStringBuffer.toString(), localArrayList.toArray(), paramPagingBean);
  }

  public List<AppUser> getUsersByRoleId(Long paramLong)
  {
    String str = "from AppUser au join au.roles as role where role.roleId=?";
    return findByHql(str, new Object[] { paramLong });
  }

  public List<AppUser> findByfullName(String paramString)
  {
    String str = "from AppUser u where u.fullname= ? ";
    return findByHql(str, new Object[] { paramString });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.impl.AppUserDaoImpl
 * JD-Core Version:    0.6.0
 */