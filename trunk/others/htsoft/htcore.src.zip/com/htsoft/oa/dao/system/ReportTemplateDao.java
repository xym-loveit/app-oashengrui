package com.htsoft.oa.dao.system;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.system.ReportTemplate;

public abstract interface ReportTemplateDao extends BaseDao<ReportTemplate>
{
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.ReportTemplateDao
 * JD-Core Version:    0.6.0
 */