package com.htsoft.oa.dao.arch.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.arch.ArchFondDao;
import com.htsoft.oa.model.arch.ArchFond;

public class ArchFondDaoImpl extends BaseDaoImpl<ArchFond>
  implements ArchFondDao
{
  public ArchFondDaoImpl()
  {
    super(ArchFond.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.arch.impl.ArchFondDaoImpl
 * JD-Core Version:    0.6.0
 */