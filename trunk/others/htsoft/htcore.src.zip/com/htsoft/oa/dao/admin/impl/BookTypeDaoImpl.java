package com.htsoft.oa.dao.admin.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.admin.BookTypeDao;
import com.htsoft.oa.model.admin.BookType;

public class BookTypeDaoImpl extends BaseDaoImpl<BookType>
  implements BookTypeDao
{
  public BookTypeDaoImpl()
  {
    super(BookType.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.impl.BookTypeDaoImpl
 * JD-Core Version:    0.6.0
 */