package com.htsoft.oa.dao.personal.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.util.DateUtil;
import com.htsoft.oa.dao.personal.DutyRegisterDao;
import com.htsoft.oa.model.personal.DutyRegister;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class DutyRegisterDaoImpl extends BaseDaoImpl<DutyRegister>
  implements DutyRegisterDao
{
  public DutyRegisterDaoImpl()
  {
    super(DutyRegister.class);
  }

  public DutyRegister getTodayUserRegister(Long paramLong1, Short paramShort, Long paramLong2)
  {
    String str = "from DutyRegister dr where dr.appUser.userId=? and dr.registerDate>=? and dr.registerDate<=? and dr.inOffFlag=? and dr.dutySection.sectionId=?";
    Calendar localCalendar = Calendar.getInstance();
    Date localDate1 = DateUtil.setStartDay(localCalendar).getTime();
    Date localDate2 = DateUtil.setEndDay(localCalendar).getTime();
    List localList = findByHql(str, new Object[] { paramLong1, localDate1, localDate2, paramShort, paramLong2 });
    if (localList.size() > 0)
      return (DutyRegister)localList.get(0);
    return null;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.personal.impl.DutyRegisterDaoImpl
 * JD-Core Version:    0.6.0
 */