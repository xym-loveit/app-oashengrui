package com.htsoft.oa.dao.flow.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.flow.FormDefDao;
import com.htsoft.oa.model.flow.FormDef;
import java.util.List;

public class FormDefDaoImpl extends BaseDaoImpl<FormDef>
  implements FormDefDao
{
  public FormDefDaoImpl()
  {
    super(FormDef.class);
  }

  public List<FormDef> getByDeployId(String paramString)
  {
    String str = "from FormDef fd where deployId=?";
    return findByHql(str, new Object[] { paramString });
  }

  public FormDef getByDeployIdActivityName(String paramString1, String paramString2)
  {
    String str = "from FormDef fd where fd.deployId=? and fd.activityName=?";
    return (FormDef)findUnique(str, new Object[] { paramString1, paramString2 });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.impl.FormDefDaoImpl
 * JD-Core Version:    0.6.0
 */