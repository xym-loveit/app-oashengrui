package com.htsoft.oa.dao.info.impl;

import com.htsoft.core.Constants;
import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.info.NewsDao;
import com.htsoft.oa.model.info.News;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.StringUtils;

public class NewsDaoImpl extends BaseDaoImpl<News>
  implements NewsDao
{
  public NewsDaoImpl()
  {
    super(News.class);
  }

  public List<News> findByTypeId(Long paramLong, PagingBean paramPagingBean)
  {
    Object[] arrayOfObject = { paramLong };
    return findByHql("from News n where n.newsType.typeId=?", arrayOfObject, paramPagingBean);
  }

  public List<News> findBySearch(Short paramShort, String paramString, PagingBean paramPagingBean)
  {
    ArrayList localArrayList = new ArrayList();
    StringBuffer localStringBuffer = new StringBuffer("from News n where n.isNotice= ? and n.status = ?");
    localArrayList.add(paramShort);
    localArrayList.add(Constants.FLAG_ACTIVATION);
    if (StringUtils.isNotEmpty(paramString))
    {
      localStringBuffer.append(" and (n.subject like ? or n.content like ?)");
      localArrayList.add("%" + paramString + "%");
      localArrayList.add("%" + paramString + "%");
    }
    localStringBuffer.append(" order by n.updateTime desc");
    return findByHql(localStringBuffer.toString(), localArrayList.toArray(), paramPagingBean);
  }

  public List<News> findImageNews(Long paramLong, PagingBean paramPagingBean)
  {
    String str = "from News vo where  vo.section.sectionId = ? order by vo.updateTime desc";
    return findByHql(str, new Object[] { paramLong }, paramPagingBean);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.info.impl.NewsDaoImpl
 * JD-Core Version:    0.6.0
 */