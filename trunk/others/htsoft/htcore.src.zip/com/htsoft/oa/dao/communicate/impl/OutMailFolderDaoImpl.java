package com.htsoft.oa.dao.communicate.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.communicate.OutMailFolderDao;
import com.htsoft.oa.model.communicate.OutMailFolder;
import java.util.List;

public class OutMailFolderDaoImpl extends BaseDaoImpl<OutMailFolder>
  implements OutMailFolderDao
{
  public OutMailFolderDaoImpl()
  {
    super(OutMailFolder.class);
  }

  public List<OutMailFolder> getAllUserFolderByParentId(Long paramLong1, Long paramLong2)
  {
    String str = "from OutMailFolder mf where mf.appUser.userId=? and parentId=? or userId is null";
    return findByHql(str, new Object[] { paramLong1, paramLong2 });
  }

  public List<OutMailFolder> getUserFolderByParentId(Long paramLong1, Long paramLong2)
  {
    String str = "from OutMailFolder mf where mf.appUser.userId=? and parentId=?";
    return findByHql(str, new Object[] { paramLong1, paramLong2 });
  }

  public List<OutMailFolder> getFolderLikePath(String paramString)
  {
    String str = "from OutMailFolder mf where mf.path like ?";
    return findByHql(str, new Object[] { paramString + '%' });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.communicate.impl.OutMailFolderDaoImpl
 * JD-Core Version:    0.6.0
 */