package com.htsoft.oa.dao.system.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.system.RelativeUserDao;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.RelativeUser;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.commons.logging.Log;

public class RelativeUserDaoImpl extends BaseDaoImpl<RelativeUser>
  implements RelativeUserDao
{
  public RelativeUserDaoImpl()
  {
    super(RelativeUser.class);
  }

  public AppUser judge(Long paramLong1, Long paramLong2)
  {
    String str = "select r from RelativeUser r where r.appUser.userId = ? and r.jobUser.userId = ? ";
    Object[] arrayOfObject = { paramLong1, paramLong2 };
    List localList = findByHql(str, arrayOfObject);
    this.logger.debug(str);
    return (localList != null) && (localList.size() > 0) ? ((RelativeUser)localList.get(0)).getJobUser() : null;
  }

  public List<AppUser> findByUserIdReJobId(Long paramLong1, Long paramLong2)
  {
    String str = "select ru.jobUser from RelativeUser ru where ru.appUser.userId=? and ru.relativeJob.reJobId=? ";
    List localList = findByHql(str, new Object[] { paramLong1, paramLong2 });
    return (List)localList;
  }

  public List<RelativeUser> list(Long paramLong1, Long paramLong2, PagingBean paramPagingBean)
  {
    ArrayList localArrayList = new ArrayList();
    StringBuffer localStringBuffer = new StringBuffer("select r from RelativeUser r where 1=1 ");
    if ((paramLong1 != null) && (paramLong1.longValue() > 0L))
    {
      localStringBuffer.append("and r.appUser.userId = ? ");
      localArrayList.add(paramLong1);
    }
    if ((paramLong2 != null) && (paramLong2.longValue() > 0L))
    {
      localStringBuffer.append("and r.relativeJob.reJobId = ? ");
      localArrayList.add(paramLong2);
    }
    this.logger.debug("自定义：RelativeUserDaoImpl:" + localStringBuffer.toString());
    return (ArrayList)findByHql(localStringBuffer.toString(), localArrayList.toArray(), paramPagingBean);
  }

  public List<Long> getReJobUserIds(Long paramLong1, Long paramLong2)
  {
    String str = "select jobUser.userId from RelativeUser ru where ru.appUser.userId=? and relativeJob.reJobId=? ";
    List localList = findByHql(str, new Object[] { paramLong1, paramLong2 });
    return localList;
  }

  public Set<AppUser> getUpUser(Long paramLong)
  {
    String str1 = "select  ru.jobUser from RelativeUser ru where ru.appUser.userId =? and ru.isSuper =?";
    List localList1 = findByHql(str1, new Object[] { paramLong, RelativeUser.SUPER_FLAG_TRUE });
    String str2 = "select  ru.appUser from RelativeUser ru where  ru.jobUser.userId = ? and ru.isSuper = ?";
    List localList2 = findByHql(str2, new Object[] { paramLong, RelativeUser.SUPER_FLAG_FALSE });
    HashSet localHashSet = new HashSet();
    localHashSet.addAll(localList1);
    localHashSet.addAll(localList2);
    return localHashSet;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.impl.RelativeUserDaoImpl
 * JD-Core Version:    0.6.0
 */