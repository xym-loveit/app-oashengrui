package com.htsoft.oa.dao.communicate.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.communicate.MailDao;
import com.htsoft.oa.model.communicate.Mail;

public class MailDaoImpl extends BaseDaoImpl<Mail>
  implements MailDao
{
  public MailDaoImpl()
  {
    super(Mail.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.communicate.impl.MailDaoImpl
 * JD-Core Version:    0.6.0
 */