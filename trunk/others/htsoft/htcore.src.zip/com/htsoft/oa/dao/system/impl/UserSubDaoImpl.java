package com.htsoft.oa.dao.system.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.system.UserSubDao;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.UserSub;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class UserSubDaoImpl extends BaseDaoImpl<UserSub>
  implements UserSubDao
{
  public UserSubDaoImpl()
  {
    super(UserSub.class);
  }

  public List<Long> upUser(Long paramLong)
  {
    String str = "from UserSub vo where vo.subAppUser.userId=?";
    Object[] arrayOfObject = { paramLong };
    List localList = findByHql(str, arrayOfObject);
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      UserSub localUserSub = (UserSub)localIterator.next();
      localArrayList.add(localUserSub.getUserId());
    }
    return localArrayList;
  }

  public List<Long> subUsers(Long paramLong)
  {
    String str = "from UserSub vo where vo.userId=?";
    Object[] arrayOfObject = { paramLong };
    List localList = findByHql(str, arrayOfObject);
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      UserSub localUserSub = (UserSub)localIterator.next();
      localArrayList.add(localUserSub.getSubAppUser().getUserId());
    }
    return localArrayList;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.impl.UserSubDaoImpl
 * JD-Core Version:    0.6.0
 */