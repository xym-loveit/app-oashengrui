package com.htsoft.oa.dao.info.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.info.InMessageDao;
import com.htsoft.oa.model.info.InMessage;
import com.htsoft.oa.model.info.ShortMessage;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;

public class InMessageDaoImpl extends BaseDaoImpl<InMessage>
  implements InMessageDao
{
  public InMessageDaoImpl()
  {
    super(InMessage.class);
  }

  public InMessage findByRead(Long paramLong)
  {
    String str = "from InMessage vo where vo.readFlag=0 and vo.delFlag=0 and vo.userId=?";
    Object[] arrayOfObject = { paramLong };
    List localList = findByHql(str, arrayOfObject);
    if (localList.size() > 0)
      return (InMessage)localList.get(localList.size() - 1);
    return null;
  }

  public Integer findByReadFlag(Long paramLong)
  {
    String str = "select count(*) from InMessage vo where vo.readFlag=0 and vo.delFlag=0 and vo.userId=" + paramLong;
    Query localQuery = getSession().createQuery(str);
    return Integer.valueOf(Integer.parseInt(localQuery.list().iterator().next().toString()));
  }

  public List<InMessage> findAll(Long paramLong, PagingBean paramPagingBean)
  {
    String str = "from InMessage vo where vo.userId=?";
    Object[] arrayOfObject = { paramLong };
    return findByHql(str, arrayOfObject, paramPagingBean);
  }

  public List<InMessage> findByShortMessage(ShortMessage paramShortMessage, PagingBean paramPagingBean)
  {
    String str = "from InMessage vo1,ShortMessage vo2 where vo1.shortMessage=?";
    Object[] arrayOfObject = { paramShortMessage };
    return findByHql(str, arrayOfObject, paramPagingBean);
  }

  public List findByUser(Long paramLong, PagingBean paramPagingBean)
  {
    String str = "select vo1,vo2 from InMessage vo1,ShortMessage vo2 where vo1.shortMessage=vo2 and vo2.msgType=1 and vo2.senderId=? order by vo2.sendTime desc";
    Object[] arrayOfObject = { paramLong };
    return findByHql(str, arrayOfObject, paramPagingBean);
  }

  public List findByUser(Long paramLong)
  {
    String str = "select vo1,vo2 from InMessage vo1,ShortMessage vo2 where vo1.shortMessage=vo2 and vo2.senderId=?";
    Object[] arrayOfObject = { paramLong };
    return findByHql(str, arrayOfObject);
  }

  public List searchInMessage(Long paramLong, InMessage paramInMessage, ShortMessage paramShortMessage, Date paramDate1, Date paramDate2, PagingBean paramPagingBean)
  {
    StringBuffer localStringBuffer = new StringBuffer("select vo1 ,vo2 from InMessage vo1,ShortMessage vo2 where vo1.shortMessage=vo2 and vo2.msgType=1 and vo2.senderId=?");
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(paramLong);
    if (paramDate2 != null)
    {
      localStringBuffer.append("and vo2.sendTime <= ?");
      localArrayList.add(paramDate2);
    }
    if (paramDate1 != null)
    {
      localStringBuffer.append("and vo2.sendTime >= ?");
      localArrayList.add(paramDate1);
    }
    if ((paramShortMessage != null) && (paramShortMessage.getMsgType() != null))
    {
      localStringBuffer.append(" and vo2.msgType=?");
      localArrayList.add(paramShortMessage.getMsgType());
    }
    if ((paramInMessage != null) && (StringUtils.isNotEmpty(paramInMessage.getUserFullname())))
    {
      localStringBuffer.append(" and vo1.userFullname=?");
      localArrayList.add(paramInMessage.getUserFullname());
    }
    localStringBuffer.append(" order by vo2.sendTime desc");
    return findByHql(localStringBuffer.toString(), localArrayList.toArray(), paramPagingBean);
  }

  public InMessage findLatest(Long paramLong)
  {
    String str = "from InMessage vo where vo.delFlag=0 and vo.userId=?";
    Object[] arrayOfObject = { paramLong };
    List localList = findByHql(str, arrayOfObject);
    if (localList.size() > 0)
      return (InMessage)localList.get(localList.size() - 1);
    return null;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.info.impl.InMessageDaoImpl
 * JD-Core Version:    0.6.0
 */