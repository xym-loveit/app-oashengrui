package com.htsoft.oa.dao.admin.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.admin.ConfPrivilegeDao;
import com.htsoft.oa.model.admin.ConfPrivilege;
import java.io.PrintStream;
import java.sql.SQLException;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class ConfPrivilegeDaoImpl extends BaseDaoImpl<ConfPrivilege>
  implements ConfPrivilegeDao
{
  public ConfPrivilegeDaoImpl()
  {
    super(ConfPrivilege.class);
  }

  public Short getPrivilege(Long paramLong1, Long paramLong2, Short paramShort)
  {
    Short localShort = Short.valueOf(0);
    String str = "select p from ConfPrivilege p where p.userId =" + paramLong1 + " and p.confId = " + paramLong2 + " and p.rights=" + paramShort;
    List localList = findByHql(str);
    if ((localList != null) && (localList.size() > 0))
    {
      ConfPrivilege localConfPrivilege = (ConfPrivilege)localList.get(0);
      localShort = localConfPrivilege.getRights();
    }
    return localShort;
  }

  public void delete(Long paramLong)
  {
    Object localObject = getHibernateTemplate().execute(new HibernateCallback(paramLong)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Query localQuery = paramSession.createQuery("delete ConfPrivilege c where c.confId = ?");
        localQuery.setLong(0, this.val$confId.longValue());
        return Integer.valueOf(localQuery.executeUpdate());
      }
    });
    System.out.println("删除数据条数：" + localObject);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.impl.ConfPrivilegeDaoImpl
 * JD-Core Version:    0.6.0
 */