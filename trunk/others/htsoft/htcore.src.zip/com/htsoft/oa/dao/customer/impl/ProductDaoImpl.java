package com.htsoft.oa.dao.customer.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.customer.ProductDao;
import com.htsoft.oa.model.customer.Product;

public class ProductDaoImpl extends BaseDaoImpl<Product>
  implements ProductDao
{
  public ProductDaoImpl()
  {
    super(Product.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.customer.impl.ProductDaoImpl
 * JD-Core Version:    0.6.0
 */