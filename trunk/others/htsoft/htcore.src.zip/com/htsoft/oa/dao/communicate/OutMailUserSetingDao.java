package com.htsoft.oa.dao.communicate;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.communicate.OutMailUserSeting;
import java.util.List;

public abstract interface OutMailUserSetingDao extends BaseDao<OutMailUserSeting>
{
  public abstract OutMailUserSeting getByLoginId(Long paramLong);

  public abstract List findByUserAll();

  public abstract List<OutMailUserSeting> findByUserAll(String paramString, PagingBean paramPagingBean);
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.communicate.OutMailUserSetingDao
 * JD-Core Version:    0.6.0
 */