package com.htsoft.oa.dao.hrm.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.hrm.JobChangeDao;
import com.htsoft.oa.model.hrm.JobChange;

public class JobChangeDaoImpl extends BaseDaoImpl<JobChange>
  implements JobChangeDao
{
  public JobChangeDaoImpl()
  {
    super(JobChange.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.hrm.impl.JobChangeDaoImpl
 * JD-Core Version:    0.6.0
 */