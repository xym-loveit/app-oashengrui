package com.htsoft.oa.dao.personal.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.personal.DutySectionDao;
import com.htsoft.oa.model.personal.DutySection;

public class DutySectionDaoImpl extends BaseDaoImpl<DutySection>
  implements DutySectionDao
{
  public DutySectionDaoImpl()
  {
    super(DutySection.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.personal.impl.DutySectionDaoImpl
 * JD-Core Version:    0.6.0
 */