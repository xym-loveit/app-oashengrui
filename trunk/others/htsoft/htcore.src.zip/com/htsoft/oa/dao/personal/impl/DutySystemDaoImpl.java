package com.htsoft.oa.dao.personal.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.personal.DutySystemDao;
import com.htsoft.oa.model.personal.DutySystem;
import java.sql.SQLException;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class DutySystemDaoImpl extends BaseDaoImpl<DutySystem>
  implements DutySystemDao
{
  public DutySystemDaoImpl()
  {
    super(DutySystem.class);
  }

  public void updateForNotDefult()
  {
    getHibernateTemplate().execute(new HibernateCallback()
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Query localQuery = paramSession.createQuery("update DutySystem ds set ds.isDefault=? where ds.isDefault=?");
        localQuery.setShort(0, DutySystem.NOT_DEFAULT.shortValue());
        localQuery.setShort(1, DutySystem.DEFAULT.shortValue());
        localQuery.executeUpdate();
        return null;
      }
    });
  }

  public List<DutySystem> getDefaultDutySystem()
  {
    String str = "from DutySystem ds where ds.isDefault=? ";
    return findByHql(str, new Object[] { DutySystem.DEFAULT });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.personal.impl.DutySystemDaoImpl
 * JD-Core Version:    0.6.0
 */