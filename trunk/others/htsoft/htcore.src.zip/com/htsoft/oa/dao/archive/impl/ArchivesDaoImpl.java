package com.htsoft.oa.dao.archive.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.archive.ArchivesDao;
import com.htsoft.oa.model.archive.Archives;
import com.htsoft.oa.model.system.AppRole;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class ArchivesDaoImpl extends BaseDaoImpl<Archives>
  implements ArchivesDao
{
  public ArchivesDaoImpl()
  {
    super(Archives.class);
  }

  public List<Archives> findByUserOrRole(Long paramLong, Set<AppRole> paramSet, PagingBean paramPagingBean)
  {
    Iterator localIterator = paramSet.iterator();
    StringBuffer localStringBuffer1 = new StringBuffer();
    while (localIterator.hasNext())
    {
      if (localStringBuffer1.length() > 0)
        localStringBuffer1.append(",");
      localStringBuffer1.append(((AppRole)localIterator.next()).getRoleId().toString());
    }
    StringBuffer localStringBuffer2 = new StringBuffer("select distinct vo1.archivesId from Archives vo1,ArchDispatch vo2 where vo2.archives=vo1 and vo2.archUserType=2 and (vo2.userId=?");
    if (localStringBuffer1.length() > 0)
      localStringBuffer2.append(" or vo2.disRoleId in (" + localStringBuffer1 + ")");
    localStringBuffer2.append(")");
    Object[] arrayOfObject = { paramLong };
    List localList = find(localStringBuffer2.toString(), arrayOfObject, paramPagingBean);
    return findByIds(localList);
  }

  private List<Archives> findByIds(List paramList)
  {
    String str = "from Document doc where doc.docId in (";
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 0; i < paramList.size(); i++)
      localStringBuffer.append(paramList.get(i).toString()).append(",");
    if (paramList.size() > 0)
    {
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
      str = str + localStringBuffer.toString() + ")";
      return findByHql(str);
    }
    return new ArrayList();
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.archive.impl.ArchivesDaoImpl
 * JD-Core Version:    0.6.0
 */