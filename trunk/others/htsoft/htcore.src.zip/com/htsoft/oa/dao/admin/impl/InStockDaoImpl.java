package com.htsoft.oa.dao.admin.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.admin.InStockDao;
import com.htsoft.oa.model.admin.InStock;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;

public class InStockDaoImpl extends BaseDaoImpl<InStock>
  implements InStockDao
{
  public InStockDaoImpl()
  {
    super(InStock.class);
  }

  public Integer findInCountByBuyId(Long paramLong)
  {
    String str = "select vo.inCounts from InStock vo where vo.buyId=?";
    Query localQuery = getSession().createQuery(str);
    localQuery.setLong(0, paramLong.longValue());
    Integer localInteger = Integer.valueOf(Integer.parseInt(localQuery.list().iterator().next().toString()));
    return localInteger;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.impl.InStockDaoImpl
 * JD-Core Version:    0.6.0
 */