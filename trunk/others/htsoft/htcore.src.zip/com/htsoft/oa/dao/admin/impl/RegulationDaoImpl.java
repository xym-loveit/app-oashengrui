package com.htsoft.oa.dao.admin.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.admin.RegulationDao;
import com.htsoft.oa.model.admin.Regulation;

public class RegulationDaoImpl extends BaseDaoImpl<Regulation>
  implements RegulationDao
{
  public RegulationDaoImpl()
  {
    super(Regulation.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.impl.RegulationDaoImpl
 * JD-Core Version:    0.6.0
 */