package com.htsoft.oa.dao.admin.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.admin.FixedAssetsDao;
import com.htsoft.oa.model.admin.FixedAssets;

public class FixedAssetsDaoImpl extends BaseDaoImpl<FixedAssets>
  implements FixedAssetsDao
{
  public FixedAssetsDaoImpl()
  {
    super(FixedAssets.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.impl.FixedAssetsDaoImpl
 * JD-Core Version:    0.6.0
 */