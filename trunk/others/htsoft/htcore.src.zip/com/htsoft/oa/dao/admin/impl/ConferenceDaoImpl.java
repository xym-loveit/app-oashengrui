package com.htsoft.oa.dao.admin.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.admin.ConfPrivilegeDao;
import com.htsoft.oa.dao.admin.ConferenceDao;
import com.htsoft.oa.dao.system.AppUserDao;
import com.htsoft.oa.dao.system.FileAttachDao;
import com.htsoft.oa.model.admin.ConfPrivilege;
import com.htsoft.oa.model.admin.Conference;
import com.htsoft.oa.model.info.ShortMessage;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.FileAttach;
import com.htsoft.oa.service.info.ShortMessageService;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.annotation.Resource;
import org.apache.commons.logging.Log;

public class ConferenceDaoImpl extends BaseDaoImpl<Conference>
  implements ConferenceDao
{
  private static SimpleDateFormat sdfc = new SimpleDateFormat("yyyy年MM月dd日 HH时mm分");

  @Resource
  private FileAttachDao fileAttachDao;

  @Resource
  private AppUserDao appUserDao;

  @Resource
  private ShortMessageService shortMessageService;

  @Resource
  private ConfPrivilegeDao confPrivilegeDao;

  public ConferenceDaoImpl()
  {
    super(Conference.class);
  }

  public List<Conference> getConfTopic(String paramString, PagingBean paramPagingBean)
  {
    Long localLong = ContextUtil.getCurrentUserId();
    ArrayList localArrayList = new ArrayList();
    StringBuffer localStringBuffer = new StringBuffer("select c from Conference c,ConfPrivilege p where c.endTime < ? and c.confId=p.confId ");
    localStringBuffer.append("and p.rights=3 and p.userId=" + localLong);
    localArrayList.add(new Date());
    if ((paramString != null) && (!paramString.isEmpty()))
    {
      localStringBuffer.append(" and c.confTopic like ? ");
      localArrayList.add("%" + paramString + "%");
    }
    this.logger.debug("可创建会议纪要的HQL：" + localStringBuffer.toString());
    return findByHql(localStringBuffer.toString(), localArrayList.toArray(), paramPagingBean);
  }

  public String baseUserIdSearchFullName(String paramString)
  {
    String str1 = "";
    for (String str2 : paramString.split(","))
      str1 = str1 + ((AppUser)this.appUserDao.get(new Long(str2))).getFullname() + ",";
    return str1.substring(0, str1.length() - 1);
  }

  public Conference send(Conference paramConference, String paramString1, String paramString2, String paramString3, String paramString4)
  {
    String str = "请审核主题为【" + paramConference.getConfTopic() + "】的会议信息！";
    this.shortMessageService.save(AppUser.SYSTEM_USER, paramConference.getCheckUserId().toString(), str, ShortMessage.MSG_TYPE_SYS);
    return temp(paramConference, paramString1, paramString2, paramString3, paramString4);
  }

  public Conference temp(Conference paramConference, String paramString1, String paramString2, String paramString3, String paramString4)
  {
    if ((paramString4 != null) && (!paramString4.isEmpty()))
    {
      localObject1 = new HashSet();
      for (String str : paramString4.split(","))
      {
        FileAttach localFileAttach = (FileAttach)this.fileAttachDao.get(new Long(str));
        ((Set)localObject1).add(localFileAttach);
      }
      paramConference.setAttachFiles((Set)localObject1);
    }
    Object localObject1 = (Conference)super.save(paramConference);
    ??? = new HashSet();
    setConfPrivilege(((Conference)localObject1).getConfId(), paramString1, 1, (Set)???);
    setConfPrivilege(((Conference)localObject1).getConfId(), paramString2, 2, (Set)???);
    setConfPrivilege(((Conference)localObject1).getConfId(), paramString3, 3, (Set)???);
    this.confPrivilegeDao.delete(((Conference)localObject1).getConfId());
    ((Conference)localObject1).setConfPrivilege((Set)???);
    return (Conference)(Conference)(Conference)super.save(localObject1);
  }

  public String judgeBoardRoomNotUse(Date paramDate1, Date paramDate2, Long paramLong)
  {
    ArrayList localArrayList = new ArrayList();
    String str1 = "success";
    String str2 = "select t from Conference t where t.roomId = ? and t.status=1 and ";
    str2 = str2 + "((t.startTime < ? and t.endTime > ?) ";
    str2 = str2 + "or (t.startTime < ? and t.endTime > ?) ";
    str2 = str2 + "or (t.startTime > ? and t.endTime <?))";
    localArrayList.add(paramLong);
    localArrayList.add(paramDate1);
    localArrayList.add(paramDate1);
    localArrayList.add(paramDate2);
    localArrayList.add(paramDate2);
    localArrayList.add(paramDate1);
    localArrayList.add(paramDate2);
    List localList = findByHql(str2, localArrayList.toArray());
    if ((localList != null) && (localList.size() > 0))
    {
      Conference localConference = (Conference)localList.get(0);
      str1 = "会议室【" + localConference.getRoomName() + "】，在【" + sdfc.format(localConference.getStartTime()) + " 至 " + sdfc.format(localConference.getEndTime()) + "】这段时间不可使用，请选择其他时间段或者会议室！";
    }
    else
    {
      str1 = "success";
    }
    this.logger.debug("Conference中判断会议室是否可用：" + str2);
    return str1;
  }

  public String apply(Long paramLong, String paramString, boolean paramBoolean)
  {
    int i = paramBoolean ? 1 : 3;
    Conference localConference = (Conference)get(paramLong);
    if (i == 1)
    {
      String str1 = "请于【" + sdfc.format(localConference.getStartTime()) + "-" + sdfc.format(localConference.getEndTime()) + "】到【" + localConference.getRoomName() + "】去主持主题为【" + localConference.getConfTopic() + "】的会议！\n\t地址：" + localConference.getRoomLocation();
      this.shortMessageService.save(AppUser.SYSTEM_USER, localConference.getCompere(), str1, ShortMessage.MSG_TYPE_SYS);
      String str2 = "请于【" + sdfc.format(localConference.getStartTime()) + "-" + sdfc.format(localConference.getEndTime()) + "】到【" + localConference.getRoomName() + "】去记录主题为【" + localConference.getConfTopic() + "】的会议内容！\n\t地址：" + localConference.getRoomLocation();
      this.shortMessageService.save(AppUser.SYSTEM_USER, localConference.getRecorder(), str2, ShortMessage.MSG_TYPE_SYS);
      String str3 = "请于【" + sdfc.format(localConference.getStartTime()) + "-" + sdfc.format(localConference.getEndTime()) + "】到【" + localConference.getRoomName() + "】去参加主题为【" + localConference.getConfTopic() + "】的会议！\n\t地址：" + localConference.getRoomLocation();
      this.shortMessageService.save(AppUser.SYSTEM_USER, localConference.getAttendUsers(), str3, ShortMessage.MSG_TYPE_SYS);
      if (((localConference.getIsEmail() != null) && (localConference.getIsEmail().shortValue() == 1)) && ((localConference.getIsMobile() == null) || (localConference.getIsMobile().shortValue() != 1)));
    }
    localConference.setStatus(Short.valueOf((short)i));
    localConference.setCheckReason(paramString);
    return "success";
  }

  public List<Conference> myJoin(Conference paramConference, Boolean paramBoolean, PagingBean paramPagingBean)
  {
    ArrayList localArrayList = new ArrayList();
    StringBuffer localStringBuffer = new StringBuffer("select c from Conference c where 1=1");
    localStringBuffer.append(" and (c.compereName like ? or c.recorderName like ? or c.attendUsersName like ?)");
    String str = ContextUtil.getCurrentUser().getFullname();
    System.out.println(str);
    localArrayList.add("%" + str + "%");
    localArrayList.add("%" + str + "%");
    localArrayList.add("%" + str + "%");
    if (paramBoolean != null)
      if (!paramBoolean.booleanValue())
      {
        localStringBuffer.append(" and c.startTime >= ?");
        localArrayList.add(new Date());
      }
      else
      {
        localStringBuffer.append(" and c.endTime < ? ");
        localArrayList.add(new Date());
      }
    if (paramConference != null)
    {
      if ((paramConference.getConfTopic() != null) && (!paramConference.getConfTopic().trim().equals("")))
      {
        localStringBuffer.append(" and c.confTopic like ?");
        localArrayList.add("%" + paramConference.getConfTopic() + "%");
      }
      if ((paramConference.getConfProperty() != null) && (!paramConference.getConfProperty().trim().equals("")))
      {
        localStringBuffer.append(" and c.confProperty = ?");
        localArrayList.add(paramConference.getConfProperty());
      }
      if ((paramConference.getConfContent() != null) && (!paramConference.getConfContent().trim().equals("")))
      {
        localStringBuffer.append(" and c.confContent like ?");
        localArrayList.add("%" + paramConference.getConfContent() + "%");
      }
      if ((paramConference.getRoomName() != null) && (!paramConference.getRoomName().trim().equals("")))
      {
        localStringBuffer.append(" and c.roomName like ?");
        localArrayList.add("%" + paramConference.getRoomName() + "%");
      }
      if (paramConference.getRoomId() != null)
      {
        localStringBuffer.append(" and c.roomId = ?");
        localArrayList.add(paramConference.getRoomId());
      }
      if (paramConference.getStartTime() != null)
      {
        localStringBuffer.append(" and c.startTime = ?");
        localArrayList.add(paramConference.getStartTime());
      }
      if (paramConference.getEndTime() != null)
      {
        localStringBuffer.append(" and c.endTime = ?");
        localArrayList.add(paramConference.getEndTime());
      }
      if (paramConference.getStatus() != null)
      {
        localStringBuffer.append(" and c.status = ?");
        localArrayList.add(paramConference.getStatus());
      }
    }
    localStringBuffer.append(" order by confId DESC");
    this.logger.debug("与我相关会议查询：" + localStringBuffer.toString());
    return findByHql(localStringBuffer.toString(), localArrayList.toArray(), paramPagingBean);
  }

  private void setConfPrivilege(Long paramLong, String paramString, int paramInt, Set<ConfPrivilege> paramSet)
  {
    for (String str : paramString.split(","))
    {
      AppUser localAppUser = (AppUser)this.appUserDao.get(new Long(str));
      ConfPrivilege localConfPrivilege = new ConfPrivilege();
      localConfPrivilege.setConfId(paramLong);
      localConfPrivilege.setUserId(localAppUser.getUserId());
      localConfPrivilege.setFullname(localAppUser.getFullname());
      localConfPrivilege.setRights(Short.valueOf((short)paramInt));
      paramSet.add(localConfPrivilege);
    }
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.impl.ConferenceDaoImpl
 * JD-Core Version:    0.6.0
 */