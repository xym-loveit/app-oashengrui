package com.htsoft.oa.dao.communicate;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.communicate.SmsHistory;

public abstract interface SmsHistoryDao extends BaseDao<SmsHistory>
{
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.communicate.SmsHistoryDao
 * JD-Core Version:    0.6.0
 */