package com.htsoft.oa.dao.admin;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.admin.CarApply;

public abstract interface CarApplyDao extends BaseDao<CarApply>
{
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.CarApplyDao
 * JD-Core Version:    0.6.0
 */