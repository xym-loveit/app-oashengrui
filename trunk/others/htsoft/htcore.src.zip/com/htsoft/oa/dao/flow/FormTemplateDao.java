package com.htsoft.oa.dao.flow;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.flow.FormTemplate;
import java.util.List;

public abstract interface FormTemplateDao extends BaseDao<FormTemplate>
{
  public abstract List<FormTemplate> getByMappingId(Long paramLong);

  public abstract FormTemplate getByMappingIdNodeName(Long paramLong, String paramString);
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.FormTemplateDao
 * JD-Core Version:    0.6.0
 */