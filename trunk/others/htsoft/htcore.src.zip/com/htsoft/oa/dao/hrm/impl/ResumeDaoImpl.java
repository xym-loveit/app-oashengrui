package com.htsoft.oa.dao.hrm.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.hrm.ResumeDao;
import com.htsoft.oa.model.hrm.Resume;

public class ResumeDaoImpl extends BaseDaoImpl<Resume>
  implements ResumeDao
{
  public ResumeDaoImpl()
  {
    super(Resume.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.hrm.impl.ResumeDaoImpl
 * JD-Core Version:    0.6.0
 */