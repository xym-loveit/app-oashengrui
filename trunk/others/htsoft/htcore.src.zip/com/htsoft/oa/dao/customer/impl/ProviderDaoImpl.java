package com.htsoft.oa.dao.customer.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.customer.ProviderDao;
import com.htsoft.oa.model.customer.Provider;

public class ProviderDaoImpl extends BaseDaoImpl<Provider>
  implements ProviderDao
{
  public ProviderDaoImpl()
  {
    super(Provider.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.customer.impl.ProviderDaoImpl
 * JD-Core Version:    0.6.0
 */