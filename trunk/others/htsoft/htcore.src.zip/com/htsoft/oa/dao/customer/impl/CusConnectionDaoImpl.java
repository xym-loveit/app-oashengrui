package com.htsoft.oa.dao.customer.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.customer.CusConnectionDao;
import com.htsoft.oa.model.customer.CusConnection;

public class CusConnectionDaoImpl extends BaseDaoImpl<CusConnection>
  implements CusConnectionDao
{
  public CusConnectionDaoImpl()
  {
    super(CusConnection.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.customer.impl.CusConnectionDaoImpl
 * JD-Core Version:    0.6.0
 */