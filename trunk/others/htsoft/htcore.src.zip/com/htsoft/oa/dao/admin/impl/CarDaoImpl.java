package com.htsoft.oa.dao.admin.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.admin.CarDao;
import com.htsoft.oa.model.admin.Car;

public class CarDaoImpl extends BaseDaoImpl<Car>
  implements CarDao
{
  public CarDaoImpl()
  {
    super(Car.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.impl.CarDaoImpl
 * JD-Core Version:    0.6.0
 */