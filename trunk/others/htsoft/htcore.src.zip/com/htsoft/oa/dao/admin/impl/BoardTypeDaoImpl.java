package com.htsoft.oa.dao.admin.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.admin.BoardTypeDao;
import com.htsoft.oa.model.admin.BoardType;

public class BoardTypeDaoImpl extends BaseDaoImpl<BoardType>
  implements BoardTypeDao
{
  public BoardTypeDaoImpl()
  {
    super(BoardType.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.impl.BoardTypeDaoImpl
 * JD-Core Version:    0.6.0
 */