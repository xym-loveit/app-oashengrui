package com.htsoft.oa.dao.admin.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.admin.BoardRooDao;
import com.htsoft.oa.model.admin.BoardRoo;

public class BoardRooDaoImpl extends BaseDaoImpl<BoardRoo>
  implements BoardRooDao
{
  public BoardRooDaoImpl()
  {
    super(BoardRoo.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.impl.BoardRooDaoImpl
 * JD-Core Version:    0.6.0
 */