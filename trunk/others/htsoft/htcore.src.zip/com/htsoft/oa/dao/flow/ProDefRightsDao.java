package com.htsoft.oa.dao.flow;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.flow.ProDefRights;

public abstract interface ProDefRightsDao extends BaseDao<ProDefRights>
{
  public abstract ProDefRights findByDefId(Long paramLong);

  public abstract ProDefRights findByTypeId(Long paramLong);
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.ProDefRightsDao
 * JD-Core Version:    0.6.0
 */