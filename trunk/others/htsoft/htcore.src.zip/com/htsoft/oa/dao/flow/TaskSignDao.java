package com.htsoft.oa.dao.flow;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.flow.TaskSign;

public abstract interface TaskSignDao extends BaseDao<TaskSign>
{
  public abstract TaskSign findByAssignId(Long paramLong);
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.TaskSignDao
 * JD-Core Version:    0.6.0
 */