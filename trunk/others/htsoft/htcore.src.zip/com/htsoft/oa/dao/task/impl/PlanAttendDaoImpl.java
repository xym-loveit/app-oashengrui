package com.htsoft.oa.dao.task.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.task.PlanAttendDao;
import com.htsoft.oa.model.task.PlanAttend;
import java.util.ArrayList;
import java.util.List;

public class PlanAttendDaoImpl extends BaseDaoImpl<PlanAttend>
  implements PlanAttendDao
{
  public PlanAttendDaoImpl()
  {
    super(PlanAttend.class);
  }

  public List<PlanAttend> FindPlanAttend(Long paramLong, Short paramShort1, Short paramShort2)
  {
    StringBuffer localStringBuffer = new StringBuffer("from PlanAttend vo where vo.workPlan.planId=?");
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(paramLong);
    if (paramShort1 != null)
    {
      localStringBuffer.append(" and vo.isDep=?");
      localArrayList.add(paramShort1);
    }
    if (paramShort2 != null)
    {
      localStringBuffer.append(" and vo.isPrimary=?");
      localArrayList.add(paramShort2);
    }
    return findByHql(localStringBuffer.toString(), localArrayList.toArray());
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.task.impl.PlanAttendDaoImpl
 * JD-Core Version:    0.6.0
 */