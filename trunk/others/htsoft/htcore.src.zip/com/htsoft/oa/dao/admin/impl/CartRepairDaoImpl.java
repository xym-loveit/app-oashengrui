package com.htsoft.oa.dao.admin.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.admin.CartRepairDao;
import com.htsoft.oa.model.admin.CartRepair;

public class CartRepairDaoImpl extends BaseDaoImpl<CartRepair>
  implements CartRepairDao
{
  public CartRepairDaoImpl()
  {
    super(CartRepair.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.impl.CartRepairDaoImpl
 * JD-Core Version:    0.6.0
 */