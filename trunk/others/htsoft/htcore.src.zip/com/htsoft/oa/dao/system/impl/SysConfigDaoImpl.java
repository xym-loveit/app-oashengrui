package com.htsoft.oa.dao.system.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.system.SysConfigDao;
import com.htsoft.oa.model.system.SysConfig;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;

public class SysConfigDaoImpl extends BaseDaoImpl<SysConfig>
  implements SysConfigDao
{
  public SysConfigDaoImpl()
  {
    super(SysConfig.class);
  }

  public SysConfig findByKey(String paramString)
  {
    String str = "from SysConfig vo where vo.configKey=?";
    Object[] arrayOfObject = { paramString };
    List localList = findByHql(str, arrayOfObject);
    if (localList.size() > 0)
      return (SysConfig)localList.get(0);
    return null;
  }

  public List<SysConfig> findConfigByTypeKey(String paramString)
  {
    String str = "from SysConfig vo where vo.typeKey=?";
    Object[] arrayOfObject = { paramString };
    return findByHql(str, arrayOfObject);
  }

  public List findTypeKeys()
  {
    String str = "select vo.typeKey from SysConfig vo group by vo.typeKey";
    Query localQuery = getSession().createQuery(str);
    return localQuery.list();
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.impl.SysConfigDaoImpl
 * JD-Core Version:    0.6.0
 */