package com.htsoft.oa.dao.flow.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.flow.ProUserAssignDao;
import com.htsoft.oa.model.flow.ProUserAssign;
import java.util.List;

public class ProUserAssignDaoImpl extends BaseDaoImpl<ProUserAssign>
  implements ProUserAssignDao
{
  public ProUserAssignDaoImpl()
  {
    super(ProUserAssign.class);
  }

  public List<ProUserAssign> getByDeployId(String paramString)
  {
    String str = "from ProUserAssign pua where pua.deployId=?";
    return findByHql(str, new Object[] { paramString });
  }

  public ProUserAssign getByDeployIdActivityName(String paramString1, String paramString2)
  {
    String str = "from ProUserAssign pua where pua.deployId=? and pua.activityName=?";
    return (ProUserAssign)findUnique(str, new Object[] { paramString1, paramString2 });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.impl.ProUserAssignDaoImpl
 * JD-Core Version:    0.6.0
 */