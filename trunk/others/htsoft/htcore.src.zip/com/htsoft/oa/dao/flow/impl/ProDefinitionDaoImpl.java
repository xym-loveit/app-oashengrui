package com.htsoft.oa.dao.flow.impl;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.flow.ProDefinitionDao;
import com.htsoft.oa.model.flow.ProDefinition;
import com.htsoft.oa.model.system.AppRole;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.Department;
import com.htsoft.oa.service.system.GlobalTypeService;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.List<Lcom.htsoft.oa.model.flow.ProDefinition;>;
import java.util.Set;
import javax.annotation.Resource;
import org.apache.commons.lang.StringUtils;

public class ProDefinitionDaoImpl extends BaseDaoImpl<ProDefinition>
  implements ProDefinitionDao
{

  @Resource
  private GlobalTypeService globalTypeService;

  public ProDefinitionDaoImpl()
  {
    super(ProDefinition.class);
  }

  public ProDefinition getByDeployId(String paramString)
  {
    String str = "from ProDefinition pd where pd.deployId=?";
    return (ProDefinition)findUnique(str, new Object[] { paramString });
  }

  public ProDefinition getByName(String paramString)
  {
    String str = "from ProDefinition pd where pd.name=?";
    return (ProDefinition)findUnique(str, new Object[] { paramString });
  }

  public List<ProDefinition> getByRights(AppUser paramAppUser, ProDefinition paramProDefinition, QueryFilter paramQueryFilter)
  {
    String str1 = "%," + paramAppUser.getUserId() + ",%";
    String str2 = "%," + paramAppUser.getDepartment().getDepId() + ",%";
    ArrayList localArrayList = new ArrayList();
    StringBuffer localStringBuffer = new StringBuffer("select pd from ProDefRights pr right join pr.proDefinition pd  where 1=1 ");
    if ((paramProDefinition != null) && (paramProDefinition.getName() != null))
    {
      localStringBuffer.append("and pd.name like = ?");
      localArrayList.add("%" + paramProDefinition.getName() + "%");
    }
    localStringBuffer.append("and (pr.userIds like ?  or pr.depIds like ? ");
    localArrayList.add(str1);
    localArrayList.add(str2);
    Set localSet = paramAppUser.getRoles();
    Object localObject = localSet.iterator();
    while (((Iterator)localObject).hasNext())
    {
      AppRole localAppRole = (AppRole)((Iterator)localObject).next();
      localStringBuffer.append("or pr.roleIds like ? ");
      String str3 = "%," + localAppRole.getRoleId() + ",%";
      localArrayList.add(str3);
    }
    localStringBuffer.append(")");
    localObject = findByHql(localStringBuffer.toString(), localArrayList.toArray());
    paramQueryFilter.getPagingBean().setTotalItems(((List)localObject).size());
    return (List<ProDefinition>)localObject;
  }

  public boolean checkNameByVo(ProDefinition paramProDefinition)
  {
    int i = 0;
    if (paramProDefinition.getDefId() == null)
      i = 1;
    StringBuffer localStringBuffer = new StringBuffer("from ProDefinition pd where pd.name = ?");
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(paramProDefinition.getName());
    if (i == 0)
    {
      localStringBuffer.append("and pd.defId != ?");
      localArrayList.add(paramProDefinition.getDefId());
    }
    List localList = findByHql(localStringBuffer.toString(), localArrayList.toArray());
    return localList.size() <= 0;
  }

  public boolean checkProcessNameByVo(ProDefinition paramProDefinition)
  {
    int i = 0;
    if (paramProDefinition.getDefId() == null)
      i = 1;
    StringBuffer localStringBuffer = new StringBuffer("from ProDefinition pd where pd.processName = ?");
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(paramProDefinition.getProcessName());
    if (i == 0)
    {
      localStringBuffer.append("and pd.defId != ?");
      localArrayList.add(paramProDefinition.getDefId());
    }
    List localList = findByHql(localStringBuffer.toString(), localArrayList.toArray());
    return localList.size() <= 0;
  }

  private List<ProDefinition> getByIds(List paramList)
  {
    String str = "from ProDefinition pd where pd.defId in (";
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 0; i < paramList.size(); i++)
      localStringBuffer.append(paramList.get(i).toString()).append(",");
    if (paramList.size() > 0)
    {
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
      str = str + localStringBuffer.toString() + ")";
      return findByHql(str);
    }
    return new ArrayList();
  }

  public List<ProDefinition> findRunningPro(ProDefinition paramProDefinition, Short paramShort, PagingBean paramPagingBean)
  {
    StringBuffer localStringBuffer = new StringBuffer("select distinct pd.defId from ProcessRun pr join pr.proDefinition pd  where pr.runStatus=?");
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(paramShort);
    if ((paramProDefinition != null) && (StringUtils.isNotEmpty(paramProDefinition.getName())))
    {
      localStringBuffer.append(" and pd.name like ?");
      localArrayList.add("%" + paramProDefinition.getName() + "%");
    }
    localStringBuffer.append(" order by pd.defId desc");
    List localList = find(localStringBuffer.toString(), localArrayList.toArray(), paramPagingBean);
    return getByIds(localList);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.impl.ProDefinitionDaoImpl
 * JD-Core Version:    0.6.0
 */