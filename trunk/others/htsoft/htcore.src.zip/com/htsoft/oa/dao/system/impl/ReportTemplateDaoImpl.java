package com.htsoft.oa.dao.system.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.system.ReportTemplateDao;
import com.htsoft.oa.model.system.ReportTemplate;

public class ReportTemplateDaoImpl extends BaseDaoImpl<ReportTemplate>
  implements ReportTemplateDao
{
  public ReportTemplateDaoImpl()
  {
    super(ReportTemplate.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.impl.ReportTemplateDaoImpl
 * JD-Core Version:    0.6.0
 */