package com.htsoft.oa.dao.flow.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.flow.FormTemplateDao;
import com.htsoft.oa.model.flow.FormTemplate;
import java.util.List;

public class FormTemplateDaoImpl extends BaseDaoImpl<FormTemplate>
  implements FormTemplateDao
{
  public FormTemplateDaoImpl()
  {
    super(FormTemplate.class);
  }

  public List<FormTemplate> getByMappingId(Long paramLong)
  {
    String str = "from FormTemplate ft where ft.formDefMapping.mappingId=?";
    return findByHql(str, new Object[] { paramLong });
  }

  public FormTemplate getByMappingIdNodeName(Long paramLong, String paramString)
  {
    String str = "from FormTemplate ft where ft.formDefMapping.mappingId=? and ft.nodeName=?";
    return (FormTemplate)findUnique(str, new Object[] { paramLong, paramString });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.impl.FormTemplateDaoImpl
 * JD-Core Version:    0.6.0
 */