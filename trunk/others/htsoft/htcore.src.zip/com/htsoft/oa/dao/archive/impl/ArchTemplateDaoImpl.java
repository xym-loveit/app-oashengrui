package com.htsoft.oa.dao.archive.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.archive.ArchTemplateDao;
import com.htsoft.oa.model.archive.ArchTemplate;

public class ArchTemplateDaoImpl extends BaseDaoImpl<ArchTemplate>
  implements ArchTemplateDao
{
  public ArchTemplateDaoImpl()
  {
    super(ArchTemplate.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.archive.impl.ArchTemplateDaoImpl
 * JD-Core Version:    0.6.0
 */