package com.htsoft.oa.dao.archive;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.archive.DocHistory;

public abstract interface DocHistoryDao extends BaseDao<DocHistory>
{
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.archive.DocHistoryDao
 * JD-Core Version:    0.6.0
 */