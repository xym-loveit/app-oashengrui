package com.htsoft.oa.dao.archive.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.archive.ArchivesDepDao;
import com.htsoft.oa.model.archive.ArchivesDep;

public class ArchivesDepDaoImpl extends BaseDaoImpl<ArchivesDep>
  implements ArchivesDepDao
{
  public ArchivesDepDaoImpl()
  {
    super(ArchivesDep.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.archive.impl.ArchivesDepDaoImpl
 * JD-Core Version:    0.6.0
 */