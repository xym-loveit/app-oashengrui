package com.htsoft.oa.dao.admin.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.admin.ConfSummaryDao;
import com.htsoft.oa.dao.admin.ConferenceDao;
import com.htsoft.oa.dao.system.FileAttachDao;
import com.htsoft.oa.model.admin.ConfSummary;
import com.htsoft.oa.model.admin.Conference;
import com.htsoft.oa.model.info.ShortMessage;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.info.ShortMessageService;
import java.util.HashSet;
import java.util.Set;
import javax.annotation.Resource;

public class ConfSummaryDaoImpl extends BaseDaoImpl<ConfSummary>
  implements ConfSummaryDao
{

  @Resource
  private ConferenceDao confDao;

  @Resource
  private FileAttachDao fileAttachDao;

  @Resource
  private ShortMessageService shortMessageService;

  public ConfSummaryDaoImpl()
  {
    super(ConfSummary.class);
  }

  public ConfSummary send(ConfSummary paramConfSummary, String paramString)
  {
    Conference localConference = (Conference)this.confDao.get(paramConfSummary.getConfId().getConfId());
    String str1 = localConference.getCompere() + "," + localConference.getRecorder() + "," + localConference.getAttendUsers();
    String str2 = "请查看主题为【" + localConference.getConfTopic() + "】的会议纪要信息！";
    this.shortMessageService.save(AppUser.SYSTEM_USER, str1, str2, ShortMessage.MSG_TYPE_SYS);
    return save(paramConfSummary, paramString);
  }

  public ConfSummary save(ConfSummary paramConfSummary, String paramString)
  {
    if ((paramString != null) && (!paramString.isEmpty()))
    {
      localObject = new HashSet();
      for (String str : paramString.split(","))
        ((Set)localObject).add(this.fileAttachDao.get(new Long(str)));
      paramConfSummary.setAttachFiles((Set)localObject);
    }
    Object localObject = (Conference)this.confDao.get(paramConfSummary.getConfId().getConfId());
    paramConfSummary.setConfId((Conference)localObject);
    return (ConfSummary)(ConfSummary)super.save(paramConfSummary);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.impl.ConfSummaryDaoImpl
 * JD-Core Version:    0.6.0
 */