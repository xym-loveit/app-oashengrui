package com.htsoft.oa.dao.info.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.info.NewsCommentDao;
import com.htsoft.oa.model.info.NewsComment;

public class NewsCommentDaoImpl extends BaseDaoImpl<NewsComment>
  implements NewsCommentDao
{
  public NewsCommentDaoImpl()
  {
    super(NewsComment.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.info.impl.NewsCommentDaoImpl
 * JD-Core Version:    0.6.0
 */