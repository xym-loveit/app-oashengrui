package com.htsoft.oa.dao.flow;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.flow.ProcessModule;

public abstract interface ProcessModuleDao extends BaseDao<ProcessModule>
{
  public abstract ProcessModule getByKey(String paramString);
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.ProcessModuleDao
 * JD-Core Version:    0.6.0
 */