package com.htsoft.oa.dao.archive;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.archive.ArchTemplate;

public abstract interface ArchTemplateDao extends BaseDao<ArchTemplate>
{
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.archive.ArchTemplateDao
 * JD-Core Version:    0.6.0
 */