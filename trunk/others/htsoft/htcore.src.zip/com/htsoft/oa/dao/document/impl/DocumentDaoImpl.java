package com.htsoft.oa.dao.document.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.document.DocumentDao;
import com.htsoft.oa.model.document.Document;
import com.htsoft.oa.model.system.AppRole;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.Department;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.List<Lcom.htsoft.oa.model.document.Document;>;
import java.util.Set;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;

public class DocumentDaoImpl extends BaseDaoImpl<Document>
  implements DocumentDao
{
  public DocumentDaoImpl()
  {
    super(Document.class);
  }

  public List<Document> findByIsShared(Document paramDocument, Date paramDate1, Date paramDate2, Long paramLong1, ArrayList<Long> paramArrayList, Long paramLong2, PagingBean paramPagingBean)
  {
    ArrayList localArrayList = new ArrayList();
    StringBuffer localStringBuffer = new StringBuffer();
    if (paramArrayList.contains(AppRole.SUPER_ROLEID))
    {
      localStringBuffer.append("select distinct vo.docId from Document vo where vo.isShared=1");
    }
    else
    {
      localStringBuffer.append("select distinct vo.docId from Document vo where vo.isShared=1 and ( 0=1 ");
      if (paramLong2 != null)
      {
        localStringBuffer.append(" or vo.sharedDepIds like ? ");
        localArrayList.add("%," + paramLong2 + ",%");
      }
      if (paramArrayList != null)
      {
        localObject = paramArrayList.iterator();
        while (((Iterator)localObject).hasNext())
        {
          Long localLong = (Long)((Iterator)localObject).next();
          localStringBuffer.append(" or vo.sharedRoleIds like ?");
          localArrayList.add("%," + localLong + ",%");
        }
      }
      if (paramLong1 != null)
      {
        localStringBuffer.append(" or vo.sharedUserIds like ?");
        localArrayList.add("%," + paramLong1 + ",%");
      }
      localStringBuffer.append(")");
    }
    if (paramDocument != null)
    {
      if (StringUtils.isNotEmpty(paramDocument.getDocName()))
      {
        localStringBuffer.append(" and vo.docName like ?");
        localArrayList.add("%" + paramDocument.getDocName() + "%");
      }
      if (StringUtils.isNotEmpty(paramDocument.getFullname()))
      {
        localStringBuffer.append(" and vo.fullname=?");
        localArrayList.add("," + paramDocument.getFullname() + ",");
      }
    }
    if (paramDate2 != null)
    {
      localStringBuffer.append(" and vo.createtime <= ?");
      localArrayList.add(paramDate2);
    }
    if (paramDate1 != null)
    {
      localStringBuffer.append(" and vo.createtime >= ?");
      localArrayList.add(paramDate1);
    }
    localStringBuffer.append(" order by vo desc");
    Object localObject = find(localStringBuffer.toString(), localArrayList.toArray(), paramPagingBean);
    return (List<Document>)getByIds((List)localObject);
  }

  private List<Document> getByIds(List paramList)
  {
    String str = "from Document doc where doc.docId in (";
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 0; i < paramList.size(); i++)
      localStringBuffer.append(paramList.get(i).toString()).append(",");
    if (paramList.size() > 0)
    {
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
      str = str + localStringBuffer.toString() + ")";
      return findByHql(str);
    }
    return new ArrayList();
  }

  public List<Document> findByPublic(String paramString, Document paramDocument, Date paramDate1, Date paramDate2, AppUser paramAppUser, PagingBean paramPagingBean)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    ArrayList localArrayList = new ArrayList();
    if (!paramAppUser.getRights().contains("__ALL"))
    {
      localStringBuffer.append("select distinct doc.docId from Document doc,DocFolder docF,DocPrivilege pr where doc.docFolder=docF and pr.docFolder=docF and docF.isShared=1 ");
      localObject1 = paramAppUser.getRoles();
      localObject2 = new StringBuffer();
      Object localObject4;
      if (localObject1 != null)
      {
        localObject3 = ((Set)localObject1).iterator();
        while (((Iterator)localObject3).hasNext())
        {
          localObject4 = ((AppRole)((Iterator)localObject3).next()).getRoleId();
          ((StringBuffer)localObject2).append(((Long)localObject4).toString() + ',');
        }
        if (((Set)localObject1).size() > 0)
          ((StringBuffer)localObject2).deleteCharAt(((StringBuffer)localObject2).length() - 1);
      }
      localStringBuffer.append(" and pr.rights>0 and ((pr.udrId=? and pr.flag=1)");
      Object localObject3 = Integer.valueOf(Integer.parseInt(paramAppUser.getUserId().toString()));
      localArrayList.add(localObject3);
      if (paramAppUser.getDepartment() != null)
      {
        localObject4 = Integer.valueOf(Integer.parseInt(paramAppUser.getDepartment().getDepId().toString()));
        localStringBuffer.append(" or (pr.udrId=? and pr.flag=2)");
        localArrayList.add(localObject4);
      }
      if ((((StringBuffer)localObject2).toString() != null) && (((StringBuffer)localObject2).length() > 0))
        localStringBuffer.append(" or (pr.udrId in (" + ((StringBuffer)localObject2).toString() + ") and pr.flag=3)");
      localStringBuffer.append(")");
    }
    else
    {
      localStringBuffer.append("select distinct doc.docId from Document doc,DocFolder docF where doc.docFolder=docF and docF.isShared=1");
    }
    if (paramString != null)
    {
      localStringBuffer.append(" and docF.path like ?");
      localArrayList.add(paramString + "%");
    }
    if (paramDocument != null)
    {
      if (paramDocument.getDocName() != null)
      {
        localStringBuffer.append(" and doc.docName like ?");
        localArrayList.add("%" + paramDocument.getDocName() + "%");
      }
      if (paramDocument.getAuthor() != null)
      {
        localStringBuffer.append(" and doc.author like ?");
        localArrayList.add("%" + paramDocument.getAuthor() + "%");
      }
      if (paramDocument.getKeywords() != null)
      {
        localStringBuffer.append(" and doc.keywords like ?");
        localArrayList.add("%" + paramDocument.getKeywords() + "%");
      }
    }
    if (paramDate2 != null)
    {
      localStringBuffer.append(" and doc.createtime <= ?");
      localArrayList.add(paramDate2);
    }
    if (paramDate1 != null)
    {
      localStringBuffer.append(" and doc.createtime >= ?");
      localArrayList.add(paramDate1);
    }
    localStringBuffer.append(" order by doc desc");
    Object localObject1 = find(localStringBuffer.toString(), localArrayList.toArray(), paramPagingBean);
    Object localObject2 = getByIds((List)localObject1);
    return (List<Document>)(List<Document>)(List<Document>)(List<Document>)localObject2;
  }

  public List<Document> findByPersonal(Long paramLong, Document paramDocument, Date paramDate1, Date paramDate2, String paramString, PagingBean paramPagingBean)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    ArrayList localArrayList = new ArrayList();
    localStringBuffer.append("select distinct doc.docId from Document doc,DocFolder docFolder where doc.docFolder=docFolder and docFolder.appUser.userId is not Null");
    if (paramString != null)
    {
      localStringBuffer.append(" and docFolder.path like ?");
      localArrayList.add(paramString + "%");
    }
    if (paramLong != null)
    {
      localStringBuffer.append(" and doc.appUser.userId=?");
      localArrayList.add(paramLong);
    }
    if ((paramDocument != null) && (paramDocument.getDocName() != null))
    {
      localStringBuffer.append(" and doc.docName like ?");
      localArrayList.add("%" + paramDocument.getDocName() + "%");
    }
    if (paramDate2 != null)
    {
      localStringBuffer.append(" and vo.createtime <= ?");
      localArrayList.add(paramDate2);
    }
    if (paramDate1 != null)
    {
      localStringBuffer.append(" and vo.createtime >= ?");
      localArrayList.add(paramDate1);
    }
    List localList = find(localStringBuffer.toString(), localArrayList.toArray(), paramPagingBean);
    return getByIds(localList);
  }

  public List<Document> findByFolder(String paramString)
  {
    String str = "select doc from Document doc where doc.docFolder.path like ?";
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(paramString + "%");
    return findByHql(str, localArrayList.toArray());
  }

  public List<Document> searchDocument(AppUser paramAppUser, String paramString, boolean paramBoolean, PagingBean paramPagingBean)
  {
    StringBuffer localStringBuffer1 = new StringBuffer("select distinct doc.docId from Document doc,DocFolder docF ");
    if (paramBoolean)
      localStringBuffer1.append(" ,DocPrivilege pr");
    localStringBuffer1.append(" where ");
    Set localSet = paramAppUser.getRoles();
    ArrayList localArrayList = new ArrayList();
    StringBuffer localStringBuffer2 = new StringBuffer();
    Iterator localIterator = localSet.iterator();
    if (localSet.size() > 0)
    {
      while (localIterator.hasNext())
      {
        localObject = ((AppRole)localIterator.next()).getRoleId();
        localStringBuffer2.append(((Long)localObject).toString() + ',');
      }
      if (localSet.size() > 0)
        localStringBuffer2.deleteCharAt(localStringBuffer2.length() - 1);
    }
    localStringBuffer1.append(" ((doc.isShared=1 ");
    if (!paramAppUser.getRights().contains("__ALL"))
    {
      localStringBuffer1.append(" and (0=1");
      if (paramAppUser.getDepartment() != null)
      {
        localStringBuffer1.append(" or doc.sharedDepIds like ? ");
        localArrayList.add("%," + paramAppUser.getDepartment().getDepId() + ",%");
      }
      while (localIterator.hasNext())
      {
        localObject = ((AppRole)localIterator.next()).getRoleId();
        localStringBuffer1.append(" or doc.sharedRoleIds like ?");
        localArrayList.add("%," + ((Long)localObject).toString() + ",%");
      }
      if (paramAppUser.getUserId() != null)
      {
        localStringBuffer1.append(" or doc.sharedUserIds like ?");
        localArrayList.add("%," + paramAppUser.getUserId() + ",%");
      }
      localStringBuffer1.append(")");
    }
    localStringBuffer1.append(") or (doc.isShared=0 and doc.docFolder=docF and docF.appUser.userId is not Null and doc.appUser.userId=? )");
    localArrayList.add(paramAppUser.getUserId());
    localStringBuffer1.append(" or (doc.docFolder=docF and docF.isShared=1");
    if ((paramBoolean) && (!paramAppUser.getRights().contains("__ALL")))
    {
      localStringBuffer1.append(" and pr.docFolder=docF");
      localStringBuffer1.append(" and pr.rights>0 and ((pr.udrId=? and pr.flag=1)");
      localObject = Integer.valueOf(Integer.parseInt(paramAppUser.getUserId().toString()));
      localArrayList.add(localObject);
      if (paramAppUser.getDepartment() != null)
      {
        Integer localInteger = Integer.valueOf(Integer.parseInt(paramAppUser.getDepartment().getDepId().toString()));
        localStringBuffer1.append(" or (pr.udrId=? and pr.flag=2)");
        localArrayList.add(localInteger);
      }
      if ((localStringBuffer2.toString() != null) && (localStringBuffer2.length() > 1))
        localStringBuffer1.append(" or (pr.udrId in (" + localStringBuffer2.toString() + ") and pr.flag=3)");
      localStringBuffer1.append(")");
    }
    localStringBuffer1.append(")");
    localStringBuffer1.append(")");
    if (StringUtils.isNotEmpty(paramString))
    {
      localStringBuffer1.append(" and (doc.content like ? or doc.docName like ?)");
      localArrayList.add("%" + paramString + "%");
      localArrayList.add("%" + paramString + "%");
    }
    localStringBuffer1.append("  order by doc desc");
    this.logger.info("HQL:" + localStringBuffer1.toString());
    Object localObject = find(localStringBuffer1.toString(), localArrayList.toArray(), paramPagingBean);
    return (List<Document>)getByIds((List)localObject);
  }

  public List<Document> findByFolder(Long paramLong)
  {
    return findByHql("from Document doc where doc.docFolder.folderId=?", new Object[] { paramLong });
  }

  public List<Document> findByPersonal(Long paramLong, Document paramDocument, Date paramDate1, Date paramDate2, String paramString)
  {
    PagingBean localPagingBean = new PagingBean(0, 10000);
    StringBuffer localStringBuffer = new StringBuffer();
    ArrayList localArrayList = new ArrayList();
    localStringBuffer.append("select distinct doc.docId from Document doc join doc.docFolder df where df.appUser.userId is not Null");
    if (paramString != null)
    {
      localStringBuffer.append(" and df.path like ?");
      localArrayList.add(paramString + "%");
    }
    if (paramLong != null)
    {
      localStringBuffer.append(" and doc.appUser.userId=?");
      localArrayList.add(paramLong);
    }
    if ((paramDocument != null) && (paramDocument.getDocName() != null))
    {
      localStringBuffer.append(" and doc.docName like ?");
      localArrayList.add("%" + paramDocument.getDocName() + "%");
    }
    if (paramDate2 != null)
    {
      localStringBuffer.append(" and vo.createtime <= ?");
      localArrayList.add(paramDate2);
    }
    if (paramDate1 != null)
    {
      localStringBuffer.append(" and vo.createtime >= ?");
      localArrayList.add(paramDate1);
    }
    localStringBuffer.append(" order by doc desc");
    List localList = find(localStringBuffer.toString(), localArrayList.toArray(), localPagingBean);
    return getByIds(localList);
  }

  public List<Document> findByOnline(Document paramDocument, Date paramDate1, Date paramDate2, AppUser paramAppUser)
  {
    PagingBean localPagingBean = new PagingBean(0, 10000);
    StringBuffer localStringBuffer = new StringBuffer();
    ArrayList localArrayList = new ArrayList();
    if (!paramAppUser.getRights().contains("__ALL"))
    {
      localStringBuffer.append("select distinct doc.docId from Document doc,DocFolder docF,DocPrivilege pr where doc.docFolder=docF and pr.docFolder=docF and docF.isShared=2 ");
      localObject1 = paramAppUser.getRoles();
      localObject2 = new StringBuffer();
      Object localObject4;
      if (localObject1 != null)
      {
        localObject3 = ((Set)localObject1).iterator();
        while (((Iterator)localObject3).hasNext())
        {
          localObject4 = ((AppRole)((Iterator)localObject3).next()).getRoleId();
          ((StringBuffer)localObject2).append(((Long)localObject4).toString() + ',');
        }
        if (((Set)localObject1).size() > 0)
          ((StringBuffer)localObject2).deleteCharAt(((StringBuffer)localObject2).length() - 1);
      }
      localStringBuffer.append(" and pr.rights>0 and ((pr.udrId=? and pr.flag=1)");
      Object localObject3 = Integer.valueOf(Integer.parseInt(paramAppUser.getUserId().toString()));
      localArrayList.add(localObject3);
      if (paramAppUser.getDepartment() != null)
      {
        localObject4 = Integer.valueOf(Integer.parseInt(paramAppUser.getDepartment().getDepId().toString()));
        localStringBuffer.append(" or (pr.udrId=? and pr.flag=2)");
        localArrayList.add(localObject4);
      }
      if ((((StringBuffer)localObject2).toString() != null) && (((StringBuffer)localObject2).length() > 0))
        localStringBuffer.append(" or (pr.udrId in (" + ((StringBuffer)localObject2).toString() + ") and pr.flag=3)");
      localStringBuffer.append(")");
    }
    else
    {
      localStringBuffer.append("select distinct doc.docId from Document doc,DocFolder docF where doc.docFolder=docF and docF.isShared=2");
    }
    if ((paramDocument != null) && (paramDocument.getDocName() != null))
    {
      localStringBuffer.append(" and doc.docName like ?");
      localArrayList.add("%" + paramDocument.getDocName() + "%");
    }
    if (paramDate2 != null)
    {
      localStringBuffer.append(" and doc.createtime <= ?");
      localArrayList.add(paramDate2);
    }
    if (paramDate1 != null)
    {
      localStringBuffer.append(" and doc.createtime >= ?");
      localArrayList.add(paramDate1);
    }
    localStringBuffer.append(" order by doc desc");
    Object localObject1 = find(localStringBuffer.toString(), localArrayList.toArray(), localPagingBean);
    Object localObject2 = getByIds((List)localObject1);
    return (List<Document>)(List<Document>)(List<Document>)(List<Document>)localObject2;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.document.impl.DocumentDaoImpl
 * JD-Core Version:    0.6.0
 */