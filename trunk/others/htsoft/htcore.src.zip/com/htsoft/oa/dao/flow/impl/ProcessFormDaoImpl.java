package com.htsoft.oa.dao.flow.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.flow.ProcessFormDao;
import com.htsoft.oa.model.flow.ProcessForm;
import java.util.List;

public class ProcessFormDaoImpl extends BaseDaoImpl<ProcessForm>
  implements ProcessFormDao
{
  public ProcessFormDaoImpl()
  {
    super(ProcessForm.class);
  }

  public List getByRunId(Long paramLong)
  {
    String str = "from ProcessForm pf where pf.processRun.runId=? and pf.endtime is not null order by pf.formId asc";
    return findByHql(str, new Object[] { paramLong });
  }

  public ProcessForm getByRunIdActivityName(Long paramLong, String paramString)
  {
    Integer localInteger = Integer.valueOf(getActvityExeTimes(paramLong, paramString).intValue());
    String str = "from ProcessForm pf where pf.processRun.runId=? and pf.activityName=? and pf.sn=?";
    return (ProcessForm)findUnique(str, new Object[] { paramLong, paramString, localInteger });
  }

  public Long getActvityExeTimes(Long paramLong, String paramString)
  {
    String str = "select count(pf.formId) from ProcessForm pf where pf.processRun.runId=? and pf.activityName=? ";
    return (Long)findUnique(str, new Object[] { paramLong, paramString });
  }

  public ProcessForm getByTaskId(String paramString)
  {
    String str = "from ProcessForm pf where pf.taskId=? order by pf.createtime desc";
    List localList = findByHql(str, new Object[] { paramString });
    if (localList.size() > 0)
      return (ProcessForm)localList.get(0);
    return null;
  }

  public ProcessForm getByRunIdTaskName(Long paramLong, String paramString)
  {
    String str = "from ProcessForm pf where pf.processRun.runId=?  and pf.activityName=?";
    List localList = findByHql(str, new Object[] { paramLong, paramString });
    if (localList.size() > 0)
      return (ProcessForm)localList.get(0);
    return null;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.impl.ProcessFormDaoImpl
 * JD-Core Version:    0.6.0
 */