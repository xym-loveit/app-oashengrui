package com.htsoft.oa.dao.flow;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.flow.TaskSignData;
import java.util.List;

public abstract interface TaskSignDataDao extends BaseDao<TaskSignData>
{
  public abstract Long getVoteCounts(String paramString, Short paramShort);

  public abstract List<TaskSignData> getByTaskId(String paramString);
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.TaskSignDataDao
 * JD-Core Version:    0.6.0
 */