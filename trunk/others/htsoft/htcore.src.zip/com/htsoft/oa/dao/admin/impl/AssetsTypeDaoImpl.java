package com.htsoft.oa.dao.admin.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.admin.AssetsTypeDao;
import com.htsoft.oa.model.admin.AssetsType;

public class AssetsTypeDaoImpl extends BaseDaoImpl<AssetsType>
  implements AssetsTypeDao
{
  public AssetsTypeDaoImpl()
  {
    super(AssetsType.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.admin.impl.AssetsTypeDaoImpl
 * JD-Core Version:    0.6.0
 */