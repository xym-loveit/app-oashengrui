package com.htsoft.oa.dao.info.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.info.SectionDao;
import com.htsoft.oa.model.info.Section;
import java.sql.SQLException;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class SectionDaoImpl extends BaseDaoImpl<Section>
  implements SectionDao
{
  public SectionDaoImpl()
  {
    super(Section.class);
  }

  public Integer getLastColumn()
  {
    Integer localInteger = (Integer)getHibernateTemplate().execute(new HibernateCallback()
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Query localQuery = paramSession.createQuery("select max(st.rowNumber) from Section st where st.colNumber = ? ");
        localQuery.setInteger(0, Section.COLUMN_ONE.intValue());
        return localQuery.uniqueResult();
      }
    });
    if (localInteger == null)
      localInteger = Integer.valueOf(1);
    return localInteger;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.info.impl.SectionDaoImpl
 * JD-Core Version:    0.6.0
 */