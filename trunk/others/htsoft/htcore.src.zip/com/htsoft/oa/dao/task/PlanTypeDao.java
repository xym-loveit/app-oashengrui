package com.htsoft.oa.dao.task;

import com.htsoft.core.dao.BaseDao;
import com.htsoft.oa.model.task.PlanType;

public abstract interface PlanTypeDao extends BaseDao<PlanType>
{
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.task.PlanTypeDao
 * JD-Core Version:    0.6.0
 */