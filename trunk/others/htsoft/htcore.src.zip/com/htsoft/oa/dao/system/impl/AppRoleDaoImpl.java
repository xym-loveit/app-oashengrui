package com.htsoft.oa.dao.system.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.oa.dao.system.AppRoleDao;
import com.htsoft.oa.model.system.AppFunction;
import com.htsoft.oa.model.system.AppRole;
import com.htsoft.oa.model.system.FunUrl;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class AppRoleDaoImpl extends BaseDaoImpl<AppRole>
  implements AppRoleDao
{
  public AppRoleDaoImpl()
  {
    super(AppRole.class);
  }

  public AppRole getByRoleName(String paramString)
  {
    String str = "from AppRole ar where ar.roleName=?";
    return (AppRole)findUnique(str, new Object[] { paramString });
  }

  public HashMap<String, Set<String>> getSecurityDataSource()
  {
    HashMap localHashMap = new HashMap();
    getHibernateTemplate().execute(new HibernateCallback(localHashMap)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        String str = "from AppRole";
        Query localQuery = paramSession.createQuery(str);
        List localList = localQuery.list();
        Iterator localIterator1 = localList.iterator();
        while (localIterator1.hasNext())
        {
          AppRole localAppRole = (AppRole)localIterator1.next();
          TreeSet localTreeSet = new TreeSet();
          Iterator localIterator2 = localAppRole.getFunctions().iterator();
          while (localIterator2.hasNext())
          {
            AppFunction localAppFunction = (AppFunction)localIterator2.next();
            Iterator localIterator3 = localAppFunction.getFunUrls().iterator();
            while (localIterator3.hasNext())
              localTreeSet.add(((FunUrl)localIterator3.next()).getUrlPath());
          }
          this.val$source.put(localAppRole.getName(), localTreeSet);
        }
        return null;
      }
    });
    return localHashMap;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.system.impl.AppRoleDaoImpl
 * JD-Core Version:    0.6.0
 */