package com.htsoft.oa.dao.flow.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.flow.FormTableDao;
import com.htsoft.oa.model.flow.FormTable;
import com.htsoft.oa.model.system.AppRole;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.Department;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.List<Lcom.htsoft.oa.model.flow.FormTable;>;
import java.util.Set;
import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class FormTableDaoImpl extends BaseDaoImpl<FormTable>
  implements FormTableDao
{
  public FormTableDaoImpl()
  {
    super(FormTable.class);
  }

  public List<FormTable> getListFromPro(String paramString1, String paramString2, AppUser paramAppUser, PagingBean paramPagingBean)
  {
    ArrayList localArrayList = new ArrayList();
    String str1 = " select DISTINCT formTable from  FormTable formTable , FormDef formDef , FormDefMapping formDefMapping, ProDefinition proDefinition  where 1=1 and formTable.formDef=formDef  and formDef=formDefMapping.formDef  and formDefMapping.proDefinition.defId=proDefinition.defId  and formTable.tableName like ?";
    paramString2 = "%" + paramString2 + "%";
    localArrayList.add(paramString2);
    Long localLong1 = new Long(0L);
    if (paramString1 != null)
      localLong1 = Long.valueOf(Long.parseLong(paramString1));
    if (localLong1.longValue() != 0L)
    {
      str1 = str1 + " and  proDefinition.proType.proTypeId =?";
      localArrayList.add(localLong1);
    }
    if (paramAppUser.isSupperManage())
      return findByHql(str1, localArrayList.toArray(), paramPagingBean);
    String str2 = "'%," + paramAppUser.getUserId() + ",%'";
    String str3 = "'%," + paramAppUser.getDepartment().getDepId() + ",%'";
    StringBuffer localStringBuffer = new StringBuffer("select pd.defId from ProDefRights pr right join pr.proDefinition pd  where 1=1 ");
    localStringBuffer.append("and (pr.userIds like " + str2 + "  or pr.depIds like " + str3 + " ");
    Set localSet = paramAppUser.getRoles();
    Object localObject1 = localSet.iterator();
    Object localObject2;
    Object localObject3;
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (AppRole)((Iterator)localObject1).next();
      localObject3 = "'%," + ((AppRole)localObject2).getRoleId() + ",%'";
      localStringBuffer.append("or pr.roleIds like " + (String)localObject3 + " ");
    }
    localStringBuffer.append(")");
    localObject1 = getHibernateTemplate().find(localStringBuffer.toString());
    if ((localObject1 != null) && (((List)localObject1).size() > 0))
    {
      localObject2 = "";
      localObject3 = ((List)localObject1).iterator();
      while (((Iterator)localObject3).hasNext())
      {
        Long localLong2 = (Long)((Iterator)localObject3).next();
        localObject2 = (String)localObject2 + localLong2 + ",";
      }
      localObject2 = ((String)localObject2).substring(0, ((String)localObject2).length() - 1);
      str1 = str1 + " and proDefinition.defId in (" + (String)localObject2 + ")";
    }
    return (List<FormTable>)(List<FormTable>)(List<FormTable>)findByHql(str1, localArrayList.toArray(), paramPagingBean);
  }

  public List<FormTable> getAllAndFields()
  {
    return (List)getHibernateTemplate().execute(new HibernateCallback()
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        String str = "from FormTable ft ";
        Query localQuery = paramSession.createQuery(str);
        List localList = localQuery.list();
        for (int i = 0; i < localList.size(); i++)
        {
          FormTable localFormTable = (FormTable)localList.get(i);
          Hibernate.initialize(localFormTable.getFormFields());
        }
        return localList;
      }
    });
  }

  public List<FormTable> findByTableKey(String paramString)
  {
    String str = "from FormTable ft where ft.tableKey=?";
    return findByHql(str, new Object[] { paramString });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.impl.FormTableDaoImpl
 * JD-Core Version:    0.6.0
 */