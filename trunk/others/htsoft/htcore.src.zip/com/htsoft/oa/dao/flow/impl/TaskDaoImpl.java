package com.htsoft.oa.dao.flow.impl;

import com.htsoft.core.dao.impl.BaseDaoImpl;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.dao.flow.TaskDao;
import com.htsoft.oa.model.flow.JbpmTask;
import com.htsoft.oa.model.system.AppRole;
import com.htsoft.oa.model.system.AppUser;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.apache.commons.lang.StringUtils;
import org.jbpm.api.Execution;
import org.jbpm.pvm.internal.model.ExecutionImpl;
import org.jbpm.pvm.internal.task.TaskImpl;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class TaskDaoImpl extends BaseDaoImpl<TaskImpl>
  implements TaskDao
{
  public TaskDaoImpl()
  {
    super(TaskImpl.class);
  }

  public List<TaskImpl> getPersonTasks(String paramString, PagingBean paramPagingBean)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("select task from org.jbpm.pvm.internal.task.TaskImpl task  where task.assignee=?");
    localStringBuffer.append(" order by task.createTime desc");
    return findByHql(localStringBuffer.toString(), new Object[] { paramString }, paramPagingBean);
  }

  public List<TaskImpl> getAllTasks(String paramString, PagingBean paramPagingBean)
  {
    ArrayList localArrayList = new ArrayList();
    String str = "from org.jbpm.pvm.internal.task.TaskImpl task where 1=1";
    if (StringUtils.isNotEmpty(paramString))
    {
      str = str + " and task.name like ?";
      localArrayList.add("%" + paramString + "%");
    }
    str = str + " order by task.createTime desc";
    return findByHql(str, localArrayList.toArray(), paramPagingBean);
  }

  public List<TaskImpl> getCandidateTasks(String paramString, PagingBean paramPagingBean)
  {
    AppUser localAppUser = (AppUser)getHibernateTemplate().load(AppUser.class, new Long(paramString));
    Iterator localIterator = localAppUser.getRoles().iterator();
    StringBuffer localStringBuffer1 = new StringBuffer();
    int i = 0;
    while (localIterator.hasNext())
    {
      if (i++ > 0)
        localStringBuffer1.append(",");
      localStringBuffer1.append("'" + ((AppRole)localIterator.next()).getRoleId().toString() + "'");
    }
    StringBuffer localStringBuffer2 = new StringBuffer();
    localStringBuffer2.append("select distinct task from org.jbpm.pvm.internal.task.TaskImpl task left join task.participations pt ");
    localStringBuffer2.append(" where task.assignee is null and pt.type = 'candidate' and ( pt.userId=? ");
    if (localAppUser.getRoles().size() > 0)
      localStringBuffer2.append(" or pt.groupId in (" + localStringBuffer1.toString() + ")");
    localStringBuffer2.append(")");
    localStringBuffer2.append(" order by task.createTime desc");
    return findByHql(localStringBuffer2.toString(), new Object[] { paramString, paramString }, paramPagingBean);
  }

  public List<TaskImpl> getTasksByUserId(String paramString, PagingBean paramPagingBean)
  {
    AppUser localAppUser = (AppUser)getHibernateTemplate().load(AppUser.class, new Long(paramString));
    Iterator localIterator = localAppUser.getRoles().iterator();
    StringBuffer localStringBuffer1 = new StringBuffer();
    int i = 0;
    while (localIterator.hasNext())
    {
      if (i++ > 0)
        localStringBuffer1.append(",");
      localStringBuffer1.append("'" + ((AppRole)localIterator.next()).getRoleId().toString() + "'");
    }
    StringBuffer localStringBuffer2 = new StringBuffer();
    localStringBuffer2.append("select distinct task from org.jbpm.pvm.internal.task.TaskImpl task left join task.participations pt where task.assignee=?");
    localStringBuffer2.append(" or ( task.assignee is null and pt.type = 'candidate' and  ( pt.userId = ? ");
    if (localAppUser.getRoles().size() > 0)
      localStringBuffer2.append(" or pt.groupId in (" + localStringBuffer1.toString() + ")");
    localStringBuffer2.append("))");
    localStringBuffer2.append(" order by task.createTime desc");
    return findByHql(localStringBuffer2.toString(), new Object[] { paramString, paramString }, paramPagingBean);
  }

  public List<JbpmTask> getByActivityNameVarKeyLongVal(String paramString1, String paramString2, Long paramLong)
  {
    String str = "select task.DBID_ taskId, task.ASSIGNEE_ assignee from jbpm4_task task join jbpm4_variable var on task.EXECUTION_=var.EXECUTION_ where  task.ACTIVITY_NAME_=? and var.KEY_=? and var.LONG_VALUE_=?";
    List localList = this.jdbcTemplate.query(str, new Object[] { paramString1, paramString2, paramLong }, new RowMapper()
    {
      public Object mapRow(ResultSet paramResultSet, int paramInt)
        throws SQLException
      {
        JbpmTask localJbpmTask = new JbpmTask();
        Long localLong = Long.valueOf(paramResultSet.getLong("taskId"));
        String str = paramResultSet.getString("assignee");
        localJbpmTask.setAssignee(str);
        localJbpmTask.setTaskId(localLong);
        return localJbpmTask;
      }
    });
    return new ArrayList(localList);
  }

  public List<Long> getGroupByTask(Long paramLong)
  {
    String str = "select pa.GROUPID_ groupId from jbpm4_participation pa  where pa.TYPE_ = 'candidate'and pa.TASK_=?";
    List localList = this.jdbcTemplate.query(str, new Object[] { paramLong }, new RowMapper()
    {
      public Object mapRow(ResultSet paramResultSet, int paramInt)
        throws SQLException
      {
        String str = paramResultSet.getString("groupId");
        return str;
      }
    });
    return new ArrayList(localList);
  }

  public List<Long> getUserIdByTask(Long paramLong)
  {
    String str = "from org.jbpm.pvm.internal.task.TaskImpl task where task.superTask.id=?";
    Object[] arrayOfObject = { paramLong };
    List localList = findByHql(str, arrayOfObject);
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      TaskImpl localTaskImpl = (TaskImpl)localIterator.next();
      localArrayList.add(new Long(localTaskImpl.getAssignee()));
    }
    return localArrayList;
  }

  public void removeExeByParentId(Long paramLong)
  {
    String str = "delete from ExecutionImpl exi where exi.parent.dbid=? ";
    update(str, new Object[] { paramLong });
  }

  public Execution getExecutionByDbid(Long paramLong)
  {
    String str = "from ExecutionImpl exi where exi.dbid=?";
    return (Execution)findUnique(str, new Object[] { paramLong });
  }

  public void save(ExecutionImpl paramExecutionImpl)
  {
    getHibernateTemplate().save(paramExecutionImpl);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.dao.flow.impl.TaskDaoImpl
 * JD-Core Version:    0.6.0
 */