package com.htsoft.oa.entity;

import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name="swf_general")
public class GeneralEntity extends FormEntity
{
  private static final long serialVersionUID = -394073212728617070L;

  @Id
  @GeneratedValue(strategy=GenerationType.AUTO)
  private Long entityId;
  private String itemSubject;
  private String itemDescp;
  private Date createtime;
  private Long runId;

  public Long getEntityId()
  {
    return this.entityId;
  }

  public void setEntityId(Long paramLong)
  {
    this.entityId = paramLong;
  }

  public String getItemSubject()
  {
    return this.itemSubject;
  }

  public void setItemSubject(String paramString)
  {
    this.itemSubject = paramString;
  }

  public String getItemDescp()
  {
    return this.itemDescp;
  }

  public void setItemDescp(String paramString)
  {
    this.itemDescp = paramString;
  }

  public Long getRunId()
  {
    return this.runId;
  }

  public void setRunId(Long paramLong)
  {
    this.runId = paramLong;
  }

  public boolean equals(Object paramObject)
  {
    return EqualsBuilder.reflectionEquals(this, paramObject);
  }

  public int hashCode()
  {
    return HashCodeBuilder.reflectionHashCode(this);
  }

  public String toString()
  {
    return ToStringBuilder.reflectionToString(this);
  }

  public Date getCreatetime()
  {
    return this.createtime;
  }

  public void setCreatetime(Date paramDate)
  {
    this.createtime = paramDate;
  }

  public String getHtml()
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<b>事项标题:</b>" + this.itemSubject + "<br/><b>事项描述:</b>" + this.itemDescp);
    if (this.createtime != null)
      localStringBuffer.append("<br/>创建时间:").append(localSimpleDateFormat.format(this.createtime));
    return localStringBuffer.toString();
  }

  public static void main(String[] paramArrayOfString)
    throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
  {
    GeneralEntity localGeneralEntity1 = GeneralEntity.class;
    System.out.println("name:" + localGeneralEntity1.getName());
    GeneralEntity localGeneralEntity2 = new GeneralEntity();
    localGeneralEntity2.setEntityId(Long.valueOf(10L));
    localGeneralEntity2.setItemSubject("title");
    localGeneralEntity2.setItemDescp("descpe");
    System.out.println("html:" + localGeneralEntity2.getHtml());
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.entity.GeneralEntity
 * JD-Core Version:    0.6.0
 */