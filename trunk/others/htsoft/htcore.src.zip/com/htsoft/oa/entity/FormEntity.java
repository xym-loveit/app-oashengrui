package com.htsoft.oa.entity;

import com.htsoft.core.util.FunctionsUtil;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;

public class FormEntity
  implements Serializable
{
  public String getHtml()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    Field[] arrayOfField1 = getClass().getDeclaredFields();
    for (Field localField : arrayOfField1)
      try
      {
        Method localMethod = getClass().getDeclaredMethod("get" + FunctionsUtil.makeFirstLetterUpperCase(localField.getName()), new Class[0]);
        if (localMethod != null)
        {
          Object localObject = localMethod.invoke(this, new Object[0]);
          if (localField.getType().toString().indexOf("java.util.Date") != -1)
          {
            SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            localObject = localSimpleDateFormat.format(localObject);
          }
          localStringBuffer.append("<b>" + localField.getName() + ":</b>").append(((Object)localObject).toString()).append("<br/>");
        }
      }
      catch (Exception localException)
      {
      }
    return (String)localStringBuffer.toString();
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.entity.FormEntity
 * JD-Core Version:    0.6.0
 */