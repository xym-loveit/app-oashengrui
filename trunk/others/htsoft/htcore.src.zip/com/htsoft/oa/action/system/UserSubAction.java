package com.htsoft.oa.action.system;

import com.google.gson.Gson;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.UserSub;
import com.htsoft.oa.service.system.AppUserService;
import com.htsoft.oa.service.system.UserSubService;
import flexjson.JSONSerializer;
import flexjson.transformer.DateTransformer;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class UserSubAction extends BaseAction
{

  @Resource
  private UserSubService userSubService;
  private UserSub userSub;

  @Resource
  private AppUserService appUserService;
  private Long subId;

  public Long getSubId()
  {
    return this.subId;
  }

  public void setSubId(Long paramLong)
  {
    this.subId = paramLong;
  }

  public UserSub getUserSub()
  {
    return this.userSub;
  }

  public void setUserSub(UserSub paramUserSub)
  {
    this.userSub = paramUserSub;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_userId_L_EQ", ContextUtil.getCurrentUserId().toString());
    localQueryFilter.addFilter("Q_subAppUser.delFlag_SN_EQ", "0");
    List localList = this.userSubService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localJSONSerializer.transform(new DateTransformer("yyyy-MM-dd"), new String[] { "subAppUser.accessionTime" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "subAppUser.password", "class" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String combo()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_userId_L_EQ", ContextUtil.getCurrentUserId().toString());
    List localList = this.userSubService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      UserSub localUserSub = (UserSub)localIterator.next();
      localStringBuffer.append("['" + localUserSub.getSubAppUser().getUserId().toString() + "','" + localUserSub.getSubAppUser().getFullname() + "'],");
    }
    if (localList.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.userSubService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    UserSub localUserSub = (UserSub)this.userSubService.get(this.subId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localUserSub));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    String str = getRequest().getParameter("subUserIds");
    String[] arrayOfString = str.split(",");
    for (int i = 0; i < arrayOfString.length; i++)
    {
      UserSub localUserSub = new UserSub();
      localUserSub.setUserId(ContextUtil.getCurrentUserId());
      Long localLong = new Long(arrayOfString[i]);
      AppUser localAppUser = (AppUser)this.appUserService.get(localLong);
      localUserSub.setSubAppUser(localAppUser);
      this.userSubService.save(localUserSub);
    }
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.UserSubAction
 * JD-Core Version:    0.6.0
 */