package com.htsoft.oa.action.communicate;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.communicate.SmsHistory;
import com.htsoft.oa.model.communicate.SmsMobile;
import com.htsoft.oa.service.communicate.SmsHistoryService;
import com.htsoft.oa.service.communicate.SmsMobileService;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class SmsHistoryAction extends BaseAction
{

  @Resource
  private SmsHistoryService smsHistoryService;

  @Resource
  private SmsMobileService smsMobileService;
  private SmsHistory smsHistory;
  private Long smsId;

  public Long getSmsId()
  {
    return this.smsId;
  }

  public void setSmsId(Long paramLong)
  {
    this.smsId = paramLong;
  }

  public SmsHistory getSmsHistory()
  {
    return this.smsHistory;
  }

  public void setSmsHistory(SmsHistory paramSmsHistory)
  {
    this.smsHistory = paramSmsHistory;
  }

  public String list()
  {
    String str = getRequest().getParameter("status");
    List localList = null;
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    if ((StringUtils.isNotEmpty(str)) && (str.equals(SmsMobile.STATUS_NOT_SENDED.toString())))
      localList = this.smsMobileService.getAll(localQueryFilter);
    else
      localList = this.smsHistoryService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    localStringBuffer.append(localGson.toJson(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.smsHistoryService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    SmsHistory localSmsHistory = (SmsHistory)this.smsHistoryService.get(this.smsId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localSmsHistory));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.smsHistoryService.save(this.smsHistory);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.communicate.SmsHistoryAction
 * JD-Core Version:    0.6.0
 */