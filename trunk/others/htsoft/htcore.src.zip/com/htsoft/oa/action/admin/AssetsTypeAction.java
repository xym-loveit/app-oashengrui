package com.htsoft.oa.action.admin;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.admin.AssetsType;
import com.htsoft.oa.service.admin.AssetsTypeService;
import com.htsoft.oa.service.admin.FixedAssetsService;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class AssetsTypeAction extends BaseAction
{

  @Resource
  private AssetsTypeService assetsTypeService;
  private AssetsType assetsType;

  @Resource
  private FixedAssetsService fixedAssetsService;
  private Long assetsTypeId;

  public Long getAssetsTypeId()
  {
    return this.assetsTypeId;
  }

  public void setAssetsTypeId(Long paramLong)
  {
    this.assetsTypeId = paramLong;
  }

  public AssetsType getAssetsType()
  {
    return this.assetsType;
  }

  public void setAssetsType(AssetsType paramAssetsType)
  {
    this.assetsType = paramAssetsType;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.assetsTypeService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String tree()
  {
    List localList = this.assetsTypeService.getAll();
    StringBuffer localStringBuffer = new StringBuffer("[{id:'0',text:'资产类型',expanded:true,children:[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      AssetsType localAssetsType = (AssetsType)localIterator.next();
      localStringBuffer.append("{id:'" + localAssetsType.getAssetsTypeId() + "',text:'" + localAssetsType.getTypeName() + "',leaf:true},");
    }
    if (localList.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
      {
        QueryFilter localQueryFilter = new QueryFilter(getRequest());
        localQueryFilter.addFilter("Q_assetsType.assetsTypeId_L_EQ", str);
        List localList = this.fixedAssetsService.getAll(localQueryFilter);
        if (localList.size() > 0)
        {
          this.jsonString = "{success:false,message:'该类型下还有资产，请将资产移走后再进行删除！'}";
          return "success";
        }
        this.assetsTypeService.remove(new Long(str));
      }
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    AssetsType localAssetsType = (AssetsType)this.assetsTypeService.get(this.assetsTypeId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localAssetsType));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.assetsTypeService.save(this.assetsType);
    setJsonString("{success:true}");
    return "success";
  }

  public String combox()
  {
    List localList = this.assetsTypeService.getAll();
    StringBuffer localStringBuffer = new StringBuffer("[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      AssetsType localAssetsType = (AssetsType)localIterator.next();
      localStringBuffer.append("['" + localAssetsType.getAssetsTypeId() + "','" + localAssetsType.getTypeName() + "'],");
    }
    if (localList.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.admin.AssetsTypeAction
 * JD-Core Version:    0.6.0
 */