package com.htsoft.oa.action.menu;

import com.htsoft.core.util.AppUtil;
import com.htsoft.core.web.action.BaseAction;
import java.io.File;
import java.util.Iterator;
import java.util.List;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class IconAction extends BaseAction
{
  private static String xmlPath = AppUtil.getAppAbsolutePath().replace("\\", "/") + "/css/icon.xml";
  private String id;

  public String getId()
  {
    return this.id;
  }

  public void setId(String paramString)
  {
    this.id = paramString;
  }

  public String list()
  {
    List localList = null;
    Element localElement1 = getXMLDocument().getRootElement();
    if ((this.id != null) && (!this.id.trim().equals("")) && (!this.id.trim().equals("0")))
    {
      localObject = localElement1.selectNodes("//Items[@id='" + this.id + "']");
      if ((localObject != null) && (((List)localObject).size() > 0))
        localList = ((Element)((List)localObject).get(0)).elements("icon");
    }
    else
    {
      localList = localElement1.selectNodes("//icon");
    }
    Object localObject = new StringBuffer(",icon:[");
    for (int i = 0; i < localList.size(); i++)
    {
      Element localElement2 = (Element)localList.get(i);
      String str2 = localElement2.attributeValue("text");
      String str3 = localElement2.attributeValue("url");
      ((StringBuffer)localObject).append("{").append("'text':'" + str2 + "','url':'" + str3 + "'").append("}");
      if (i == localList.size() - 1)
        continue;
      ((StringBuffer)localObject).append(",");
    }
    ((StringBuffer)localObject).append("]");
    String str1 = "{success:true" + ((StringBuffer)localObject).toString() + "}";
    setJsonString(str1);
    return (String)"success";
  }

  public String loadTree()
  {
    StringBuffer localStringBuffer = new StringBuffer("");
    localStringBuffer.append("[{id:'0',text:'" + AppUtil.getCompanyName() + "',expanded:true,children:[");
    Document localDocument = getXMLDocument();
    if (localDocument != null)
    {
      Element localElement1 = localDocument.getRootElement();
      List localList = localElement1.elements();
      Iterator localIterator = localList.iterator();
      for (int i = 0; localIterator.hasNext(); i++)
      {
        Element localElement2 = (Element)localIterator.next();
        String str = localElement2.getName();
        int j = (str != null) && ("items".equalsIgnoreCase(str)) ? 1 : 0;
        if (j == 0)
          break;
        localStringBuffer.append(getElementValue(localElement2));
      }
      if ((localList != null) && (localList.size() == i))
        localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    }
    localStringBuffer.append("]}]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  private String findChidNode(Element paramElement)
  {
    List localList = paramElement.elements();
    StringBuffer localStringBuffer1 = new StringBuffer("");
    if ((localList == null) || (localList.size() == 0))
    {
      localStringBuffer1.append("leaf:true},");
    }
    else
    {
      int i = 0;
      StringBuffer localStringBuffer2 = new StringBuffer("children:[");
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        Element localElement = (Element)localIterator.next();
        String str = localElement.getName();
        int j = (str != null) && ("items".equalsIgnoreCase(str)) ? 1 : 0;
        if (j == 0)
          break;
        localStringBuffer2.append(getElementValue(localElement));
        i++;
      }
      if ((localList.size() == i) && (i != 0))
      {
        localStringBuffer2.deleteCharAt(localStringBuffer2.length() - 1);
        localStringBuffer2.append("]},");
        localStringBuffer1.append(localStringBuffer2);
      }
      else
      {
        localStringBuffer1.append("leaf:true},");
      }
    }
    return localStringBuffer1.toString();
  }

  private StringBuffer getElementValue(Element paramElement)
  {
    StringBuffer localStringBuffer = new StringBuffer("");
    String str1 = paramElement.attribute("id").getValue();
    String str2 = paramElement.attribute("text") != null ? paramElement.attribute("text").getValue() : "";
    String str3 = paramElement.attribute("iconCls") != null ? paramElement.attribute("iconCls").getValue() : "";
    localStringBuffer.append("{id:'" + str1 + "',text:'" + str2).append("',iconCls:'" + str3).append("',");
    localStringBuffer.append(findChidNode(paramElement));
    return localStringBuffer;
  }

  private Document getXMLDocument()
  {
    Document localDocument = null;
    try
    {
      SAXReader localSAXReader = new SAXReader();
      localDocument = localSAXReader.read(new File(xmlPath));
    }
    catch (DocumentException localDocumentException)
    {
      localDocumentException.printStackTrace();
    }
    return localDocument;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.menu.IconAction
 * JD-Core Version:    0.6.0
 */