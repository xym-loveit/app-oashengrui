package com.htsoft.oa.action.communicate;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.CertUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.communicate.OutMailUserSeting;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.communicate.OutMailUserSetingService;
import com.sun.mail.pop3.POP3Folder;
import com.sun.net.ssl.internal.ssl.Provider;
import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Type;
import java.security.Security;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import javax.annotation.Resource;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.URLName;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;

public class OutMailUserSetingAction extends BaseAction
{

  @Resource
  private OutMailUserSetingService outMailUserSetingService;
  private OutMailUserSeting outMailUserSeting;

  public OutMailUserSeting getOutMailUserSeting()
  {
    return this.outMailUserSeting;
  }

  public void setOutMailUserSeting(OutMailUserSeting paramOutMailUserSeting)
  {
    this.outMailUserSeting = paramOutMailUserSeting;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.outMailUserSetingService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.outMailUserSetingService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    OutMailUserSeting localOutMailUserSeting = this.outMailUserSetingService.getByLoginId(ContextUtil.getCurrentUserId());
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setDateFormat("yyyy-MM-dd").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    if (localOutMailUserSeting != null)
    {
      localStringBuffer.append(localGson.toJson(localOutMailUserSeting));
    }
    else
    {
      localOutMailUserSeting = new OutMailUserSeting();
      localOutMailUserSeting.setUserId(ContextUtil.getCurrentUserId());
      localOutMailUserSeting.setUserName(ContextUtil.getCurrentUser().getUsername());
      localStringBuffer.append(localGson.toJson(localOutMailUserSeting));
    }
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    boolean bool1 = false;
    boolean bool2 = false;
    bool1 = send(this.outMailUserSeting);
    bool2 = fetch(this.outMailUserSeting);
    if ((bool1) && (bool2))
      setJsonString("{success:true}");
    else if ((!bool1) && (!bool2))
      setJsonString("{failure:true,msg:'连接到smtp,pop服务器失败，请检查书写是否正确!!'}");
    else if (!bool1)
      setJsonString("{failure:true,msg:'连接到smtp服务器失败，请检查书写是否正确!!'}");
    else if (!bool2)
      setJsonString("{failure:true,msg:'连接到pop服务器失败，请检查书写是否正确!!'}");
    if (this.outMailUserSeting.getId() == null)
    {
      this.outMailUserSeting.setUserId(ContextUtil.getCurrentUserId());
      this.outMailUserSetingService.save(this.outMailUserSeting);
      this.logger.debug(">>>" + this.outMailUserSeting);
    }
    else
    {
      OutMailUserSeting localOutMailUserSeting = (OutMailUserSeting)this.outMailUserSetingService.get(this.outMailUserSeting.getId());
      try
      {
        BeanUtil.copyNotNullProperties(localOutMailUserSeting, this.outMailUserSeting);
        this.outMailUserSetingService.save(localOutMailUserSeting);
        this.logger.debug(">>>" + localOutMailUserSeting);
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        localIllegalAccessException.printStackTrace();
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        localInvocationTargetException.printStackTrace();
      }
    }
    return "success";
  }

  protected boolean send(OutMailUserSeting paramOutMailUserSeting)
  {
    this.logger.debug("send start...");
    Transport localTransport = null;
    Session localSession = null;
    try
    {
      Properties localProperties = new Properties();
      localProperties.setProperty("mail.smtp.host", paramOutMailUserSeting.getSmtpHost());
      localProperties.setProperty("mail.smtp.port", paramOutMailUserSeting.getSmtpPort());
      localProperties.put("mail.smtp.auth", "true");
      localProperties.setProperty("mail.smtp.socketFactory.fallback", "false");
      localProperties.setProperty("mail.smtp.socketFactory.port", paramOutMailUserSeting.getSmtpPort());
      File localFile = CertUtil.get(paramOutMailUserSeting.getSmtpHost(), Integer.parseInt(paramOutMailUserSeting.getSmtpPort()));
      if (localFile != null)
      {
        this.logger.debug("ssl connection...");
        Security.addProvider(new Provider());
        localProperties.setProperty("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        System.setProperty("javax.net.ssl.trustStore", localFile.getAbsolutePath());
        localProperties.setProperty("javax.net.ssl.trustStore", localFile.getAbsolutePath());
      }
      else
      {
        this.logger.debug("plaintext connection or tls connection...");
        localProperties.put("mail.smtp.starttls.enable", "true");
      }
      String str1 = paramOutMailUserSeting.getMailAddress();
      String str2 = paramOutMailUserSeting.getMailPass();
      localSession = Session.getInstance(localProperties, new Authenticator(str1, str2)
      {
        protected PasswordAuthentication getPasswordAuthentication()
        {
          return new PasswordAuthentication(this.val$username, this.val$password);
        }
      });
      this.logger.debug("connetion session:" + localSession);
      MimeMessage localMimeMessage = new MimeMessage(localSession);
      MimeMultipart localMimeMultipart = new MimeMultipart();
      localMimeMessage.setSubject("宏天邮件测试", "utf-8");
      MimeBodyPart localMimeBodyPart = new MimeBodyPart();
      localMimeBodyPart.setHeader("Content-Transfer-Encoding", "base64");
      localMimeBodyPart.setContent("宏天邮件测试", "text/html;charset=utf-8");
      localMimeMessage.setText("宏天邮件测试", "utf-8");
      localMimeMessage.setSentDate(new Date());
      localMimeMultipart.addBodyPart(localMimeBodyPart);
      localMimeMessage.setFrom(new InternetAddress(paramOutMailUserSeting.getMailAddress(), MimeUtility.encodeWord(paramOutMailUserSeting.getUserName(), "utf-8", "Q")));
      InternetAddress[] arrayOfInternetAddress = new InternetAddress[1];
      arrayOfInternetAddress[0] = new InternetAddress(paramOutMailUserSeting.getMailAddress(), MimeUtility.encodeWord(paramOutMailUserSeting.getUserName(), "utf-8", "Q"));
      localMimeMessage.addRecipients(Message.RecipientType.TO, arrayOfInternetAddress);
      localMimeMessage.saveChanges();
      localTransport = localSession.getTransport("smtp");
      localTransport.connect(paramOutMailUserSeting.getSmtpHost().toString(), str1, str2);
      Transport.send(localMimeMessage);
      this.logger.debug("send end...");
      int j = 1;
      return j;
    }
    catch (Exception localException)
    {
      this.logger.info("连接smtp 服务器失败");
      localException.printStackTrace();
      int i = 0;
      return i;
    }
    finally
    {
      try
      {
        localTransport.close();
      }
      catch (MessagingException localMessagingException3)
      {
        this.logger.info("关闭连接失败");
        localMessagingException3.printStackTrace();
      }
    }
    throw localObject;
  }

  protected boolean fetch(OutMailUserSeting paramOutMailUserSeting)
  {
    this.logger.debug("fectch start...");
    Store localStore = null;
    POP3Folder localPOP3Folder = null;
    try
    {
      File localFile = CertUtil.get(paramOutMailUserSeting.getPopHost(), Integer.parseInt(paramOutMailUserSeting.getPopPort()));
      Properties localProperties = new Properties();
      localProperties.setProperty("mail.pop3.socketFactory.fallback", "false");
      localProperties.setProperty("mail.pop3.port", paramOutMailUserSeting.getPopPort());
      localProperties.setProperty("mail.pop3.socketFactory.port", paramOutMailUserSeting.getPopPort());
      if (localFile != null)
      {
        this.logger.debug("ssl connection...");
        Security.addProvider(new Provider());
        localProperties.setProperty("mail.pop3.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        System.setProperty("javax.net.ssl.trustStore", localFile.getAbsolutePath());
        localProperties.setProperty("javax.net.ssl.trustStore", localFile.getAbsolutePath());
      }
      else
      {
        this.logger.debug("plaintext connection or tls connection...");
        localProperties.put("mail.smtp.starttls.enable", "true");
      }
      Session localSession = Session.getInstance(localProperties, new Authenticator()
      {
        protected PasswordAuthentication getPasswordAuthentication()
        {
          return new PasswordAuthentication(OutMailUserSetingAction.this.outMailUserSeting.getMailAddress(), OutMailUserSetingAction.this.outMailUserSeting.getMailPass());
        }
      });
      URLName localURLName = new URLName("pop3", paramOutMailUserSeting.getPopHost(), Integer.parseInt(paramOutMailUserSeting.getPopPort()), null, paramOutMailUserSeting.getMailAddress(), paramOutMailUserSeting.getMailPass());
      localStore = localSession.getStore(localURLName);
      localStore.connect();
      localPOP3Folder = (POP3Folder)localStore.getFolder("INBOX");
      localPOP3Folder.open(1);
      Message[] arrayOfMessage = localPOP3Folder.getMessages();
      int j = arrayOfMessage.length;
      this.logger.debug("mail count:" + j);
      this.logger.debug("fectch end...");
      if (j > 0)
      {
        k = 1;
        return k;
      }
      int k = 0;
      return k;
    }
    catch (Exception localException1)
    {
      this.logger.info("连接pop 服务器失败");
      localException1.printStackTrace();
      int i = 0;
      return i;
    }
    finally
    {
      try
      {
        localPOP3Folder.close(false);
      }
      catch (Exception localException8)
      {
        this.logger.info("关闭连接失败");
        localException8.printStackTrace();
      }
      try
      {
        localStore.close();
      }
      catch (Exception localException9)
      {
        this.logger.info("关闭连接失败");
        localException9.printStackTrace();
      }
    }
    throw localObject;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.communicate.OutMailUserSetingAction
 * JD-Core Version:    0.6.0
 */