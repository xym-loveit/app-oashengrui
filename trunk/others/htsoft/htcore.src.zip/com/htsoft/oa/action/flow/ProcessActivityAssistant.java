package com.htsoft.oa.action.flow;

import com.htsoft.core.jbpm.pv.ParamField;
import com.htsoft.core.util.AppUtil;
import com.htsoft.core.util.XmlUtil;
import java.io.FileInputStream;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.Element;

public class ProcessActivityAssistant
{
  private static final Log logger = LogFactory.getLog(ProcessActivityAssistant.class);

  public static Map<String, ParamField> constructMobileFieldMap(String paramString1, String paramString2)
  {
    String str = getMobileFieldsAbsPath(paramString1, paramString2);
    return genFieldMap(paramString1, paramString2, str);
  }

  public static Map<String, ParamField> constructFieldMap(String paramString1, String paramString2)
  {
    String str = getFieldAbsPath(paramString1, paramString2);
    return genFieldMap(paramString1, paramString2, str);
  }

  public static Map<String, ParamField> genFieldMap(String paramString1, String paramString2, String paramString3)
  {
    FileInputStream localFileInputStream = null;
    LinkedHashMap localLinkedHashMap = new LinkedHashMap();
    try
    {
      localFileInputStream = new FileInputStream(paramString3);
    }
    catch (Exception localException1)
    {
      logger.warn("error when read the file from " + paramString2 + "-fields.xml, the reason is not upload ");
    }
    if (localFileInputStream == null)
      try
      {
        localFileInputStream = new FileInputStream(getCommonFieldsAbsPath(paramString2));
      }
      catch (Exception localException2)
      {
        logger.warn("error when read the file from 通用、表单-fields.xml, the reason is not upload ");
      }
    Document localDocument = XmlUtil.load(localFileInputStream);
    if (localDocument != null)
    {
      Element localElement1 = localDocument.getRootElement();
      List localList = localElement1.elements();
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        Element localElement2 = (Element)localIterator.next();
        String str1 = localElement2.attribute("name").getValue();
        Attribute localAttribute1 = localElement2.attribute("label");
        Attribute localAttribute2 = localElement2.attribute("type");
        Attribute localAttribute3 = localElement2.attribute("length");
        Attribute localAttribute4 = localElement2.attribute("isShowed");
        String str2 = localAttribute1 == null ? str1 : localAttribute1.getValue();
        String str3 = localAttribute2 == null ? "varchar" : localAttribute2.getValue();
        Integer localInteger = Integer.valueOf(localAttribute3 == null ? 0 : new Integer(localAttribute3.getValue()).intValue());
        Short localShort = Short.valueOf((localAttribute4 == null) || ("true".equals(localAttribute4.getValue())) ? 1 : 0);
        ParamField localParamField = new ParamField(str1, str3, str2, localInteger, localShort);
        localLinkedHashMap.put(str1, localParamField);
      }
    }
    return localLinkedHashMap;
  }

  public static String getStartFormPath(String paramString)
  {
    return "/" + paramString + "/开始.vm";
  }

  public static String getFormPath(String paramString1, String paramString2)
  {
    return "/" + paramString1 + "/" + paramString2 + ".vm";
  }

  public static String getFieldAbsPath(String paramString1, String paramString2)
  {
    return AppUtil.getFlowFormAbsolutePath() + paramString1 + "/" + paramString2 + "-fields.xml";
  }

  public static String getMobileFieldsAbsPath(String paramString1, String paramString2)
  {
    return AppUtil.getMobileFlowFlowAbsPath() + paramString1 + "/" + paramString2 + "-fields.xml";
  }

  public static String getFieldStartAbsPath(String paramString)
  {
    return AppUtil.getFlowFormAbsolutePath() + paramString + "/开始-fields.xml";
  }

  public static String getCommonFormPath(String paramString)
  {
    if ("开始".equals(paramString))
      return "/通用/开始.vm";
    return "/通用/表单.vm";
  }

  public static String getCommonFieldsAbsPath(String paramString)
  {
    String str = AppUtil.getFlowFormAbsolutePath();
    if ("开始".equals(paramString))
      return str + "通用/开始-fields.xml";
    return str + "通用/表单-fields.xml";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.flow.ProcessActivityAssistant
 * JD-Core Version:    0.6.0
 */