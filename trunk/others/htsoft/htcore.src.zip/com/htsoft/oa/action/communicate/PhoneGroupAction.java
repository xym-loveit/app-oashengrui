package com.htsoft.oa.action.communicate;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.communicate.PhoneGroup;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.communicate.PhoneBookService;
import com.htsoft.oa.service.communicate.PhoneGroupService;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class PhoneGroupAction extends BaseAction
{

  @Resource
  private PhoneGroupService phoneGroupService;
  private PhoneGroup phoneGroup;

  @Resource
  private PhoneBookService phoneBookService;
  private Long groupId;

  public Long getGroupId()
  {
    return this.groupId;
  }

  public void setGroupId(Long paramLong)
  {
    this.groupId = paramLong;
  }

  public PhoneGroup getPhoneGroup()
  {
    return this.phoneGroup;
  }

  public void setPhoneGroup(PhoneGroup paramPhoneGroup)
  {
    this.phoneGroup = paramPhoneGroup;
  }

  public String list()
  {
    String str1 = getRequest().getParameter("isPublic");
    Object localObject = new ArrayList();
    if ((StringUtils.isNotEmpty(str1)) && ("true".equals(str1)))
      localObject = this.phoneGroupService.getPublicAll();
    else
      localObject = this.phoneGroupService.getAll(ContextUtil.getCurrentUserId());
    String str2 = getRequest().getParameter("method");
    StringBuffer localStringBuffer = new StringBuffer();
    int i = 0;
    if (StringUtils.isNotEmpty(str2))
    {
      localStringBuffer.append("[");
    }
    else
    {
      i++;
      localStringBuffer.append("[{id:'0',text:'联系人分组',expanded:true,children:[");
    }
    Iterator localIterator = ((List)localObject).iterator();
    while (localIterator.hasNext())
    {
      PhoneGroup localPhoneGroup = (PhoneGroup)localIterator.next();
      localStringBuffer.append("{id:'" + localPhoneGroup.getGroupId() + "',text:'" + localPhoneGroup.getGroupName() + "',leaf:true},");
    }
    if (!((List)localObject).isEmpty())
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    if (i == 0)
      localStringBuffer.append("]");
    else
      localStringBuffer.append("]}]");
    this.jsonString = localStringBuffer.toString();
    return (String)"success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
      {
        Long localLong = new Long(str);
        PhoneGroup localPhoneGroup1 = (PhoneGroup)this.phoneGroupService.get(localLong);
        this.phoneGroupService.remove(localLong);
        List localList = this.phoneGroupService.findBySnDown(localPhoneGroup1.getSn(), localPhoneGroup1.getAppUser().getUserId());
        Iterator localIterator = localList.iterator();
        while (localIterator.hasNext())
        {
          PhoneGroup localPhoneGroup2 = (PhoneGroup)localIterator.next();
          localPhoneGroup2.setSn(Integer.valueOf(localPhoneGroup2.getSn().intValue() - 1));
          this.phoneGroupService.save(localPhoneGroup2);
        }
      }
    this.jsonString = "{success:true}";
    return "success";
  }

  public String count()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.phoneBookService.getAll(localQueryFilter);
    setJsonString("{success:true,count:" + localList.size() + "}");
    return "success";
  }

  public String get()
  {
    PhoneGroup localPhoneGroup = (PhoneGroup)this.phoneGroupService.get(this.groupId);
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localPhoneGroup));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    Integer localInteger = Integer.valueOf(0);
    AppUser localAppUser = ContextUtil.getCurrentUser();
    if (PhoneGroup.IS_PUBLIC == this.phoneGroup.getIsPublic())
      localInteger = this.phoneGroupService.findPublicLastSn();
    else
      localInteger = this.phoneGroupService.findLastSn(localAppUser.getUserId());
    if (localInteger == null)
      localInteger = Integer.valueOf(0);
    this.phoneGroup.setSn(Integer.valueOf(localInteger.intValue() + 1));
    this.phoneGroup.setAppUser(localAppUser);
    this.phoneGroupService.save(this.phoneGroup);
    setJsonString("{success:true}");
    return "success";
  }

  public String move()
  {
    String str1 = getRequest().getParameter("optId");
    String str2 = getRequest().getParameter("groupId");
    Long localLong1 = ContextUtil.getCurrentUserId();
    if (StringUtils.isNotEmpty(str2))
    {
      Integer localInteger1 = Integer.valueOf(Integer.parseInt(str1));
      Long localLong2 = Long.valueOf(Long.parseLong(str2));
      this.phoneGroup = ((PhoneGroup)this.phoneGroupService.get(localLong2));
      Integer localInteger2 = this.phoneGroup.getSn();
      Object localObject;
      if ((localInteger1.intValue() == 1) && (localInteger2.intValue() > 1))
      {
        localObject = this.phoneGroupService.findBySn(Integer.valueOf(localInteger2.intValue() - 1), localLong1);
        ((PhoneGroup)localObject).setSn(localInteger2);
        this.phoneGroupService.save(localObject);
        this.phoneGroup.setSn(Integer.valueOf(localInteger2.intValue() - 1));
        this.phoneGroupService.save(this.phoneGroup);
      }
      if ((localInteger1.intValue() == 2) && (localInteger2.intValue() < this.phoneGroupService.findLastSn(localLong1).intValue()))
      {
        localObject = this.phoneGroupService.findBySn(Integer.valueOf(localInteger2.intValue() + 1), localLong1);
        ((PhoneGroup)localObject).setSn(localInteger2);
        this.phoneGroup.setSn(Integer.valueOf(localInteger2.intValue() + 1));
        this.phoneGroupService.save(localObject);
        this.phoneGroupService.save(this.phoneGroup);
      }
      Iterator localIterator;
      PhoneGroup localPhoneGroup;
      if ((localInteger1.intValue() == 3) && (localInteger2.intValue() > 1))
      {
        localObject = this.phoneGroupService.findBySnUp(localInteger2, localLong1);
        localIterator = ((List)localObject).iterator();
        while (localIterator.hasNext())
        {
          localPhoneGroup = (PhoneGroup)localIterator.next();
          localPhoneGroup.setSn(Integer.valueOf(localPhoneGroup.getSn().intValue() + 1));
          this.phoneGroupService.save(localPhoneGroup);
        }
        this.phoneGroup.setSn(Integer.valueOf(1));
        this.phoneGroupService.save(this.phoneGroup);
      }
      if ((localInteger1.intValue() == 4) && (localInteger2.intValue() < this.phoneGroupService.findLastSn(localLong1).intValue()))
      {
        localObject = this.phoneGroupService.findBySnDown(localInteger2, localLong1);
        localIterator = ((List)localObject).iterator();
        while (localIterator.hasNext())
        {
          localPhoneGroup = (PhoneGroup)localIterator.next();
          localPhoneGroup.setSn(Integer.valueOf(localPhoneGroup.getSn().intValue() - 1));
          this.phoneGroupService.save(localPhoneGroup);
        }
        this.phoneGroup.setSn(Integer.valueOf(this.phoneGroupService.findLastSn(localLong1).intValue() + 1));
        this.phoneGroupService.save(this.phoneGroup);
      }
      setJsonString("{success:true}");
    }
    else
    {
      setJsonString("{success:false}");
    }
    return (String)"success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.communicate.PhoneGroupAction
 * JD-Core Version:    0.6.0
 */