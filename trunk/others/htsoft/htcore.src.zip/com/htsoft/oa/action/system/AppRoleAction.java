package com.htsoft.oa.action.system;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.AppUtil;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.system.AppFunction;
import com.htsoft.oa.model.system.AppRole;
import com.htsoft.oa.service.system.AppFunctionService;
import com.htsoft.oa.service.system.AppRoleService;
import java.lang.reflect.Type;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.dom4j.Document;

public class AppRoleAction extends BaseAction
{

  @Resource
  private AppFunctionService appFunctionService;
  private static String IS_COPY = "1";

  @Resource
  private AppRoleService appRoleService;
  private AppRole appRole;
  private Long roleId;

  public Long getRoleId()
  {
    return this.roleId;
  }

  public void setRoleId(Long paramLong)
  {
    this.roleId = paramLong;
  }

  public AppRole getAppRole()
  {
    return this.appRole;
  }

  public void setAppRole(AppRole paramAppRole)
  {
    this.appRole = paramAppRole;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.appRoleService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String tree()
  {
    StringBuffer localStringBuffer = new StringBuffer("[");
    List localList = this.appRoleService.getAll();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      AppRole localAppRole = (AppRole)localIterator.next();
      localStringBuffer.append("{id:'" + localAppRole.getRoleId() + "',text:'" + localAppRole.getRoleName() + "',leaf:true},");
    }
    if (!localList.isEmpty())
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
      {
        AppRole localAppRole = (AppRole)this.appRoleService.get(new Long(str));
        localAppRole.getAppUsers().remove(localAppRole);
        localAppRole.getFunctions().remove(localAppRole);
        this.appRoleService.remove(localAppRole);
      }
    this.jsonString = "{success:true}";
    return "success";
  }

  public String grant()
  {
    AppRole localAppRole = (AppRole)this.appRoleService.get(this.roleId);
    String str = getRequest().getParameter("rights");
    if (str == null)
      str = "";
    if (!str.equals(localAppRole.getRights()))
    {
      localAppRole.setRights(str);
      localAppRole.getFunctions().clear();
      String[] arrayOfString = str.split("[,]");
      for (int i = 0; i < arrayOfString.length; i++)
      {
        if (!arrayOfString[i].startsWith("_"))
          continue;
        AppFunction localAppFunction = this.appFunctionService.getByKey(arrayOfString[i]);
        if (localAppFunction == null)
          continue;
        localAppRole.getFunctions().add(localAppFunction);
      }
      this.appRoleService.save(localAppRole);
      AppUtil.reloadSecurityDataSource();
    }
    return "success";
  }

  public String grantXml()
  {
    Document localDocument = AppUtil.getGrantMenuDocument();
    setJsonString(localDocument.asXML());
    return "success";
  }

  public String get()
  {
    AppRole localAppRole = (AppRole)this.appRoleService.get(this.roleId);
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localAppRole));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    String str = getRequest().getParameter("isCopy");
    AppRole localAppRole;
    if ((StringUtils.isNotEmpty(str)) && (IS_COPY.equals(str)))
    {
      localAppRole = new AppRole();
      localAppRole.setIsDefaultIn(Short.valueOf(0));
      localAppRole.setRoleDesc(this.appRole.getRoleDesc());
      localAppRole.setStatus(this.appRole.getStatus());
      localAppRole.setRoleName(this.appRole.getRoleName());
      this.appRole = ((AppRole)this.appRoleService.get(this.appRole.getRoleId()));
      HashSet localHashSet = new HashSet(this.appRole.getFunctions());
      localAppRole.setFunctions(localHashSet);
      localAppRole.setRights(this.appRole.getRights());
      this.appRoleService.save(localAppRole);
    }
    else if (this.appRole.getRoleId() == null)
    {
      this.appRole.setIsDefaultIn(Short.valueOf(0));
      this.appRoleService.save(this.appRole);
    }
    else
    {
      localAppRole = (AppRole)this.appRoleService.get(new Long(this.appRole.getRoleId().longValue()));
      try
      {
        BeanUtil.copyNotNullProperties(localAppRole, this.appRole);
        this.appRoleService.save(localAppRole);
      }
      catch (Exception localException)
      {
      }
    }
    setJsonString("{success:true}");
    return "success";
  }

  public String check()
  {
    String str = getRequest().getParameter("roleName");
    AppRole localAppRole = this.appRoleService.getByRoleName(str);
    if (localAppRole == null)
      setJsonString("{success:true}");
    else
      setJsonString("{success:false}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.AppRoleAction
 * JD-Core Version:    0.6.0
 */