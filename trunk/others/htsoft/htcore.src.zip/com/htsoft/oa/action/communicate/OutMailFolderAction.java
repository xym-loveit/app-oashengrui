package com.htsoft.oa.action.communicate;

import com.google.gson.Gson;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.communicate.OutMail;
import com.htsoft.oa.model.communicate.OutMailFolder;
import com.htsoft.oa.service.communicate.OutMailFolderService;
import com.htsoft.oa.service.communicate.OutMailService;
import java.io.PrintStream;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class OutMailFolderAction extends BaseAction
{
  static long FOLDER_ID_RECEIVE = 1L;
  static long FOLDER_ID_SEND = 2L;
  static long FOLDER_ID_DRAFT = 3L;
  static long FOLDER_ID_DELETE = 4L;
  static long FOLDER_TYPE_OTHER = 10L;
  static short OTHER_FOLDER_TYPE = 10;
  static int FIRST_LEVEL = 1;
  static long FIRST_PARENTID = new Long(0L).longValue();

  @Resource
  private OutMailFolderService outMailFolderService;
  private OutMailFolder outMailFolder;

  @Resource
  private OutMailService outMailService;
  private OutMail outMail;
  private Long folderId;

  public Long getFolderId()
  {
    return this.folderId;
  }

  public void setFolderId(Long paramLong)
  {
    this.folderId = paramLong;
  }

  public OutMailFolder getOutMailFolder()
  {
    return this.outMailFolder;
  }

  public void setOutMailFolder(OutMailFolder paramOutMailFolder)
  {
    this.outMailFolder = paramOutMailFolder;
  }

  public String list()
  {
    StringBuffer localStringBuffer = new StringBuffer("[{id:'0',text:'外部邮箱',iconCls:'menu-mail_box',expanded:true,children:[");
    Long localLong = ContextUtil.getCurrentUserId();
    List localList = this.outMailFolderService.getAllUserFolderByParentId(localLong, Long.valueOf(FIRST_PARENTID));
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      OutMailFolder localOutMailFolder = (OutMailFolder)localIterator.next();
      long l = localOutMailFolder.getFolderId().longValue();
      localStringBuffer.append("{id:'" + localOutMailFolder.getFolderId()).append("',text:'" + localOutMailFolder.getFolderName()).append("',");
      if (l == FOLDER_ID_RECEIVE)
        localStringBuffer.append("iconCls:'menu-mail_inbox',");
      else if (l == FOLDER_ID_SEND)
        localStringBuffer.append("iconCls:'menu-mail_outbox',");
      else if (l == FOLDER_ID_DRAFT)
        localStringBuffer.append("iconCls:'menu-mail_drafts',");
      else if (l == FOLDER_ID_DELETE)
        localStringBuffer.append("iconCls:'menu-mail_trash',");
      else
        localStringBuffer.append("iconCls:'menu-mail_folder',");
      localStringBuffer.append(findChildsFolder(localLong, localOutMailFolder.getFolderId()));
    }
    if (!localList.isEmpty())
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  private String findChildsFolder(Long paramLong1, Long paramLong2)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    List localList = this.outMailFolderService.getUserFolderByParentId(paramLong1, paramLong2);
    if (localList.size() == 0)
    {
      localStringBuffer.append("leaf:true,expanded:true},");
      return localStringBuffer.toString();
    }
    localStringBuffer.append("children:[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      OutMailFolder localOutMailFolder = (OutMailFolder)localIterator.next();
      localStringBuffer.append("{id:'" + localOutMailFolder.getFolderId() + "',text:'" + localOutMailFolder.getFolderName() + "',");
      localStringBuffer.append("iconCls:'menu-mail_folder',");
      localStringBuffer.append(findChildsFolder(paramLong1, localOutMailFolder.getFolderId()));
    }
    localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]},");
    return localStringBuffer.toString();
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.outMailFolderService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    OutMailFolder localOutMailFolder = (OutMailFolder)this.outMailFolderService.get(this.folderId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localOutMailFolder));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    OutMailFolder localOutMailFolder = null;
    System.out.println("outMailFolder=" + this.outMailFolder);
    Long localLong = this.outMailFolder.getParentId();
    System.out.println(localLong);
    if ((localLong == null) || (localLong.longValue() == FIRST_PARENTID))
    {
      this.outMailFolder.setParentId(new Long(FIRST_PARENTID));
      this.outMailFolder.setDepLevel(Integer.valueOf(FIRST_LEVEL));
      System.out.println("11111outMailFolder" + this.outMailFolder);
    }
    else
    {
      localOutMailFolder = (OutMailFolder)this.outMailFolderService.get(localLong);
      this.outMailFolder.setDepLevel(Integer.valueOf(localOutMailFolder.getDepLevel().intValue() + 1));
      System.out.println("2222outMailFolder" + this.outMailFolder);
      System.out.println("2222parentFolder" + localOutMailFolder);
    }
    this.outMailFolder.setFolderType(Short.valueOf(OTHER_FOLDER_TYPE));
    this.outMailFolder.setUserId(ContextUtil.getCurrentUserId());
    this.outMailFolderService.save(this.outMailFolder);
    if (this.outMailFolder.getParentId().longValue() == FIRST_PARENTID)
      this.outMailFolder.setPath("0." + this.outMailFolder.getFolderId() + ".");
    else
      this.outMailFolder.setPath(localOutMailFolder.getPath() + this.outMailFolder.getFolderId() + ".");
    this.outMailFolderService.save(this.outMailFolder);
    setJsonString("{success:true}");
    return "success";
  }

  public String remove()
  {
    String str = getRequest().getParameter("count");
    if (this.folderId != null)
    {
      OutMailFolder localOutMailFolder1 = (OutMailFolder)this.outMailFolderService.get(new Long(this.folderId.longValue()));
      List localList1 = this.outMailFolderService.getFolderLikePath(localOutMailFolder1.getPath());
      Object localObject2;
      if ((str != null) && (new Long(str).longValue() > 0L))
      {
        localObject1 = (OutMailFolder)this.outMailFolderService.get(new Long(FOLDER_ID_DELETE));
        localObject2 = localList1.iterator();
        while (((Iterator)localObject2).hasNext())
        {
          OutMailFolder localOutMailFolder2 = (OutMailFolder)((Iterator)localObject2).next();
          List localList2 = this.outMailService.findByFolderId(localOutMailFolder2.getFolderId());
          Iterator localIterator = localList2.iterator();
          while (localIterator.hasNext())
          {
            OutMail localOutMail = (OutMail)localIterator.next();
            localOutMail.setOutMailFolder((OutMailFolder)localObject1);
            this.outMailService.save(localOutMail);
          }
        }
      }
      Object localObject1 = localList1.iterator();
      while (((Iterator)localObject1).hasNext())
      {
        localObject2 = (OutMailFolder)((Iterator)localObject1).next();
        this.outMailFolderService.remove(((OutMailFolder)localObject2).getFolderId());
      }
    }
    this.jsonString = "{success:true}";
    return (String)(String)"success";
  }

  public String count()
  {
    OutMailFolder localOutMailFolder1 = (OutMailFolder)this.outMailFolderService.get(new Long(this.folderId.longValue()));
    List localList = this.outMailFolderService.getFolderLikePath(localOutMailFolder1.getPath());
    Long localLong1 = Long.valueOf(0L);
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      OutMailFolder localOutMailFolder2 = (OutMailFolder)localIterator.next();
      Long localLong2 = this.outMailService.CountByFolderId(localOutMailFolder2.getFolderId());
      localLong1 = Long.valueOf(localLong1.longValue() + localLong2.longValue());
    }
    setJsonString("{success:true,count:" + localLong1 + "}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.communicate.OutMailFolderAction
 * JD-Core Version:    0.6.0
 */