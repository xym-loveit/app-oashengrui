package com.htsoft.oa.action.info;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.info.AppTips;
import com.htsoft.oa.service.info.AppTipsService;
import java.lang.reflect.Type;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class AppTipsAction extends BaseAction
{

  @Resource
  private AppTipsService appTipsService;
  private AppTips appTips;
  private Long tipsId;

  public Long getTipsId()
  {
    return this.tipsId;
  }

  public void setTipsId(Long paramLong)
  {
    this.tipsId = paramLong;
  }

  public AppTips getAppTips()
  {
    return this.appTips;
  }

  public void setAppTips(AppTips paramAppTips)
  {
    this.appTips = paramAppTips;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_appUser.userId_L_EQ", ContextUtil.getCurrentUserId().toString());
    List localList = this.appTipsService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    Object localObject1;
    Object localObject2;
    Object localObject3;
    if (getRequest().getParameter("ids").equals("all"))
    {
      localObject1 = new QueryFilter(getRequest());
      ((QueryFilter)localObject1).addFilter("Q_appUser.userId_L_EQ", ContextUtil.getCurrentUserId().toString());
      localObject2 = this.appTipsService.getAll((QueryFilter)localObject1);
      localObject3 = ((List)localObject2).iterator();
      while (((Iterator)localObject3).hasNext())
      {
        AppTips localAppTips1 = (AppTips)((Iterator)localObject3).next();
        this.appTipsService.remove(localAppTips1);
      }
    }
    else
    {
      localObject1 = getRequest().getParameterValues("ids");
      localObject2 = getRequest().getParameterValues("names");
      if ((localObject1 != null) && (localObject2 != null))
        for (String str : localObject2)
        {
          AppTips localAppTips2 = this.appTipsService.findByName(str);
          if (localAppTips2 == null)
            continue;
          this.appTipsService.remove(localAppTips2);
        }
    }
    this.jsonString = "{success:true}";
    return (String)(String)(String)"success";
  }

  public String get()
  {
    AppTips localAppTips = (AppTips)this.appTipsService.get(this.tipsId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localAppTips));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    String str = getRequest().getParameter("data");
    if (StringUtils.isNotEmpty(str))
    {
      Gson localGson = new Gson();
      AppTips[] arrayOfAppTips1 = (AppTips[])localGson.fromJson(str, [Lcom.htsoft.oa.model.info.AppTips.class);
      for (AppTips localAppTips1 : arrayOfAppTips1)
        if (localAppTips1.getTipsId().longValue() == -1L)
        {
          localAppTips1.setTipsId(null);
          localAppTips1.setCreateTime(new Date());
          localAppTips1.setDislevel(Integer.valueOf(1));
          localAppTips1.setAppUser(ContextUtil.getCurrentUser());
          this.appTipsService.save(localAppTips1);
        }
        else
        {
          if (localAppTips1.getTipsId().longValue() != -2L)
            continue;
          AppTips localAppTips2 = this.appTipsService.findByName(localAppTips1.getTipsName());
          if (localAppTips2 == null)
            continue;
          localAppTips1.setTipsId(null);
          try
          {
            BeanUtil.copyNotNullProperties(localAppTips2, localAppTips1);
          }
          catch (Exception localException)
          {
            localException.printStackTrace();
          }
          localAppTips2.setDislevel(Integer.valueOf(1));
          localAppTips2.setAppUser(ContextUtil.getCurrentUser());
          this.appTipsService.save(localAppTips2);
        }
    }
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.info.AppTipsAction
 * JD-Core Version:    0.6.0
 */