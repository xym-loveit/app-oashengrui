package com.htsoft.oa.action.personal;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.util.DateUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.personal.Duty;
import com.htsoft.oa.model.personal.DutyRegister;
import com.htsoft.oa.model.personal.DutySection;
import com.htsoft.oa.model.personal.DutySystem;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.personal.DutyRegisterService;
import com.htsoft.oa.service.personal.DutySectionService;
import com.htsoft.oa.service.personal.DutyService;
import com.htsoft.oa.service.personal.DutySystemService;
import com.htsoft.oa.service.system.AppUserService;
import java.lang.reflect.Type;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class DutyRegisterAction extends BaseAction
{

  @Resource
  private DutyRegisterService dutyRegisterService;

  @Resource
  private DutyService dutyService;

  @Resource
  private DutySystemService dutySystemService;

  @Resource
  private DutySectionService dutySectionService;

  @Resource
  private AppUserService appUserService;
  private DutyRegister dutyRegister;
  private Long registerId;

  public Long getRegisterId()
  {
    return this.registerId;
  }

  public void setRegisterId(Long paramLong)
  {
    this.registerId = paramLong;
  }

  public DutyRegister getDutyRegister()
  {
    return this.dutyRegister;
  }

  public void setDutyRegister(DutyRegister paramDutyRegister)
  {
    this.dutyRegister = paramDutyRegister;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.dutyRegisterService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").excludeFieldsWithoutExposeAnnotation().create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String person()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_appUser.userId_L_EQ", ContextUtil.getCurrentUserId().toString());
    localQueryFilter.addSorted("registerDate", "desc");
    List localList = this.dutyRegisterService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").excludeFieldsWithoutExposeAnnotation().create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String today()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    DutySystem localDutySystem = null;
    Duty localDuty = this.dutyService.getCurUserDuty(ContextUtil.getCurrentUserId());
    if (localDuty != null)
      localDutySystem = localDuty.getDutySystem();
    else
      localDutySystem = this.dutySystemService.getDefaultDutySystem();
    if (localDutySystem == null)
    {
      setJsonString("{success:true,exception:'尚未为用户设置排班，请联系管理员!'}");
    }
    else
    {
      AppUser localAppUser = ContextUtil.getCurrentUser();
      String str = localDutySystem.getSystemSetting();
      String[] arrayOfString1 = str.split("[|]");
      Calendar localCalendar1 = Calendar.getInstance();
      int i = localCalendar1.get(7);
      String[] arrayOfString2 = arrayOfString1[(i - 1)].split("[,]");
      localStringBuffer.append("{success:true,result:[");
      for (int j = 0; j < arrayOfString2.length; j++)
      {
        if ("-".equals(arrayOfString2[j]))
          continue;
        DutySection localDutySection = (DutySection)this.dutySectionService.get(new Long(arrayOfString2[j]));
        DutyRegister localDutyRegister1 = this.dutyRegisterService.getTodayUserRegister(localAppUser.getUserId(), DutyRegister.SIGN_IN, localDutySection.getSectionId());
        DutyRegister localDutyRegister2 = this.dutyRegisterService.getTodayUserRegister(localAppUser.getUserId(), DutyRegister.SIGN_OFF, localDutySection.getSectionId());
        if (j > 0)
          localStringBuffer.append(",");
        localStringBuffer.append("{sectionId:'").append(localDutySection.getSectionId()).append("',systemName:'").append(localDutySection.getSectionName()).append("',startSignin:'").append(localDutySection.getStartSignin1()).append("',dutyStartTime:'").append(localDutySection.getDutyStartTime1()).append("',endSignin:'").append(localDutySection.getEndSignin1()).append("',earlyOffTime:'").append(localDutySection.getEarlyOffTime1()).append("',dutyEndTime:'").append(localDutySection.getDutyEndTime1()).append("',signOutTime:'").append(localDutySection.getSignOutTime1()).append("'");
        Calendar localCalendar2;
        Calendar localCalendar3;
        int k;
        int m;
        if (localDutyRegister1 != null)
        {
          localStringBuffer.append(",signInTime:'").append(localDutyRegister1.getRegisterTime()).append("',signInFlag:'").append(localDutyRegister1.getRegFlag()).append("',allowSignIn:'0'");
        }
        else
        {
          localStringBuffer.append(",signInTime:'',signInFlag:''");
          localCalendar2 = Calendar.getInstance();
          localCalendar2.setTime(localDutySection.getStartSignin());
          DateUtil.copyYearMonthDay(localCalendar2, localCalendar1);
          localCalendar3 = Calendar.getInstance();
          localCalendar3.setTime(localDutySection.getEndSignin());
          DateUtil.copyYearMonthDay(localCalendar3, localCalendar1);
          k = localCalendar1.compareTo(localCalendar2);
          m = localCalendar1.compareTo(localCalendar3);
          if ((k >= 0) && (m <= 0))
            localStringBuffer.append(",allowSignIn:'1'");
          else if (k < 0)
            localStringBuffer.append(",allowSignIn:'-1'");
          else
            localStringBuffer.append(",allowSignIn:'0'");
        }
        if (localDutyRegister2 != null)
        {
          localStringBuffer.append(",signOffTime:'").append(localDutyRegister2.getRegisterTime()).append("',signOffFlag:'").append(localDutyRegister2.getRegFlag()).append("',allowSignOff:'0'");
        }
        else
        {
          localStringBuffer.append(",signOffTime:'',signOffFlag:''");
          localCalendar2 = Calendar.getInstance();
          localCalendar2.setTime(localDutySection.getEarlyOffTime());
          DateUtil.copyYearMonthDay(localCalendar2, localCalendar1);
          localCalendar3 = Calendar.getInstance();
          localCalendar3.setTime(localDutySection.getSignOutTime());
          DateUtil.copyYearMonthDay(localCalendar3, localCalendar1);
          k = localCalendar1.compareTo(localCalendar2);
          m = localCalendar1.compareTo(localCalendar3);
          if ((k >= 0) && (m <= 0))
            localStringBuffer.append(",allowSignOff:'1'");
          else if (k < 0)
            localStringBuffer.append(",allowSignOff:'-1'");
          else
            localStringBuffer.append(",allowSignOff:'0'");
        }
        localStringBuffer.append("}");
      }
      localStringBuffer.append("]}");
      setJsonString(localStringBuffer.toString());
    }
    this.dutySystemService.evict(localDutySystem);
    return "success";
  }

  public String signIn()
  {
    String str = getRequest().getParameter("sectionId");
    this.dutyRegisterService.signInOff(new Long(str), DutyRegister.SIGN_IN, ContextUtil.getCurrentUser(), new Date());
    this.jsonString = "{success:true}";
    return "success";
  }

  public String signOff()
  {
    String str = getRequest().getParameter("sectionId");
    this.dutyRegisterService.signInOff(new Long(str), DutyRegister.SIGN_OFF, ContextUtil.getCurrentUser(), new Date());
    this.jsonString = "{success:true}";
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.dutyRegisterService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    DutyRegister localDutyRegister = (DutyRegister)this.dutyRegisterService.get(this.registerId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localDutyRegister));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    HttpServletRequest localHttpServletRequest = getRequest();
    String str = localHttpServletRequest.getParameter("userIds");
    Long localLong = new Long(localHttpServletRequest.getParameter("sectionId"));
    Short localShort = new Short(localHttpServletRequest.getParameter("inOffFlag"));
    Date localDate = DateUtil.parseDate(localHttpServletRequest.getParameter("registerDate"));
    String[] arrayOfString = str.split("[,]");
    for (int i = 0; i < arrayOfString.length; i++)
    {
      AppUser localAppUser = (AppUser)this.appUserService.get(new Long(arrayOfString[i]));
      this.dutyRegisterService.signInOff(localLong, localShort, localAppUser, localDate);
    }
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.personal.DutyRegisterAction
 * JD-Core Version:    0.6.0
 */