package com.htsoft.oa.action.flow;

import com.htsoft.core.service.DynamicService;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.StringUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.flow.ProcessRun;
import com.htsoft.oa.service.flow.JbpmService;
import com.htsoft.oa.service.flow.ProcessFormService;
import com.htsoft.oa.service.flow.ProcessRunService;
import java.io.Serializable;
import java.util.Map;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.jbpm.pvm.internal.model.ExecutionImpl;

public class ProcessRunDetailAction extends BaseAction
{

  @Resource
  private ProcessRunService processRunService;

  @Resource
  private ProcessFormService processFormService;

  @Resource
  private JbpmService jbpmService;
  private Long runId;
  private Long taskId;

  public Long getRunId()
  {
    return this.runId;
  }

  public void setRunId(Long paramLong)
  {
    this.runId = paramLong;
  }

  public Long getTaskId()
  {
    return this.taskId;
  }

  public void setTaskId(Long paramLong)
  {
    this.taskId = paramLong;
  }

  public String execute()
    throws Exception
  {
    ProcessRun localProcessRun = null;
    if (this.runId == null)
    {
      localObject1 = (ExecutionImpl)this.jbpmService.getProcessInstanceByTaskId(this.taskId.toString());
      str = ((ExecutionImpl)localObject1).getId();
      if (((ExecutionImpl)localObject1).getSuperProcessExecution() != null)
        str = ((ExecutionImpl)localObject1).getSuperProcessExecution().getId();
      localProcessRun = this.processRunService.getByPiId(str);
      getRequest().setAttribute("processRun", localProcessRun);
      this.runId = localProcessRun.getRunId();
    }
    else
    {
      localProcessRun = (ProcessRun)this.processRunService.get(this.runId);
    }
    Object localObject1 = localProcessRun.getEntityId();
    String str = localProcessRun.getEntityName();
    if ((localObject1 != null) && (str != null))
    {
      if (StringUtil.isNumeric(localObject1.toString()))
        localObject1 = new Long(localObject1.toString());
      if (str != null)
      {
        localObject2 = BeanUtil.getDynamicServiceBean(str);
        if (localObject1 != null)
        {
          Object localObject3 = ((DynamicService)localObject2).get((Serializable)localObject1);
          if (localObject3 != null)
          {
            getRequest().setAttribute("entity", localObject3);
            getRequest().setAttribute("entityHtml", BeanUtil.mapEntity2Html((Map)localObject3, str));
          }
        }
      }
    }
    Object localObject2 = this.processFormService.getByRunId(this.runId);
    getRequest().setAttribute("pfList", localObject2);
    return (String)(String)"success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.flow.ProcessRunDetailAction
 * JD-Core Version:    0.6.0
 */