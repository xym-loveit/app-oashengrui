package com.htsoft.oa.action.admin;

import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.admin.Conference;
import com.htsoft.oa.service.admin.ConferenceService;
import javax.annotation.Resource;

public class ConferenceDetailAction extends BaseAction
{

  @Resource
  private ConferenceService conferenceService;
  private Long confId;
  private Conference conference;

  public Conference getConference()
  {
    return this.conference;
  }

  public void setConference(Conference paramConference)
  {
    this.conference = paramConference;
  }

  public Long getConfId()
  {
    return this.confId;
  }

  public void setConfId(Long paramLong)
  {
    this.confId = paramLong;
  }

  public String execute()
    throws Exception
  {
    this.conference = ((Conference)this.conferenceService.get(this.confId));
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.admin.ConferenceDetailAction
 * JD-Core Version:    0.6.0
 */