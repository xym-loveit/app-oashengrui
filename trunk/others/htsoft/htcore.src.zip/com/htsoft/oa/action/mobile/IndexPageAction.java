package com.htsoft.oa.action.mobile;

import com.htsoft.core.web.action.BaseAction;

public class IndexPageAction extends BaseAction
{
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.mobile.IndexPageAction
 * JD-Core Version:    0.6.0
 */