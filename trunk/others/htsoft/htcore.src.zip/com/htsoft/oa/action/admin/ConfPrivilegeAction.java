package com.htsoft.oa.action.admin;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.admin.ConfPrivilege;
import com.htsoft.oa.service.admin.ConfPrivilegeService;
import java.lang.reflect.Type;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class ConfPrivilegeAction extends BaseAction
{

  @Resource
  private ConfPrivilegeService confPrivilegeService;
  private ConfPrivilege confPrivilege;
  private Long privilegeId;

  public Long getPrivilegeId()
  {
    return this.privilegeId;
  }

  public void setPrivilegeId(Long paramLong)
  {
    this.privilegeId = paramLong;
  }

  public ConfPrivilege getConfPrivilege()
  {
    return this.confPrivilege;
  }

  public void setConfPrivilege(ConfPrivilege paramConfPrivilege)
  {
    this.confPrivilege = paramConfPrivilege;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.confPrivilegeService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.confPrivilegeService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    ConfPrivilege localConfPrivilege = (ConfPrivilege)this.confPrivilegeService.get(this.privilegeId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localConfPrivilege));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.confPrivilegeService.save(this.confPrivilege);
    setJsonString("{success:true}");
    return "success";
  }

  public String allowView()
  {
    String str = getRequest().getParameter("confId");
    Short localShort = this.confPrivilegeService.getPrivilege(new Long(str), Short.valueOf(1));
    if (localShort.shortValue() == 1)
      setJsonString("{success:true}");
    else
      setJsonString("{failure:true,msg:'对不起，您没有权限查看该会议内容，请原谅！'}");
    return "success";
  }

  public String allowUpdater()
  {
    String str = getRequest().getParameter("confId");
    Short localShort = this.confPrivilegeService.getPrivilege(new Long(str), Short.valueOf(2));
    if (localShort.shortValue() == 2)
      setJsonString("{success:true}");
    else
      setJsonString("{failure:true,msg:'对不起，您没有权限编辑该会议内容，请原谅！'}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.admin.ConfPrivilegeAction
 * JD-Core Version:    0.6.0
 */