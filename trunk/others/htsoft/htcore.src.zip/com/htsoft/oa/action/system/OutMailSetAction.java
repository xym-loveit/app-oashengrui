package com.htsoft.oa.action.system;

import com.google.gson.Gson;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.communicate.OutMailUserSeting;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.communicate.OutMailUserSetingService;
import com.htsoft.oa.service.system.AppUserService;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class OutMailSetAction extends BaseAction
{

  @Resource
  private OutMailUserSetingService outMailUserSetingService;

  @Resource
  private AppUserService appUserService;
  private AppUser appUser;
  private OutMailUserSeting outMailUserSeting;
  private Long id;

  public AppUser getAppUser()
  {
    return this.appUser;
  }

  public void setAppUser(AppUser paramAppUser)
  {
    this.appUser = paramAppUser;
  }

  public OutMailUserSeting getOutMailUserSeting()
  {
    return this.outMailUserSeting;
  }

  public void setOutMailUserSeting(OutMailUserSeting paramOutMailUserSeting)
  {
    this.outMailUserSeting = paramOutMailUserSeting;
  }

  public Long getId()
  {
    return this.id;
  }

  public void setId(Long paramLong)
  {
    this.id = paramLong;
  }

  public String list()
  {
    PagingBean localPagingBean = new PagingBean(this.start.intValue(), this.limit.intValue());
    String str = getRequest().getParameter("userName");
    List localList;
    StringBuffer localStringBuffer;
    int i;
    OutMailUserSeting localOutMailUserSeting;
    if (StringUtils.isNotEmpty(str))
    {
      localList = this.outMailUserSetingService.findByUserAll(str, localPagingBean);
      localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localPagingBean.getTotalItems()).append(",result:[");
      for (i = 0; i < localList.size(); i++)
      {
        localOutMailUserSeting = (OutMailUserSeting)localList.get(i);
        if (localOutMailUserSeting != null)
          localStringBuffer.append("{'id':'" + localOutMailUserSeting.getId() + "','userId':'" + localOutMailUserSeting.getUserId() + "'" + ",'userName':'" + localOutMailUserSeting.getUserName() + "'" + ",'mailAddress':'" + localOutMailUserSeting.getMailAddress() + "'" + ",'mailPass':'" + localOutMailUserSeting.getMailPass() + "','smtpHost':'" + localOutMailUserSeting.getSmtpHost() + "','smtpPort':'" + localOutMailUserSeting.getSmtpPort() + "'" + ",'mailAddress':'" + localOutMailUserSeting.getMailAddress() + "','mailAddress':'" + localOutMailUserSeting.getMailAddress() + "'" + ",'popHost':'" + localOutMailUserSeting.getPopHost() + "','popPort':'" + localOutMailUserSeting.getPopPort() + "'}");
        else
          localStringBuffer.append("{'id':'','userId':'','userName':'','mailAddress':'','mailAddress':'','mailPass':'','smtpHost':'','smtpPort':'','popHost':'','popPort':''}");
      }
      localStringBuffer.append("]}");
      this.jsonString = localStringBuffer.toString();
    }
    else
    {
      localList = this.outMailUserSetingService.findByUserAll();
      localStringBuffer = new StringBuffer("{success:true,'totalCounts':");
      localStringBuffer.append(localList.size()).append(",result:[");
      for (i = 0; i < localList.size(); i++)
      {
        if (i > 0)
          localStringBuffer.append(",");
        localOutMailUserSeting = (OutMailUserSeting)((java.lang.Object[])localList.get(i))[0];
        AppUser localAppUser = (AppUser)((java.lang.Object[])localList.get(i))[1];
        localStringBuffer.append("{'userId':'" + localAppUser.getUserId() + "','userName':'" + localAppUser.getFullname() + "',");
        if (localOutMailUserSeting != null)
          localStringBuffer.append("'id':'" + localOutMailUserSeting.getId() + "','mailAddress':'" + localOutMailUserSeting.getMailAddress() + "'" + ",'mailPass':'" + localOutMailUserSeting.getMailPass() + "','smtpHost':'" + localOutMailUserSeting.getSmtpHost() + "','smtpPort':'" + localOutMailUserSeting.getSmtpPort() + "'" + ",'mailAddress':'" + localOutMailUserSeting.getMailAddress() + "','mailAddress':'" + localOutMailUserSeting.getMailAddress() + "'" + ",'popHost':'" + localOutMailUserSeting.getPopHost() + "','popPort':'" + localOutMailUserSeting.getPopPort() + "'}");
        else
          localStringBuffer.append("'id':'','mailAddress':'','mailAddress':'','mailPass':'','smtpHost':'','smtpPort':'','popHost':'','popPort':''}");
      }
      localStringBuffer.append("]}");
      this.jsonString = localStringBuffer.toString();
    }
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.outMailUserSetingService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    OutMailUserSeting localOutMailUserSeting = (OutMailUserSeting)this.outMailUserSetingService.get(this.id);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    if (localOutMailUserSeting != null)
    {
      localStringBuffer.append(localGson.toJson(localOutMailUserSeting));
    }
    else
    {
      localOutMailUserSeting = new OutMailUserSeting();
      localOutMailUserSeting.setUserId(ContextUtil.getCurrentUserId());
      localOutMailUserSeting.setUserName(ContextUtil.getCurrentUser().getUsername());
      localStringBuffer.append(localGson.toJson(localOutMailUserSeting));
    }
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    String str = getRequest().getParameter("data");
    if (StringUtils.isNotEmpty(str))
    {
      Gson localGson = new Gson();
      OutMailUserSeting[] arrayOfOutMailUserSeting1 = (OutMailUserSeting[])localGson.fromJson(str, [Lcom.htsoft.oa.model.communicate.OutMailUserSeting.class);
      for (OutMailUserSeting localOutMailUserSeting : arrayOfOutMailUserSeting1)
      {
        if (localOutMailUserSeting.getId().longValue() == -1L)
          localOutMailUserSeting.setId(null);
        if ((localOutMailUserSeting.getReuserId() == null) || (!StringUtils.isNotEmpty(localOutMailUserSeting.getMailAddress())) || (!StringUtils.isNotEmpty(localOutMailUserSeting.getPopHost())) || (!StringUtils.isNotEmpty(localOutMailUserSeting.getUserName())) || (!StringUtils.isNotEmpty(localOutMailUserSeting.getSmtpPort())) || (!StringUtils.isNotEmpty(localOutMailUserSeting.getSmtpHost())) || (!StringUtils.isNotEmpty(localOutMailUserSeting.getPopPort())) || (!StringUtils.isNotEmpty(localOutMailUserSeting.getMailPass())))
          continue;
        AppUser localAppUser = (AppUser)this.appUserService.get(localOutMailUserSeting.getReuserId());
        localOutMailUserSeting.setAppUser(localAppUser);
        this.outMailUserSetingService.save(localOutMailUserSeting);
      }
    }
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.OutMailSetAction
 * JD-Core Version:    0.6.0
 */