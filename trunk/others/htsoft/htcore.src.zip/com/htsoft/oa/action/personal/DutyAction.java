package com.htsoft.oa.action.personal;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.personal.Duty;
import com.htsoft.oa.model.personal.DutySystem;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.personal.DutyService;
import com.htsoft.oa.service.personal.DutySystemService;
import com.htsoft.oa.service.system.AppUserService;
import flexjson.JSONSerializer;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;

public class DutyAction extends BaseAction
{

  @Resource
  private DutyService dutyService;

  @Resource
  private DutySystemService dutySystemService;

  @Resource
  private AppUserService appUserService;
  private Duty duty;
  private Long dutyId;

  public Long getDutyId()
  {
    return this.dutyId;
  }

  public void setDutyId(Long paramLong)
  {
    this.dutyId = paramLong;
  }

  public Duty getDuty()
  {
    return this.duty;
  }

  public void setDuty(Duty paramDuty)
  {
    this.duty = paramDuty;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.dutyService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "startTime", "endTime" });
    localStringBuffer.append(localJSONSerializer.serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.dutyService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    Duty localDuty = (Duty)this.dutyService.get(this.dutyId);
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "startTime", "endTime" });
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localJSONSerializer.serialize(localDuty));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    String str = getRequest().getParameter("dutySystemId");
    if (StringUtils.isNotEmpty(str))
    {
      localObject = (DutySystem)this.dutySystemService.get(new Long(str));
      this.duty.setDutySystem((DutySystem)localObject);
    }
    Object localObject = getRequest().getParameter("duty.userId");
    String[] arrayOfString = ((String)localObject).split("[,]");
    StringBuffer localStringBuffer = new StringBuffer("");
    int i = 0;
    if (arrayOfString != null)
      for (int j = 0; j < arrayOfString.length; j++)
      {
        AppUser localAppUser = (AppUser)this.appUserService.get(new Long(arrayOfString[j]));
        Duty localDuty = new Duty();
        try
        {
          BeanUtil.copyNotNullProperties(localDuty, this.duty);
          boolean bool = false;
          if (localDuty.getDutyId() == null)
            bool = this.dutyService.isExistDutyForUser(localAppUser.getUserId(), localDuty.getStartTime(), localDuty.getEndTime());
          if (bool)
          {
            i = 1;
            localStringBuffer.append(localAppUser.getFullname()).append(",");
          }
          else
          {
            localDuty.setAppUser(localAppUser);
            localDuty.setFullname(localAppUser.getFullname());
            this.dutyService.save(localDuty);
          }
        }
        catch (Exception localException)
        {
          this.logger.error("error:" + localException.getMessage());
        }
      }
    if (i != 0)
    {
      SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
      localStringBuffer.append("在该时间(").append(localSimpleDateFormat.format(this.duty.getStartTime())).append("至").append(localSimpleDateFormat.format(this.duty.getEndTime())).append(")内已经存在班制!");
    }
    setJsonString("{success:true,exception:'" + localStringBuffer.toString() + "'}");
    return (String)"success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.personal.DutyAction
 * JD-Core Version:    0.6.0
 */