package com.htsoft.oa.action.customer;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.customer.Product;
import com.htsoft.oa.service.customer.ProductService;
import flexjson.JSONSerializer;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class ProductAction extends BaseAction
{

  @Resource
  private ProductService productService;
  private Product product;
  private Long productId;

  public Long getProductId()
  {
    return this.productId;
  }

  public void setProductId(Long paramLong)
  {
    this.productId = paramLong;
  }

  public Product getProduct()
  {
    return this.product;
  }

  public void setProduct(Product paramProduct)
  {
    this.product = paramProduct;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.productService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "createtime", "updatetime" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.productService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    Product localProduct = (Product)this.productService.get(this.productId);
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "createtime", "updatetime" });
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localProduct));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.product.setUpdatetime(new Date());
    this.productService.save(this.product);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.customer.ProductAction
 * JD-Core Version:    0.6.0
 */