package com.htsoft.oa.action.admin;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.admin.InStock;
import com.htsoft.oa.model.admin.OfficeGoods;
import com.htsoft.oa.service.admin.InStockService;
import com.htsoft.oa.service.admin.OfficeGoodsService;
import flexjson.JSONSerializer;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class InStockAction extends BaseAction
{

  @Resource
  private InStockService inStockService;
  private InStock inStock;

  @Resource
  private OfficeGoodsService officeGoodsService;
  private Long buyId;

  public Long getBuyId()
  {
    return this.buyId;
  }

  public void setBuyId(Long paramLong)
  {
    this.buyId = paramLong;
  }

  public InStock getInStock()
  {
    return this.inStock;
  }

  public void setInStock(InStock paramInStock)
  {
    this.inStock = paramInStock;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.inStockService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "inDate" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.inStockService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    InStock localInStock = (InStock)this.inStockService.get(this.buyId);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "inDate" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localInStock));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss-SSS");
    this.inStock.setStockNo(localSimpleDateFormat.format(new Date()));
    Integer localInteger1 = this.inStock.getInCounts();
    BigDecimal localBigDecimal1 = this.inStock.getPrice();
    BigDecimal localBigDecimal2 = null;
    if ((localInteger1 != null) && (localBigDecimal1 != null))
      localBigDecimal2 = localBigDecimal1.multiply(BigDecimal.valueOf(localInteger1.intValue()));
    this.inStock.setAmount(localBigDecimal2);
    Long localLong = this.inStock.getGoodsId();
    OfficeGoods localOfficeGoods = (OfficeGoods)this.officeGoodsService.get(localLong);
    if (this.inStock.getBuyId() == null)
    {
      localOfficeGoods.setStockCounts(Integer.valueOf(localOfficeGoods.getStockCounts().intValue() + this.inStock.getInCounts().intValue()));
    }
    else
    {
      Integer localInteger2 = this.inStock.getInCounts();
      Integer localInteger3 = this.inStockService.findInCountByBuyId(this.inStock.getBuyId());
      if (!localInteger3.equals(localInteger2))
        localOfficeGoods.setStockCounts(Integer.valueOf(localOfficeGoods.getStockCounts().intValue() - localInteger3.intValue() + localInteger2.intValue()));
    }
    this.inStockService.save(this.inStock);
    this.officeGoodsService.save(localOfficeGoods);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.admin.InStockAction
 * JD-Core Version:    0.6.0
 */