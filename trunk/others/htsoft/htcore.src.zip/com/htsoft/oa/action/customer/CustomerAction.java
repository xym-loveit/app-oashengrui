package com.htsoft.oa.action.customer;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.customer.Customer;
import com.htsoft.oa.service.customer.CustomerService;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class CustomerAction extends BaseAction
{

  @Resource
  private CustomerService customerService;
  private Customer customer;
  private Long customerId;
  private String customerNo;

  public Long getCustomerId()
  {
    return this.customerId;
  }

  public void setCustomerId(Long paramLong)
  {
    this.customerId = paramLong;
  }

  public Customer getCustomer()
  {
    return this.customer;
  }

  public void setCustomer(Customer paramCustomer)
  {
    this.customer = paramCustomer;
  }

  public String getCustomerNo()
  {
    return this.customerNo;
  }

  public void setCustomerNo(String paramString)
  {
    this.customerNo = paramString;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.customerService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.customerService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    Customer localCustomer = (Customer)this.customerService.get(this.customerId);
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localCustomer));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    int i = 0;
    StringBuffer localStringBuffer = new StringBuffer("{");
    if (this.customer.getCustomerId() == null)
    {
      if (this.customerService.checkCustomerNo(this.customer.getCustomerNo()))
        i = 1;
      else
        localStringBuffer.append("msg:'客户已存在,请重新填写.',rewrite:true,");
    }
    else
      i = 1;
    if (i != 0)
    {
      this.customerService.save(this.customer);
      localStringBuffer.append("success:true,customerId:" + this.customer.getCustomerId() + "}");
    }
    else
    {
      localStringBuffer.append("failure:true}");
    }
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String number()
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss-SSS");
    String str = localSimpleDateFormat.format(new Date());
    setJsonString("{success:true,customerNo:'" + str + "'}");
    return "success";
  }

  public String check()
  {
    boolean bool = false;
    bool = this.customerService.checkCustomerNo(this.customerNo);
    if (bool)
      setJsonString("{success:true,pass:true}");
    else
      setJsonString("{success:true,pass:false}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.customer.CustomerAction
 * JD-Core Version:    0.6.0
 */