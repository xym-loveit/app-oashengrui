package com.htsoft.oa.action.document;

import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.system.FileAttach;
import com.htsoft.oa.service.system.FileAttachService;
import javax.annotation.Resource;

public class FileDetailAction extends BaseAction
{

  @Resource
  private FileAttachService fileAttachService;
  private FileAttach fileAttach;
  private Long fileId;

  public Long getFileId()
  {
    return this.fileId;
  }

  public void setFileId(Long paramLong)
  {
    this.fileId = paramLong;
  }

  public FileAttach getFileAttach()
  {
    return this.fileAttach;
  }

  public void setFileAttach(FileAttach paramFileAttach)
  {
    this.fileAttach = paramFileAttach;
  }

  public String execute()
    throws Exception
  {
    this.fileAttach = ((FileAttach)this.fileAttachService.get(this.fileId));
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.document.FileDetailAction
 * JD-Core Version:    0.6.0
 */