package com.htsoft.oa.action.flow;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.jbpm.jpdl.Node;
import com.htsoft.core.util.AppUtil;
import com.htsoft.core.util.FileUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.flow.FormDefMapping;
import com.htsoft.oa.model.flow.FormTemplate;
import com.htsoft.oa.model.flow.ProDefinition;
import com.htsoft.oa.service.flow.FormDefMappingService;
import com.htsoft.oa.service.flow.FormTemplateService;
import com.htsoft.oa.service.flow.JbpmService;
import com.htsoft.oa.service.flow.ProDefinitionService;
import java.io.File;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;

public class FormTemplateAction extends BaseAction
{

  @Resource
  private FormTemplateService formTemplateService;

  @Resource
  private FormDefMappingService formDefMappingService;

  @Resource
  private ProDefinitionService proDefinitionService;

  @Resource
  private JbpmService jbpmService;
  private FormTemplate formTemplate;
  private Long templateId;
  private Long mappingId;

  public Long getTemplateId()
  {
    return this.templateId;
  }

  public void setTemplateId(Long paramLong)
  {
    this.templateId = paramLong;
  }

  public Long getMappingId()
  {
    return this.mappingId;
  }

  public void setMappingId(Long paramLong)
  {
    this.mappingId = paramLong;
  }

  public FormTemplate getFormTemplate()
  {
    return this.formTemplate;
  }

  public void setFormTemplate(FormTemplate paramFormTemplate)
  {
    this.formTemplate = paramFormTemplate;
  }

  public String mappings()
  {
    FormDefMapping localFormDefMapping = (FormDefMapping)this.formDefMappingService.get(this.mappingId);
    List localList1 = this.formTemplateService.getByMappingId(this.mappingId);
    List localList2 = this.jbpmService.getFormNodesByDeployId(new Long(localFormDefMapping.getDeployId()));
    StringBuffer localStringBuffer = new StringBuffer("{success:true,result:[");
    for (int i = 0; i < localList2.size(); i++)
    {
      String str = ((Node)localList2.get(i)).getName();
      localStringBuffer.append("{nodeName:'").append(str).append("'");
      Iterator localIterator = localList1.iterator();
      while (localIterator.hasNext())
      {
        FormTemplate localFormTemplate = (FormTemplate)localIterator.next();
        if (str.equals(localFormTemplate.getNodeName()))
        {
          localStringBuffer.append(",mappingId:'").append(localFormTemplate.getMappingId()).append("',templateId:'").append(localFormTemplate.getTemplateId()).append("',formUrl:'").append(localFormTemplate.getFormUrl() == null ? "" : localFormTemplate.getFormUrl()).append("',tempType:'").append(localFormTemplate.getTempType() == null ? 1 : localFormTemplate.getTempType().shortValue()).append("'");
          break;
        }
      }
      localStringBuffer.append("},");
    }
    if (localList2.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String saveList()
  {
    String str = getRequest().getParameter("formTemps");
    if (StringUtils.isNotEmpty("formTemps"))
    {
      Gson localGson = new Gson();
      FormTemplate[] arrayOfFormTemplate1 = (FormTemplate[])(FormTemplate[])localGson.fromJson(str, [Lcom.htsoft.oa.model.flow.FormTemplate.class);
      if (arrayOfFormTemplate1 != null)
        for (FormTemplate localFormTemplate1 : arrayOfFormTemplate1)
        {
          if (localFormTemplate1.getTemplateId() == null)
            continue;
          FormTemplate localFormTemplate2 = (FormTemplate)this.formTemplateService.get(localFormTemplate1.getTemplateId());
          localFormTemplate2.setTempType(localFormTemplate1.getTempType());
          localFormTemplate2.setFormUrl(localFormTemplate1.getFormUrl());
          this.formTemplateService.save(localFormTemplate2);
        }
    }
    return "success";
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.formTemplateService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.formTemplateService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    FormTemplate localFormTemplate = (FormTemplate)this.formTemplateService.get(this.templateId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localFormTemplate));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    String str1 = getRequest().getParameter("activityName");
    String str2 = getRequest().getParameter("extFormDef");
    FormTemplate localFormTemplate = (FormTemplate)this.formTemplateService.get(this.templateId);
    localFormTemplate.setTempContent(str2);
    String str3 = getRequest().getParameter("extDef");
    localFormTemplate.setExtDef(str3);
    this.formTemplateService.save(localFormTemplate);
    String str4 = getRequest().getParameter("formItemDef");
    this.logger.info("extFormDef:" + str2);
    this.logger.info("formItemDef:" + str4);
    ProDefinition localProDefinition = this.proDefinitionService.getByDeployId(localFormTemplate.getFormDefMapping().getDeployId());
    String str5 = AppUtil.getAppAbsolutePath() + "/WEB-INF/FlowForm/" + localProDefinition.getName() + "/" + localFormTemplate.getFormDefMapping().getVersionNo();
    File localFile = new File(str5);
    if (!localFile.exists())
      localFile.mkdirs();
    if (localProDefinition != null)
    {
      String str6 = str5 + "/" + str1 + ".vm";
      FileUtil.writeFile(str6, str2);
    }
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.flow.FormTemplateAction
 * JD-Core Version:    0.6.0
 */