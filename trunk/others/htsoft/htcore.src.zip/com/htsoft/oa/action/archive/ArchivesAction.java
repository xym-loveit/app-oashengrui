package com.htsoft.oa.action.archive;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.archive.ArchHasten;
import com.htsoft.oa.model.archive.Archives;
import com.htsoft.oa.model.archive.ArchivesDep;
import com.htsoft.oa.model.archive.ArchivesDoc;
import com.htsoft.oa.model.archive.DocHistory;
import com.htsoft.oa.model.flow.ProcessRun;
import com.htsoft.oa.model.info.ShortMessage;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.Department;
import com.htsoft.oa.model.system.FileAttach;
import com.htsoft.oa.model.system.GlobalType;
import com.htsoft.oa.service.archive.ArchHastenService;
import com.htsoft.oa.service.archive.ArchivesDepService;
import com.htsoft.oa.service.archive.ArchivesDocService;
import com.htsoft.oa.service.archive.ArchivesService;
import com.htsoft.oa.service.archive.DocHistoryService;
import com.htsoft.oa.service.flow.JbpmService;
import com.htsoft.oa.service.flow.ProcessRunService;
import com.htsoft.oa.service.flow.TaskService;
import com.htsoft.oa.service.info.ShortMessageService;
import com.htsoft.oa.service.system.AppUserService;
import com.htsoft.oa.service.system.DepartmentService;
import com.htsoft.oa.service.system.FileAttachService;
import com.htsoft.oa.service.system.GlobalTypeService;
import flexjson.JSONSerializer;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.jbpm.api.task.Task;

public class ArchivesAction extends BaseAction
{

  @Resource
  private ArchivesService archivesService;

  @Resource
  private ArchivesDocService archivesDocService;

  @Resource
  private GlobalTypeService globalTypeService;

  @Resource
  private DepartmentService departmentService;

  @Resource
  private ArchivesDepService archivesDepService;

  @Resource
  private JbpmService jbpmService;

  @Resource
  private ProcessRunService processRunService;
  private Archives archives;

  @Resource
  private AppUserService appUserService;

  @Resource
  private FileAttachService fileAttachService;

  @Resource
  private DocHistoryService docHistoryService;

  @Resource
  private TaskService taskservice;

  @Resource
  private ShortMessageService messageService;

  @Resource
  private ArchHastenService archHastenService;
  private Long archivesId;

  public Long getArchivesId()
  {
    return this.archivesId;
  }

  public void setArchivesId(Long paramLong)
  {
    this.archivesId = paramLong;
  }

  public Archives getArchives()
  {
    return this.archives;
  }

  public void setArchives(Archives paramArchives)
  {
    this.archives = paramArchives;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    List localList1 = this.archivesService.getAll(localQueryFilter);
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:[");
    Iterator localIterator1 = localList1.iterator();
    while (localIterator1.hasNext())
    {
      Archives localArchives = (Archives)localIterator1.next();
      localStringBuffer.append("{archivesId:").append(localArchives.getArchivesId());
      localStringBuffer.append(",archivesType:").append(localJSONSerializer.serialize(localArchives.getArchivesType()));
      localStringBuffer.append(",archivesRecType:").append(localJSONSerializer.serialize(localArchives.getArchivesRecType()));
      localStringBuffer.append(",archivesNo:").append(localGson.toJson(localArchives.getArchivesNo()));
      localStringBuffer.append(",issueDep:").append(localGson.toJson(localArchives.getIssueDep()));
      localStringBuffer.append(",subject:").append(localGson.toJson(localArchives.getSubject()));
      localStringBuffer.append(",issueDate:'").append(localSimpleDateFormat.format(localArchives.getIssueDate())).append("'");
      localStringBuffer.append(",status:").append(localGson.toJson(localArchives.getStatus()));
      localStringBuffer.append(",fileCounts:").append(localArchives.getFileCounts());
      localStringBuffer.append(",privacyLevel:").append(localGson.toJson(localArchives.getPrivacyLevel()));
      localStringBuffer.append(",urgentLevel:").append(localGson.toJson(localArchives.getUrgentLevel()));
      localStringBuffer.append(",issuer:").append(localGson.toJson(localArchives.getIssuer()));
      localStringBuffer.append(",keywords:").append(localGson.toJson(localArchives.getKeywords()));
      localStringBuffer.append(",sources:").append(localGson.toJson(localArchives.getSources()));
      localStringBuffer.append(",archType:").append(localArchives.getArchType());
      localStringBuffer.append(",createtime:'").append(localSimpleDateFormat.format(localArchives.getCreatetime())).append("'");
      localStringBuffer.append(",runId:").append(localArchives.getRunId());
      localStringBuffer.append(",archStatus:").append(localArchives.getArchStatus());
      if (localArchives.getRunId() != null)
      {
        ProcessRun localProcessRun = (ProcessRun)this.processRunService.get(localArchives.getRunId());
        if (localProcessRun.getPiId() != null)
        {
          List localList2 = this.jbpmService.getTasksByPiId(localProcessRun.getPiId());
          localStringBuffer.append(",tasks:[");
          Iterator localIterator2 = localList2.iterator();
          while (localIterator2.hasNext())
          {
            Task localTask = (Task)localIterator2.next();
            localStringBuffer.append("{taskId:").append(localTask.getId()).append(",taskName:").append(localGson.toJson(localTask.getName()));
            if (localTask.getAssignee() != null)
            {
              AppUser localAppUser = (AppUser)this.appUserService.get(new Long(localTask.getAssignee()));
              if (localAppUser != null)
                localStringBuffer.append(",userId:").append(localTask.getAssignee()).append(",fullname:").append(localGson.toJson(localAppUser.getFullname()));
            }
            localStringBuffer.append("},");
          }
          if (localList2.size() > 0)
            localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
          localStringBuffer.append("]");
        }
      }
      localStringBuffer.append("},");
    }
    if (localList1.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String cruList()
  {
    PagingBean localPagingBean = getInitPagingBean();
    AppUser localAppUser = ContextUtil.getCurrentUser();
    List localList = this.archivesService.findByUserOrRole(localAppUser.getUserId(), localAppUser.getRoles(), localPagingBean);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localPagingBean.getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.archivesService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    Archives localArchives = (Archives)this.archivesService.get(this.archivesId);
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localArchives));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    String str1 = getRequest().getParameter("archivesRecfileIds");
    String str2 = getRequest().getParameter("archDepId");
    String str3 = getRequest().getParameter("signUserIds");
    AppUser localAppUser = ContextUtil.getCurrentUser();
    this.archives.setArchType(Archives.ARCHIVE_TYPE_RECEIVE);
    this.archives.setIssuerId(localAppUser.getUserId());
    this.archives.setIssuer(localAppUser.getFullname());
    this.archives.setHandlerUids(str3);
    this.archives.setIssueDate(new Date());
    if (StringUtils.isNotEmpty(str1))
      this.archives.setFileCounts(Integer.valueOf(str1.split(",").length));
    this.archivesService.save(this.archives);
    Object localObject1;
    Object localObject2;
    if (StringUtils.isNotEmpty(str1))
    {
      localObject1 = this.archivesDocService.findByAid(this.archives.getArchivesId());
      localObject2 = ((List)localObject1).iterator();
      Object localObject3;
      while (((Iterator)localObject2).hasNext())
      {
        localObject3 = (ArchivesDoc)((Iterator)localObject2).next();
        this.archivesDocService.remove(localObject3);
      }
      localObject2 = str1.split(",");
      for (String str4 : localObject2)
      {
        FileAttach localFileAttach = (FileAttach)this.fileAttachService.get(new Long(str4));
        ArchivesDoc localArchivesDoc = new ArchivesDoc();
        localArchivesDoc.setArchives(this.archives);
        localArchivesDoc.setFileAttach(localFileAttach);
        localArchivesDoc.setDocName(localFileAttach.getFileName());
        localArchivesDoc.setDocStatus(Short.valueOf(1));
        localArchivesDoc.setCurVersion(Integer.valueOf(1));
        localArchivesDoc.setDocPath(localFileAttach.getFilePath());
        localArchivesDoc.setCreatetime(new Date());
        localArchivesDoc.setUpdatetime(new Date());
        this.archivesDocService.save(localArchivesDoc);
      }
    }
    if (StringUtils.isNotEmpty(str2))
    {
      localObject1 = (ArchivesDep)this.archivesDepService.get(new Long(str2));
      localObject2 = ContextUtil.getCurrentUser();
      ((ArchivesDep)localObject1).setStatus(ArchivesDep.STATUS_SIGNED);
      ((ArchivesDep)localObject1).setSignTime(new Date());
      ((ArchivesDep)localObject1).setSignFullname(((AppUser)localObject2).getFullname());
      ((ArchivesDep)localObject1).setSignUserID(((AppUser)localObject2).getUserId());
      this.archivesDepService.save(localObject1);
    }
    setJsonString("{success:true,archivesId:" + this.archives.getArchivesId() + "}");
    return (String)(String)(String)"success";
  }

  public String docs()
  {
    StringBuffer localStringBuffer = new StringBuffer("{success:true,totalCounts:");
    if (this.archivesId != null)
    {
      this.archives = ((Archives)this.archivesService.get(this.archivesId));
      Gson localGson = new Gson();
      Set localSet = this.archives.getArchivesDocs();
      ArrayList localArrayList = new ArrayList();
      localArrayList.addAll(localSet);
      Type localType = new TypeToken()
      {
      }
      .getType();
      localStringBuffer.append(localSet.size());
      localStringBuffer.append(",results:").append(new Gson().toJson(localArrayList, localType));
    }
    else
    {
      localStringBuffer.append("0,results:[]");
    }
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String getIssue()
  {
    Archives localArchives = (Archives)this.archivesService.get(this.archivesId);
    JSONSerializer localJSONSerializer = new JSONSerializer();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localJSONSerializer.serialize(localArchives));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String saveIssue()
  {
    String str1 = getRequest().getParameter("docs");
    String str2 = getRequest().getParameter("statusValue");
    Long localLong = new Long(1L);
    AppUser localAppUser = ContextUtil.getCurrentUser();
    HashSet localHashSet = new HashSet();
    Object localObject1;
    Object localObject2;
    if (StringUtils.isNotEmpty(str1))
    {
      localObject1 = new Gson();
      localObject2 = (ArchivesDoc[])((Gson)localObject1).fromJson(str1, [Lcom.htsoft.oa.model.archive.ArchivesDoc.class);
      if (localObject2 != null)
        for (int i = 0; i < localObject2.length; i++)
        {
          if ((localObject2[i].getDocId() == null) || (localObject2[i].getDocId().longValue() == 0L))
          {
            localObject2[i].setDocId(null);
            localObject2[i].initUsers(localAppUser);
            localObject2[i].setDocStatus(Short.valueOf(ArchivesDoc.STATUS_MODIFY));
            localObject2[i].setUpdatetime(new Date());
            localObject2[i].setCreatetime(new Date());
            localObject2[i].setFileAttach(this.fileAttachService.getByPath(localObject2[i].getDocPath()));
            this.archivesDocService.save(localObject2[i]);
            DocHistory localDocHistory = new DocHistory();
            localDocHistory.setArchivesDoc(localObject2[i]);
            localDocHistory.setFileAttach(localObject2[i].getFileAttach());
            localDocHistory.setDocName(localObject2[i].getDocName());
            localDocHistory.setPath(localObject2[i].getDocPath());
            localDocHistory.setVersion(Integer.valueOf(ArchivesDoc.ORI_VERSION));
            localDocHistory.setUpdatetime(new Date());
            localDocHistory.setMender(localAppUser.getFullname());
            this.docHistoryService.save(localDocHistory);
          }
          else
          {
            localObject2[i] = ((ArchivesDoc)this.archivesDocService.get(localObject2[i].getDocId()));
          }
          localHashSet.add(localObject2[i]);
        }
    }
    if (this.archives.getArchivesId() == null)
    {
      this.archives.setIssuer(localAppUser.getFullname());
      this.archives.setIssuerId(localAppUser.getUserId());
      localObject1 = (GlobalType)this.globalTypeService.get(this.archives.getArchivesType().getProTypeId());
      this.archives.setArchivesType((GlobalType)localObject1);
      this.archives.setArchType(Archives.ARCHIVE_TYPE_DISPATCH);
      if (StringUtils.isNotEmpty(str2))
        this.archives.setStatus(str2);
      else
        this.archives.setStatus("主任核稿");
      this.archives.setCreatetime(new Date());
      this.archives.setIssueDate(new Date());
      this.archives.setFileCounts(Integer.valueOf(localHashSet.size()));
      this.archives.setArchivesDocs(localHashSet);
      this.archivesService.save(this.archives);
    }
    else
    {
      localObject1 = (Archives)this.archivesService.get(this.archives.getArchivesId());
      localObject2 = (GlobalType)this.globalTypeService.get(this.archives.getArchivesType().getProTypeId());
      this.archives.setArchivesType((GlobalType)localObject2);
      this.archives.setTypeName(((GlobalType)localObject2).getTypeName());
      if (StringUtils.isNotEmpty(str2))
        this.archives.setStatus(str2);
      else
        this.archives.setStatus("主任核稿");
      this.archives.setCreatetime(((Archives)localObject1).getCreatetime());
      this.archives.setFileCounts(Integer.valueOf(localHashSet.size()));
      this.archives.setArchivesDocs(localHashSet);
      this.archives.setIssueDate(new Date());
      this.archives.setArchType(((Archives)localObject1).getArchType());
      this.archives.setIssuer(((Archives)localObject1).getIssuer());
      this.archives.setIssuerId(((Archives)localObject1).getIssuerId());
      this.archivesService.merge(this.archives);
    }
    setJsonString("{success:true,archivesId:'" + this.archives.getArchivesId() + "'}");
    return (String)(String)"success";
  }

  public String handOut()
  {
    if (this.archivesId == null)
      this.archivesId = this.archives.getArchivesId();
    this.archives = ((Archives)this.archivesService.get(this.archivesId));
    String str1 = this.archives.getRecDepIds();
    StringBuffer localStringBuffer1 = new StringBuffer("");
    if (StringUtils.isNotEmpty(str1))
    {
      localObject = str1.split("[,]");
      if (localObject != null)
      {
        StringBuffer localStringBuffer2 = new StringBuffer("");
        for (int i = 0; i < localObject.length; i++)
        {
          Long localLong = new Long(localObject[i]);
          Department localDepartment = (Department)this.departmentService.get(localLong);
          ArchivesDep localArchivesDep = new ArchivesDep();
          localArchivesDep.setSubject(this.archives.getSubject());
          localArchivesDep.setDepartment(localDepartment);
          localArchivesDep.setArchives(this.archives);
          localArchivesDep.setIsMain(ArchivesDep.RECEIVE_MAIN);
          localArchivesDep.setStatus(ArchivesDep.STATUS_UNSIGNED);
          this.archivesDepService.save(localArchivesDep);
        }
        if (StringUtils.isNotEmpty(localStringBuffer2.toString()))
        {
          String str2 = "您有新的公文,请及时签收.";
          this.messageService.save(AppUser.SYSTEM_USER, localStringBuffer2.toString(), str2, ShortMessage.MSG_TYPE_TASK);
        }
      }
    }
    Object localObject = getRequest().getParameter("statusValue");
    if (StringUtils.isNotEmpty((String)localObject))
      this.archives.setStatus((String)localObject);
    this.archivesService.save(this.archives);
    return (String)"success";
  }

  public String hasten()
  {
    String str1 = getRequest().getParameter("activityName");
    String str2 = getRequest().getParameter("archivesId");
    String str3 = getRequest().getParameter("content");
    if ((StringUtils.isNotEmpty(str1)) && (StringUtils.isNotEmpty(str2)))
    {
      Long localLong1 = new Long(str2);
      Archives localArchives = (Archives)this.archivesService.get(localLong1);
      Set localSet = this.taskservice.getHastenByActivityNameVarKeyLongVal(str1, "archives.archivesId", new Long(str2));
      StringBuffer localStringBuffer = new StringBuffer();
      Iterator localIterator = localSet.iterator();
      while (localIterator.hasNext())
      {
        ArchHasten localArchHasten = new ArchHasten();
        Long localLong2 = (Long)localIterator.next();
        AppUser localAppUser = (AppUser)this.appUserService.get(localLong2);
        localArchHasten.setContent(str3);
        localArchHasten.setCreatetime(new Date());
        localArchHasten.setArchives(localArchives);
        localArchHasten.setHastenFullname(ContextUtil.getCurrentUser().getFullname());
        localArchHasten.setHandlerUserId(localAppUser.getUserId());
        localArchHasten.setHandlerFullname(localAppUser.getFullname());
        this.archHastenService.save(localArchHasten);
        localStringBuffer.append(localLong2.toString()).append(",");
      }
      if (localSet.size() > 0)
      {
        localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
        this.messageService.save(AppUser.SYSTEM_USER, localStringBuffer.toString(), str3, ShortMessage.MSG_TYPE_TASK);
      }
    }
    this.jsonString = "{success:true}";
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.archive.ArchivesAction
 * JD-Core Version:    0.6.0
 */