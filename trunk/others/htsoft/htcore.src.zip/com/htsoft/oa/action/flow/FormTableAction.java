package com.htsoft.oa.action.flow;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.flow.FormTable;
import com.htsoft.oa.service.flow.FormTableGenService;
import com.htsoft.oa.service.flow.FormTableService;
import flexjson.JSONSerializer;
import java.lang.reflect.Type;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;

public class FormTableAction extends BaseAction
{

  @Resource
  private FormTableService formTableService;
  private FormTable formTable;

  @Resource
  private FormTableGenService formTableGenService;
  private Long tableId;

  public Long getTableId()
  {
    return this.tableId;
  }

  public void setTableId(Long paramLong)
  {
    this.tableId = paramLong;
  }

  public FormTable getFormTable()
  {
    return this.formTable;
  }

  public void setFormTable(FormTable paramFormTable)
  {
    this.formTable = paramFormTable;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.formTableService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localStringBuffer.append(localJSONSerializer.serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.formTableService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    FormTable localFormTable = (FormTable)this.formTableService.get(this.tableId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localFormTable));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    if (this.formTable.getTableId() == null)
    {
      this.formTableService.save(this.formTable);
    }
    else
    {
      FormTable localFormTable = (FormTable)this.formTableService.get(this.formTable.getTableId());
      try
      {
        BeanUtil.copyNotNullProperties(localFormTable, this.formTable);
        this.formTableService.save(localFormTable);
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.flow.FormTableAction
 * JD-Core Version:    0.6.0
 */