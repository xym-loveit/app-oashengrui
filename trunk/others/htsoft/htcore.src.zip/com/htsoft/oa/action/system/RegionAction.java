package com.htsoft.oa.action.system;

import com.google.gson.Gson;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.system.Region;
import com.htsoft.oa.service.system.RegionService;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class RegionAction extends BaseAction
{

  @Resource
  private RegionService regionService;
  private Region region;
  private Long regionId;

  public Long getRegionId()
  {
    return this.regionId;
  }

  public void setRegionId(Long paramLong)
  {
    this.regionId = paramLong;
  }

  public Region getRegion()
  {
    return this.region;
  }

  public void setRegion(Region paramRegion)
  {
    this.region = paramRegion;
  }

  public String list()
  {
    List localList = null;
    StringBuffer localStringBuffer = new StringBuffer("[");
    Iterator localIterator;
    Region localRegion;
    if (this.regionId == null)
    {
      localList = this.regionService.getProvince();
      localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        localRegion = (Region)localIterator.next();
        localStringBuffer.append("['" + localRegion.getRegionId() + "','" + localRegion.getRegionName() + "'],");
      }
    }
    else
    {
      localList = this.regionService.getCity(this.regionId);
      if (localList.size() > 0)
      {
        localIterator = localList.iterator();
        while (localIterator.hasNext())
        {
          localRegion = (Region)localIterator.next();
          localStringBuffer.append("'" + localRegion.getRegionName() + "',");
        }
      }
      else
      {
        setRegion((Region)this.regionService.get(this.regionId));
        localStringBuffer.append("'" + this.region.getRegionName() + "',");
      }
    }
    localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String tree()
  {
    StringBuffer localStringBuffer = new StringBuffer("[{id:'0',text:'中国',expanded:true,children:[");
    List localList = this.regionService.getProvince();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Region localRegion = (Region)localIterator.next();
      localStringBuffer.append("{id:'" + localRegion.getRegionId() + "',text:'" + localRegion.getRegionName() + "',");
      localStringBuffer.append(findCity(localRegion.getRegionId()));
    }
    if (!localList.isEmpty())
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String findCity(Long paramLong)
  {
    StringBuffer localStringBuffer = new StringBuffer("");
    List localList = this.regionService.getCity(paramLong);
    if (localList.size() == 0)
    {
      localStringBuffer.append("leaf:true},");
      return localStringBuffer.toString();
    }
    localStringBuffer.append("children:[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Region localRegion = (Region)localIterator.next();
      localStringBuffer.append("{id:'" + localRegion.getRegionId() + "',text:'" + localRegion.getRegionName() + "',leaf:true},");
    }
    localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]},");
    return localStringBuffer.toString();
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.regionService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    Region localRegion = (Region)this.regionService.get(this.regionId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localRegion));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.regionService.save(this.region);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.RegionAction
 * JD-Core Version:    0.6.0
 */