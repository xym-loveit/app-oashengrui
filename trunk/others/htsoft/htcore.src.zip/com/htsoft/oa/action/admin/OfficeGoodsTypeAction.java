package com.htsoft.oa.action.admin;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.admin.OfficeGoodsType;
import com.htsoft.oa.service.admin.OfficeGoodsService;
import com.htsoft.oa.service.admin.OfficeGoodsTypeService;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class OfficeGoodsTypeAction extends BaseAction
{

  @Resource
  private OfficeGoodsTypeService officeGoodsTypeService;
  private OfficeGoodsType officeGoodsType;

  @Resource
  private OfficeGoodsService officeGoodsService;
  private Long typeId;

  public Long getTypeId()
  {
    return this.typeId;
  }

  public void setTypeId(Long paramLong)
  {
    this.typeId = paramLong;
  }

  public OfficeGoodsType getOfficeGoodsType()
  {
    return this.officeGoodsType;
  }

  public void setOfficeGoodsType(OfficeGoodsType paramOfficeGoodsType)
  {
    this.officeGoodsType = paramOfficeGoodsType;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.officeGoodsTypeService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String tree()
  {
    String str = getRequest().getParameter("method");
    List localList = this.officeGoodsTypeService.getAll();
    StringBuffer localStringBuffer = new StringBuffer();
    int i = 0;
    if (StringUtils.isNotEmpty(str))
    {
      localStringBuffer.append("[");
    }
    else
    {
      i++;
      localStringBuffer.append("[{id:'0',text:'办公用品分类',expanded:true,children:[");
    }
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      OfficeGoodsType localOfficeGoodsType = (OfficeGoodsType)localIterator.next();
      localStringBuffer.append("{id:'" + localOfficeGoodsType.getTypeId() + "',text:'" + localOfficeGoodsType.getTypeName() + "',leaf:true},");
    }
    if (localList.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    if (i == 0)
      localStringBuffer.append("]");
    else
      localStringBuffer.append("]}]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
      {
        QueryFilter localQueryFilter = new QueryFilter(getRequest());
        localQueryFilter.addFilter("Q_officeGoodsType.typeId_L_EQ", str);
        List localList = this.officeGoodsService.getAll(localQueryFilter);
        if (localList.size() > 0)
        {
          this.jsonString = "{success:false,message:'该类型下还有用品，请转移后再删除！'}";
          return "success";
        }
        this.officeGoodsTypeService.remove(new Long(str));
      }
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    OfficeGoodsType localOfficeGoodsType = (OfficeGoodsType)this.officeGoodsTypeService.get(this.typeId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localOfficeGoodsType));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.officeGoodsTypeService.save(this.officeGoodsType);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.admin.OfficeGoodsTypeAction
 * JD-Core Version:    0.6.0
 */