package com.htsoft.oa.action.info;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.info.SuggestBox;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.SysConfig;
import com.htsoft.oa.service.info.SuggestBoxService;
import com.htsoft.oa.service.system.AppUserService;
import com.htsoft.oa.service.system.SysConfigService;
import java.lang.reflect.Type;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class SuggestBoxAction extends BaseAction
{

  @Resource
  private SuggestBoxService suggestBoxService;

  @Resource
  private SysConfigService sysConfigService;

  @Resource
  private AppUserService appUserService;
  private SuggestBox suggestBox;
  private Long boxId;

  public Long getBoxId()
  {
    return this.boxId;
  }

  public void setBoxId(Long paramLong)
  {
    this.boxId = paramLong;
  }

  public SuggestBox getSuggestBox()
  {
    return this.suggestBox;
  }

  public void setSuggestBox(SuggestBox paramSuggestBox)
  {
    this.suggestBox = paramSuggestBox;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.suggestBoxService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.suggestBoxService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    SuggestBox localSuggestBox = (SuggestBox)this.suggestBoxService.get(this.boxId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localSuggestBox));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.suggestBox.setCreatetime(new Date());
    this.suggestBox.setSenderIp(getRequest().getRemoteAddr());
    SysConfig localSysConfig = this.sysConfigService.findByKey("suggestId");
    AppUser localAppUser = (AppUser)this.appUserService.get(new Long(localSysConfig.getDataValue()));
    if (localAppUser != null)
    {
      this.suggestBox.setRecFullname(localAppUser.getFullname());
      this.suggestBox.setRecUid(localAppUser.getUserId());
    }
    this.suggestBoxService.save(this.suggestBox);
    setJsonString("{success:true}");
    return "success";
  }

  public String reply()
  {
    SuggestBox localSuggestBox = (SuggestBox)this.suggestBoxService.get(this.suggestBox.getBoxId());
    AppUser localAppUser = (AppUser)this.appUserService.get(new Long(this.sysConfigService.findByKey("suggestId").getDataValue()));
    localSuggestBox.setReplyId(localAppUser.getUserId());
    localSuggestBox.setIsOpen(this.suggestBox.getIsOpen());
    localSuggestBox.setReplyFullname(localAppUser.getFullname());
    localSuggestBox.setReplyTime(new Date());
    localSuggestBox.setStatus(SuggestBox.STATUS_AUDIT);
    localSuggestBox.setReplyContent(this.suggestBox.getReplyContent());
    this.suggestBoxService.save(localSuggestBox);
    setJsonString("{success:true}");
    return "success";
  }

  public String match()
  {
    SuggestBox localSuggestBox = (SuggestBox)this.suggestBoxService.get(this.suggestBox.getBoxId());
    if (localSuggestBox.getQueryPwd().equals(this.suggestBox.getQueryPwd()))
      setJsonString("{success:true}");
    else
      setJsonString("{failure:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.info.SuggestBoxAction
 * JD-Core Version:    0.6.0
 */