package com.htsoft.oa.action.flow;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.jbpm.pv.ParamField;
import com.htsoft.oa.model.flow.ProcessRun;
import java.io.Serializable;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class FlowRunInfo
{
  public static final String ENTITY_PK = "entityId";
  public static final String ENTITY_NAME = "entityName";
  public static final String PROCESS_RUNID = "runId";
  public static final String START_USER_ID = "startUserId";
  private boolean useTemplate = false;
  private ProcessRun processRun;
  private Map variables = new HashMap();
  private Map<String, ParamField> paramFields = new HashMap();
  private boolean isStartFlow = false;
  private HttpServletRequest request;
  private String processName = "通用";
  private String activityName = "开始";
  private String destName = null;
  private String transitionName;
  private String preHandler;
  private String afterHandler;
  private String taskId;
  private String piId;
  private String defId;
  private String formDefId;
  private Serializable entityPK;
  private String entityName;
  private String flowSubject;
  private boolean back = false;
  private String comments = null;
  private Short signVoteType = null;
  private boolean sendMsg = false;
  private boolean sendMail = false;

  public FlowRunInfo(HttpServletRequest paramHttpServletRequest)
  {
    this.request = paramHttpServletRequest;
    String str1 = paramHttpServletRequest.getParameter("signUserIds");
    if (StringUtils.isNotEmpty(str1))
      this.variables.put("signUserIds", str1);
    String str2 = paramHttpServletRequest.getParameter("flowAssignId");
    if (StringUtils.isNotEmpty(str2))
      this.variables.put("flowAssignId", str2);
    String str3 = paramHttpServletRequest.getParameter("signVoteType");
    if (StringUtils.isNotEmpty(str3))
      this.variables.put("signVoteType", new Short(str3));
    String str4 = paramHttpServletRequest.getParameter("toParentPath");
    if (StringUtils.isNotEmpty(str4))
      this.variables.put("toParentPath", str4);
    String str5 = paramHttpServletRequest.getParameter("dueDate");
    if (StringUtils.isNotEmpty(str5))
      this.variables.put("dueDate", str5);
    String str6 = paramHttpServletRequest.getParameter("flowVars");
    if (StringUtils.isNotEmpty(str6))
    {
      localObject1 = new Gson();
      localObject2 = new TypeToken()
      {
      }
      .getType();
      localObject3 = (Map)((Gson)localObject1).fromJson(str6, (Type)localObject2);
      this.variables.putAll((Map)localObject3);
    }
    if ("true".equals(paramHttpServletRequest.getParameter("startFlow")))
    {
      this.isStartFlow = true;
      this.defId = paramHttpServletRequest.getParameter("defId");
    }
    Object localObject1 = paramHttpServletRequest.getParameter("taskId");
    if (StringUtils.isNotEmpty((String)localObject1))
      this.taskId = ((String)localObject1);
    Object localObject2 = paramHttpServletRequest.getParameter("formDefId");
    if (StringUtils.isNotEmpty((String)localObject2))
      this.formDefId = ((String)localObject2);
    Object localObject3 = paramHttpServletRequest.getParameter("piId");
    if (StringUtils.isNotEmpty((String)localObject3))
      this.piId = ((String)localObject3);
    String str7 = paramHttpServletRequest.getParameter("activityName");
    if (StringUtils.isNotEmpty(str7))
      this.activityName = str7;
    String str8 = paramHttpServletRequest.getParameter("taskName");
    if (StringUtils.isNotEmpty(str8))
      this.activityName = str8;
    String str9 = paramHttpServletRequest.getParameter("destName");
    if (StringUtils.isNotEmpty(str9))
      this.destName = str9;
    String str10 = paramHttpServletRequest.getParameter("signalName");
    if (StringUtils.isNotEmpty(str10))
      this.transitionName = str10;
    String str11 = paramHttpServletRequest.getParameter("back");
    if ("true".equals(str11))
      this.back = true;
    String str12 = paramHttpServletRequest.getParameter("comments");
    if (StringUtils.isNotEmpty(str12))
      this.comments = str12;
    String str13 = paramHttpServletRequest.getParameter("preHandler");
    if (StringUtils.isNotEmpty(str13))
      this.preHandler = str13;
    String str14 = paramHttpServletRequest.getParameter("afterHandler");
    if (StringUtils.isNotEmpty(str14))
      this.afterHandler = str14;
    String str15 = paramHttpServletRequest.getParameter("sendMsg");
    if ("true".equals(str15))
      this.sendMsg = true;
    String str16 = paramHttpServletRequest.getParameter("sendMail");
    if ("true".equals(str16))
      this.sendMail = true;
    String str17 = paramHttpServletRequest.getParameter("useTemplate");
    if ("true".equals(str17))
      this.useTemplate = true;
  }

  public FlowRunInfo()
  {
  }

  public Map getVariables()
  {
    return this.variables;
  }

  public void setVariables(Map paramMap)
  {
    this.variables = paramMap;
  }

  public boolean isStartFlow()
  {
    return this.isStartFlow;
  }

  public void setStartFlow(boolean paramBoolean)
  {
    this.isStartFlow = paramBoolean;
  }

  public HttpServletRequest getRequest()
  {
    return this.request;
  }

  public void setRequest(HttpServletRequest paramHttpServletRequest)
  {
    this.request = paramHttpServletRequest;
  }

  public String getProcessName()
  {
    return this.processName;
  }

  public void setProcessName(String paramString)
  {
    this.processName = paramString;
  }

  public String getActivityName()
  {
    return this.activityName;
  }

  public void setActivityName(String paramString)
  {
    this.activityName = paramString;
  }

  public Map<String, ParamField> getParamFields()
  {
    return this.paramFields;
  }

  public void setParamFields(Map<String, ParamField> paramMap)
  {
    this.paramFields = paramMap;
  }

  public String getTransitionName()
  {
    return this.transitionName;
  }

  public void setTransitionName(String paramString)
  {
    this.transitionName = paramString;
  }

  public String getTaskId()
  {
    return this.taskId;
  }

  public void setTaskId(String paramString)
  {
    this.taskId = paramString;
  }

  public String getPiId()
  {
    return this.piId;
  }

  public void setPiId(String paramString)
  {
    this.piId = paramString;
  }

  public String getDestName()
  {
    return this.destName;
  }

  public void setDestName(String paramString)
  {
    this.destName = paramString;
  }

  public void setdAssignId(String paramString)
  {
    this.variables.put("flowAssignId", paramString);
  }

  public void setMultipleTask(String paramString)
  {
    this.variables.put("signUserIds", paramString);
  }

  public String getPreHandler()
  {
    return this.preHandler;
  }

  public void setPreHandler(String paramString)
  {
    this.preHandler = paramString;
  }

  public String getAfterHandler()
  {
    return this.afterHandler;
  }

  public void setAfterHandler(String paramString)
  {
    this.afterHandler = paramString;
  }

  public String getDefId()
  {
    return this.defId;
  }

  public void setDefId(String paramString)
  {
    this.defId = paramString;
  }

  public boolean isBack()
  {
    return this.back;
  }

  public void setBack(boolean paramBoolean)
  {
    this.back = paramBoolean;
  }

  public String getComments()
  {
    return this.comments;
  }

  public void setComments(String paramString)
  {
    this.comments = paramString;
  }

  public String getFormDefId()
  {
    return this.formDefId;
  }

  public void setFormDefId(String paramString)
  {
    this.formDefId = paramString;
  }

  public Serializable getEntityPK()
  {
    return this.entityPK;
  }

  public void setEntityPK(Serializable paramSerializable)
  {
    this.entityPK = paramSerializable;
  }

  public String getEntityName()
  {
    return this.entityName;
  }

  public void setEntityName(String paramString)
  {
    this.entityName = paramString;
  }

  public String getFlowSubject()
  {
    return this.flowSubject;
  }

  public void setFlowSubject(String paramString)
  {
    this.flowSubject = paramString;
  }

  public Short getSignVoteType()
  {
    return this.signVoteType;
  }

  public void setSignVoteType(Short paramShort)
  {
    this.signVoteType = paramShort;
  }

  public boolean isSendMsg()
  {
    return this.sendMsg;
  }

  public void setSendMsg(boolean paramBoolean)
  {
    this.sendMsg = paramBoolean;
  }

  public boolean isSendMail()
  {
    return this.sendMail;
  }

  public void setSendMail(boolean paramBoolean)
  {
    this.sendMail = paramBoolean;
  }

  public ProcessRun getProcessRun()
  {
    return this.processRun;
  }

  public void setProcessRun(ProcessRun paramProcessRun)
  {
    this.processRun = paramProcessRun;
  }

  public boolean isUseTemplate()
  {
    return this.useTemplate;
  }

  public void setUseTemplate(boolean paramBoolean)
  {
    this.useTemplate = paramBoolean;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.flow.FlowRunInfo
 * JD-Core Version:    0.6.0
 */