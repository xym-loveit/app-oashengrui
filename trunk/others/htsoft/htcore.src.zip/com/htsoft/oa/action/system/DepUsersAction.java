package com.htsoft.oa.action.system;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.DepUsers;
import com.htsoft.oa.model.system.Department;
import com.htsoft.oa.service.system.DepUsersService;
import com.htsoft.oa.service.system.DepartmentService;
import flexjson.JSONSerializer;
import flexjson.transformer.DateTransformer;
import java.io.Serializable;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;

public class DepUsersAction extends BaseAction
{

  @Resource
  private DepUsersService depUsersService;

  @Resource
  private DepartmentService departmentService;
  private DepUsers depUsers;
  private Long depUserId;

  public Long getDepUserId()
  {
    return this.depUserId;
  }

  public void setDepUserId(Long paramLong)
  {
    this.depUserId = paramLong;
  }

  public DepUsers getDepUsers()
  {
    return this.depUsers;
  }

  public void setDepUsers(DepUsers paramDepUsers)
  {
    this.depUsers = paramDepUsers;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    String str1 = getRequest().getParameter("depId");
    String str2 = "0.";
    if (StringUtils.isNotEmpty(str1))
    {
      localObject1 = Long.valueOf(Long.parseLong(str1));
      localObject2 = (Department)this.departmentService.get((Serializable)localObject1);
      if (localObject2 != null)
      {
        str2 = ((Department)localObject2).getPath();
        localQueryFilter.addFilter("Q_department.path_S_LK", str2);
      }
    }
    Object localObject1 = this.depUsersService.getAll(localQueryFilter);
    Object localObject2 = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localJSONSerializer.transform(new DateTransformer("yyyy-MM-dd"), new String[] { "appUser.accessionTime" });
    ((StringBuffer)localObject2).append(localJSONSerializer.serialize(localObject1));
    ((StringBuffer)localObject2).append("}");
    this.jsonString = ((StringBuffer)localObject2).toString();
    return (String)(String)"success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.depUsersService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    DepUsers localDepUsers = (DepUsers)this.depUsersService.get(this.depUserId);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(JsonUtil.getJSONSerializer(new String[] { "accessionTime" }).serialize(localDepUsers));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    String str = "{success:true,msg:'数据操作成功！'}";
    int i = (this.depUsers != null) && (this.depUsers.getDepUserId() == null) ? 1 : 0;
    Long localLong = this.depUsers.getAppUser().getUserId();
    if ((this.depUsers.getIsMain().equals(DepUsers.ISMAIN)) && (this.depUsersService.existsDep(this.depUsers.getDepUserId(), localLong).booleanValue()))
    {
      str = "{failure:true,msg:'对不起，该用户已经添加了主部门，请选择添加副部门！'}";
      setJsonString(str);
      return "success";
    }
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addSorted("sn", "DESC");
    localQueryFilter.getPagingBean().setPageSize(1);
    localQueryFilter.getPagingBean().setStart(Integer.valueOf(0));
    List localList = this.depUsersService.getAll(localQueryFilter);
    Integer localInteger = Integer.valueOf(0);
    if ((localList != null) && (localList.size() > 0))
      localInteger = Integer.valueOf(((DepUsers)localList.get(0)).getSn().intValue() + 1);
    this.depUsers.setSn(localInteger);
    if (i != 0)
      str = this.depUsersService.add(this.depUsers);
    else
      this.depUsersService.save(this.depUsers);
    setJsonString(str);
    return "success";
  }

  public String sn()
  {
    String str = getRequest().getParameter("depParams");
    if (StringUtils.isNotEmpty(str))
    {
      Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd hh:mm:ss").create();
      DepUsers[] arrayOfDepUsers1 = (DepUsers[])localGson.fromJson(str, [Lcom.htsoft.oa.model.system.DepUsers.class);
      if ((arrayOfDepUsers1 != null) && (arrayOfDepUsers1.length > 0))
        for (DepUsers localDepUsers1 : arrayOfDepUsers1)
          if (localDepUsers1.getDepUserId() != null)
          {
            DepUsers localDepUsers2 = (DepUsers)this.depUsersService.get(localDepUsers1.getDepUserId());
            try
            {
              BeanUtil.copyNotNullProperties(localDepUsers2, localDepUsers1);
              this.depUsersService.save(localDepUsers2);
            }
            catch (Exception localException)
            {
              this.logger.error(localException.getMessage());
            }
          }
          else
          {
            this.depUsersService.save(localDepUsers1);
          }
    }
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.DepUsersAction
 * JD-Core Version:    0.6.0
 */