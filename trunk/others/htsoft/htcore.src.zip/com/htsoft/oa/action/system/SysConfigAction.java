package com.htsoft.oa.action.system;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.AppUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.system.SysConfig;
import com.htsoft.oa.service.system.SysConfigService;
import flexjson.JSONSerializer;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class SysConfigAction extends BaseAction
{

  @Resource
  private SysConfigService sysConfigService;
  private SysConfig sysConfig;
  private Long configId;

  public Long getConfigId()
  {
    return this.configId;
  }

  public void setConfigId(Long paramLong)
  {
    this.configId = paramLong;
  }

  public SysConfig getSysConfig()
  {
    return this.sysConfig;
  }

  public void setSysConfig(SysConfig paramSysConfig)
  {
    this.sysConfig = paramSysConfig;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.sysConfigService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.sysConfigService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    SysConfig localSysConfig = (SysConfig)this.sysConfigService.get(this.configId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localSysConfig));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    Map localMap1 = AppUtil.getSysConfig();
    Map localMap2 = getRequest().getParameterMap();
    Iterator localIterator = localMap2.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      String str = (String)localEntry.getKey();
      SysConfig localSysConfig = this.sysConfigService.findByKey(str);
      String[] arrayOfString = (String[])(String[])localEntry.getValue();
      localSysConfig.setDataValue(arrayOfString[0]);
      this.sysConfigService.save(localSysConfig);
      localMap1.remove(str);
      localMap1.put(str, arrayOfString[0]);
    }
    AppUtil.reloadSysConfig();
    setJsonString("{success:true}");
    return "success";
  }

  public String load()
  {
    Map localMap = this.sysConfigService.findByType();
    JSONSerializer localJSONSerializer = new JSONSerializer();
    setJsonString("{success:true,data:" + localJSONSerializer.deepSerialize(localMap) + "}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.SysConfigAction
 * JD-Core Version:    0.6.0
 */