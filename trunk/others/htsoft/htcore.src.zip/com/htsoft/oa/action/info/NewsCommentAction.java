package com.htsoft.oa.action.info;

import com.google.gson.Gson;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.info.News;
import com.htsoft.oa.model.info.NewsComment;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.info.NewsCommentService;
import com.htsoft.oa.service.info.NewsService;
import com.htsoft.oa.service.system.AppUserService;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class NewsCommentAction extends BaseAction
{

  @Resource
  private NewsCommentService newsCommentService;

  @Resource
  private AppUserService appUserService;

  @Resource
  private NewsService newsService;
  private NewsComment newsComment;
  private Long commentId;

  public Long getCommentId()
  {
    return this.commentId;
  }

  public void setCommentId(Long paramLong)
  {
    this.commentId = paramLong;
  }

  public NewsComment getNewsComment()
  {
    return this.newsComment;
  }

  public void setNewsComment(NewsComment paramNewsComment)
  {
    this.newsComment = paramNewsComment;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    String str = getRequest().getParameter("start");
    List localList = this.newsCommentService.getAll(localQueryFilter);
    Gson localGson = new Gson();
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      NewsComment localNewsComment = (NewsComment)localIterator.next();
      localStringBuffer.append("{commentId:'").append(localNewsComment.getCommentId()).append("',subject:").append(localGson.toJson(localNewsComment.getNews().getSubject())).append(",content:").append(localGson.toJson(localNewsComment.getContent())).append(",createtime:'").append(localSimpleDateFormat.format(localNewsComment.getCreatetime())).append("',fullname:'").append(localNewsComment.getFullname()).append("',start:'").append(str).append("'},");
    }
    if (localList.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
      {
        NewsComment localNewsComment = (NewsComment)this.newsCommentService.get(new Long(str));
        News localNews = localNewsComment.getNews();
        if (localNews.getReplyCounts().intValue() > 1)
          localNews.setReplyCounts(Integer.valueOf(localNews.getReplyCounts().intValue() - 1));
        this.newsService.save(localNews);
        this.newsCommentService.remove(new Long(str));
      }
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    NewsComment localNewsComment = (NewsComment)this.newsCommentService.get(this.commentId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localNewsComment));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    News localNews = (News)this.newsService.get(this.newsComment.getNewsId());
    localNews.setReplyCounts(Integer.valueOf(localNews.getReplyCounts().intValue() + 1));
    this.newsService.save(localNews);
    this.newsComment.setAppUser((AppUser)this.appUserService.get(this.newsComment.getUserId()));
    this.newsComment.setCreatetime(new Date());
    this.newsComment.setNews(localNews);
    this.newsCommentService.save(this.newsComment);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.info.NewsCommentAction
 * JD-Core Version:    0.6.0
 */