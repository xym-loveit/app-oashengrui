package com.htsoft.oa.action.system;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.htsoft.core.util.AppUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.system.Company;
import com.htsoft.oa.service.system.CompanyService;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;

public class CompanyAction extends BaseAction
{
  private Company company;

  @Resource
  private CompanyService companyService;

  public Company getCompany()
  {
    return this.company;
  }

  public void setCompany(Company paramCompany)
  {
    this.company = paramCompany;
  }

  public String check()
  {
    List localList = this.companyService.findCompany();
    if (localList.size() > 0)
      setJsonString("{success:true}");
    else
      setJsonString("{success:false}");
    return "success";
  }

  public String list()
  {
    List localList = this.companyService.findCompany();
    if (localList.size() > 0)
    {
      this.company = ((Company)localList.get(0));
      Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
      StringBuffer localStringBuffer = new StringBuffer("{success:true,result:[");
      localStringBuffer.append(localGson.toJson(this.company));
      localStringBuffer.append("]}");
      setJsonString(localStringBuffer.toString());
    }
    else
    {
      setJsonString("{success:false,message:'还没有填写公司信息'}");
      return "success";
    }
    return "success";
  }

  public String add()
  {
    this.companyService.save(this.company);
    Map localMap = AppUtil.getSysConfig();
    localMap.remove("app.logoPath");
    localMap.remove("app.companyName");
    localMap.put("app.logoPath", this.company.getLogo());
    localMap.put("app.companyName", this.company.getCompanyName());
    setJsonString("{success:true}");
    return "success";
  }

  public String delphoto()
  {
    List localList = this.companyService.findCompany();
    if (localList.size() > 0)
    {
      this.company = ((Company)localList.get(0));
      this.company.setLogo("");
      this.companyService.save(this.company);
    }
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.CompanyAction
 * JD-Core Version:    0.6.0
 */