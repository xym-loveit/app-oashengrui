package com.htsoft.oa.action.info;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.info.InMessage;
import com.htsoft.oa.model.info.ShortMessage;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.info.InMessageService;
import com.htsoft.oa.service.info.ShortMessageService;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class InMessageAction extends BaseAction
{
  static short HAVE_DELETE = 1;
  private InMessage inMessage;
  private ShortMessage shortMessage;
  private Date from;
  private Date to;

  @Resource
  private InMessageService inMessageService;

  @Resource
  private ShortMessageService shortMessageService;

  public InMessage getInMessage()
  {
    return this.inMessage;
  }

  public void setInMessage(InMessage paramInMessage)
  {
    this.inMessage = paramInMessage;
  }

  public ShortMessage getShortMessage()
  {
    return this.shortMessage;
  }

  public void setShortMessage(ShortMessage paramShortMessage)
  {
    this.shortMessage = paramShortMessage;
  }

  public Date getFrom()
  {
    return this.from;
  }

  public void setFrom(Date paramDate)
  {
    this.from = paramDate;
  }

  public Date getTo()
  {
    return this.to;
  }

  public void setTo(Date paramDate)
  {
    this.to = paramDate;
  }

  public String list()
  {
    PagingBean localPagingBean = getInitPagingBean();
    AppUser localAppUser = ContextUtil.getCurrentUser();
    List localList = this.inMessageService.searchInMessage(localAppUser.getUserId(), this.inMessage, this.shortMessage, this.from, this.to, localPagingBean);
    ArrayList localArrayList = new ArrayList();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':" + localPagingBean.getTotalItems() + ",result:");
    for (int i = 0; i < localList.size(); i++)
    {
      localObject = (InMessage)((Object[])localList.get(i))[0];
      localArrayList.add(localObject);
    }
    Gson localGson = new Gson();
    Object localObject = new TypeToken()
    {
    }
    .getType();
    localStringBuffer.append(localGson.toJson(localArrayList, (Type)localObject));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return (String)"success";
  }

  public String know()
  {
    String str = getRequest().getParameter("receiveId");
    Long localLong = null;
    if (StringUtils.isNotEmpty(str))
      localLong = Long.valueOf(Long.parseLong(str));
    InMessage localInMessage = (InMessage)this.inMessageService.get(localLong);
    localInMessage.setReadFlag(Short.valueOf(1));
    this.inMessageService.save(localInMessage);
    setJsonString("{success:true}");
    return "success";
  }

  public String multiRemove()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
      {
        this.inMessage = ((InMessage)this.inMessageService.get(Long.valueOf(Long.parseLong(str))));
        this.inMessage.setDelFlag(Short.valueOf(HAVE_DELETE));
        this.inMessageService.save(this.inMessage);
      }
    this.jsonString = "{success:true}";
    return "success";
  }

  public String reply()
  {
    String str = getRequest().getParameter("receiveId");
    if (StringUtils.isNotEmpty(str))
    {
      Long localLong = Long.valueOf(Long.parseLong(str));
      this.inMessage = ((InMessage)this.inMessageService.get(localLong));
      StringBuffer localStringBuffer = new StringBuffer("{success:true,data:[");
      localStringBuffer.append("{'messageId':" + this.inMessage.getShortMessage().getMessageId() + ",'senderId':'" + this.inMessage.getShortMessage().getSenderId() + "','sender':'" + this.inMessage.getShortMessage().getSender() + "'}").append("]}");
      setJsonString(localStringBuffer.toString());
    }
    else
    {
      setJsonString("{success:false}");
    }
    return "success";
  }

  public String read()
  {
    Long localLong = ContextUtil.getCurrentUser().getUserId();
    int i = 0;
    if (localLong != null)
    {
      this.inMessage = this.inMessageService.findByRead(localLong);
      if (this.inMessage == null)
      {
        i = 1;
        this.inMessage = this.inMessageService.findLatest(localLong);
      }
      if (this.inMessage != null)
      {
        this.inMessage.setReadFlag(InMessage.FLAG_READ);
        this.inMessageService.save(this.inMessage);
        this.shortMessage = this.inMessage.getShortMessage();
        SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String str = localSimpleDateFormat.format(this.shortMessage.getSendTime());
        StringBuffer localStringBuffer = new StringBuffer("{success:true,message:");
        localStringBuffer.append("{'receiveId':" + this.inMessage.getReceiveId() + ",'messageId':" + this.shortMessage.getMessageId() + ",'senderId':" + this.shortMessage.getSenderId() + ",'sender':'" + this.shortMessage.getSender() + "','content':'" + this.shortMessage.getContent().replace("\n", " ") + "','sendTime':'" + str + "','msgType':" + this.shortMessage.getMsgType());
        if (i == 0)
        {
          InMessage localInMessage = this.inMessageService.findByRead(localLong);
          if (localInMessage != null)
            localStringBuffer.append(",haveNext:true");
          else
            localStringBuffer.append(",haveNext:false");
        }
        else
        {
          localStringBuffer.append(",haveNext:false");
        }
        localStringBuffer.append("}}");
        setJsonString(localStringBuffer.toString());
      }
      else
      {
        setJsonString("{success:false}");
      }
    }
    else
    {
      setJsonString("{success:true}");
    }
    return "success";
  }

  public String count()
  {
    Integer localInteger = this.inMessageService.findByReadFlag(ContextUtil.getCurrentUser().getUserId());
    setJsonString("{success:true,count:'" + localInteger + "'}");
    return "success";
  }

  public String detail()
  {
    String str = getRequest().getParameter("receiveId");
    if (StringUtils.isNotEmpty(str))
    {
      Long localLong = new Long(str);
      this.inMessage = ((InMessage)this.inMessageService.get(localLong));
      this.inMessage.setReadFlag(Short.valueOf(1));
      this.inMessageService.save(this.inMessage);
    }
    return "detail";
  }

  public String display()
  {
    PagingBean localPagingBean = new PagingBean(0, 8);
    AppUser localAppUser = ContextUtil.getCurrentUser();
    List localList = this.shortMessageService.searchShortMessage(localAppUser.getUserId(), null, null, null, localPagingBean, InMessage.FLAG_UNREAD);
    ArrayList localArrayList = new ArrayList();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':" + localPagingBean.getTotalItems() + ",result:");
    for (int i = 0; i < localList.size(); i++)
    {
      InMessage localInMessage = (InMessage)((Object[])localList.get(i))[0];
      localArrayList.add(localInMessage);
    }
    getRequest().setAttribute("messageList", localArrayList);
    return "display";
  }

  public String multiRead()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
      {
        this.inMessage = ((InMessage)this.inMessageService.get(Long.valueOf(Long.parseLong(str))));
        this.inMessage.setReadFlag(InMessage.FLAG_READ);
        this.inMessageService.save(this.inMessage);
      }
    this.jsonString = "{success:true}";
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.info.InMessageAction
 * JD-Core Version:    0.6.0
 */