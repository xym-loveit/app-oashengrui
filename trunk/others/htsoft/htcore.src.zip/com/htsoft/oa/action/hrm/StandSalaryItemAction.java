package com.htsoft.oa.action.hrm;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.hrm.StandSalaryItem;
import com.htsoft.oa.service.hrm.StandSalaryItemService;
import java.lang.reflect.Type;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class StandSalaryItemAction extends BaseAction
{

  @Resource
  private StandSalaryItemService standSalaryItemService;
  private StandSalaryItem standSalaryItem;
  private Long itemId;
  private Long standardId;

  public Long getStandardId()
  {
    return this.standardId;
  }

  public void setStandardId(Long paramLong)
  {
    this.standardId = paramLong;
  }

  public Long getItemId()
  {
    return this.itemId;
  }

  public void setItemId(Long paramLong)
  {
    this.itemId = paramLong;
  }

  public StandSalaryItem getStandSalaryItem()
  {
    return this.standSalaryItem;
  }

  public void setStandSalaryItem(StandSalaryItem paramStandSalaryItem)
  {
    this.standSalaryItem = paramStandSalaryItem;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = null;
    if (this.standardId != null)
      localList = this.standSalaryItemService.getAllByStandardId(this.standardId);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localList.size()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.standSalaryItemService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    StandSalaryItem localStandSalaryItem = (StandSalaryItem)this.standSalaryItemService.get(this.itemId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localStandSalaryItem));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.standSalaryItemService.save(this.standSalaryItem);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.hrm.StandSalaryItemAction
 * JD-Core Version:    0.6.0
 */