package com.htsoft.oa.action.arch;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.arch.ArchFond;
import com.htsoft.oa.model.arch.ArchRoll;
import com.htsoft.oa.model.system.Dictionary;
import com.htsoft.oa.service.arch.ArchFondService;
import com.htsoft.oa.service.arch.ArchRollService;
import com.htsoft.oa.service.arch.BorrowFileListService;
import com.htsoft.oa.service.arch.BorrowRecordService;
import com.htsoft.oa.service.arch.RollFileListService;
import com.htsoft.oa.service.arch.RollFileService;
import com.htsoft.oa.service.system.DictionaryService;
import com.htsoft.oa.service.system.FileAttachService;
import flexjson.JSONSerializer;
import flexjson.transformer.DateTransformer;
import java.lang.reflect.Type;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Resource;
import org.apache.commons.logging.Log;

public class ArchReportAction extends BaseAction
{

  @Resource
  private ArchFondService archFondService;

  @Resource
  private ArchRollService archRollService;

  @Resource
  private RollFileService rollFileService;

  @Resource
  private RollFileListService rollFileListService;

  @Resource
  private FileAttachService fileAttachService;

  @Resource
  private BorrowRecordService borrowRecordService;

  @Resource
  private BorrowFileListService borrowFileListService;

  @Resource
  private DictionaryService dictionaryService;
  private String year;
  private String itemName;

  public String getItemName()
  {
    return this.itemName;
  }

  public void setItemName(String paramString)
  {
    this.itemName = paramString;
  }

  public String getYear()
  {
    return this.year;
  }

  public void setYear(String paramString)
  {
    this.year = paramString;
  }

  public String yearReportArch()
  {
    try
    {
      SimpleDateFormat localSimpleDateFormat1 = new SimpleDateFormat("yyyy");
      SimpleDateFormat localSimpleDateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
      Date localDate1 = localSimpleDateFormat1.parse(this.year);
      long l = localDate1.getTime() / 1000L + 31449600L;
      Date localDate2 = new Date(l * 1000L);
      String str1 = localSimpleDateFormat2.format(localDate1);
      String str2 = localSimpleDateFormat2.format(localDate2);
      int i = 0;
      int j = 0;
      int k = 0;
      int m = 0;
      int n = 0;
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      QueryFilter localQueryFilter1 = new QueryFilter(getRequest());
      localQueryFilter1.getPagingBean().setStart(Integer.valueOf(i2));
      localQueryFilter1.getPagingBean().setPageSize(i3);
      localQueryFilter1.addFilter("Q_createTime_D_LE", str2);
      this.archFondService.getAll(localQueryFilter1);
      i = localQueryFilter1.getPagingBean().getTotalItems();
      QueryFilter localQueryFilter2 = new QueryFilter(getRequest());
      localQueryFilter2.getPagingBean().setStart(Integer.valueOf(i2));
      localQueryFilter2.getPagingBean().setPageSize(i3);
      localQueryFilter2.addFilter("Q_createTime_D_LE", str2);
      this.archRollService.getAll(localQueryFilter2);
      k = localQueryFilter2.getPagingBean().getTotalItems();
      QueryFilter localQueryFilter3 = new QueryFilter(getRequest());
      localQueryFilter3.getPagingBean().setStart(Integer.valueOf(i2));
      localQueryFilter3.getPagingBean().setPageSize(i3);
      localQueryFilter3.addFilter("Q_createTime_D_LE", str2);
      this.rollFileService.getAll(localQueryFilter3);
      m = localQueryFilter3.getPagingBean().getTotalItems();
      QueryFilter localQueryFilter4 = new QueryFilter(getRequest());
      localQueryFilter4.getPagingBean().setStart(Integer.valueOf(i2));
      localQueryFilter4.getPagingBean().setPageSize(i3);
      localQueryFilter4.addFilter("Q_createTime_D_GE", str1);
      localQueryFilter4.addFilter("Q_createTime_D_LE", str2);
      this.archRollService.getAll(localQueryFilter4);
      n = localQueryFilter4.getPagingBean().getTotalItems();
      QueryFilter localQueryFilter5 = new QueryFilter(getRequest());
      localQueryFilter5.getPagingBean().setStart(Integer.valueOf(i2));
      localQueryFilter5.getPagingBean().setPageSize(i3);
      localQueryFilter5.addFilter("Q_createTime_D_GE", str1);
      localQueryFilter5.addFilter("Q_createTime_D_LE", str2);
      this.rollFileService.getAll(localQueryFilter5);
      i1 = localQueryFilter5.getPagingBean().getTotalItems();
      HashMap localHashMap = new HashMap();
      localHashMap.put("fondTotal", Integer.valueOf(i));
      localHashMap.put("archTotal", Integer.valueOf(k + m));
      localHashMap.put("rollTotal", Integer.valueOf(k));
      localHashMap.put("fileTotal", Integer.valueOf(m));
      localHashMap.put("thisYearRollTotal", Integer.valueOf(n));
      localHashMap.put("thisYearFileTotal", Integer.valueOf(i1));
      StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
      Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
      localStringBuffer.append(localGson.toJson(localHashMap));
      localStringBuffer.append("}");
      setJsonString(localStringBuffer.toString());
    }
    catch (ParseException localParseException)
    {
      localParseException.printStackTrace();
    }
    return "success";
  }

  public String yearReportFile()
  {
    try
    {
      SimpleDateFormat localSimpleDateFormat1 = new SimpleDateFormat("yyyy");
      SimpleDateFormat localSimpleDateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
      Date localDate1 = localSimpleDateFormat1.parse(this.year);
      long l = localDate1.getTime() / 1000L + 31449600L;
      Date localDate2 = new Date(l * 1000L);
      String str1 = localSimpleDateFormat2.format(localDate1);
      String str2 = localSimpleDateFormat2.format(localDate2);
      QueryFilter localQueryFilter1 = new QueryFilter(getRequest());
      localQueryFilter1.addFilter("Q_createTime_D_GE", str1);
      localQueryFilter1.addFilter("Q_createTime_D_LE", str2);
      List localList1 = this.archFondService.getAll(localQueryFilter1);
      List localList2 = this.dictionaryService.getByItemName(this.itemName);
      int i = 0;
      int j = 0;
      ArrayList localArrayList = new ArrayList();
      Object localObject1 = localList1.iterator();
      while (((Iterator)localObject1).hasNext())
      {
        localObject2 = (ArchFond)((Iterator)localObject1).next();
        HashMap localHashMap = new HashMap();
        localHashMap.put("afNo", ((ArchFond)localObject2).getAfNo());
        Iterator localIterator = localList2.iterator();
        while (localIterator.hasNext())
        {
          Dictionary localDictionary = (Dictionary)localIterator.next();
          QueryFilter localQueryFilter2 = new QueryFilter(getRequest());
          localQueryFilter2.getPagingBean().setStart(Integer.valueOf(i));
          localQueryFilter2.getPagingBean().setPageSize(j);
          localQueryFilter2.addFilter("Q_createTime_D_GE", str1);
          localQueryFilter2.addFilter("Q_createTime_D_LE", str2);
          localQueryFilter2.addFilter("Q_timeLimit_S_LK", localDictionary.getItemValue());
          localQueryFilter2.addFilter("Q_archRoll.archFondId_L_EQ", ((ArchFond)localObject2).getArchFondId().toString());
          this.rollFileService.getAll(localQueryFilter2);
          int k = localQueryFilter2.getPagingBean().getTotalItems();
          localHashMap.put(localDictionary.getDicId().toString(), Integer.valueOf(k));
        }
        localArrayList.add(localHashMap);
      }
      localObject1 = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter1.getPagingBean().getTotalItems()).append(",result:");
      Object localObject2 = new Gson();
      ((StringBuffer)localObject1).append(((Gson)localObject2).toJson(localArrayList));
      ((StringBuffer)localObject1).append("}");
      this.jsonString = ((StringBuffer)localObject1).toString();
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return (String)(String)"success";
  }

  public String yearReportTidy()
  {
    try
    {
      SimpleDateFormat localSimpleDateFormat1 = new SimpleDateFormat("yyyy");
      SimpleDateFormat localSimpleDateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
      Date localDate1 = localSimpleDateFormat1.parse(this.year);
      long l = localDate1.getTime() / 1000L + 31449600L;
      Date localDate2 = new Date(l * 1000L);
      String str1 = localSimpleDateFormat2.format(localDate1);
      String str2 = localSimpleDateFormat2.format(localDate2);
      QueryFilter localQueryFilter1 = new QueryFilter(getRequest());
      localQueryFilter1.addFilter("Q_createTime_D_GE", str1);
      localQueryFilter1.addFilter("Q_createTime_D_LE", str2);
      List localList1 = this.archFondService.getAll(localQueryFilter1);
      List localList2 = this.dictionaryService.getByItemName(this.itemName);
      int i = 0;
      int j = 0;
      ArrayList localArrayList = new ArrayList();
      Object localObject1 = localList1.iterator();
      while (((Iterator)localObject1).hasNext())
      {
        localObject2 = (ArchFond)((Iterator)localObject1).next();
        HashMap localHashMap = new HashMap();
        localHashMap.put("afNo", ((ArchFond)localObject2).getAfNo());
        int k = 0;
        Iterator localIterator = localList2.iterator();
        while (localIterator.hasNext())
        {
          Dictionary localDictionary = (Dictionary)localIterator.next();
          QueryFilter localQueryFilter2 = new QueryFilter(getRequest());
          localQueryFilter2.getPagingBean().setStart(Integer.valueOf(i));
          localQueryFilter2.getPagingBean().setPageSize(j);
          localQueryFilter2.addFilter("Q_tidyTime_D_GE", str1);
          localQueryFilter2.addFilter("Q_tidyTime_D_LE", str2);
          localQueryFilter2.addFilter("Q_timeLimit_S_LK", localDictionary.getItemValue());
          localQueryFilter2.addFilter("Q_archRoll.archFondId_L_EQ", ((ArchFond)localObject2).getArchFondId().toString());
          localQueryFilter2.addFilter("Q_archStatus_SN_EQ", "1");
          this.rollFileService.getAll(localQueryFilter2);
          int m = localQueryFilter2.getPagingBean().getTotalItems();
          localHashMap.put(localDictionary.getDicId().toString(), Integer.valueOf(m));
          if (m > 0)
            k = 1;
        }
        if (k != 0)
          localArrayList.add(localHashMap);
      }
      localObject1 = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter1.getPagingBean().getTotalItems()).append(",result:");
      Object localObject2 = new Gson();
      ((StringBuffer)localObject1).append(((Gson)localObject2).toJson(localArrayList));
      ((StringBuffer)localObject1).append("}");
      this.jsonString = ((StringBuffer)localObject1).toString();
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return (String)(String)"success";
  }

  public String yearReportBorrowMain()
  {
    int i = 0;
    int j = 0;
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.getPagingBean().setStart(Integer.valueOf(i));
    localQueryFilter.getPagingBean().setPageSize(j);
    this.borrowFileListService.getAll(localQueryFilter);
    int k = localQueryFilter.getPagingBean().getTotalItems();
    HashMap localHashMap = new HashMap();
    localHashMap.put("totalCount", Integer.valueOf(k));
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
    localStringBuffer.append(localGson.toJson(localHashMap));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String yearReportBorrowYear()
  {
    try
    {
      SimpleDateFormat localSimpleDateFormat1 = new SimpleDateFormat("yyyy");
      SimpleDateFormat localSimpleDateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
      Date localDate1 = localSimpleDateFormat1.parse(this.year);
      long l = localDate1.getTime() / 1000L + 31449600L;
      Date localDate2 = new Date(l * 1000L);
      String str1 = localSimpleDateFormat2.format(localDate1);
      String str2 = localSimpleDateFormat2.format(localDate2);
      int i = 0;
      int j = 0;
      QueryFilter localQueryFilter1 = new QueryFilter(getRequest());
      localQueryFilter1.getPagingBean().setStart(Integer.valueOf(i));
      localQueryFilter1.getPagingBean().setPageSize(j);
      localQueryFilter1.addFilter("Q_borrowRecord.borrowDate_D_GE", str1);
      localQueryFilter1.addFilter("Q_borrowRecord.borrowDate_D_LE", str2);
      this.borrowFileListService.getAll(localQueryFilter1);
      int k = localQueryFilter1.getPagingBean().getTotalItems();
      QueryFilter localQueryFilter2 = new QueryFilter(getRequest());
      localQueryFilter2.getPagingBean().setStart(Integer.valueOf(i));
      localQueryFilter2.getPagingBean().setPageSize(j);
      localQueryFilter2.addFilter("Q_borrowRecord.borrowDate_D_GE", str1);
      localQueryFilter2.addFilter("Q_borrowRecord.borrowDate_D_LE", str2);
      localQueryFilter2.addFilter("Q_listType_S_EQ", "案卷");
      this.borrowFileListService.getAll(localQueryFilter2);
      int m = localQueryFilter2.getPagingBean().getTotalItems();
      QueryFilter localQueryFilter3 = new QueryFilter(getRequest());
      localQueryFilter3.getPagingBean().setStart(Integer.valueOf(i));
      localQueryFilter3.getPagingBean().setPageSize(j);
      localQueryFilter3.addFilter("Q_borrowRecord.borrowDate_D_GE", str1);
      localQueryFilter3.addFilter("Q_borrowRecord.borrowDate_D_LE", str2);
      localQueryFilter3.addFilter("Q_listType_S_EQ", "文件");
      this.borrowFileListService.getAll(localQueryFilter3);
      int n = localQueryFilter3.getPagingBean().getTotalItems();
      HashMap localHashMap = new HashMap();
      localHashMap.put("totalCount", "" + k + "");
      localHashMap.put("rollTotal", Integer.valueOf(m));
      localHashMap.put("fileTotal", "" + n + "");
      StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
      Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
      localStringBuffer.append(localGson.toJson(localHashMap));
      localStringBuffer.append("}");
      setJsonString(localStringBuffer.toString());
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return "success";
  }

  public String yearReportBorrowDetail()
  {
    try
    {
      SimpleDateFormat localSimpleDateFormat1 = new SimpleDateFormat("yyyy");
      SimpleDateFormat localSimpleDateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
      Date localDate1 = localSimpleDateFormat1.parse(this.year);
      long l = localDate1.getTime() / 1000L + 31449600L;
      Date localDate2 = new Date(l * 1000L);
      String str1 = localSimpleDateFormat2.format(localDate1);
      String str2 = localSimpleDateFormat2.format(localDate2);
      this.logger.debug(this.itemName);
      List localList = this.dictionaryService.getByItemName(this.itemName);
      int i = 0;
      int j = 0;
      HashMap localHashMap = new HashMap();
      Object localObject1 = localList.iterator();
      while (((Iterator)localObject1).hasNext())
      {
        localObject2 = (Dictionary)((Iterator)localObject1).next();
        QueryFilter localQueryFilter1 = new QueryFilter(getRequest());
        localQueryFilter1.getPagingBean().setStart(Integer.valueOf(i));
        localQueryFilter1.getPagingBean().setPageSize(j);
        localQueryFilter1.addFilter("Q_borrowRecord.borrowDate_D_GE", str1);
        localQueryFilter1.addFilter("Q_borrowRecord.borrowDate_D_LE", str2);
        localQueryFilter1.addFilter("Q_listType_S_EQ", "案卷");
        localQueryFilter1.addFilter("Q_borrowRecord.borrowReason_S_EQ", ((Dictionary)localObject2).getItemValue());
        this.borrowFileListService.getAll(localQueryFilter1);
        int k = localQueryFilter1.getPagingBean().getTotalItems();
        QueryFilter localQueryFilter2 = new QueryFilter(getRequest());
        localQueryFilter2.getPagingBean().setStart(Integer.valueOf(i));
        localQueryFilter2.getPagingBean().setPageSize(j);
        localQueryFilter2.addFilter("Q_borrowRecord.borrowDate_D_GE", str1);
        localQueryFilter2.addFilter("Q_borrowRecord.borrowDate_D_LE", str2);
        localQueryFilter2.addFilter("Q_listType_S_EQ", "文件");
        localQueryFilter2.addFilter("Q_borrowRecord.borrowReason_S_EQ", ((Dictionary)localObject2).getItemValue());
        this.borrowFileListService.getAll(localQueryFilter2);
        int m = localQueryFilter2.getPagingBean().getTotalItems();
        localHashMap.put("rollTotal" + ((Dictionary)localObject2).getDicId(), Integer.valueOf(k));
        localHashMap.put("fileTotal" + ((Dictionary)localObject2).getDicId(), Integer.valueOf(m));
      }
      localObject1 = new StringBuffer("{success:true").append(",data:");
      Object localObject2 = new Gson();
      ((StringBuffer)localObject1).append(((Gson)localObject2).toJson(localHashMap));
      ((StringBuffer)localObject1).append("}");
      this.jsonString = ((StringBuffer)localObject1).toString();
      this.logger.debug("jsonString=" + this.jsonString);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return (String)(String)"success";
  }

  public String rollReportByFond()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.archFondService.getAll(localQueryFilter);
    ArrayList localArrayList = new ArrayList();
    Object localObject1 = localList.iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (ArchFond)((Iterator)localObject1).next();
      int i = ((ArchFond)localObject2).getArchRolls().size();
      ((ArchFond)localObject2).setCaseNums(Integer.valueOf(i));
      if ((((ArchFond)localObject2).getCaseNums() == null) || (((ArchFond)localObject2).getCaseNums().equals("")))
        this.archFondService.save(localObject2);
      HashMap localHashMap = new HashMap();
      localHashMap.put("name", ((ArchFond)localObject2).getAfNo());
      localHashMap.put("num", Integer.valueOf(i));
      localArrayList.add(localHashMap);
    }
    localObject1 = new TypeToken()
    {
    }
    .getType();
    Object localObject2 = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localJSONSerializer.transform(new DateTransformer("yyyy-MM-dd"), new String[] { "createTime", "updateTime" });
    ((StringBuffer)localObject2).append(localJSONSerializer.serialize(localArrayList));
    ((StringBuffer)localObject2).append("}");
    this.jsonString = ((StringBuffer)localObject2).toString();
    return (String)(String)"success";
  }

  public String rollReportByTimeLimit()
  {
    this.logger.debug("itemName=" + this.itemName);
    List localList = this.dictionaryService.getByItemName(this.itemName);
    int i = 0;
    int j = 0;
    ArrayList localArrayList = new ArrayList();
    int k = 0;
    Object localObject1 = localList.iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (Dictionary)((Iterator)localObject1).next();
      localObject3 = new QueryFilter(getRequest());
      ((QueryFilter)localObject3).getPagingBean().setStart(Integer.valueOf(i));
      ((QueryFilter)localObject3).getPagingBean().setPageSize(j);
      ((QueryFilter)localObject3).addFilter("Q_timeLimit_S_LK", ((Dictionary)localObject2).getItemValue().trim());
      this.archRollService.getAll((QueryFilter)localObject3);
      int m = ((QueryFilter)localObject3).getPagingBean().getTotalItems();
      k += m;
      HashMap localHashMap = new HashMap();
      localHashMap.put("name", ((Dictionary)localObject2).getItemValue());
      localHashMap.put("num", Integer.valueOf(m));
      localHashMap.put("isTotal", Boolean.valueOf(false));
      localArrayList.add(localHashMap);
    }
    localObject1 = new QueryFilter(getRequest());
    ((QueryFilter)localObject1).getPagingBean().setStart(Integer.valueOf(i));
    ((QueryFilter)localObject1).getPagingBean().setPageSize(j);
    this.archRollService.getAll((QueryFilter)localObject1);
    Object localObject2 = new HashMap();
    ((Map)localObject2).put("name", "其它");
    ((Map)localObject2).put("num", Integer.valueOf(((QueryFilter)localObject1).getPagingBean().getTotalItems() - k));
    ((Map)localObject2).put("isTotal", Boolean.valueOf(false));
    localArrayList.add(localObject2);
    Object localObject3 = new StringBuffer("{success:true").append(",result:");
    Gson localGson = new Gson();
    ((StringBuffer)localObject3).append(localGson.toJson(localArrayList));
    ((StringBuffer)localObject3).append("}");
    this.jsonString = ((StringBuffer)localObject3).toString();
    return (String)(String)(String)"success";
  }

  public String fileReportByRoll()
  {
    ArrayList localArrayList = new ArrayList();
    QueryFilter localQueryFilter1 = new QueryFilter(getRequest());
    List localList = this.archRollService.getAll(localQueryFilter1);
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      ArchRoll localArchRoll = (ArchRoll)localIterator.next();
      int k = localArchRoll.getRollFiles().size();
      localHashMap = new HashMap();
      localHashMap.put("name", localArchRoll.getRollNo());
      localHashMap.put("nums", Integer.valueOf(k));
      localHashMap.put("isTotal", Boolean.valueOf(false));
      localArrayList.add(localHashMap);
    }
    int i = 0;
    int j = 0;
    QueryFilter localQueryFilter2 = new QueryFilter(getRequest());
    localQueryFilter2.getPagingBean().setStart(Integer.valueOf(i));
    localQueryFilter2.getPagingBean().setPageSize(j);
    localQueryFilter2.addFilter("Q_archRoll_NULL", "");
    this.rollFileService.getAll(localQueryFilter2);
    HashMap localHashMap = new HashMap();
    localHashMap.put("name", "其它");
    localHashMap.put("nums", Integer.valueOf(localQueryFilter2.getPagingBean().getTotalItems()));
    localHashMap.put("isTotal", Boolean.valueOf(false));
    localArrayList.add(localHashMap);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter1.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localJSONSerializer.transform(new DateTransformer("yyyy-MM-dd"), new String[] { "createTime", "updateTime", "setupTime", "endTime", "startTime" });
    localStringBuffer.append(localJSONSerializer.serialize(localArrayList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String fileReportByTimeLimit()
  {
    this.logger.debug("itemName=" + this.itemName);
    List localList = this.dictionaryService.getByItemName(this.itemName);
    int i = 0;
    int j = 0;
    ArrayList localArrayList = new ArrayList();
    int k = 0;
    Object localObject1 = localList.iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (Dictionary)((Iterator)localObject1).next();
      localObject3 = new HashMap();
      localObject4 = new QueryFilter(getRequest());
      ((QueryFilter)localObject4).getPagingBean().setStart(Integer.valueOf(i));
      ((QueryFilter)localObject4).getPagingBean().setPageSize(j);
      ((QueryFilter)localObject4).addFilter("Q_timeLimit_S_LK", ((Dictionary)localObject2).getItemValue().trim());
      this.rollFileService.getAll((QueryFilter)localObject4);
      int m = ((QueryFilter)localObject4).getPagingBean().getTotalItems();
      k += m;
      ((Map)localObject3).put("name", ((Dictionary)localObject2).getItemValue());
      ((Map)localObject3).put("nums", Integer.valueOf(m));
      ((Map)localObject3).put("isTotal", Boolean.valueOf(false));
      localArrayList.add(localObject3);
    }
    localObject1 = new QueryFilter(getRequest());
    ((QueryFilter)localObject1).getPagingBean().setStart(Integer.valueOf(i));
    ((QueryFilter)localObject1).getPagingBean().setPageSize(j);
    this.rollFileService.getAll((QueryFilter)localObject1);
    Object localObject2 = new HashMap();
    ((Map)localObject2).put("name", "其它");
    ((Map)localObject2).put("nums", Integer.valueOf(((QueryFilter)localObject1).getPagingBean().getTotalItems() - k));
    ((Map)localObject2).put("isTotal", Boolean.valueOf(false));
    localArrayList.add(localObject2);
    Object localObject3 = new StringBuffer("{success:true").append(",result:");
    Object localObject4 = new Gson();
    ((StringBuffer)localObject3).append(((Gson)localObject4).toJson(localArrayList));
    ((StringBuffer)localObject3).append("}");
    this.jsonString = ((StringBuffer)localObject3).toString();
    return (String)(String)(String)(String)"success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.arch.ArchReportAction
 * JD-Core Version:    0.6.0
 */