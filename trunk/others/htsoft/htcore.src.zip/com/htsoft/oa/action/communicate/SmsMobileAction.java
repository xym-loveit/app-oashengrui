package com.htsoft.oa.action.communicate;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.communicate.SmsMobile;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.communicate.SmsMobileService;
import com.htsoft.oa.service.system.AppUserService;
import java.lang.reflect.Type;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class SmsMobileAction extends BaseAction
{

  @Resource
  private SmsMobileService smsMobileService;

  @Resource
  private AppUserService appUserService;
  private SmsMobile smsMobile;
  private Long smsId;

  public Long getSmsId()
  {
    return this.smsId;
  }

  public void setSmsId(Long paramLong)
  {
    this.smsId = paramLong;
  }

  public SmsMobile getSmsMobile()
  {
    return this.smsMobile;
  }

  public void setSmsMobile(SmsMobile paramSmsMobile)
  {
    this.smsMobile = paramSmsMobile;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.smsMobileService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    localStringBuffer.append(localGson.toJson(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.smsMobileService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    SmsMobile localSmsMobile = (SmsMobile)this.smsMobileService.get(this.smsId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localSmsMobile));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    StringBuffer localStringBuffer = new StringBuffer("");
    String str1 = getRequest().getParameter("recipientIds");
    Object localObject1;
    AppUser localAppUser;
    SmsMobile localSmsMobile;
    if (StringUtils.isNotEmpty(str1))
    {
      localObject1 = str1.split(",");
      for (String str2 : localObject1)
      {
        localAppUser = (AppUser)this.appUserService.get(new Long(str2));
        if (localAppUser.getMobile() == null)
        {
          localStringBuffer.append("用户<font color=\"red\">").append(localAppUser.getUsername()).append("</font>");
        }
        else
        {
          localSmsMobile = new SmsMobile();
          localSmsMobile.setPhoneNumber(localAppUser.getMobile());
          localSmsMobile.setRecipients(localAppUser.getFullname());
          localSmsMobile.setSendTime(new Date());
          localSmsMobile.setSmsContent(this.smsMobile.getSmsContent());
          localSmsMobile.setUserId(ContextUtil.getCurrentUserId());
          localSmsMobile.setUserName(ContextUtil.getCurrentUser().getFullname());
          localSmsMobile.setStatus(SmsMobile.STATUS_NOT_SENDED);
          this.smsMobileService.save(localSmsMobile);
        }
      }
      if (localStringBuffer.length() > 0)
        localStringBuffer.append("未设置手机号码.");
    }
    else
    {
      localObject1 = this.smsMobile.getPhoneNumber();
      if (StringUtils.isNotEmpty((String)localObject1))
      {
        ??? = ((String)localObject1).split(",");
        for (localAppUser : ???)
        {
          localSmsMobile = new SmsMobile();
          localSmsMobile.setPhoneNumber(localAppUser);
          localSmsMobile.setRecipients(localAppUser);
          localSmsMobile.setSendTime(new Date());
          localSmsMobile.setSmsContent(this.smsMobile.getSmsContent());
          localSmsMobile.setUserId(ContextUtil.getCurrentUserId());
          localSmsMobile.setUserName(ContextUtil.getCurrentUser().getFullname());
          localSmsMobile.setStatus(SmsMobile.STATUS_NOT_SENDED);
          this.smsMobileService.save(localSmsMobile);
        }
      }
    }
    setJsonString("{success:true,msg:'" + localStringBuffer.toString() + "'}");
    return (String)(String)"success";
  }

  public String send()
  {
    this.smsMobile.setSendTime(new Date());
    this.smsMobileService.save(this.smsMobile);
    this.smsMobileService.sendOneSms(this.smsMobile);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.communicate.SmsMobileAction
 * JD-Core Version:    0.6.0
 */