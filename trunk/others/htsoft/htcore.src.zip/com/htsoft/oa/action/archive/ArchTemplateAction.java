package com.htsoft.oa.action.archive;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.archive.ArchTemplate;
import com.htsoft.oa.service.archive.ArchTemplateService;
import flexjson.JSONSerializer;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class ArchTemplateAction extends BaseAction
{

  @Resource
  private ArchTemplateService archTemplateService;
  private ArchTemplate archTemplate;
  private Long templateId;

  public Long getTemplateId()
  {
    return this.templateId;
  }

  public void setTemplateId(Long paramLong)
  {
    this.templateId = paramLong;
  }

  public ArchTemplate getArchTemplate()
  {
    return this.archTemplate;
  }

  public void setArchTemplate(ArchTemplate paramArchTemplate)
  {
    this.archTemplate = paramArchTemplate;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.archTemplateService.getAll(localQueryFilter);
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    localStringBuffer.append(localJSONSerializer.serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.archTemplateService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    ArchTemplate localArchTemplate = (ArchTemplate)this.archTemplateService.get(this.templateId);
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localJSONSerializer.serialize(localArchTemplate));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.archTemplateService.save(this.archTemplate);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.archive.ArchTemplateAction
 * JD-Core Version:    0.6.0
 */