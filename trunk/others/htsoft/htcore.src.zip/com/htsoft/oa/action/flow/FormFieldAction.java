package com.htsoft.oa.action.flow;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.flow.FormField;
import com.htsoft.oa.service.flow.FormFieldService;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.htmlparser.NodeFilter;
import org.htmlparser.Parser;
import org.htmlparser.filters.NodeClassFilter;
import org.htmlparser.filters.OrFilter;
import org.htmlparser.tags.InputTag;
import org.htmlparser.tags.SelectTag;
import org.htmlparser.tags.TextareaTag;
import org.htmlparser.util.NodeList;
import org.htmlparser.util.ParserException;

public class FormFieldAction extends BaseAction
{

  @Resource
  private FormFieldService formFieldService;
  private FormField formField;
  private Long fieldId;

  public Long getFieldId()
  {
    return this.fieldId;
  }

  public void setFieldId(Long paramLong)
  {
    this.fieldId = paramLong;
  }

  public FormField getFormField()
  {
    return this.formField;
  }

  public void setFormField(FormField paramFormField)
  {
    this.formField = paramFormField;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.formFieldService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.formFieldService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    FormField localFormField = (FormField)this.formFieldService.get(this.fieldId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localFormField));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    if (this.formField.getFieldId() == null)
    {
      this.formFieldService.save(this.formField);
    }
    else
    {
      FormField localFormField = (FormField)this.formFieldService.get(this.formField.getFieldId());
      try
      {
        BeanUtil.copyNotNullProperties(localFormField, this.formField);
        this.formFieldService.save(localFormField);
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    setJsonString("{success:true}");
    return "success";
  }

  public String getFields()
  {
    String str1 = getRequest().getParameter("htmlCode");
    ArrayList localArrayList = new ArrayList();
    try
    {
      NodeClassFilter localNodeClassFilter1 = new NodeClassFilter(InputTag.class);
      localObject1 = new NodeClassFilter(SelectTag.class);
      NodeClassFilter localNodeClassFilter2 = new NodeClassFilter(TextareaTag.class);
      NodeList localNodeList = null;
      Parser localParser = new Parser();
      localParser.setInputHTML(str1);
      localParser.setEncoding(localParser.getEncoding());
      OrFilter localOrFilter = new OrFilter();
      localOrFilter.setPredicates(new NodeFilter[] { localObject1, localNodeClassFilter1, localNodeClassFilter2 });
      localNodeList = localParser.parse(localOrFilter);
      for (int i = 0; i <= localNodeList.size(); i++)
      {
        if ((localNodeList.elementAt(i) instanceof InputTag))
        {
          localObject2 = (InputTag)localNodeList.elementAt(i);
          if (!((InputTag)localObject2).getAttribute("type").toUpperCase().equals("BUTTON"))
          {
            localFormField = new FormField();
            localFormField.setFieldDscp("");
            localFormField.setFieldName(((InputTag)localObject2).getAttribute("name"));
            j = 64;
            str2 = ((InputTag)localObject2).getAttribute("txtsize");
            if (StringUtils.isNotEmpty(str2))
              j = new Integer(str2).intValue();
            localFormField.setFieldSize(Integer.valueOf(j));
            localFormField.setFieldType(((InputTag)localObject2).getAttribute("txtvalueType"));
            localFormField.setIsRequired(new Short("1".equals(((InputTag)localObject2).getAttribute("txtisnotnull")) ? "1" : "0"));
            localFormField.setIsPrimary(Short.valueOf(0));
            String str3 = ((InputTag)localObject2).getAttribute("dateFormat");
            if (StringUtils.isNotEmpty(str3))
              localFormField.setShowFormat(str3);
            localFormField.setIsList(Short.valueOf(1));
            localFormField.setIsQuery(Short.valueOf(1));
            localFormField.setForeignTable("");
            localArrayList.add(localFormField);
          }
        }
        if ((localNodeList.elementAt(i) instanceof SelectTag))
        {
          localObject2 = (SelectTag)localNodeList.elementAt(i);
          localFormField = new FormField();
          localFormField.setFieldDscp("");
          localFormField.setFieldName(((SelectTag)localObject2).getAttribute("name"));
          j = 128;
          str2 = ((SelectTag)localObject2).getAttribute("txtsize");
          if (StringUtils.isNotEmpty(str2))
            j = new Integer(str2).intValue();
          localFormField.setFieldSize(Integer.valueOf(j));
          localFormField.setFieldType(((SelectTag)localObject2).getAttribute("txtvaluetype"));
          localFormField.setIsList(Short.valueOf(1));
          localFormField.setIsRequired(Short.valueOf(0));
          localFormField.setIsPrimary(Short.valueOf(0));
          localFormField.setIsQuery(Short.valueOf(1));
          localFormField.setForeignTable("");
          localArrayList.add(localFormField);
        }
        if (!(localNodeList.elementAt(i) instanceof TextareaTag))
          continue;
        Object localObject2 = (TextareaTag)localNodeList.elementAt(i);
        FormField localFormField = new FormField();
        localFormField.setFieldDscp("");
        localFormField.setFieldName(((TextareaTag)localObject2).getAttribute("name"));
        int j = 128;
        String str2 = ((TextareaTag)localObject2).getAttribute("txtsize");
        if (StringUtils.isNotEmpty(str2))
          j = new Integer(str2).intValue();
        localFormField.setFieldSize(Integer.valueOf(j));
        localFormField.setFieldType(((TextareaTag)localObject2).getAttribute("txtvaluetype"));
        localFormField.setIsList(Short.valueOf(1));
        localFormField.setIsRequired(Short.valueOf(0));
        localFormField.setIsPrimary(Short.valueOf(0));
        localFormField.setIsQuery(Short.valueOf(1));
        localFormField.setForeignTable("");
        localArrayList.add(localFormField);
      }
    }
    catch (ParserException localParserException)
    {
      localParserException.printStackTrace();
    }
    Gson localGson = new Gson();
    Object localObject1 = new StringBuffer("{success:true,fields:");
    ((StringBuffer)localObject1).append(localGson.toJson(localArrayList));
    ((StringBuffer)localObject1).append("}");
    setJsonString(((StringBuffer)localObject1).toString());
    return (String)(String)"success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.flow.FormFieldAction
 * JD-Core Version:    0.6.0
 */