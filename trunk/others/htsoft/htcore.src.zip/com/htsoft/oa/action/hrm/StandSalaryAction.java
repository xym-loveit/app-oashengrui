package com.htsoft.oa.action.hrm;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.hrm.StandSalary;
import com.htsoft.oa.model.hrm.StandSalaryItem;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.hrm.StandSalaryItemService;
import com.htsoft.oa.service.hrm.StandSalaryService;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class StandSalaryAction extends BaseAction
{
  private static short STATUS_DRAFT = 0;
  private static short STATUS_PASS = 1;
  private static short STATUS_NOT_PASS = 2;

  @Resource
  private StandSalaryService standSalaryService;

  @Resource
  private StandSalaryItemService standSalaryItemService;
  private StandSalary standSalary;
  private String data;
  private Long standardId;
  private String deleteItemIds;

  public String getDeleteItemIds()
  {
    return this.deleteItemIds;
  }

  public void setDeleteItemIds(String paramString)
  {
    this.deleteItemIds = paramString;
  }

  public String getData()
  {
    return this.data;
  }

  public void setData(String paramString)
  {
    this.data = paramString;
  }

  public Long getStandardId()
  {
    return this.standardId;
  }

  public void setStandardId(Long paramLong)
  {
    this.standardId = paramLong;
  }

  public StandSalary getStandSalary()
  {
    return this.standSalary;
  }

  public void setStandSalary(StandSalary paramStandSalary)
  {
    this.standSalary = paramStandSalary;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.standSalaryService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.standSalaryService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    StandSalary localStandSalary = (StandSalary)this.standSalaryService.get(this.standardId);
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localStandSalary));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String getform()
  {
    StandSalary localStandSalary = (StandSalary)this.standSalaryService.get(this.standardId);
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localStandSalary));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    int i = 0;
    StringBuffer localStringBuffer = new StringBuffer("{");
    if (this.standSalary.getStandardId() == null)
    {
      if (this.standSalaryService.checkStandNo(this.standSalary.getStandardNo()))
        i = 1;
      else
        localStringBuffer.append("msg:'标准编号已存在,请重新输入.',");
    }
    else
      i = 1;
    if (i != 0)
    {
      if (this.standSalary.getStandardId() != null)
      {
        this.standSalary.setModifyName(ContextUtil.getCurrentUser().getFullname());
        this.standSalary.setModifyTime(new Date());
      }
      else
      {
        this.standSalary.setSetdownTime(new Date());
        this.standSalary.setFramer(ContextUtil.getCurrentUser().getFullname());
      }
      this.standSalary.setStatus(Short.valueOf(STATUS_DRAFT));
      Object localObject1;
      if (StringUtils.isNotEmpty(this.deleteItemIds))
      {
        localObject1 = this.deleteItemIds.split(",");
        for (String str : localObject1)
        {
          if (!StringUtils.isNotEmpty(str))
            continue;
          this.standSalaryItemService.remove(new Long(str));
        }
      }
      this.standSalaryService.save(this.standSalary);
      if (StringUtils.isNotEmpty(this.data))
      {
        localObject1 = new Gson();
        ??? = (StandSalaryItem[])((Gson)localObject1).fromJson(this.data, [Lcom.htsoft.oa.model.hrm.StandSalaryItem.class);
        for (Object localObject4 : ???)
        {
          if (localObject4.getItemId().longValue() == -1L)
            localObject4.setItemId(null);
          localObject4.setStandardId(this.standSalary.getStandardId());
          this.standSalaryItemService.save(localObject4);
        }
      }
      localStringBuffer.append("success:true}");
    }
    else
    {
      localStringBuffer.append("failure:true}");
    }
    setJsonString(localStringBuffer.toString());
    return (String)(String)"success";
  }

  public String check()
  {
    String str = getRequest().getParameter("status");
    StandSalary localStandSalary = (StandSalary)this.standSalaryService.get(this.standSalary.getStandardId());
    localStandSalary.setCheckName(ContextUtil.getCurrentUser().getFullname());
    localStandSalary.setCheckTime(new Date());
    localStandSalary.setCheckOpinion(this.standSalary.getCheckOpinion());
    if ((StringUtils.isNotEmpty(str)) && (Short.valueOf(str).shortValue() == STATUS_PASS))
      localStandSalary.setStatus(Short.valueOf(STATUS_PASS));
    else
      localStandSalary.setStatus(Short.valueOf(STATUS_NOT_PASS));
    this.standSalaryService.save(localStandSalary);
    return "success";
  }

  public String number()
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss-SSSS");
    String str = localSimpleDateFormat.format(new Date());
    setJsonString("{success:true,standardNo:'SN" + str + "'}");
    return "success";
  }

  public String combo()
  {
    List localList = this.standSalaryService.findByPassCheck();
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer();
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    this.jsonString = localStringBuffer.toString();
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.hrm.StandSalaryAction
 * JD-Core Version:    0.6.0
 */