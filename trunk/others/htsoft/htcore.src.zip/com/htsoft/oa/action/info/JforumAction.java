package com.htsoft.oa.action.info;

import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.system.AppUserService;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class JforumAction extends BaseAction
{

  @Resource
  private AppUserService appUserService;
  private Long userId;

  public Long getUserId()
  {
    return this.userId;
  }

  public void setUserId(Long paramLong)
  {
    this.userId = paramLong;
  }

  public String execute()
  {
    AppUser localAppUser = null;
    String str = getRequest().getParameter("userId");
    if (str == null)
      localAppUser = (AppUser)this.appUserService.get(new Long(str));
    else
      localAppUser = (AppUser)this.appUserService.get(ContextUtil.getCurrentUserId());
    getRequest().setAttribute("appUser", localAppUser);
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.info.JforumAction
 * JD-Core Version:    0.6.0
 */