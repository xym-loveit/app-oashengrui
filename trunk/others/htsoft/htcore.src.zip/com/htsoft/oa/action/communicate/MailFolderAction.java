package com.htsoft.oa.action.communicate;

import com.google.gson.Gson;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.communicate.MailBox;
import com.htsoft.oa.model.communicate.MailFolder;
import com.htsoft.oa.service.communicate.MailBoxService;
import com.htsoft.oa.service.communicate.MailFolderService;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;

public class MailFolderAction extends BaseAction
{
  static long FOLDER_ID_RECEIVE = 1L;
  static long FOLDER_ID_SEND = 2L;
  static long FOLDER_ID_DRAFT = 3L;
  static long FOLDER_ID_DELETE = 4L;
  static short OTHER_FOLDER_TYPE = 10;
  static int FIRST_LEVEL = 1;
  static long FIRST_LEVEL_PARENTID = 0L;

  @Resource
  private MailFolderService mailFolderService;

  @Resource
  private MailBoxService mailBoxService;
  private MailFolder mailFolder;
  private Long folderId;

  public Long getFolderId()
  {
    return this.folderId;
  }

  public void setFolderId(Long paramLong)
  {
    this.folderId = paramLong;
  }

  public MailFolder getMailFolder()
  {
    return this.mailFolder;
  }

  public void setMailFolder(MailFolder paramMailFolder)
  {
    this.mailFolder = paramMailFolder;
  }

  public String list()
  {
    StringBuffer localStringBuffer = new StringBuffer("[{id:'0',text:'我的邮箱',iconCls:'menu-mail_box',expanded:true,children:[");
    Long localLong1 = ContextUtil.getCurrentUserId();
    List localList = this.mailFolderService.getAllUserFolderByParentId(localLong1, Long.valueOf(0L));
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      MailFolder localMailFolder = (MailFolder)localIterator.next();
      localStringBuffer.append("{id:'" + localMailFolder.getFolderId()).append("',text:'" + localMailFolder.getFolderName()).append("',");
      Long localLong2 = localMailFolder.getFolderId();
      if (localLong2.longValue() == FOLDER_ID_RECEIVE)
        localStringBuffer.append("iconCls:'menu-mail_inbox',");
      else if (localLong2.longValue() == FOLDER_ID_SEND)
        localStringBuffer.append("iconCls:'menu-mail_outbox',");
      else if (localLong2.longValue() == FOLDER_ID_DRAFT)
        localStringBuffer.append("iconCls:'menu-mail_drafts',");
      else if (localLong2.longValue() == FOLDER_ID_DELETE)
        localStringBuffer.append("iconCls:'menu-mail_trash',");
      else
        localStringBuffer.append("iconCls:'menu-mail_folder',");
      localStringBuffer.append(findChildsFolder(localLong1, localMailFolder.getFolderId()));
    }
    if (!localList.isEmpty())
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}]");
    setJsonString(localStringBuffer.toString());
    this.logger.info("tree json:" + localStringBuffer.toString());
    return "success";
  }

  public String findChildsFolder(Long paramLong1, Long paramLong2)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    List localList = this.mailFolderService.getUserFolderByParentId(paramLong1, paramLong2);
    if (localList.size() == 0)
    {
      localStringBuffer.append("leaf:true,expanded:true},");
      return localStringBuffer.toString();
    }
    localStringBuffer.append("children:[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      MailFolder localMailFolder = (MailFolder)localIterator.next();
      localStringBuffer.append("{id:'" + localMailFolder.getFolderId() + "',text:'" + localMailFolder.getFolderName() + "',");
      localStringBuffer.append("iconCls:'menu-mail_folder',");
      localStringBuffer.append(findChildsFolder(paramLong1, localMailFolder.getFolderId()));
    }
    localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]},");
    return localStringBuffer.toString();
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.mailFolderService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String count()
  {
    MailFolder localMailFolder1 = (MailFolder)this.mailFolderService.get(new Long(this.folderId.longValue()));
    List localList = this.mailFolderService.getFolderLikePath(localMailFolder1.getPath());
    Long localLong1 = Long.valueOf(0L);
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      MailFolder localMailFolder2 = (MailFolder)localIterator.next();
      Long localLong2 = this.mailBoxService.CountByFolderId(localMailFolder2.getFolderId());
      localLong1 = Long.valueOf(localLong1.longValue() + localLong2.longValue());
    }
    setJsonString("{success:true,count:" + localLong1 + "}");
    return "success";
  }

  public String remove()
  {
    String str = getRequest().getParameter("count");
    if (this.folderId != null)
    {
      MailFolder localMailFolder1 = (MailFolder)this.mailFolderService.get(new Long(this.folderId.longValue()));
      List localList1 = this.mailFolderService.getFolderLikePath(localMailFolder1.getPath());
      Object localObject2;
      if ((str != null) && (new Long(str).longValue() > 0L))
      {
        localObject1 = (MailFolder)this.mailFolderService.get(Long.valueOf(4L));
        localObject2 = localList1.iterator();
        while (((Iterator)localObject2).hasNext())
        {
          MailFolder localMailFolder2 = (MailFolder)((Iterator)localObject2).next();
          List localList2 = this.mailBoxService.findByFolderId(localMailFolder2.getFolderId());
          Iterator localIterator = localList2.iterator();
          while (localIterator.hasNext())
          {
            MailBox localMailBox = (MailBox)localIterator.next();
            localMailBox.setMailFolder((MailFolder)localObject1);
            this.mailBoxService.save(localMailBox);
          }
        }
      }
      Object localObject1 = localList1.iterator();
      while (((Iterator)localObject1).hasNext())
      {
        localObject2 = (MailFolder)((Iterator)localObject1).next();
        this.mailFolderService.remove(((MailFolder)localObject2).getFolderId());
      }
    }
    this.jsonString = "{success:true}";
    return (String)(String)"success";
  }

  public String get()
  {
    MailFolder localMailFolder = (MailFolder)this.mailFolderService.get(this.folderId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localMailFolder));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    MailFolder localMailFolder = null;
    Long localLong = this.mailFolder.getParentId();
    if ((localLong == null) || (localLong.longValue() == FIRST_LEVEL_PARENTID))
    {
      this.mailFolder.setParentId(new Long(FIRST_LEVEL_PARENTID));
      this.mailFolder.setDepLevel(Integer.valueOf(FIRST_LEVEL));
    }
    else
    {
      localMailFolder = (MailFolder)this.mailFolderService.get(localLong);
      this.mailFolder.setDepLevel(Integer.valueOf(localMailFolder.getDepLevel().intValue() + 1));
    }
    this.mailFolder.setFolderType(Short.valueOf(OTHER_FOLDER_TYPE));
    this.mailFolder.setUserId(ContextUtil.getCurrentUserId());
    this.mailFolderService.save(this.mailFolder);
    if (this.mailFolder.getParentId().longValue() == FIRST_LEVEL_PARENTID)
      this.mailFolder.setPath("0." + this.mailFolder.getFolderId() + ".");
    else
      this.mailFolder.setPath(localMailFolder.getPath() + this.mailFolder.getFolderId() + ".");
    this.mailFolderService.save(this.mailFolder);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.communicate.MailFolderAction
 * JD-Core Version:    0.6.0
 */