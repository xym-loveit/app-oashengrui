package com.htsoft.oa.action.flow;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.AppUtil;
import com.htsoft.core.util.FileUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.flow.FieldRights;
import com.htsoft.oa.model.flow.FormDef;
import com.htsoft.oa.model.flow.FormDefMapping;
import com.htsoft.oa.model.flow.FormTable;
import com.htsoft.oa.model.flow.FormTableItem;
import com.htsoft.oa.model.flow.ProDefinition;
import com.htsoft.oa.service.flow.FieldRightsService;
import com.htsoft.oa.service.flow.FormDefMappingService;
import com.htsoft.oa.service.flow.FormDefService;
import com.htsoft.oa.service.flow.FormTableGenService;
import com.htsoft.oa.service.flow.FormTableService;
import com.htsoft.oa.service.flow.ProDefinitionService;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class FormDefAction extends BaseAction
{

  @Resource
  private FormDefService formDefService;

  @Resource
  private FormTableGenService formTableGenService;

  @Resource
  private FormTableService formTableService;

  @Resource
  private ProDefinitionService proDefinitionService;

  @Resource
  private FormDefMappingService formDefMappingService;

  @Resource
  private FieldRightsService fieldRightsService;
  private FormDef formDef;
  private FormTable formTable;
  private FormTable formTable1;
  private Long formDefId;
  private Long defId;

  public Long getFormDefId()
  {
    return this.formDefId;
  }

  public void setFormDefId(Long paramLong)
  {
    this.formDefId = paramLong;
  }

  public FormDef getFormDef()
  {
    return this.formDef;
  }

  public void setFormDef(FormDef paramFormDef)
  {
    this.formDef = paramFormDef;
  }

  public FormTable getFormTable()
  {
    return this.formTable;
  }

  public void setFormTable(FormTable paramFormTable)
  {
    this.formTable = paramFormTable;
  }

  public FormTable getFormTable1()
  {
    return this.formTable1;
  }

  public void setFormTable1(FormTable paramFormTable)
  {
    this.formTable1 = paramFormTable;
  }

  public Long getDefId()
  {
    return this.defId;
  }

  public void setDefId(Long paramLong)
  {
    this.defId = paramLong;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.formDefService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.formDefService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    FormDef localFormDef = (FormDef)this.formDefService.get(this.formDefId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localFormDef));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String gen()
  {
    FormDef localFormDef = (FormDef)this.formDefService.get(this.formDefId);
    Set localSet = localFormDef.getFormTables();
    if (localSet.size() > 0)
    {
      FormTable[] arrayOfFormTable = new FormTable[localSet.size()];
      Iterator localIterator = localSet.iterator();
      int i = 0;
      while (localIterator.hasNext())
        arrayOfFormTable[(i++)] = ((FormTable)localIterator.next());
      if (this.formTableGenService.genBean(arrayOfFormTable) == true)
        setJsonString("{success:true}");
      else
        setJsonString("{failure:true}");
      localFormDef.setIsGen(FormDef.HAS_GEN);
      this.formDefService.save(localFormDef);
    }
    return "success";
  }

  public String genAll()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_formDef.status_SN_EQ", FormDef.HAS_Pub.toString());
    List localList = this.formTableService.getAll(localQueryFilter);
    if (localList.size() > 0)
    {
      FormTable[] arrayOfFormTable = new FormTable[localList.size()];
      Iterator localIterator = localList.iterator();
      int i = 0;
      while (localIterator.hasNext())
        arrayOfFormTable[(i++)] = ((FormTable)localIterator.next());
      if (this.formTableGenService.genBean(arrayOfFormTable))
        setJsonString("{success:true}");
      else
        setJsonString("{failure:true}");
    }
    return "success";
  }

  public String save()
  {
    HashMap localHashMap = new HashMap();
    String str = getRequest().getParameter("objs");
    if (StringUtils.isNotEmpty(str))
    {
      Gson localGson = new Gson();
      FormTableItem[] arrayOfFormTableItem1 = (FormTableItem[])localGson.fromJson(str, [Lcom.htsoft.oa.model.flow.FormTableItem.class);
      for (FormTableItem localFormTableItem : arrayOfFormTableItem1)
      {
        FormTable localFormTable = new FormTable();
        localFormTable.setTableId(localFormTableItem.getTableId());
        localFormTable.setTableKey(localFormTableItem.getTableKey());
        localFormTable.setTableName(localFormTableItem.getTableName());
        localFormTable.setIsMain(localFormTableItem.getIsMain());
        localHashMap.put(localFormTable, localFormTableItem.getFields());
        List localList = this.formTableService.findByTableKey(localFormTableItem.getTableKey());
        if ((localList.size() <= 2) && ((localList.size() != 1) || (localFormTableItem.getTableId() != null)))
          continue;
        setJsonString("{success:false,msg:'" + localFormTableItem.getTableKey() + "'}");
        return "success";
      }
    }
    this.formDef = this.formDefService.saveFormDef(this.formDef, localHashMap);
    setJsonString("{success:true}");
    return "success";
  }

  public String add()
  {
    String str = "{success:true}";
    ProDefinition localProDefinition = (ProDefinition)this.proDefinitionService.get(this.defId);
    FormDefMapping localFormDefMapping = this.formDefMappingService.getByDeployId(localProDefinition.getDeployId());
    FormDef localFormDef = (FormDef)this.formDefService.get(this.formDefId);
    if ((localFormDefMapping != null) && (localFormDefMapping.getFormDefId() == this.formDefId))
    {
      str = "{failure:true,msg:'对不起，该表单信息已经添加，请选择其他表单信息！'}";
    }
    else
    {
      Object localObject1;
      Object localObject2;
      if (localFormDefMapping == null)
      {
        localObject1 = (ProDefinition)this.proDefinitionService.get(this.defId);
        localObject2 = new FormDefMapping();
        ((FormDefMapping)localObject2).setDeployId(((ProDefinition)localObject1).getDeployId());
        ((FormDefMapping)localObject2).setDefId(this.defId);
        ((FormDefMapping)localObject2).setFormDef(localFormDef);
        ((FormDefMapping)localObject2).setVersionNo(((ProDefinition)localObject1).getNewVersion());
        this.formDefMappingService.save(localObject2);
      }
      else
      {
        localObject1 = this.fieldRightsService.getByMappingId(localFormDefMapping.getMappingId());
        if (((List)localObject1).size() > 0)
        {
          localObject2 = ((List)localObject1).iterator();
          while (((Iterator)localObject2).hasNext())
          {
            FieldRights localFieldRights = (FieldRights)((Iterator)localObject2).next();
            this.fieldRightsService.remove(localFieldRights);
          }
        }
        localFormDefMapping.setFormDef(localFormDef);
        this.formDefMappingService.save(localFormDefMapping);
      }
    }
    setJsonString(str);
    return (String)(String)"success";
  }

  public String check()
  {
    boolean bool = this.formDefMappingService.formDefHadMapping(this.formDefId);
    if (bool)
      setJsonString("{success:true,msg:'该表单已经同相应的流程关联了！'}");
    else
      setJsonString("{success:false}");
    return "success";
  }

  public String saveVmXml()
  {
    String str1 = getRequest().getParameter("defId");
    String str2 = getRequest().getParameter("activityName");
    String str3 = getRequest().getParameter("vmSources");
    ProDefinition localProDefinition = (ProDefinition)this.proDefinitionService.get(new Long(str1));
    String str4 = AppUtil.getAppAbsolutePath() + "/WEB-INF/FlowForm/" + localProDefinition.getName() + "/" + localProDefinition.getNewVersion() + str2;
    String str5 = str4 + ".vm";
    FileUtil.writeFile(str5, str3);
    setJsonString("{success:true}");
    return "success";
  }

  public String getVmXml()
  {
    String str1 = getRequest().getParameter("defId");
    String str2 = getRequest().getParameter("activityName");
    ProDefinition localProDefinition = (ProDefinition)this.proDefinitionService.get(new Long(str1));
    String str3 = AppUtil.getAppAbsolutePath() + "/WEB-INF/FlowForm/" + localProDefinition.getName() + "/" + localProDefinition.getNewVersion() + "/" + str2;
    String str4 = str3 + ".vm";
    String str5 = FileUtil.readFile(str4);
    Gson localGson = new Gson();
    setJsonString("{success:true,vmSources:" + localGson.toJson(str5) + "}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.flow.FormDefAction
 * JD-Core Version:    0.6.0
 */