package com.htsoft.oa.action.admin;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.admin.BoardType;
import com.htsoft.oa.service.admin.BoardTypeService;
import java.lang.reflect.Type;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class BoardTypeAction extends BaseAction
{

  @Resource
  private BoardTypeService boardTypeService;
  private BoardType boardType;
  private Long typeId;

  public Long getTypeId()
  {
    return this.typeId;
  }

  public void setTypeId(Long paramLong)
  {
    this.typeId = paramLong;
  }

  public BoardType getBoardType()
  {
    return this.boardType;
  }

  public void setBoardType(BoardType paramBoardType)
  {
    this.boardType = paramBoardType;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addSorted("typeId", "DESC");
    List localList = this.boardTypeService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':");
    localStringBuffer.append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType)).append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("typeIds");
    for (String str : arrayOfString1)
      this.boardTypeService.remove(new Long(str));
    setJsonString("{success:true}");
    return "success";
  }

  public String del()
  {
    this.boardTypeService.remove(this.typeId);
    setJsonString("{success:true}");
    return "success";
  }

  public String save()
  {
    this.boardTypeService.save(this.boardType);
    setJsonString("{success:true}");
    return "success";
  }

  public String get()
  {
    BoardType localBoardType = (BoardType)this.boardTypeService.get(this.typeId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localBoardType)).append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.admin.BoardTypeAction
 * JD-Core Version:    0.6.0
 */