package com.htsoft.oa.action.arch;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.arch.BorrowFileList;
import com.htsoft.oa.model.arch.BorrowRecord;
import com.htsoft.oa.model.arch.RollFile;
import com.htsoft.oa.model.arch.RollFileList;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.FileAttach;
import com.htsoft.oa.service.arch.BorrowFileListService;
import com.htsoft.oa.service.arch.BorrowRecordService;
import com.htsoft.oa.service.arch.RollFileListService;
import com.htsoft.oa.service.arch.RollFileService;
import com.htsoft.oa.service.system.FileAttachService;
import flexjson.JSONSerializer;
import flexjson.transformer.DateTransformer;
import java.lang.reflect.Type;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;

public class RollFileAction extends BaseAction
{

  @Resource
  private RollFileService rollFileService;

  @Resource
  private RollFileListService rollFileListService;

  @Resource
  private FileAttachService fileAttachService;

  @Resource
  private BorrowRecordService borrowRecordService;

  @Resource
  private BorrowFileListService borrowFileListService;
  private RollFile rollFile;
  private Long rollFileId;

  public Long getRollFileId()
  {
    return this.rollFileId;
  }

  public void setRollFileId(Long paramLong)
  {
    this.rollFileId = paramLong;
  }

  public RollFile getRollFile()
  {
    return this.rollFile;
  }

  public void setRollFile(RollFile paramRollFile)
  {
    this.rollFile = paramRollFile;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.rollFileService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localJSONSerializer.transform(new DateTransformer("yyyy-MM-dd"), new String[] { "fileTime", "createTime", "archFond.createTime", "archFond.updateTime", "archRoll.archFond.createTime", "archRoll.archFond.updateTime", "rollFile.archRoll.archFond.createTime", "rollFile.archRoll.archFond.updateTime", "archRoll.startTime", "archRoll.endTime", "archRoll.setupTime", "archRoll.createTime", "fileAttach.createtime" });
    localStringBuffer.append(localJSONSerializer.serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    this.logger.debug(this.jsonString);
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
      {
        RollFile localRollFile = (RollFile)this.rollFileService.get(new Long(str));
        Set localSet1 = localRollFile.getRollFileLists();
        Iterator localIterator = localSet1.iterator();
        while (localIterator.hasNext())
        {
          localObject1 = (RollFileList)localIterator.next();
          localObject2 = ((RollFileList)localObject1).getFileAttach();
          this.rollFileListService.remove(localObject1);
          this.rollFileListService.flush();
          this.fileAttachService.removeByPath(((FileAttach)localObject2).getFilePath());
        }
        Object localObject1 = localRollFile.getBorrowFileList();
        Object localObject2 = ((Set)localObject1).iterator();
        while (((Iterator)localObject2).hasNext())
        {
          BorrowFileList localBorrowFileList = (BorrowFileList)((Iterator)localObject2).next();
          this.borrowFileListService.remove(localBorrowFileList);
          this.borrowFileListService.flush();
          BorrowRecord localBorrowRecord = localBorrowFileList.getBorrowRecord();
          Set localSet2 = localBorrowRecord.getBorrowFileLists();
          if ((localSet2 == null) || (localSet2.size() == 0))
            this.borrowRecordService.remove(localBorrowRecord);
        }
        this.rollFileService.remove(localRollFile);
        this.rollFileService.flush();
      }
    this.jsonString = "{success:true}";
    return (String)(String)"success";
  }

  public String get()
  {
    RollFile localRollFile = (RollFile)this.rollFileService.get(this.rollFileId);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localJSONSerializer.transform(new DateTransformer("yyyy-MM-dd"), new String[] { "createTime", "updateTime", "fileTime" });
    localStringBuffer.append(localJSONSerializer.serialize(localRollFile));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    Long localLong = null;
    Object localObject2;
    if (this.rollFile.getRollFileId() == null)
    {
      this.rollFileService.save(this.rollFile);
      localLong = this.rollFile.getRollFileId();
    }
    else
    {
      localObject1 = (RollFile)this.rollFileService.get(this.rollFile.getRollFileId());
      try
      {
        Set localSet = ((RollFile)localObject1).getRollFileLists();
        localObject2 = ((RollFile)localObject1).getBorrowFileList();
        BeanUtil.copyNotNullProperties(localObject1, this.rollFile);
        ((RollFile)localObject1).setRollFileLists(localSet);
        ((RollFile)localObject1).setBorrowFileList((Set)localObject2);
        this.rollFileService.save(localObject1);
        localLong = ((RollFile)localObject1).getRollFileId();
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    Object localObject1 = getRequest().getParameter("params");
    if (StringUtils.isNotEmpty((String)localObject1))
    {
      Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
      localObject2 = (RollFileList[])localGson.fromJson((String)localObject1, [Lcom.htsoft.oa.model.arch.RollFileList.class);
      if ((localObject2 != null) && (localObject2.length > 0))
        for (Object localObject4 : localObject2)
        {
          localObject4.setRollFileId(localLong);
          this.rollFileListService.save(localObject4);
        }
    }
    setJsonString("{success:true,rollFileId:" + this.rollFile.getRollFileId() + "}");
    return (String)(String)"success";
  }

  public String updateDownLoad()
  {
    String str = getRequest().getParameter("params");
    this.logger.debug("params=" + str);
    if (StringUtils.isNotEmpty(str))
    {
      Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
      RollFileList[] arrayOfRollFileList1 = (RollFileList[])localGson.fromJson(str, [Lcom.htsoft.oa.model.arch.RollFileList.class);
      if ((arrayOfRollFileList1 != null) && (arrayOfRollFileList1.length > 0))
        for (RollFileList localRollFileList : arrayOfRollFileList1)
          this.rollFileListService.save(localRollFileList);
    }
    setJsonString("{success:true}");
    return "success";
  }

  public String tidy()
  {
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
    String str = getRequest().getParameter("params");
    if (StringUtils.isNotEmpty(str))
    {
      RollFile[] arrayOfRollFile1 = (RollFile[])localGson.fromJson(str, [Lcom.htsoft.oa.model.arch.RollFile.class);
      if ((arrayOfRollFile1 != null) && (arrayOfRollFile1.length > 0))
        for (RollFile localRollFile1 : arrayOfRollFile1)
        {
          RollFile localRollFile2 = (RollFile)this.rollFileService.get(localRollFile1.getRollFileId());
          try
          {
            Set localSet1 = localRollFile2.getRollFileLists();
            Set localSet2 = localRollFile2.getBorrowFileList();
            BeanUtil.copyNotNullProperties(localRollFile2, localRollFile1);
            localRollFile2.setRollFileLists(localSet1);
            localRollFile2.setBorrowFileList(localSet2);
            localRollFile2.setTidyName(ContextUtil.getCurrentUser().getFullname());
            localRollFile2.setTidyTime(new Date());
            this.rollFileService.save(localRollFile2);
          }
          catch (Exception localException)
          {
            this.logger.error(localException.getMessage());
          }
        }
    }
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.arch.RollFileAction
 * JD-Core Version:    0.6.0
 */