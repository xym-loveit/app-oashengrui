package com.htsoft.oa.action.personal;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.personal.DutySection;
import com.htsoft.oa.service.personal.DutySectionService;
import flexjson.JSONSerializer;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class DutySectionAction extends BaseAction
{

  @Resource
  private DutySectionService dutySectionService;
  private DutySection dutySection;
  private Long sectionId;

  public Long getSectionId()
  {
    return this.sectionId;
  }

  public void setSectionId(Long paramLong)
  {
    this.sectionId = paramLong;
  }

  public DutySection getDutySection()
  {
    return this.dutySection;
  }

  public void setDutySection(DutySection paramDutySection)
  {
    this.dutySection = paramDutySection;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.dutySectionService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer();
    localStringBuffer.append(localJSONSerializer.serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.dutySectionService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String combo()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    List localList = this.dutySectionService.getAll();
    localStringBuffer.append("[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      DutySection localDutySection = (DutySection)localIterator.next();
      localStringBuffer.append("['").append(localDutySection.getSectionId()).append("','").append(localDutySection.getSectionName()).append("'],");
    }
    if (localList.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String get()
  {
    DutySection localDutySection = (DutySection)this.dutySectionService.get(this.sectionId);
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localJSONSerializer.serialize(localDutySection));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.dutySectionService.save(this.dutySection);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.personal.DutySectionAction
 * JD-Core Version:    0.6.0
 */