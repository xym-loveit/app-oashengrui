package com.htsoft.oa.action.personal;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.personal.HolidayRecord;
import com.htsoft.oa.service.personal.HolidayRecordService;
import java.lang.reflect.Type;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class HolidayRecordAction extends BaseAction
{

  @Resource
  private HolidayRecordService holidayRecordService;
  private HolidayRecord holidayRecord;
  private Long recordId;

  public Long getRecordId()
  {
    return this.recordId;
  }

  public void setRecordId(Long paramLong)
  {
    this.recordId = paramLong;
  }

  public HolidayRecord getHolidayRecord()
  {
    return this.holidayRecord;
  }

  public void setHolidayRecord(HolidayRecord paramHolidayRecord)
  {
    this.holidayRecord = paramHolidayRecord;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.holidayRecordService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.holidayRecordService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    HolidayRecord localHolidayRecord = (HolidayRecord)this.holidayRecordService.get(this.recordId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localHolidayRecord));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    if (this.holidayRecord.getIsAll() == null)
      this.holidayRecord.setIsAll(HolidayRecord.IS_PERSONAL_HOLIDAY);
    else
      this.holidayRecord.setIsAll(HolidayRecord.IS_ALL_HOLIDAY);
    this.holidayRecordService.save(this.holidayRecord);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.personal.HolidayRecordAction
 * JD-Core Version:    0.6.0
 */