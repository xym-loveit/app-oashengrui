package com.htsoft.oa.action.system;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.Constants;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.log.Action;
import com.htsoft.core.model.OnlineUser;
import com.htsoft.core.util.AppUtil;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.util.StringUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.system.AppRole;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.DepUsers;
import com.htsoft.oa.model.system.Department;
import com.htsoft.oa.model.system.IndexDisplay;
import com.htsoft.oa.model.system.PanelItem;
import com.htsoft.oa.model.system.SysConfig;
import com.htsoft.oa.model.system.UserJob;
import com.htsoft.oa.service.system.AppRoleService;
import com.htsoft.oa.service.system.AppUserService;
import com.htsoft.oa.service.system.DepUsersService;
import com.htsoft.oa.service.system.DepartmentService;
import com.htsoft.oa.service.system.IndexDisplayService;
import com.htsoft.oa.service.system.RelativeUserService;
import com.htsoft.oa.service.system.SysConfigService;
import com.htsoft.oa.service.system.UserJobService;
import com.htsoft.oa.service.system.UserSubService;
import flexjson.JSONSerializer;
import flexjson.transformer.DateTransformer;
import java.io.Serializable;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;

public class AppUserAction extends BaseAction
{
  private static Long SUPPER_MANAGER_ID = Long.valueOf(-1L);

  @Resource
  private AppUserService appUserService;

  @Resource
  private DepartmentService departmentService;

  @Resource
  private AppRoleService appRoleService;

  @Resource
  private UserSubService userSubService;

  @Resource
  private IndexDisplayService indexDisplayService;

  @Resource
  private DepUsersService depUsersService;

  @Resource
  private UserJobService userJobService;

  @Resource
  private SysConfigService sysConfigService;

  @Resource
  private RelativeUserService relativeUserService;
  private AppUser appUser;
  private Long userId;
  private Long depId;
  private Long roleId;

  public Long getDepId()
  {
    return this.depId;
  }

  public void setDepId(Long paramLong)
  {
    this.depId = paramLong;
  }

  public Long getRoleId()
  {
    return this.roleId;
  }

  public void setRoleId(Long paramLong)
  {
    this.roleId = paramLong;
  }

  public Long getUserId()
  {
    return this.userId;
  }

  public void setUserId(Long paramLong)
  {
    this.userId = paramLong;
  }

  public AppUser getAppUser()
  {
    return this.appUser;
  }

  public void setAppUser(AppUser paramAppUser)
  {
    this.appUser = paramAppUser;
  }

  public String getCurrent()
  {
    AppUser localAppUser = ContextUtil.getCurrentUser();
    Department localDepartment = localAppUser.getDepartment();
    if (localDepartment == null)
    {
      localDepartment = new Department();
      localDepartment.setDepId(Long.valueOf(0L));
      localDepartment.setDepName(AppUtil.getCompanyName());
    }
    List localList = this.indexDisplayService.findByUser(localAppUser.getUserId());
    ArrayList localArrayList = new ArrayList();
    Object localObject1 = localList.iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (IndexDisplay)((Iterator)localObject1).next();
      localObject3 = new PanelItem();
      ((PanelItem)localObject3).setPanelId(((IndexDisplay)localObject2).getPortalId());
      ((PanelItem)localObject3).setColumn(((IndexDisplay)localObject2).getColNum().intValue());
      ((PanelItem)localObject3).setRow(((IndexDisplay)localObject2).getRowNum().intValue());
      localArrayList.add(localObject3);
    }
    localObject1 = new StringBuffer();
    ((StringBuffer)localObject1).append("{success:true,user:{userId:'").append(localAppUser.getUserId()).append("',fullname:'").append(localAppUser.getFullname()).append("',username:'").append(localAppUser.getUsername()).append("',depId:'").append(localDepartment.getDepId()).append("',depName:'").append(localDepartment.getDepName()).append("',rights:'");
    ((StringBuffer)localObject1).append(localAppUser.getRights().toString().replace("[", "").replace("]", ""));
    Object localObject2 = new Gson();
    ((StringBuffer)localObject1).append("',topModules:");
    ((StringBuffer)localObject1).append(((Gson)localObject2).toJson(localAppUser.getTopModules().values()));
    ((StringBuffer)localObject1).append(",items:").append(((Gson)localObject2).toJson(localArrayList).toString());
    ((StringBuffer)localObject1).append("},sysConfigs:{");
    Object localObject3 = this.sysConfigService.getAll();
    Iterator localIterator = ((List)localObject3).iterator();
    while (localIterator.hasNext())
    {
      SysConfig localSysConfig = (SysConfig)localIterator.next();
      ((StringBuffer)localObject1).append("'").append(localSysConfig.getConfigKey()).append("':'").append(localSysConfig.getDataValue()).append("',");
    }
    if (((List)localObject3).size() > 0)
      ((StringBuffer)localObject1).deleteCharAt(((StringBuffer)localObject1).length() - 1);
    ((StringBuffer)localObject1).append("}}");
    setJsonString(((StringBuffer)localObject1).toString());
    return (String)(String)(String)"success";
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_delFlag_SN_EQ", Constants.FLAG_UNDELETED.toString());
    List localList = this.appUserService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localJSONSerializer.transform(new DateTransformer("yyyy-MM-dd"), new String[] { "accessionTime" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "password" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String select()
  {
    PagingBean localPagingBean = getInitPagingBean();
    String str1 = getRequest().getParameter("depId");
    String str2 = "0.";
    this.appUser = ContextUtil.getCurrentUser();
    if (StringUtils.isNotEmpty(str1))
    {
      localObject1 = Long.valueOf(Long.parseLong(str1));
      localObject2 = (Department)this.departmentService.get((Serializable)localObject1);
      if (localObject2 != null)
        str2 = ((Department)localObject2).getPath();
    }
    else
    {
      localObject1 = this.appUser.getDepartment();
      if (localObject1 != null)
        str2 = ((Department)localObject1).getPath();
    }
    Object localObject1 = this.appUserService.findByDepartment(str2, localPagingBean);
    Object localObject2 = new StringBuffer("{success:true,'totalCounts':").append(localPagingBean.getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localJSONSerializer.transform(new DateTransformer("yyyy-MM-dd"), new String[] { "accessionTime" });
    ((StringBuffer)localObject2).append(localJSONSerializer.exclude(new String[] { "password" }).serialize(localObject1));
    ((StringBuffer)localObject2).append("}");
    this.jsonString = ((StringBuffer)localObject2).toString();
    return (String)(String)"success";
  }

  public String online()
  {
    Object localObject1 = new HashMap();
    HashMap localHashMap1 = new HashMap();
    HashMap localHashMap2 = new HashMap();
    localObject1 = AppUtil.getOnlineUsers();
    if (this.depId != null)
    {
      localObject2 = ((Map)localObject1).keySet().iterator();
      while (((Iterator)localObject2).hasNext())
      {
        localObject3 = (String)((Iterator)localObject2).next();
        localObject4 = new OnlineUser();
        localObject4 = (OnlineUser)((Map)localObject1).get(localObject3);
        String str = "";
        if (!((OnlineUser)localObject4).getUserId().equals(AppUser.SUPER_USER))
          str = ((OnlineUser)localObject4).getDepPath();
        if (!this.depId.equals(new Long(0L)))
        {
          if (Pattern.compile("." + this.depId + ".").matcher(str).find())
            localHashMap1.put(localObject3, localObject4);
        }
        else
          localHashMap1.put(localObject3, localObject4);
      }
    }
    if (this.roleId != null)
    {
      localObject2 = ((Map)localObject1).keySet().iterator();
      while (((Iterator)localObject2).hasNext())
      {
        localObject3 = (String)((Iterator)localObject2).next();
        localObject4 = new OnlineUser();
        localObject4 = (OnlineUser)((Map)localObject1).get(localObject3);
        if (Pattern.compile("," + this.roleId + ",").matcher(((OnlineUser)localObject4).getRoleIds()).find())
          localHashMap2.put(localObject3, localObject4);
      }
    }
    Object localObject2 = new TypeToken()
    {
    }
    .getType();
    Object localObject3 = new StringBuffer("{success:true,'totalCounts':").append(((Map)localObject1).size()).append(",result:");
    Object localObject4 = new Gson();
    if (this.depId != null)
      ((StringBuffer)localObject3).append(((Gson)localObject4).toJson(localHashMap1.values(), (Type)localObject2));
    else if (this.roleId != null)
      ((StringBuffer)localObject3).append(((Gson)localObject4).toJson(localHashMap2.values(), (Type)localObject2));
    else
      ((StringBuffer)localObject3).append(((Gson)localObject4).toJson(((Map)localObject1).values(), (Type)localObject2));
    ((StringBuffer)localObject3).append("}");
    this.jsonString = ((StringBuffer)localObject3).toString();
    return (String)(String)(String)(String)"success";
  }

  public String find()
  {
    String str = getRequest().getParameter("roleId");
    PagingBean localPagingBean = getInitPagingBean();
    if (StringUtils.isNotEmpty(str))
    {
      List localList = this.appUserService.findByRole(Long.valueOf(Long.parseLong(str)), localPagingBean);
      Type localType = new TypeToken()
      {
      }
      .getType();
      StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localPagingBean.getTotalItems()).append(",result:");
      Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
      localStringBuffer.append(localGson.toJson(localList, localType));
      localStringBuffer.append("}");
      this.jsonString = localStringBuffer.toString();
    }
    else
    {
      this.jsonString = "{success:false}";
    }
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    StringBuffer localStringBuffer = new StringBuffer("{success:true");
    if (arrayOfString1 != null)
    {
      localStringBuffer.append(",msg:'");
      for (String str : arrayOfString1)
      {
        AppUser localAppUser = (AppUser)this.appUserService.get(new Long(str));
        AppRole localAppRole = (AppRole)this.appRoleService.get(SUPPER_MANAGER_ID);
        if (localAppUser.getRoles().contains(localAppRole))
        {
          localStringBuffer.append("员工:").append(localAppUser.getUsername()).append("是超级管理员,不能删除!<br><br/>");
        }
        else if (localAppUser.getUserId().equals(ContextUtil.getCurrentUserId()))
        {
          localStringBuffer.append("不能删除自己!<br></br>");
        }
        else
        {
          localAppUser.setStatus(Constants.FLAG_DISABLE);
          localAppUser.setDelFlag(Constants.FLAG_DELETED);
          localAppUser.setUsername("__" + localAppUser.getUsername());
          this.appUserService.save(localAppUser);
        }
      }
      localStringBuffer.append("'");
    }
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String get()
  {
    AppUser localAppUser = null;
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "accessionTime" });
    if (this.userId != null)
    {
      localAppUser = (AppUser)this.appUserService.get(this.userId);
    }
    else
    {
      localJSONSerializer.exclude(new String[] { "accessionTime", "department", "password", "status", "position" });
      localAppUser = ContextUtil.getCurrentUser();
    }
    StringBuffer localStringBuffer = new StringBuffer("{success:true,totalCounts:1,data:[");
    localStringBuffer.append(JsonUtil.getJSONSerializer(new String[] { "accessionTime" }).serialize(localAppUser));
    localStringBuffer.append("]}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  @Action(description="添加或保存用户信息")
  public String save()
  {
    String str = getRequest().getParameter("roleParams");
    Object localObject1;
    Object localObject2;
    if (StringUtils.isNotEmpty(str))
    {
      Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
      localObject1 = (AppRole[])localGson.fromJson(str, [Lcom.htsoft.oa.model.system.AppRole.class);
      if ((localObject1 != null) && (localObject1.length > 0))
      {
        localObject2 = new HashSet();
        for (Object localObject5 : localObject1)
        {
          if (localObject5.getRoleId() == null)
            continue;
          AppRole localAppRole = (AppRole)this.appRoleService.get(localObject5.getRoleId());
          ((Set)localObject2).add(localAppRole);
        }
        this.appUser.setRoles((Set)localObject2);
      }
    }
    int i = 1;
    if (this.appUser.getUserId() != null)
    {
      localObject1 = (AppUser)this.appUserService.get(this.appUser.getUserId());
      this.appUser.setDelFlag(((AppUser)localObject1).getDelFlag());
      this.appUser.setPassword(((AppUser)localObject1).getPassword());
      this.appUser.setDynamicPwd(((AppUser)localObject1).getDynamicPwd());
      this.appUser.setDyPwdStatus(((AppUser)localObject1).getDyPwdStatus());
      this.appUserService.merge(this.appUser);
      setJsonString("{success:true}");
    }
    else if (this.appUserService.findByUserName(this.appUser.getUsername()) == null)
    {
      this.appUser.setDelFlag(Constants.FLAG_UNDELETED);
      this.appUser.setPassword(StringUtil.encryptSha256(this.appUser.getPassword()));
      this.appUserService.save(this.appUser);
      setJsonString("{success:true}");
    }
    else
    {
      i = 0;
      setJsonString("{success:false,msg:'用户登录账号:" + this.appUser.getUsername() + "已存在,请重新输入账号.'}");
    }
    if (i != 0)
    {
      localObject1 = getRequest().getParameter("depParams");
      Object localObject6;
      Object localObject7;
      if (StringUtils.isNotEmpty((String)localObject1))
      {
        localObject2 = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
        ??? = (DepUsers[])((Gson)localObject2).fromJson((String)localObject1, [Lcom.htsoft.oa.model.system.DepUsers.class);
        if ((??? != null) && (???.length > 0))
        {
          ??? = 0;
          for (localObject6 : ???)
            if (localObject6.getDepUserId() != null)
            {
              localObject7 = (DepUsers)this.depUsersService.get(localObject6.getDepUserId());
              Department localDepartment = (Department)this.departmentService.get(localObject6.getDepartment().getDepId());
              try
              {
                BeanUtil.copyNotNullProperties(localObject7, localObject6);
                ((DepUsers)localObject7).setAppUser(this.appUser);
                ((DepUsers)localObject7).setDepartment(localDepartment);
                if (((DepUsers)localObject7).getSn() == null)
                  ((DepUsers)localObject7).setSn(Integer.valueOf(???++));
                this.depUsersService.save(localObject7);
                if (localObject6.getDepid().equals(localDepartment.getDepId()))
                  this.depUsersService.remove(localObject7);
              }
              catch (Exception localException2)
              {
                this.logger.error(localException2.getMessage());
              }
            }
            else
            {
              localObject6.setAppUser(this.appUser);
              if (localObject6.getSn() == null)
                localObject6.setSn(Integer.valueOf(???++));
              this.depUsersService.save(localObject6);
            }
        }
      }
      localObject2 = getRequest().getParameter("jobParams");
      if (StringUtils.isNotEmpty((String)localObject2))
      {
        ??? = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
        UserJob[] arrayOfUserJob = (UserJob[])((Gson)???).fromJson((String)localObject2, [Lcom.htsoft.oa.model.system.UserJob.class);
        if ((arrayOfUserJob != null) && (arrayOfUserJob.length > 0))
          for (localObject6 : arrayOfUserJob)
            if (localObject6.getUserJobId() != null)
            {
              localObject7 = (UserJob)this.userJobService.get(localObject6.getUserJobId());
              try
              {
                BeanUtil.copyNotNullProperties(localObject7, localObject6);
                ((UserJob)localObject7).setAppUser(this.appUser);
                this.userJobService.save(localObject7);
              }
              catch (Exception localException1)
              {
                this.logger.error(localException1.getMessage());
              }
            }
            else
            {
              localObject6.setAppUser(this.appUser);
              this.userJobService.save(localObject6);
            }
      }
    }
    return (String)(String)(String)(String)(String)"success";
  }

  public String selectedRoles()
  {
    if (this.userId != null)
    {
      setAppUser((AppUser)this.appUserService.get(this.userId));
      Set localSet = this.appUser.getRoles();
      StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localSet.size()).append(",result:");
      JSONSerializer localJSONSerializer = new JSONSerializer();
      localStringBuffer.append(localJSONSerializer.serialize(localSet));
      localStringBuffer.append("}");
      this.jsonString = localStringBuffer.toString();
    }
    return "success";
  }

  public String chooseRoles()
  {
    List localList = this.appRoleService.getAll();
    AppRole localAppRole;
    if (this.userId != null)
    {
      setAppUser((AppUser)this.appUserService.get(this.userId));
      localObject = this.appUser.getRoles();
      localIterator = ((Set)localObject).iterator();
      while (localIterator.hasNext())
      {
        localAppRole = (AppRole)localIterator.next();
        localList.remove(localAppRole);
      }
    }
    Object localObject = new StringBuffer("[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      localAppRole = (AppRole)localIterator.next();
      if (localAppRole.getStatus().shortValue() != 0)
        ((StringBuffer)localObject).append("{id : '" + localAppRole.getRoleId() + "',text : '" + localAppRole.getRoleName() + "',leaf:true},");
    }
    ((StringBuffer)localObject).deleteCharAt(((StringBuffer)localObject).length() - 1);
    ((StringBuffer)localObject).append("]");
    setJsonString(((StringBuffer)localObject).toString());
    return (String)"success";
  }

  public String multiDelRole()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (this.userId != null)
    {
      setAppUser((AppUser)this.appUserService.get(this.userId));
      Set localSet = this.appUser.getRoles();
      if (arrayOfString1 != null)
        for (String str : arrayOfString1)
        {
          AppRole localAppRole = (AppRole)this.appRoleService.get(new Long(str));
          localSet.remove(localAppRole);
        }
      this.appUser.setRoles(localSet);
      this.appUserService.save(this.appUser);
    }
    this.jsonString = "{success:true}";
    return "success";
  }

  @Action(description="修改密码")
  public String resetPassword()
  {
    String str1 = getRequest().getParameter("appUserUserId");
    String str2 = StringUtil.encryptSha256(getRequest().getParameter("oldPassword"));
    String str3 = getRequest().getParameter("newPassword");
    String str4 = getRequest().getParameter("againPassword");
    if (StringUtils.isNotEmpty(str1))
      setAppUser((AppUser)this.appUserService.get(new Long(str1)));
    else
      setAppUser(ContextUtil.getCurrentUser());
    StringBuffer localStringBuffer = new StringBuffer("{msg:'");
    int i = 0;
    if (str2.equals(this.appUser.getPassword()))
    {
      if (str3.equals(str4))
        i = 1;
      else
        localStringBuffer.append("两次输入不一致.'");
    }
    else
      localStringBuffer.append("旧密码输入不正确.'");
    if (i != 0)
    {
      this.appUser.setPassword(StringUtil.encryptSha256(str3));
      this.appUserService.save(this.appUser);
      setJsonString("{success:true}");
    }
    else
    {
      localStringBuffer.append(",failure:true}");
      setJsonString(localStringBuffer.toString());
    }
    return "success";
  }

  @Action(description="重置密码")
  public String createPassword()
  {
    String str1 = getRequest().getParameter("appUserUserId");
    String str2 = getRequest().getParameter("newpassword");
    String str3 = getRequest().getParameter("password");
    StringBuffer localStringBuffer = new StringBuffer("{msg:'");
    if (StringUtils.isNotEmpty(str1))
      setAppUser((AppUser)this.appUserService.get(new Long(str1)));
    else
      setAppUser(ContextUtil.getCurrentUser());
    if (str2.equals(str3))
    {
      this.appUser.setPassword(StringUtil.encryptSha256(str2));
      this.appUserService.save(this.appUser);
      setJsonString("{success:true}");
    }
    else
    {
      localStringBuffer.append("重置失败!,两次输入的密码不一致,请重新输入!.'");
      localStringBuffer.append(",failure:true}");
      setJsonString(localStringBuffer.toString());
    }
    return "success";
  }

  public String photo()
  {
    setAppUser((AppUser)this.appUserService.get(getUserId()));
    this.appUser.setPhoto("");
    this.appUserService.save(this.appUser);
    return "success";
  }

  public String subAdepartment()
  {
    PagingBean localPagingBean = getInitPagingBean();
    String str1 = getRequest().getParameter("depId");
    String str2 = "0.";
    AppUser localAppUser = ContextUtil.getCurrentUser();
    if (StringUtils.isNotEmpty(str1))
    {
      localObject1 = Long.valueOf(Long.parseLong(str1));
      localObject2 = (Department)this.departmentService.get((Serializable)localObject1);
      if (localObject2 != null)
        str2 = ((Department)localObject2).getPath();
    }
    else
    {
      localObject1 = localAppUser.getDepartment();
      if (localObject1 != null)
        str2 = ((Department)localObject1).getPath();
    }
    if ("0.".equals(str2))
      str2 = null;
    Object localObject1 = localAppUser.getUserId();
    Object localObject2 = this.userSubService.findAllUpUser((Long)localObject1);
    List localList = this.userSubService.subUsers((Long)localObject1);
    ((Set)localObject2).add(localObject1);
    Object localObject3 = localList.iterator();
    while (((Iterator)localObject3).hasNext())
    {
      localObject4 = (Long)((Iterator)localObject3).next();
      ((Set)localObject2).add(localObject4);
    }
    localObject3 = this.appUserService.findSubAppUser(str2, (Set)localObject2, localPagingBean);
    Object localObject4 = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localPagingBean.getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    localStringBuffer.append(localGson.toJson(localObject3, (Type)localObject4));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return (String)(String)(String)(String)"success";
  }

  public String subArole()
  {
    String str = getRequest().getParameter("roleId");
    PagingBean localPagingBean = getInitPagingBean();
    AppUser localAppUser = ContextUtil.getCurrentUser();
    if (StringUtils.isNotEmpty(str))
    {
      Long localLong = localAppUser.getUserId();
      Set localSet = this.userSubService.findAllUpUser(localLong);
      List localList = this.userSubService.subUsers(localLong);
      localSet.add(localLong);
      Object localObject1 = localList.iterator();
      while (((Iterator)localObject1).hasNext())
      {
        localObject2 = (Long)((Iterator)localObject1).next();
        localSet.add(localObject2);
      }
      localObject1 = this.appUserService.findSubAppUserByRole(new Long(str), localSet, localPagingBean);
      Object localObject2 = new TypeToken()
      {
      }
      .getType();
      StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localPagingBean.getTotalItems()).append(",result:");
      Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
      localStringBuffer.append(localGson.toJson(localObject1, (Type)localObject2));
      localStringBuffer.append("}");
      this.jsonString = localStringBuffer.toString();
    }
    else
    {
      this.jsonString = "{success:false}";
    }
    return (String)(String)"success";
  }

  public String onlineAsub()
  {
    Object localObject1 = new HashMap();
    HashMap localHashMap = new HashMap();
    localObject1 = AppUtil.getOnlineUsers();
    AppUser localAppUser = ContextUtil.getCurrentUser();
    Long localLong = localAppUser.getUserId();
    Set localSet = this.userSubService.findAllUpUser(localLong);
    localSet.add(localLong);
    List localList = this.userSubService.subUsers(localLong);
    Object localObject2 = localList.iterator();
    while (((Iterator)localObject2).hasNext())
    {
      localObject3 = (Long)((Iterator)localObject2).next();
      localSet.add(localObject3);
    }
    localObject2 = ((Map)localObject1).keySet().iterator();
    while (((Iterator)localObject2).hasNext())
    {
      localObject3 = (String)((Iterator)localObject2).next();
      localObject4 = new OnlineUser();
      localObject4 = (OnlineUser)((Map)localObject1).get(localObject3);
      if (!localSet.contains(((OnlineUser)localObject4).getUserId()))
        localHashMap.put(localObject3, localObject4);
    }
    localObject2 = new TypeToken()
    {
    }
    .getType();
    Object localObject3 = new StringBuffer("{success:true,'totalCounts':").append(((Map)localObject1).size()).append(",result:");
    Object localObject4 = new Gson();
    ((StringBuffer)localObject3).append(((Gson)localObject4).toJson(localHashMap.values(), (Type)localObject2));
    ((StringBuffer)localObject3).append("}");
    this.jsonString = ((StringBuffer)localObject3).toString();
    return (String)(String)(String)(String)"success";
  }

  public String upUser()
  {
    Set localSet = this.relativeUserService.getUpUser(ContextUtil.getCurrentUserId());
    StringBuffer localStringBuffer = new StringBuffer("[");
    Iterator localIterator = localSet.iterator();
    while (localIterator.hasNext())
    {
      AppUser localAppUser = (AppUser)localIterator.next();
      localStringBuffer.append("['" + localAppUser.getUserId().toString() + "','" + localAppUser.getFullname() + "'],");
    }
    if (localSet.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  @Action(description="修改个人资料")
  public String profile()
  {
    AppUser localAppUser = ContextUtil.getCurrentUser();
    try
    {
      BeanUtil.copyNotNullProperties(localAppUser, this.appUser);
    }
    catch (Exception localException)
    {
      this.logger.info(localException);
    }
    this.appUserService.save(localAppUser);
    this.jsonString = "{success:true}";
    return "success";
  }

  public String bindDyPwd()
  {
    StringBuffer localStringBuffer = new StringBuffer("{success:true,msg:'");
    String str1 = getRequest().getParameter("curDynamicPwd");
    HashMap localHashMap = new HashMap();
    localHashMap.put("app", "demoauthapp");
    localHashMap.put("user", this.appUser.getDynamicPwd());
    localHashMap.put("pw", str1);
    String str2 = this.appUserService.initDynamicPwd(localHashMap, "bind");
    if (str2.equals("ok"))
    {
      AppUser localAppUser = (AppUser)this.appUserService.get(this.appUser.getUserId());
      localAppUser.setDynamicPwd(this.appUser.getDynamicPwd());
      localAppUser.setDyPwdStatus(AppUser.DYNPWD_STATUS_BIND);
      this.appUserService.save(localAppUser);
      localStringBuffer.append("成功绑定!");
    }
    else
    {
      localStringBuffer.append(str2);
    }
    localStringBuffer.append("'}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String unbindDyPwd()
  {
    StringBuffer localStringBuffer = new StringBuffer("{success:true,msg:'");
    String str1 = getRequest().getParameter("curDynamicPwd");
    HashMap localHashMap = new HashMap();
    localHashMap.put("app", "demoauthapp");
    localHashMap.put("user", this.appUser.getDynamicPwd());
    localHashMap.put("pw", str1);
    String str2 = this.appUserService.initDynamicPwd(localHashMap, "unbind");
    if (str2.equals("ok"))
    {
      AppUser localAppUser = (AppUser)this.appUserService.get(this.appUser.getUserId());
      localAppUser.setDyPwdStatus(AppUser.DYNPWD_STATUS_UNBIND);
      this.appUserService.save(localAppUser);
      localStringBuffer.append("解绑成功!");
    }
    else
    {
      localStringBuffer.append(str2);
    }
    localStringBuffer.append("'}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.AppUserAction
 * JD-Core Version:    0.6.0
 */