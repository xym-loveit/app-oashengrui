package com.htsoft.oa.action.arch;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.arch.BorrowFileList;
import com.htsoft.oa.service.arch.BorrowFileListService;
import flexjson.JSONSerializer;
import flexjson.transformer.DateTransformer;
import java.lang.reflect.Type;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class BorrowFileListAction extends BaseAction
{

  @Resource
  private BorrowFileListService borrowFileListService;
  private BorrowFileList borrowFileList;
  private Long listId;

  public Long getListId()
  {
    return this.listId;
  }

  public void setListId(Long paramLong)
  {
    this.listId = paramLong;
  }

  public BorrowFileList getBorrowFileList()
  {
    return this.borrowFileList;
  }

  public void setBorrowFileList(BorrowFileList paramBorrowFileList)
  {
    this.borrowFileList = paramBorrowFileList;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.borrowFileListService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localList.size()).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localJSONSerializer.exclude(new String[] { "*.class" }).transform(new DateTransformer("yyyy-MM-dd"), new String[] { "createtime", "archFond.createTime", "archFond.updateTime", "archRoll.archFond.createTime", "archRoll.archFond.updateTime", "rollFile.archRoll.archFond.createTime", "rollFile.archRoll.archFond.updateTime", "archRoll.startTime", "archRoll.endTime", "archRoll.setupTime", "archRoll.createTime", "rollFile.archRoll.startTime", "rollFile.archRoll.endTime", "rollFile.archRoll.setupTime", "rollFile.archRoll.createTime", "rollFile.createTime", "rollFile.fileTime", "borrowRecord.borrowDate", "borrowRecord.checkDate", "borrowRecord.returnDate", "borrowRecord.appUser.accessionTime" });
    localStringBuffer.append(localJSONSerializer.serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String listCheck()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.borrowFileListService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localJSONSerializer.exclude(new String[] { "*.class" }).transform(new DateTransformer("yyyy-MM-dd"), new String[] { "createtime", "archFond.createTime", "archFond.updateTime", "archRoll.archFond.createTime", "archRoll.archFond.updateTime", "rollFile.archRoll.archFond.createTime", "rollFile.archRoll.archFond.updateTime", "archRoll.startTime", "archRoll.endTime", "archRoll.setupTime", "archRoll.createTime", "rollFile.archRoll.startTime", "rollFile.archRoll.endTime", "rollFile.archRoll.setupTime", "rollFile.archRoll.createTime", "rollFile.createTime", "rollFile.fileTime", "borrowRecord.borrowDate", "borrowRecord.checkDate", "borrowRecord.returnDate", "borrowRecord.appUser.accessionTime" });
    localStringBuffer.append(localJSONSerializer.serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.borrowFileListService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    BorrowFileList localBorrowFileList = (BorrowFileList)this.borrowFileListService.get(this.listId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localBorrowFileList));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.borrowFileListService.save(this.borrowFileList);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.arch.BorrowFileListAction
 * JD-Core Version:    0.6.0
 */