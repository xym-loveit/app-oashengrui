package com.htsoft.oa.action.document;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.document.PaintTemplate;
import com.htsoft.oa.service.document.PaintTemplateService;
import flexjson.JSONSerializer;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;

public class PaintTemplateAction extends BaseAction
{

  @Resource
  private PaintTemplateService paintTemplateService;
  private PaintTemplate paintTemplate;
  private Long ptemplateId;

  public Long getPtemplateId()
  {
    return this.ptemplateId;
  }

  public void setPtemplateId(Long paramLong)
  {
    this.ptemplateId = paramLong;
  }

  public PaintTemplate getPaintTemplate()
  {
    return this.paintTemplate;
  }

  public void setPaintTemplate(PaintTemplate paramPaintTemplate)
  {
    this.paintTemplate = paramPaintTemplate;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.paintTemplateService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer();
    localJSONSerializer.exclude(new String[] { "class" });
    localStringBuffer.append(localJSONSerializer.serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.paintTemplateService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String getByKey()
  {
    String str = getRequest().getParameter("templateKey");
    List localList = this.paintTemplateService.getByKey(str);
    if (localList.size() > 0)
    {
      StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
      JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer();
      localJSONSerializer.exclude(new String[] { "class" });
      localStringBuffer.append(localJSONSerializer.serialize(localList.get(0)));
      localStringBuffer.append("}");
      setJsonString(localStringBuffer.toString());
    }
    return "success";
  }

  public String get()
  {
    PaintTemplate localPaintTemplate = (PaintTemplate)this.paintTemplateService.get(this.ptemplateId);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer();
    localJSONSerializer.exclude(new String[] { "class" });
    localStringBuffer.append(localJSONSerializer.serialize(localPaintTemplate));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    if (this.paintTemplate.getPtemplateId() == null)
    {
      boolean bool = this.paintTemplateService.isKeyExist(this.paintTemplate.getTemplateKey());
      if (bool)
      {
        setJsonString("{success:false,msg:'该Key已经存在！'}");
        return "success";
      }
      this.paintTemplateService.save(this.paintTemplate);
    }
    else
    {
      List localList = this.paintTemplateService.getByKeyExceptId(this.paintTemplate.getTemplateKey(), this.paintTemplate.getPtemplateId());
      if (localList.size() > 0)
      {
        setJsonString("{success:false,msg:'该Key已经存在！'}");
        return "success";
      }
      PaintTemplate localPaintTemplate = (PaintTemplate)this.paintTemplateService.get(this.paintTemplate.getPtemplateId());
      try
      {
        BeanUtil.copyNotNullProperties(localPaintTemplate, this.paintTemplate);
        this.paintTemplateService.save(localPaintTemplate);
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.document.PaintTemplateAction
 * JD-Core Version:    0.6.0
 */