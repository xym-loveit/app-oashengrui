package com.htsoft.oa.action.arch;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.arch.BorrowFileList;
import com.htsoft.oa.model.arch.BorrowRecord;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.arch.BorrowFileListService;
import com.htsoft.oa.service.arch.BorrowRecordService;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;

public class BorrowRecordAction extends BaseAction
{

  @Resource
  private BorrowRecordService borrowRecordService;
  private BorrowRecord borrowRecord;

  @Resource
  private BorrowFileListService borrowFileListService;
  private Long recordId;

  public Long getRecordId()
  {
    return this.recordId;
  }

  public void setRecordId(Long paramLong)
  {
    this.recordId = paramLong;
  }

  public BorrowRecord getBorrowRecord()
  {
    return this.borrowRecord;
  }

  public void setBorrowRecord(BorrowRecord paramBorrowRecord)
  {
    this.borrowRecord = paramBorrowRecord;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.borrowRecordService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setDateFormat("yyyy-MM-dd").create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.borrowRecordService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    BorrowRecord localBorrowRecord = (BorrowRecord)this.borrowRecordService.get(this.recordId);
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setDateFormat("yyyy-MM-dd").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localBorrowRecord));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    this.logger.debug("sb:" + localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    if (this.borrowRecord.getRecordId() == null)
    {
      this.borrowRecordService.save(this.borrowRecord);
    }
    else
    {
      localObject = (BorrowRecord)this.borrowRecordService.get(this.borrowRecord.getRecordId());
      try
      {
        Set localSet = ((BorrowRecord)localObject).getBorrowFileLists();
        BeanUtil.copyNotNullProperties(localObject, this.borrowRecord);
        ((BorrowRecord)localObject).setBorrowFileLists(localSet);
        this.borrowRecordService.save(localObject);
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    Object localObject = getRequest().getParameter("params");
    if (StringUtils.isNotEmpty((String)localObject))
    {
      Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
      BorrowFileList[] arrayOfBorrowFileList1 = (BorrowFileList[])localGson.fromJson((String)localObject, [Lcom.htsoft.oa.model.arch.BorrowFileList.class);
      if ((arrayOfBorrowFileList1 != null) && (arrayOfBorrowFileList1.length > 0))
        for (BorrowFileList localBorrowFileList : arrayOfBorrowFileList1)
        {
          localBorrowFileList.setRecordId(this.borrowRecord.getRecordId());
          this.borrowFileListService.save(localBorrowFileList);
        }
    }
    setJsonString("{success:true,recordId:" + this.borrowRecord.getRecordId() + "}");
    return (String)"success";
  }

  public String check()
  {
    BorrowRecord localBorrowRecord = (BorrowRecord)this.borrowRecordService.get(this.borrowRecord.getRecordId());
    localBorrowRecord.setReturnStatus(this.borrowRecord.getReturnStatus());
    localBorrowRecord.setCheckId(ContextUtil.getCurrentUserId());
    localBorrowRecord.setCheckName(ContextUtil.getCurrentUser().getUsername());
    this.borrowRecordService.save(localBorrowRecord);
    setJsonString("{success:true,recordId:" + localBorrowRecord.getRecordId() + "}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.arch.BorrowRecordAction
 * JD-Core Version:    0.6.0
 */