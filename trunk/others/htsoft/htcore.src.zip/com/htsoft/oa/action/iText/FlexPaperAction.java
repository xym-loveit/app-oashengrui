package com.htsoft.oa.action.iText;

import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.document.Document;
import com.htsoft.oa.service.document.DocumentService;
import java.text.SimpleDateFormat;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class FlexPaperAction extends BaseAction
{
  SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
  private Long docId;

  @Resource
  private DocumentService documentService;

  public void setDocId(Long paramLong)
  {
    this.docId = paramLong;
  }

  public Long getDocId()
  {
    return this.docId;
  }

  public String execute()
  {
    Document localDocument = (Document)this.documentService.get(this.docId);
    HttpServletRequest localHttpServletRequest = getRequest();
    localHttpServletRequest.setAttribute("createtime", this.sdf.format(localDocument.getCreatetime()));
    localHttpServletRequest.setAttribute("updatetime", this.sdf.format(localDocument.getUpdatetime()));
    localHttpServletRequest.setAttribute("docName", localDocument.getDocName());
    localHttpServletRequest.setAttribute("document", localDocument);
    localHttpServletRequest.setAttribute("swfPath", localHttpServletRequest.getContextPath() + "/" + localDocument.getSwfPath());
    localHttpServletRequest.setAttribute("attachFileList", localDocument.getAttachFiles().toArray());
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.iText.FlexPaperAction
 * JD-Core Version:    0.6.0
 */