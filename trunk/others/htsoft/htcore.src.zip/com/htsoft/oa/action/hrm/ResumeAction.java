package com.htsoft.oa.action.hrm;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.hrm.Resume;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.FileAttach;
import com.htsoft.oa.service.hrm.ResumeService;
import com.htsoft.oa.service.system.FileAttachService;
import java.lang.reflect.Type;
import java.util.Date;
import java.util.List;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class ResumeAction extends BaseAction
{

  @Resource
  private ResumeService resumeService;
  private Resume resume;

  @Resource
  private FileAttachService fileAttachService;
  private Long resumeId;

  public Long getResumeId()
  {
    return this.resumeId;
  }

  public void setResumeId(Long paramLong)
  {
    this.resumeId = paramLong;
  }

  public Resume getResume()
  {
    return this.resume;
  }

  public void setResume(Resume paramResume)
  {
    this.resume = paramResume;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.resumeService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.resumeService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    Resume localResume = (Resume)this.resumeService.get(this.resumeId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:[");
    localStringBuffer.append(localGson.toJson(localResume));
    localStringBuffer.append("]}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    String str = getRequest().getParameter("fileIds");
    Object localObject;
    if (this.resume.getResumeId() == null)
    {
      localObject = ContextUtil.getCurrentUser();
      this.resume.setRegistor(((AppUser)localObject).getFullname());
      this.resume.setRegTime(new Date());
    }
    if (StringUtils.isNotEmpty(str))
    {
      this.resume.getResumeFiles().clear();
      localObject = str.split(",");
      for (int i = 0; i < localObject.length; i++)
      {
        FileAttach localFileAttach = (FileAttach)this.fileAttachService.get(new Long(localObject[i]));
        this.resume.getResumeFiles().add(localFileAttach);
      }
    }
    this.resumeService.save(this.resume);
    setJsonString("{success:true}");
    return (String)"success";
  }

  public String delphoto()
  {
    String str = getRequest().getParameter("resumeId");
    if (StringUtils.isNotEmpty(str))
    {
      this.resume = ((Resume)this.resumeService.get(new Long(str)));
      this.resume.setPhoto("");
      this.resumeService.save(this.resume);
      setJsonString("{success:true}");
    }
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.hrm.ResumeAction
 * JD-Core Version:    0.6.0
 */