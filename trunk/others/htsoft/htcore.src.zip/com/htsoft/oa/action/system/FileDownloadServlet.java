package com.htsoft.oa.action.system;

import com.htsoft.core.util.AppUtil;
import com.htsoft.oa.model.system.FileAttach;
import com.htsoft.oa.service.system.FileAttachService;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang.StringUtils;

public class FileDownloadServlet extends HttpServlet
{
  private FileAttachService fileAttachService = (FileAttachService)AppUtil.getBean("fileAttachService");

  protected void doGet(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
    throws ServletException, IOException
  {
    String str1 = paramHttpServletRequest.getParameter("fileId");
    paramHttpServletRequest.setCharacterEncoding("UTF-8");
    paramHttpServletResponse.setCharacterEncoding("UTF-8");
    if (StringUtils.isNotEmpty(str1))
    {
      FileAttach localFileAttach = (FileAttach)this.fileAttachService.get(new Long(str1));
      String str2 = localFileAttach.getExt();
      if (str2.toLowerCase().endsWith("zip"))
        paramHttpServletResponse.setContentType("application/x-zip-compressed");
      else if (str2.toLowerCase().endsWith("rar"))
        paramHttpServletResponse.setContentType("application/octet-stream");
      else if (str2.toLowerCase().endsWith("doc"))
        paramHttpServletResponse.setContentType("application/msword");
      else if ((str2.toLowerCase().endsWith("xls")) || (str2.toLowerCase().endsWith("csv")))
        paramHttpServletResponse.setContentType("application/ms-excel ");
      else if (str2.toLowerCase().endsWith("pdf"))
        paramHttpServletResponse.setContentType("application/pdf");
      else
        paramHttpServletResponse.setContentType("application/x-msdownload");
      ServletOutputStream localServletOutputStream = null;
      try
      {
        FileInputStream localFileInputStream = new FileInputStream(getServletContext().getRealPath("/") + "/attachFiles/" + localFileAttach.getFilePath());
        paramHttpServletResponse.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(localFileAttach.getFileName(), "UTF-8"));
        localServletOutputStream = paramHttpServletResponse.getOutputStream();
        byte[] arrayOfByte = new byte[1024];
        for (int i = localFileInputStream.read(arrayOfByte); i > 0; i = localFileInputStream.read(arrayOfByte))
          localServletOutputStream.write(arrayOfByte, 0, i);
      }
      catch (Exception localIOException4)
      {
        localException.printStackTrace();
      }
      finally
      {
        if (localServletOutputStream != null)
        {
          try
          {
            localServletOutputStream.flush();
          }
          catch (IOException localIOException5)
          {
            localIOException5.printStackTrace();
          }
          try
          {
            localServletOutputStream.close();
          }
          catch (IOException localIOException6)
          {
            localIOException6.printStackTrace();
          }
        }
      }
    }
  }

  protected void doPost(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
    throws ServletException, IOException
  {
    doGet(paramHttpServletRequest, paramHttpServletResponse);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.FileDownloadServlet
 * JD-Core Version:    0.6.0
 */