package com.htsoft.oa.action.customer;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.customer.Contract;
import com.htsoft.oa.model.customer.ContractConfig;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.FileAttach;
import com.htsoft.oa.service.customer.ContractConfigService;
import com.htsoft.oa.service.customer.ContractService;
import com.htsoft.oa.service.system.FileAttachService;
import flexjson.JSONSerializer;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class ContractAction extends BaseAction
{

  @Resource
  private ContractService contractService;

  @Resource
  private ContractConfigService contractConfigService;

  @Resource
  private FileAttachService fileAttachService;
  private Contract contract;
  private Long contractId;
  private String contractAttachIDs;
  private String data;

  public Long getContractId()
  {
    return this.contractId;
  }

  public void setContractId(Long paramLong)
  {
    this.contractId = paramLong;
  }

  public Contract getContract()
  {
    return this.contract;
  }

  public void setContract(Contract paramContract)
  {
    this.contract = paramContract;
  }

  public String getData()
  {
    return this.data;
  }

  public void setData(String paramString)
  {
    this.data = paramString;
  }

  public String getContractAttachIDs()
  {
    return this.contractAttachIDs;
  }

  public void setContractAttachIDs(String paramString)
  {
    this.contractAttachIDs = paramString;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.contractService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "signupTime" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class", "contractConfigs" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.contractService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    Contract localContract = (Contract)this.contractService.get(this.contractId);
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localContract));
    localStringBuffer.append(",projectId:" + localContract.getProjectId());
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    int i = 0;
    StringBuffer localStringBuffer = new StringBuffer("{");
    if (this.contract.getValidDate().getTime() <= this.contract.getExpireDate().getTime())
      i = 1;
    else
      localStringBuffer.append("msg:'合同失效日期不能早于生效日期,请重新填写!',");
    if (i != 0)
    {
      this.contract.setCreator(ContextUtil.getCurrentUser().getFullname());
      this.contract.setCreatetime(new Date());
      String[] arrayOfString = getContractAttachIDs().split(",");
      HashSet localHashSet = new HashSet();
      for (String str : arrayOfString)
      {
        if (str.equals(""))
          continue;
        localHashSet.add(this.fileAttachService.get(new Long(str)));
      }
      this.contract.setContractFiles(localHashSet);
      this.contractService.save(this.contract);
      if (StringUtils.isNotEmpty(this.data))
      {
        ??? = new Gson();
        ContractConfig[] arrayOfContractConfig1 = (ContractConfig[])((Gson)???).fromJson(this.data, [Lcom.htsoft.oa.model.customer.ContractConfig.class);
        for (ContractConfig localContractConfig : arrayOfContractConfig1)
        {
          if (localContractConfig.getConfigId().longValue() == -1L)
          {
            localContractConfig.setConfigId(null);
            localContractConfig.setContractId(this.contract.getContractId());
          }
          this.contractConfigService.save(localContractConfig);
        }
      }
      localStringBuffer.append("success:true}");
    }
    else
    {
      localStringBuffer.append("failure:true}");
    }
    setJsonString(localStringBuffer.toString());
    return (String)"success";
  }

  public String removeFile()
  {
    setContract((Contract)this.contractService.get(this.contractId));
    Set localSet = this.contract.getContractFiles();
    FileAttach localFileAttach = (FileAttach)this.fileAttachService.get(new Long(this.contractAttachIDs));
    localSet.remove(localFileAttach);
    this.contract.setContractFiles(localSet);
    this.contractService.save(this.contract);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.customer.ContractAction
 * JD-Core Version:    0.6.0
 */