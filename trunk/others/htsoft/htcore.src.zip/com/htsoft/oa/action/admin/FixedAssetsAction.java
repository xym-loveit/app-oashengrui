package com.htsoft.oa.action.admin;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.admin.DepreType;
import com.htsoft.oa.model.admin.FixedAssets;
import com.htsoft.oa.service.admin.DepreRecordService;
import com.htsoft.oa.service.admin.DepreTypeService;
import com.htsoft.oa.service.admin.FixedAssetsService;
import flexjson.JSONSerializer;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class FixedAssetsAction extends BaseAction
{

  @Resource
  private FixedAssetsService fixedAssetsService;
  private FixedAssets fixedAssets;

  @Resource
  private DepreRecordService depreRecordService;

  @Resource
  private DepreTypeService depreTypeService;
  private Long assetsId;

  public Long getAssetsId()
  {
    return this.assetsId;
  }

  public void setAssetsId(Long paramLong)
  {
    this.assetsId = paramLong;
  }

  public FixedAssets getFixedAssets()
  {
    return this.fixedAssets;
  }

  public void setFixedAssets(FixedAssets paramFixedAssets)
  {
    this.fixedAssets = paramFixedAssets;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.fixedAssetsService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "buyDate", "startDepre", "manuDate" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.fixedAssetsService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    FixedAssets localFixedAssets = (FixedAssets)this.fixedAssetsService.get(this.assetsId);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "manuDate", "buyDate", "startDepre" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localFixedAssets));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss-SSSS");
    if (this.fixedAssets.getAssetsId() == null)
      this.fixedAssets.setAssetsNo(localSimpleDateFormat.format(new Date()));
    Long localLong = this.fixedAssets.getDepreType().getDepreTypeId();
    if (localLong != null)
    {
      DepreType localDepreType = (DepreType)this.depreTypeService.get(localLong);
      if (localDepreType.getCalMethod().shortValue() != 2)
      {
        BigDecimal localBigDecimal1 = this.fixedAssets.getRemainValRate();
        BigDecimal localBigDecimal2 = new BigDecimal("1").subtract(localBigDecimal1.divide(new BigDecimal("100"))).divide(this.fixedAssets.getIntendTerm(), 2, 2);
        this.fixedAssets.setDepreRate(localBigDecimal2);
      }
    }
    this.fixedAssetsService.save(this.fixedAssets);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.admin.FixedAssetsAction
 * JD-Core Version:    0.6.0
 */