package com.htsoft.oa.action.system;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.system.Dictionary;
import com.htsoft.oa.model.system.GlobalType;
import com.htsoft.oa.service.system.DictionaryService;
import com.htsoft.oa.service.system.GlobalTypeService;
import flexjson.JSONSerializer;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;

public class DictionaryAction extends BaseAction
{

  @Resource
  private DictionaryService dictionaryService;

  @Resource
  private GlobalTypeService globalTypeService;
  private Dictionary dictionary;
  private Long dicId;
  private String itemName;

  public String getItemName()
  {
    return this.itemName;
  }

  public void setItemName(String paramString)
  {
    this.itemName = paramString;
  }

  public Long getDicId()
  {
    return this.dicId;
  }

  public void setDicId(Long paramLong)
  {
    this.dicId = paramLong;
  }

  public Dictionary getDictionary()
  {
    return this.dictionary;
  }

  public void setDictionary(Dictionary paramDictionary)
  {
    this.dictionary = paramDictionary;
  }

  public String mulSave()
  {
    String str = getRequest().getParameter("data");
    if (StringUtils.isNotEmpty(str))
    {
      Gson localGson = new Gson();
      Dictionary[] arrayOfDictionary = (Dictionary[])localGson.fromJson(str, [Lcom.htsoft.oa.model.system.Dictionary.class);
      for (int i = 0; i < arrayOfDictionary.length; i++)
      {
        Dictionary localDictionary = (Dictionary)this.dictionaryService.get(arrayOfDictionary[i].getDicId());
        try
        {
          BeanUtil.copyNotNullProperties(localDictionary, arrayOfDictionary[i]);
          this.dictionaryService.save(localDictionary);
        }
        catch (Exception localException)
        {
          this.logger.error(localException.getMessage());
        }
      }
    }
    this.jsonString = "{success:true}";
    return "success";
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    String str = getRequest().getParameter("parentId");
    if ((StringUtils.isNotEmpty(str)) && (!"0".equals(str)))
    {
      localObject = (GlobalType)this.globalTypeService.get(new Long(str));
      localQueryFilter.addFilter("Q_globalType.path_S_LFK", ((GlobalType)localObject).getPath());
    }
    Object localObject = this.dictionaryService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localStringBuffer.append(localJSONSerializer.serialize(localObject));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return (String)"success";
  }

  public String load()
  {
    List localList = this.dictionaryService.getAllByItemName(this.itemName);
    StringBuffer localStringBuffer = new StringBuffer("[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      localStringBuffer.append("'").append(str).append("',");
    }
    if (localList.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String loadItem()
  {
    List localList = this.dictionaryService.getByItemName(this.itemName);
    StringBuffer localStringBuffer = new StringBuffer("[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Dictionary localDictionary = (Dictionary)localIterator.next();
      localStringBuffer.append("[").append(localDictionary.getDicId()).append(",'").append(localDictionary.getItemValue()).append("'],");
    }
    if (localList.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String loadItemRecord()
  {
    List localList = this.dictionaryService.getByItemName(this.itemName);
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localList));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String typeChange()
  {
    String str1 = getRequest().getParameter("dicIds");
    String str2 = getRequest().getParameter("dicTypeId");
    if ((StringUtils.isNotEmpty(str1)) && (StringUtils.isNotEmpty(str2)))
    {
      GlobalType localGlobalType = (GlobalType)this.globalTypeService.get(new Long(str2));
      String[] arrayOfString1 = str1.split("[,]");
      if (arrayOfString1 != null)
        for (String str3 : arrayOfString1)
        {
          Dictionary localDictionary = (Dictionary)this.dictionaryService.get(new Long(str3));
          localDictionary.setGlobalType(localGlobalType);
          localDictionary.setItemName(localGlobalType.getTypeName());
          this.dictionaryService.save(localDictionary);
        }
    }
    setJsonString("{success:true}");
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.dictionaryService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    Dictionary localDictionary = (Dictionary)this.dictionaryService.get(this.dicId);
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localDictionary));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    Object localObject;
    if (this.dictionary.getDicId() != null)
    {
      localObject = (Dictionary)this.dictionaryService.get(this.dictionary.getDicId());
      try
      {
        BeanUtil.copyNotNullProperties(localObject, this.dictionary);
        this.dictionaryService.save(localObject);
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    else
    {
      localObject = getRequest().getParameter("parentId");
      if (StringUtils.isNotEmpty((String)localObject))
      {
        GlobalType localGlobalType = (GlobalType)this.globalTypeService.get(new Long((String)localObject));
        this.dictionary.setGlobalType(localGlobalType);
      }
      this.dictionaryService.save(this.dictionary);
    }
    setJsonString("{success:true}");
    return (String)"success";
  }

  public String items()
  {
    List localList = this.dictionaryService.getAllItems();
    StringBuffer localStringBuffer = new StringBuffer("[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      localStringBuffer.append("'").append(str).append("',");
    }
    if (localList.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.DictionaryAction
 * JD-Core Version:    0.6.0
 */