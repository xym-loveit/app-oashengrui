package com.htsoft.oa.action.hrm;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.hrm.SalaryPayoff;
import com.htsoft.oa.model.hrm.StandSalaryItem;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.hrm.SalaryPayoffService;
import com.htsoft.oa.service.hrm.StandSalaryItemService;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class SalaryPayoffAction extends BaseAction
{

  @Resource
  private SalaryPayoffService salaryPayoffService;

  @Resource
  private StandSalaryItemService standSalaryItemService;
  private SalaryPayoff salaryPayoff;
  private Long recordId;

  public Long getRecordId()
  {
    return this.recordId;
  }

  public void setRecordId(Long paramLong)
  {
    this.recordId = paramLong;
  }

  public SalaryPayoff getSalaryPayoff()
  {
    return this.salaryPayoff;
  }

  public void setSalaryPayoff(SalaryPayoff paramSalaryPayoff)
  {
    this.salaryPayoff = paramSalaryPayoff;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.salaryPayoffService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.salaryPayoffService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    SalaryPayoff localSalaryPayoff = (SalaryPayoff)this.salaryPayoffService.get(this.recordId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:[");
    localStringBuffer.append(localGson.toJson(localSalaryPayoff));
    localStringBuffer.append("]}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    if (this.salaryPayoff.getRecordId() == null)
    {
      this.salaryPayoff.setCheckStatus(Short.valueOf(SalaryPayoff.CHECK_FLAG_NONE));
      this.salaryPayoff.setRegTime(new Date());
      this.salaryPayoff.setRegister(ContextUtil.getCurrentUser().getFullname());
    }
    BigDecimal localBigDecimal = this.salaryPayoff.getStandAmount().add(this.salaryPayoff.getEncourageAmount()).subtract(this.salaryPayoff.getDeductAmount());
    if (this.salaryPayoff.getAchieveAmount().compareTo(new BigDecimal(0)) == 1)
      localBigDecimal = localBigDecimal.add(this.salaryPayoff.getAchieveAmount());
    this.salaryPayoff.setAcutalAmount(localBigDecimal);
    this.salaryPayoffService.save(this.salaryPayoff);
    setJsonString("{success:true}");
    return "success";
  }

  public String check()
  {
    SalaryPayoff localSalaryPayoff = (SalaryPayoff)this.salaryPayoffService.get(new Long(this.recordId.longValue()));
    localSalaryPayoff.setCheckTime(new Date());
    localSalaryPayoff.setCheckName(ContextUtil.getCurrentUser().getFullname());
    localSalaryPayoff.setCheckStatus(this.salaryPayoff.getCheckStatus());
    localSalaryPayoff.setCheckOpinion(this.salaryPayoff.getCheckOpinion());
    this.salaryPayoffService.save(localSalaryPayoff);
    return "success";
  }

  public String personal()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList1 = this.salaryPayoffService.getAll(localQueryFilter);
    StringBuffer localStringBuffer1 = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:[");
    Iterator localIterator1 = localList1.iterator();
    while (localIterator1.hasNext())
    {
      SalaryPayoff localSalaryPayoff = (SalaryPayoff)localIterator1.next();
      localStringBuffer1.append("{recordId:'").append(localSalaryPayoff.getRecordId()).append("',fullname:'").append(localSalaryPayoff.getFullname()).append("',profileNo:'").append(localSalaryPayoff.getProfileNo()).append("',idNo:'").append(localSalaryPayoff.getIdNo()).append("',standAmount:'").append(localSalaryPayoff.getStandAmount()).append("',acutalAmount:'").append(localSalaryPayoff.getAcutalAmount()).append("',startTime:'").append(localSalaryPayoff.getStartTime()).append("',endTime:'").append(localSalaryPayoff.getEndTime()).append("',checkStatus:'").append(localSalaryPayoff.getCheckStatus());
      List localList2 = this.standSalaryItemService.getAllByStandardId(localSalaryPayoff.getStandardId());
      StringBuffer localStringBuffer2 = new StringBuffer("<table class=\"table-info\" cellpadding=\"0\" cellspacing=\"1\" width=\"98%\" align=\"center\"><tr>");
      if ((localSalaryPayoff.getEncourageAmount() != new BigDecimal(0)) && (localSalaryPayoff.getEncourageAmount() != null))
        localStringBuffer2.append("<th>").append("奖励金额</th><td>").append(localSalaryPayoff.getEncourageAmount()).append("</td>");
      if ((localSalaryPayoff.getEncourageAmount() != new BigDecimal(0)) && (localSalaryPayoff.getEncourageAmount() != null))
        localStringBuffer2.append("<th>").append("扣除金额</th><td>").append(localSalaryPayoff.getDeductAmount()).append("</td>");
      if ((localSalaryPayoff.getEncourageAmount() != new BigDecimal(0)) && (localSalaryPayoff.getEncourageAmount() != null))
        localStringBuffer2.append("<th>").append("效绩金额</th><td>").append(localSalaryPayoff.getAchieveAmount()).append("</td>");
      localStringBuffer2.append("</tr></table><table class=\"table-info\" cellpadding=\"0\" cellspacing=\"1\" width=\"98%\" align=\"center\"><tr>");
      Iterator localIterator2 = localList2.iterator();
      StandSalaryItem localStandSalaryItem;
      while (localIterator2.hasNext())
      {
        localStandSalaryItem = (StandSalaryItem)localIterator2.next();
        localStringBuffer2.append("<th>").append(localStandSalaryItem.getItemName()).append("</th>");
      }
      localStringBuffer2.append("</tr><tr>");
      localIterator2 = localList2.iterator();
      while (localIterator2.hasNext())
      {
        localStandSalaryItem = (StandSalaryItem)localIterator2.next();
        localStringBuffer2.append("<td>").append(localStandSalaryItem.getAmount()).append("</td>");
      }
      localStringBuffer2.append("</tr></table>");
      localStringBuffer1.append("',content:'").append(localStringBuffer2.toString()).append("'},");
    }
    if (localList1.size() > 0)
      localStringBuffer1.deleteCharAt(localStringBuffer1.length() - 1);
    localStringBuffer1.append("]}");
    this.jsonString = localStringBuffer1.toString();
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.hrm.SalaryPayoffAction
 * JD-Core Version:    0.6.0
 */