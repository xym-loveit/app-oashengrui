package com.htsoft.oa.action.system;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.system.TypeKey;
import com.htsoft.oa.service.system.TypeKeyService;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class TypeKeyAction extends BaseAction
{

  @Resource
  private TypeKeyService typeKeyService;
  private TypeKey typeKey;
  private Long typekeyId;

  public Long getTypekeyId()
  {
    return this.typekeyId;
  }

  public void setTypekeyId(Long paramLong)
  {
    this.typekeyId = paramLong;
  }

  public TypeKey getTypeKey()
  {
    return this.typeKey;
  }

  public void setTypeKey(TypeKey paramTypeKey)
  {
    this.typeKey = paramTypeKey;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.typeKeyService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.typeKeyService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    TypeKey localTypeKey = (TypeKey)this.typeKeyService.get(this.typekeyId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localTypeKey));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.typeKeyService.save(this.typeKey);
    setJsonString("{success:true}");
    return "success";
  }

  public String combo()
  {
    List localList = this.typeKeyService.getAll();
    StringBuffer localStringBuffer = new StringBuffer("[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      TypeKey localTypeKey = (TypeKey)localIterator.next();
      if (localStringBuffer.length() > 1)
        localStringBuffer.append(",");
      localStringBuffer.append("['").append(localTypeKey.getTypeKey()).append("','").append(localTypeKey.getTypeName()).append("(").append(localTypeKey.getTypeKey()).append(")").append("']");
    }
    localStringBuffer.append("]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.TypeKeyAction
 * JD-Core Version:    0.6.0
 */