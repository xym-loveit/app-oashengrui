package com.htsoft.oa.action.admin;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.admin.OfficeGoods;
import com.htsoft.oa.service.admin.OfficeGoodsService;
import flexjson.JSONSerializer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class OfficeGoodsAction extends BaseAction
{

  @Resource
  private OfficeGoodsService officeGoodsService;
  private OfficeGoods officeGoods;
  private Long goodsId;

  public Long getGoodsId()
  {
    return this.goodsId;
  }

  public void setGoodsId(Long paramLong)
  {
    this.goodsId = paramLong;
  }

  public OfficeGoods getOfficeGoods()
  {
    return this.officeGoods;
  }

  public void setOfficeGoods(OfficeGoods paramOfficeGoods)
  {
    this.officeGoods = paramOfficeGoods;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.officeGoodsService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer();
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.officeGoodsService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    OfficeGoods localOfficeGoods = (OfficeGoods)this.officeGoodsService.get(this.goodsId);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localOfficeGoods));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss-SSSS");
    if (this.officeGoods.getGoodsId() == null)
    {
      this.officeGoods.setGoodsNo(localSimpleDateFormat.format(new Date()));
      this.officeGoods.setStockCounts(Integer.valueOf(0));
    }
    this.officeGoodsService.save(this.officeGoods);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.admin.OfficeGoodsAction
 * JD-Core Version:    0.6.0
 */