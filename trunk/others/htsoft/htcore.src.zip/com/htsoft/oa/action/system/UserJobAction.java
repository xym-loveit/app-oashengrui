package com.htsoft.oa.action.system;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.hrm.Job;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.UserJob;
import com.htsoft.oa.service.hrm.JobService;
import com.htsoft.oa.service.system.UserJobService;
import flexjson.JSONSerializer;
import flexjson.transformer.DateTransformer;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class UserJobAction extends BaseAction
{

  @Resource
  private UserJobService userJobService;

  @Resource
  private JobService jobService;
  private UserJob userJob;
  private Long userJobId;

  public Long getUserJobId()
  {
    return this.userJobId;
  }

  public void setUserJobId(Long paramLong)
  {
    this.userJobId = paramLong;
  }

  public UserJob getUserJob()
  {
    return this.userJob;
  }

  public void setUserJob(UserJob paramUserJob)
  {
    this.userJob = paramUserJob;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    if ((this.userJob != null) && (this.userJob.getJob() != null) && (this.userJob.getJob().getJobId().longValue() > 0L))
    {
      localObject = (Job)this.jobService.get(this.userJob.getJob().getJobId());
      localQueryFilter.addFilter("Q_job.path_S_LK", ((Job)localObject).getPath());
    }
    Object localObject = this.userJobService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localJSONSerializer.transform(new DateTransformer("yyyy-MM-dd"), new String[] { "appUser.accessionTime" });
    localStringBuffer.append(localJSONSerializer.serialize(localObject));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return (String)"success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.userJobService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    UserJob localUserJob = (UserJob)this.userJobService.get(this.userJobId);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(JsonUtil.getJSONSerializer(new String[] { "accessionTime" }).serialize(localUserJob));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    String str = "{success:true,msg:'数据操作成功！'}";
    Long localLong = this.userJob.getAppUser().getUserId();
    if ((this.userJob.getIsMain().equals(UserJob.ISMIAN)) && (this.userJobService.IsExistsjob(this.userJob.getUserJobId(), localLong).booleanValue()))
    {
      str = "{failure:true,msg:'对不起，该用户已经存在主职位，请添加副职位！'}";
      setJsonString(str);
      return "success";
    }
    int i = (this.userJob != null) && (this.userJob.getUserJobId() != null) ? 1 : 0;
    if (i == 0)
      str = this.userJobService.add(this.userJob);
    else
      this.userJobService.save(this.userJob);
    setJsonString(str);
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.UserJobAction
 * JD-Core Version:    0.6.0
 */