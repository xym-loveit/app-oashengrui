package com.htsoft.oa.action.admin;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.admin.BoardRoo;
import com.htsoft.oa.service.admin.BoardRooService;
import java.lang.reflect.Type;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class BoardRooAction extends BaseAction
{

  @Resource
  private BoardRooService boardRooService;
  private BoardRoo boardRoo;
  private Long roomId;

  public Long getRoomId()
  {
    return this.roomId;
  }

  public void setRoomId(Long paramLong)
  {
    this.roomId = paramLong;
  }

  public BoardRoo getBoardRoo()
  {
    return this.boardRoo;
  }

  public void setBoardRoo(BoardRoo paramBoardRoo)
  {
    this.boardRoo = paramBoardRoo;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addSorted("roomId", "DESC");
    List localList = this.boardRooService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType)).append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.boardRooService.remove(Long.valueOf(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String del()
  {
    this.boardRooService.remove(this.roomId);
    this.jsonString = "{success:true}";
    return "success";
  }

  public String save()
  {
    this.boardRooService.save(this.boardRoo);
    this.jsonString = "{success:true,msg:'保存成功'}";
    return "success";
  }

  public String get()
  {
    BoardRoo localBoardRoo = (BoardRoo)this.boardRooService.get(this.roomId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localBoardRoo)).append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.admin.BoardRooAction
 * JD-Core Version:    0.6.0
 */