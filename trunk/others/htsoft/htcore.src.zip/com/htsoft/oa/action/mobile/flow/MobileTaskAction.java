package com.htsoft.oa.action.mobile.flow;

import com.htsoft.core.jbpm.pv.ParamField;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.action.flow.FlowRunInfo;
import com.htsoft.oa.action.flow.ProcessActivityAssistant;
import com.htsoft.oa.model.flow.ProDefinition;
import com.htsoft.oa.model.flow.ProcessForm;
import com.htsoft.oa.model.flow.ProcessRun;
import com.htsoft.oa.model.flow.Transform;
import com.htsoft.oa.service.flow.JbpmService;
import com.htsoft.oa.service.flow.ProDefinitionService;
import com.htsoft.oa.service.flow.ProcessRunService;
import com.htsoft.oa.service.flow.TaskService;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map<Ljava.lang.String;Lcom.htsoft.core.jbpm.pv.ParamField;>;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.jbpm.api.ProcessDefinition;
import org.jbpm.api.model.Transition;
import org.jbpm.pvm.internal.task.TaskImpl;

public class MobileTaskAction extends BaseAction
{

  @Resource
  private ProcessRunService processRunService;

  @Resource
  private ProDefinitionService proDefinitionService;
  private Long defId;
  private String taskId;
  private String processName;
  private String taskName;
  private List outTrans = new ArrayList();
  private String vmPath;

  @Resource(name="flowTaskService")
  private TaskService flowTaskService;

  @Resource
  private JbpmService jbpmService;

  public String getProcessName()
  {
    return this.processName;
  }

  public void setProcessName(String paramString)
  {
    this.processName = paramString;
  }

  public String getTaskName()
  {
    return this.taskName;
  }

  public void setTaskName(String paramString)
  {
    this.taskName = paramString;
  }

  public String getVmPath()
  {
    return this.vmPath;
  }

  public void setVmPath(String paramString)
  {
    this.vmPath = paramString;
  }

  public List getOutTrans()
  {
    return this.outTrans;
  }

  public void setOutTrans(List paramList)
  {
    this.outTrans = paramList;
  }

  public String list()
  {
    PagingBean localPagingBean = getInitPagingBean();
    List localList = this.flowTaskService.getTaskInfosByUserId(ContextUtil.getCurrentUserId().toString(), localPagingBean);
    getRequest().setAttribute("taskList", localList);
    return "success";
  }

  public String next()
  {
    this.taskId = getRequest().getParameter("taskId");
    if (StringUtils.isNotEmpty(this.taskId))
    {
      TaskImpl localTaskImpl = (TaskImpl)this.jbpmService.getTaskById(this.taskId);
      this.taskName = localTaskImpl.getName();
      ProcessDefinition localProcessDefinition = this.jbpmService.getProcessDefinitionByTaskId(this.taskId);
      ProDefinition localProDefinition = this.proDefinitionService.getByDeployId(localProcessDefinition.getDeploymentId());
      this.processName = localProDefinition.getName();
      this.vmPath = (this.processName + "/" + this.taskName);
      String str = getSession().getServletContext().getRealPath("") + "/mobile/flow/FlowForm/" + this.vmPath + ".vm";
      if (this.logger.isDebugEnabled())
        this.logger.debug("viewPath:" + str);
      if (!new File(str).exists())
        this.vmPath = "通用/表单";
      List localList = this.jbpmService.getTransitionsByTaskId(this.taskId.toString());
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        Transition localTransition = (Transition)localIterator.next();
        if (localTransition.getDestination() != null)
          this.outTrans.add(new Transform(localTransition));
      }
    }
    return "next";
  }

  public String start()
  {
    ProDefinition localProDefinition = (ProDefinition)this.proDefinitionService.get(this.defId);
    this.taskName = this.jbpmService.getStartNodeName(localProDefinition);
    this.processName = localProDefinition.getName();
    this.vmPath = (this.processName + "/" + this.taskName);
    String str = getSession().getServletContext().getRealPath("") + "/mobile/flow/FlowForm/" + this.vmPath + ".vm";
    if (this.logger.isDebugEnabled())
      this.logger.debug("viewPath:" + str);
    if (!new File(str).exists())
      this.vmPath = "通用/开始";
    return "start";
  }

  public String saveStart()
  {
    FlowRunInfo localFlowRunInfo = getFlowRunInfo();
    this.jbpmService.doStartProcess(localFlowRunInfo);
    return "list";
  }

  protected Map<String, ParamField> constructFieldMap()
  {
    HttpServletRequest localHttpServletRequest = getRequest();
    if (StringUtils.isEmpty(this.taskName))
    {
      localObject1 = null;
      if (StringUtils.isNotEmpty(this.taskId))
      {
        localObject2 = this.jbpmService.getProcessDefinitionByTaskId(this.taskId);
        localObject1 = this.proDefinitionService.getByDeployId(((ProcessDefinition)localObject2).getDeploymentId());
      }
      else
      {
        localObject1 = (ProDefinition)this.proDefinitionService.get(this.defId);
      }
      this.taskName = this.jbpmService.getStartNodeName((ProDefinition)localObject1);
      this.processName = ((ProDefinition)localObject1).getName();
    }
    else if ((StringUtils.isEmpty(this.processName)) && (StringUtils.isNotEmpty(this.taskId)))
    {
      localObject1 = this.jbpmService.getProcessDefinitionByTaskId(this.taskId);
      localObject2 = this.proDefinitionService.getByDeployId(((ProcessDefinition)localObject1).getDeploymentId());
      this.processName = ((ProDefinition)localObject2).getName();
    }
    Object localObject1 = ProcessActivityAssistant.constructMobileFieldMap(this.processName, this.taskName);
    Object localObject2 = ((Map)localObject1).keySet().iterator();
    while (((Iterator)localObject2).hasNext())
    {
      String str = (String)((Iterator)localObject2).next();
      ParamField localParamField = (ParamField)((Map)localObject1).get(str);
      localParamField.setName(localParamField.getName().replace(".", "_"));
      localParamField.setValue(localHttpServletRequest.getParameter(str));
    }
    return (Map<String, ParamField>)(Map<String, ParamField>)localObject1;
  }

  protected ProcessRun initNewProcessRun()
  {
    ProDefinition localProDefinition = (ProDefinition)this.proDefinitionService.get(this.defId);
    return this.processRunService.getInitNewProcessRun(localProDefinition);
  }

  protected ProcessForm initNewProcessForm(ProcessRun paramProcessRun)
  {
    ProcessForm localProcessForm = new ProcessForm();
    localProcessForm.setActivityName(this.taskName);
    localProcessForm.setProcessRun(paramProcessRun);
    return localProcessForm;
  }

  protected FlowRunInfo getFlowRunInfo()
  {
    FlowRunInfo localFlowRunInfo = new FlowRunInfo(getRequest());
    Map localMap = constructFieldMap();
    localFlowRunInfo.setParamFields(localMap);
    return localFlowRunInfo;
  }

  public String getTaskId()
  {
    return this.taskId;
  }

  public void setTaskId(String paramString)
  {
    this.taskId = paramString;
  }

  public Long getDefId()
  {
    return this.defId;
  }

  public void setDefId(Long paramLong)
  {
    this.defId = paramLong;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.mobile.flow.MobileTaskAction
 * JD-Core Version:    0.6.0
 */