package com.htsoft.oa.action.system;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.RelativeJob;
import com.htsoft.oa.model.system.RelativeUser;
import com.htsoft.oa.service.system.AppUserService;
import com.htsoft.oa.service.system.RelativeJobService;
import com.htsoft.oa.service.system.RelativeUserService;
import flexjson.JSONSerializer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;

public class RelativeUserAction extends BaseAction
{

  @Resource
  private RelativeUserService relativeUserService;

  @Resource
  private AppUserService appUserService;

  @Resource
  private RelativeJobService relativeJobService;
  private RelativeUser relativeUser;
  private Long relativeUserId;
  private Long userId;
  private Long reJobId;

  public Long getRelativeUserId()
  {
    return this.relativeUserId;
  }

  public void setRelativeUserId(Long paramLong)
  {
    this.relativeUserId = paramLong;
  }

  public RelativeUser getRelativeUser()
  {
    return this.relativeUser;
  }

  public void setRelativeUser(RelativeUser paramRelativeUser)
  {
    this.relativeUser = paramRelativeUser;
  }

  public Long getUserId()
  {
    return this.userId;
  }

  public void setUserId(Long paramLong)
  {
    this.userId = paramLong;
  }

  public Long getReJobId()
  {
    return this.reJobId;
  }

  public void setReJobId(Long paramLong)
  {
    this.reJobId = paramLong;
  }

  public String list()
  {
    PagingBean localPagingBean = getInitPagingBean();
    List localList = this.relativeUserService.list(this.userId, this.reJobId, localPagingBean);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localPagingBean.getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.relativeUserService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    RelativeUser localRelativeUser = (RelativeUser)this.relativeUserService.get(this.relativeUserId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localRelativeUser));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    if (this.relativeUser.getRelativeUserId() == null)
    {
      this.relativeUserService.save(this.relativeUser);
    }
    else
    {
      RelativeUser localRelativeUser = (RelativeUser)this.relativeUserService.get(this.relativeUser.getRelativeUserId());
      try
      {
        BeanUtil.copyNotNullProperties(localRelativeUser, this.relativeUser);
        this.relativeUserService.save(localRelativeUser);
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    setJsonString("{success:true}");
    return "success";
  }

  public String mutliAdd()
  {
    int i = 0;
    ArrayList localArrayList = new ArrayList();
    String str1 = "";
    String str2 = getRequest().getParameter("jobUserIds");
    String str3 = getRequest().getParameter("userId");
    AppUser localAppUser1 = (AppUser)this.appUserService.get(new Long(str3));
    Object localObject2;
    AppUser localAppUser2;
    for (localObject2 : str2.split(","))
      if (((String)localObject2).equals(str3))
      {
        i = 1;
      }
      else
      {
        localAppUser2 = this.relativeUserService.judge(new Long(str3), new Long((String)localObject2));
        if (localAppUser2 == null)
          localArrayList.add(new Long((String)localObject2));
        else
          str1 = str1 + localAppUser2.getFullname() + ",";
      }
    if (!str1.equals(""))
      str1 = str1.substring(0, str1.length() - 1);
    ??? = "";
    if ((localArrayList != null) && (localArrayList.size() > 0))
    {
      String str4 = "";
      Iterator localIterator = localArrayList.iterator();
      while (localIterator.hasNext())
      {
        localObject2 = (Long)localIterator.next();
        localAppUser2 = (AppUser)this.appUserService.get(new Long(((Long)localObject2).longValue()));
        RelativeUser localRelativeUser1 = new RelativeUser();
        RelativeJob localRelativeJob = (RelativeJob)this.relativeJobService.get(this.reJobId);
        localRelativeUser1.setRelativeJob(localRelativeJob);
        localRelativeUser1.setJobUser(localAppUser2);
        localRelativeUser1.setAppUser(localAppUser1);
        localRelativeUser1.setIsSuper(this.relativeUser.getIsSuper());
        RelativeUser localRelativeUser2 = (RelativeUser)this.relativeUserService.save(localRelativeUser1);
        str4 = str4 + localRelativeUser2.getJobUser().getFullname() + ",";
      }
      str4 = str4.substring(0, str4.length() - 1);
      ??? = "{success:true,msg:'成功添加[" + str4 + "]用户";
      if ((str1 != null) && (!str1.equals("")))
        ??? = (String)??? + "，其中[" + str1 + "]已经添加";
      if (i != 0)
        ??? = (String)??? + "，用户本身不能添加";
      ??? = (String)??? + "！'}";
    }
    else
    {
      ??? = "{success:true,msg:'对不起，没有适合添加的用户，请重新选择！'}";
    }
    setJsonString((String)???);
    return (String)(String)"success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.RelativeUserAction
 * JD-Core Version:    0.6.0
 */