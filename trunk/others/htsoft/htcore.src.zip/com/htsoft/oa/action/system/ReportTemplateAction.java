package com.htsoft.oa.action.system;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.AppUtil;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.system.ReportParam;
import com.htsoft.oa.model.system.ReportTemplate;
import com.htsoft.oa.service.system.ReportParamService;
import com.htsoft.oa.service.system.ReportTemplateService;
import flexjson.JSONSerializer;
import java.io.File;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Type;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class ReportTemplateAction extends BaseAction
{
  private String uploadPath = AppUtil.getAppAbsolutePath() + "/attachFiles/";

  @Resource
  private ReportTemplateService reportTemplateService;
  private ReportTemplate reportTemplate;

  @Resource
  private ReportParamService reportParamService;
  private Long reportId;

  public Long getReportId()
  {
    return this.reportId;
  }

  public void setReportId(Long paramLong)
  {
    this.reportId = paramLong;
  }

  public ReportTemplate getReportTemplate()
  {
    return this.reportTemplate;
  }

  public void setReportTemplate(ReportTemplate paramReportTemplate)
  {
    this.reportTemplate = paramReportTemplate;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.reportTemplateService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String checkKey()
  {
    String str = getRequest().getParameter("Q_reportKey_S_EQ");
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.reportTemplateService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
      {
        this.reportTemplate = ((ReportTemplate)this.reportTemplateService.get(new Long(str)));
        List localList = this.reportParamService.findByRepTemp(new Long(str));
        Object localObject1 = localList.iterator();
        while (((Iterator)localObject1).hasNext())
        {
          localObject2 = (ReportParam)((Iterator)localObject1).next();
          this.reportParamService.remove(localObject2);
        }
        localObject1 = new File(this.uploadPath + this.reportTemplate.getReportLocation());
        Object localObject2 = ((File)localObject1).getParentFile();
        deleteFile((File)localObject2);
        this.reportTemplateService.remove(new Long(str));
      }
    this.jsonString = "{success:true}";
    return (String)(String)"success";
  }

  public String get()
  {
    ReportTemplate localReportTemplate = (ReportTemplate)this.reportTemplateService.get(this.reportId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localReportTemplate));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    if (this.reportTemplate.getReportId() == null)
    {
      this.reportTemplate.setCreatetime(new Date());
      this.reportTemplate.setUpdatetime(new Date());
      this.reportTemplateService.save(this.reportTemplate);
    }
    else
    {
      ReportTemplate localReportTemplate = (ReportTemplate)this.reportTemplateService.get(this.reportTemplate.getReportId());
      if (!localReportTemplate.getReportLocation().toString().trim().equals(this.reportTemplate.getReportLocation().toString().trim()))
      {
        File localFile = new File(this.uploadPath + localReportTemplate.getReportLocation());
        deleteFile(localFile.getParentFile());
      }
      try
      {
        BeanUtil.copyNotNullProperties(localReportTemplate, this.reportTemplate);
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        localIllegalAccessException.printStackTrace();
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        localInvocationTargetException.printStackTrace();
      }
      localReportTemplate.setUpdatetime(new Date());
      this.reportTemplateService.save(localReportTemplate);
    }
    setJsonString("{success:true}");
    return "success";
  }

  private void deleteFile(File paramFile)
  {
    if (paramFile.exists())
    {
      if (paramFile.isFile())
      {
        paramFile.delete();
      }
      else if (paramFile.isDirectory())
      {
        File[] arrayOfFile = paramFile.listFiles();
        for (int i = 0; i < arrayOfFile.length; i++)
          deleteFile(arrayOfFile[i]);
      }
      paramFile.delete();
    }
    else
    {
      System.out.println("所删除的文件不存在！\n");
    }
  }

  public String load()
  {
    String str = getRequest().getParameter("reportId");
    if (StringUtils.isNotEmpty(str))
    {
      List localList = this.reportParamService.findByRepTemp(new Long(str));
      JSONSerializer localJSONSerializer = new JSONSerializer();
      Gson localGson = new Gson();
      StringBuffer localStringBuffer = new StringBuffer();
      localStringBuffer.append(localGson.toJson(localList));
      setJsonString("{success:true,data:" + localStringBuffer.toString() + "}");
    }
    else
    {
      setJsonString("{success:false}");
    }
    return "success";
  }

  public String submit()
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-mm-dd");
    Map localMap = getRequest().getParameterMap();
    Iterator localIterator = localMap.entrySet().iterator();
    StringBuffer localStringBuffer = new StringBuffer();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      String str1 = (String)localEntry.getKey();
      String[] arrayOfString = (String[])(String[])localEntry.getValue();
      String str2 = arrayOfString[0];
      if ((str2 == null) || (str2.equals("")))
        str2 = "%";
      else
        try
        {
          localSimpleDateFormat.parse(str2.trim());
        }
        catch (ParseException localParseException)
        {
          str2 = "%" + str2.trim() + "%";
        }
      localStringBuffer.append("&" + str1 + "=" + str2);
    }
    setJsonString("{success:true,data:'" + localStringBuffer.toString() + "'}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.ReportTemplateAction
 * JD-Core Version:    0.6.0
 */