package com.htsoft.oa.action.admin;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.admin.ConfAttend;
import com.htsoft.oa.service.admin.ConfAttendService;
import java.lang.reflect.Type;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class ConfAttendAction extends BaseAction
{

  @Resource
  private ConfAttendService confAttendService;
  private ConfAttend confAttend;
  private Long attendId;

  public Long getAttendId()
  {
    return this.attendId;
  }

  public void setAttendId(Long paramLong)
  {
    this.attendId = paramLong;
  }

  public ConfAttend getConfAttend()
  {
    return this.confAttend;
  }

  public void setConfAttend(ConfAttend paramConfAttend)
  {
    this.confAttend = paramConfAttend;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.confAttendService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.confAttendService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    ConfAttend localConfAttend = (ConfAttend)this.confAttendService.get(this.attendId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localConfAttend));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.confAttendService.save(this.confAttend);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.admin.ConfAttendAction
 * JD-Core Version:    0.6.0
 */