package com.htsoft.oa.action.admin;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.admin.Car;
import com.htsoft.oa.model.admin.CarApply;
import com.htsoft.oa.model.info.ShortMessage;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.admin.CarApplyService;
import com.htsoft.oa.service.admin.CarService;
import com.htsoft.oa.service.info.ShortMessageService;
import flexjson.JSONSerializer;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class CarApplyAction extends BaseAction
{

  @Resource
  private CarApplyService carApplyService;
  private CarApply carApply;

  @Resource
  private ShortMessageService shortMessageService;

  @Resource
  private CarService carService;
  private Long applyId;

  public Long getApplyId()
  {
    return this.applyId;
  }

  public void setApplyId(Long paramLong)
  {
    this.applyId = paramLong;
  }

  public CarApply getCarApply()
  {
    return this.carApply;
  }

  public void setCarApply(CarApply paramCarApply)
  {
    this.carApply = paramCarApply;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.carApplyService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "applyDate", "startTime", "endTime" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.carApplyService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    CarApply localCarApply = (CarApply)this.carApplyService.get(this.applyId);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "applyDate", "startTime", "endTime" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class", "car.carApplys" }).serialize(localCarApply));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    if (this.carApply.getApplyId() != null)
    {
      CarApply localCarApply = (CarApply)this.carApplyService.get(this.carApply.getApplyId());
      try
      {
        BeanUtil.copyNotNullProperties(localCarApply, this.carApply);
        this.carApplyService.save(localCarApply);
        if (localCarApply.getApprovalStatus().shortValue() == Car.PASS_APPLY)
        {
          Long localLong = localCarApply.getUserId();
          Car localCar = (Car)this.carService.get(localCarApply.getCar().getCarId());
          String str = "你申请的车牌号为" + localCar.getCarNo() + "已经通过审批，请注意查收";
          this.shortMessageService.save(AppUser.SYSTEM_USER, localLong.toString(), str, ShortMessage.MSG_TYPE_SYS);
        }
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
    }
    else
    {
      this.carApplyService.save(this.carApply);
    }
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.admin.CarApplyAction
 * JD-Core Version:    0.6.0
 */