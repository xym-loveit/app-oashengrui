package com.htsoft.oa.action.admin;

import com.google.gson.Gson;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.admin.DepreRecord;
import com.htsoft.oa.model.admin.DepreType;
import com.htsoft.oa.model.admin.FixedAssets;
import com.htsoft.oa.service.admin.DepreRecordService;
import com.htsoft.oa.service.admin.FixedAssetsService;
import flexjson.JSONSerializer;
import flexjson.transformer.DateTransformer;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class DepreRecordAction extends BaseAction
{

  @Resource
  private DepreRecordService depreRecordService;
  private DepreRecord depreRecord;

  @Resource
  private FixedAssetsService fixedAssetsService;
  private Long recordId;
  static int YEARS = 11;

  public Long getRecordId()
  {
    return this.recordId;
  }

  public void setRecordId(Long paramLong)
  {
    this.recordId = paramLong;
  }

  public DepreRecord getDepreRecord()
  {
    return this.depreRecord;
  }

  public void setDepreRecord(DepreRecord paramDepreRecord)
  {
    this.depreRecord = paramDepreRecord;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.depreRecordService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localJSONSerializer.transform(new DateTransformer("yyyy-MM-dd HH:mm:ss"), new String[] { "calTime" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.depreRecordService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    DepreRecord localDepreRecord = (DepreRecord)this.depreRecordService.get(this.recordId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localDepreRecord));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String depreciate()
  {
    String str = getRequest().getParameter("ids");
    if (StringUtils.isNotEmpty(str))
    {
      FixedAssets localFixedAssets = (FixedAssets)this.fixedAssetsService.get(new Long(str));
      BigDecimal localBigDecimal1 = localFixedAssets.getAssetCurValue();
      BigDecimal localBigDecimal2 = localFixedAssets.getAssetValue();
      int i = localFixedAssets.getDepreType().getCalMethod().shortValue();
      Integer localInteger1 = Integer.valueOf(0);
      Object localObject1;
      Object localObject2;
      Date localDate;
      Object localObject4;
      GregorianCalendar localGregorianCalendar;
      Object localObject5;
      Object localObject6;
      Object localObject7;
      Object localObject8;
      Object localObject9;
      if (i == 1)
      {
        localObject1 = new BigDecimal(0);
        localObject1 = localFixedAssets.getDepreRate();
        localObject2 = ((BigDecimal)localObject1).divide(new BigDecimal(12), 2, 2);
        localDate = this.depreRecordService.findMaxDate(new Long(str));
        if (localDate == null)
          localDate = localFixedAssets.getStartDepre();
        Integer localInteger2 = localFixedAssets.getDepreType().getDeprePeriod();
        localObject4 = localBigDecimal2.multiply(new BigDecimal(localInteger2.toString())).multiply((BigDecimal)localObject2);
        localGregorianCalendar = new GregorianCalendar();
        localGregorianCalendar.setTime(localDate);
        localObject5 = new GregorianCalendar();
        ((GregorianCalendar)localObject5).setTime(localFixedAssets.getStartDepre());
        localObject6 = Integer.valueOf(localFixedAssets.getIntendTerm().intValue());
        ((GregorianCalendar)localObject5).add(1, ((Integer)localObject6).intValue());
        while (localInteger2.intValue() >= 1)
        {
          localGregorianCalendar.add(2, localInteger2.intValue());
          localObject7 = localGregorianCalendar.getTime();
          if ((((Date)localObject7).after(new Date())) || (((Date)localObject7).after(((GregorianCalendar)localObject5).getTime())))
            break;
          localObject8 = localInteger1;
          localObject9 = localInteger1 = Integer.valueOf(localInteger1.intValue() + 1);
          localObject8 = new DepreRecord();
          ((DepreRecord)localObject8).setFixedAssets(localFixedAssets);
          ((DepreRecord)localObject8).setCalTime((Date)localObject7);
          localBigDecimal1 = localBigDecimal1.subtract((BigDecimal)localObject4);
          if (localBigDecimal1.compareTo(new BigDecimal("0.001")) == -1)
            break;
          ((DepreRecord)localObject8).setDepreAmount((BigDecimal)localObject4);
          this.depreRecordService.save(localObject8);
        }
      }
      else
      {
        Object localObject3;
        if (i == 2)
        {
          localObject1 = localInteger1;
          localObject2 = localInteger1 = Integer.valueOf(localInteger1.intValue() + 1);
          localObject1 = getRequest().getParameter("cruCalDate");
          if (StringUtils.isNotEmpty((String)localObject1))
          {
            localObject2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            localDate = new Date();
            try
            {
              localDate = ((SimpleDateFormat)localObject2).parse((String)localObject1);
            }
            catch (ParseException localParseException)
            {
              localParseException.printStackTrace();
              setJsonString("{success:false}");
              return "success";
            }
            localObject3 = new BigDecimal(1).subtract(localFixedAssets.getRemainValRate().divide(new BigDecimal(100))).multiply(localFixedAssets.getAssetValue());
            localObject4 = ((BigDecimal)localObject3).divide(localFixedAssets.getIntendWorkGross(), 2, 2);
            localBigDecimal1 = localBigDecimal1.subtract(((BigDecimal)localObject4).multiply(this.depreRecord.getWorkCapacity()));
            this.depreRecord.setCalTime(localDate);
            this.depreRecord.setFixedAssets(localFixedAssets);
            this.depreRecord.setDepreAmount(((BigDecimal)localObject4).multiply(this.depreRecord.getWorkCapacity()));
            this.depreRecordService.save(this.depreRecord);
          }
          else
          {
            setJsonString("{success:false}");
            return "success";
          }
        }
        else
        {
          Object localObject10;
          BigDecimal localBigDecimal3;
          Object localObject11;
          Object localObject12;
          Object localObject13;
          Object localObject14;
          Object localObject15;
          Object localObject16;
          Integer localInteger3;
          if (i == 3)
          {
            localObject1 = localFixedAssets.getDepreType().getDeprePeriod();
            localObject2 = this.depreRecordService.findMaxDate(new Long(str));
            if (localObject2 == null)
              localObject2 = localFixedAssets.getStartDepre();
            localDate = localFixedAssets.getStartDepre();
            localObject3 = new GregorianCalendar();
            localObject4 = new GregorianCalendar();
            localGregorianCalendar = new GregorianCalendar();
            localObject5 = new BigDecimal(2).divide(localFixedAssets.getIntendTerm(), 2, 3);
            localObject6 = ((BigDecimal)localObject5).divide(new BigDecimal(12), 2, 3);
            ((GregorianCalendar)localObject4).setTime(localDate);
            localObject7 = Integer.valueOf(localFixedAssets.getIntendTerm().intValue());
            if (((Integer)localObject7).intValue() > 2)
              ((GregorianCalendar)localObject4).add(1, ((Integer)localObject7).intValue() - 2);
            localGregorianCalendar.setTime(localDate);
            localGregorianCalendar.add(1, ((Integer)localObject7).intValue());
            ((GregorianCalendar)localObject3).setTime((Date)localObject2);
            localObject8 = Integer.valueOf(0);
            localObject9 = new BigDecimal(0);
            while (((Integer)localObject1).intValue() > 0)
            {
              localObject10 = new DepreRecord();
              localBigDecimal3 = new BigDecimal(0);
              localObject11 = ((GregorianCalendar)localObject3).getTime();
              ((GregorianCalendar)localObject3).add(2, ((Integer)localObject1).intValue());
              if ((((GregorianCalendar)localObject3).getTime().after(new Date())) || (((GregorianCalendar)localObject3).getTime().after(localGregorianCalendar.getTime())))
                break;
              localObject12 = localInteger1;
              localObject13 = localInteger1 = Integer.valueOf(localInteger1.intValue() + 1);
              if (!((GregorianCalendar)localObject3).getTime().after(((GregorianCalendar)localObject4).getTime()))
              {
                localBigDecimal3 = localBigDecimal1.multiply((BigDecimal)localObject6).multiply(new BigDecimal(((Integer)localObject1).toString()));
                localBigDecimal1 = localBigDecimal1.subtract(localBigDecimal3);
              }
              else
              {
                localObject12 = new GregorianCalendar();
                ((GregorianCalendar)localObject12).setTime((Date)localObject11);
                localObject13 = Integer.valueOf(0);
                localObject14 = ((GregorianCalendar)localObject12).getTime();
                localObject15 = ((GregorianCalendar)localObject4).getTime();
                while (((Date)localObject14).before((Date)localObject15))
                {
                  ((GregorianCalendar)localObject12).add(2, 1);
                  localBigDecimal1 = localBigDecimal1.subtract(localBigDecimal1.multiply((BigDecimal)localObject6));
                  localBigDecimal3 = localBigDecimal3.add(localBigDecimal1.multiply((BigDecimal)localObject6));
                  localObject16 = localObject13;
                  localInteger3 = localObject13 = Integer.valueOf(((Integer)localObject13).intValue() + 1);
                }
                if (((Integer)localObject1).intValue() - ((Integer)localObject13).intValue() > 0)
                {
                  if (((Integer)localObject8).intValue() == 0)
                    localObject9 = localBigDecimal1.subtract(localBigDecimal1.multiply(localFixedAssets.getRemainValRate().divide(new BigDecimal(100), 2, 2)));
                  localObject16 = localObject8;
                  localInteger3 = localObject8 = Integer.valueOf(((Integer)localObject8).intValue() + 1);
                  localObject16 = Integer.valueOf(((Integer)localObject1).intValue() - ((Integer)localObject13).intValue());
                  if (localFixedAssets.getIntendTerm().intValue() > 1)
                  {
                    localBigDecimal3 = localBigDecimal3.add(((BigDecimal)localObject9).divide(new BigDecimal(24), 2, 3).multiply(new BigDecimal(((Integer)localObject16).toString())));
                    localBigDecimal1 = localBigDecimal1.subtract(((BigDecimal)localObject9).divide(new BigDecimal(24), 2, 3).multiply(new BigDecimal(((Integer)localObject16).toString())));
                  }
                  else
                  {
                    localBigDecimal3 = localBigDecimal3.add(((BigDecimal)localObject9).divide(new BigDecimal(12), 2, 3).multiply(new BigDecimal(((Integer)localObject16).toString())));
                    localBigDecimal1 = localBigDecimal1.subtract(((BigDecimal)localObject9).divide(new BigDecimal(12), 2, 3).multiply(new BigDecimal(((Integer)localObject16).toString())));
                  }
                }
              }
              localObject12 = ((GregorianCalendar)localObject3).getTime();
              ((DepreRecord)localObject10).setCalTime((Date)localObject12);
              ((DepreRecord)localObject10).setFixedAssets(localFixedAssets);
              ((DepreRecord)localObject10).setDepreAmount(localBigDecimal3);
              this.depreRecordService.save(localObject10);
            }
          }
          else if (i == 4)
          {
            localObject1 = localFixedAssets.getDepreType().getDeprePeriod();
            localObject2 = this.depreRecordService.findMaxDate(new Long(str));
            if (localObject2 == null)
              localObject2 = localFixedAssets.getStartDepre();
            localDate = localFixedAssets.getStartDepre();
            localObject3 = localFixedAssets.getIntendTerm();
            localObject4 = ((BigDecimal)localObject3).multiply(((BigDecimal)localObject3).add(new BigDecimal(1))).divide(new BigDecimal(2));
            localGregorianCalendar = new GregorianCalendar();
            localObject5 = new GregorianCalendar();
            ((GregorianCalendar)localObject5).setTime(localDate);
            localGregorianCalendar.setTime((Date)localObject2);
            localObject6 = new GregorianCalendar();
            ((GregorianCalendar)localObject6).setTime(localFixedAssets.getStartDepre());
            localObject7 = Integer.valueOf(localFixedAssets.getIntendTerm().intValue());
            ((GregorianCalendar)localObject6).add(1, ((Integer)localObject7).intValue());
            localObject8 = localFixedAssets.getAssetValue().multiply(new BigDecimal(1).subtract(localFixedAssets.getRemainValRate().divide(new BigDecimal(100), 2, 2)));
            while (((Integer)localObject1).intValue() > 0)
            {
              localObject9 = localGregorianCalendar.getTime();
              localObject10 = new GregorianCalendar();
              ((GregorianCalendar)localObject10).setTime((Date)localObject9);
              localGregorianCalendar.add(2, ((Integer)localObject1).intValue());
              localBigDecimal3 = new BigDecimal(0);
              localObject11 = Integer.valueOf(localGregorianCalendar.get(1) - ((GregorianCalendar)localObject10).get(1));
              if ((localGregorianCalendar.getTime().after(new Date())) || (localGregorianCalendar.getTime().after(((GregorianCalendar)localObject6).getTime())))
                break;
              localObject12 = localInteger1;
              localObject13 = localInteger1 = Integer.valueOf(localInteger1.intValue() + 1);
              localObject12 = Integer.valueOf(localGregorianCalendar.get(1) - ((GregorianCalendar)localObject5).get(1));
              localObject13 = ((BigDecimal)localObject3).subtract(new BigDecimal(((Integer)localObject12).intValue())).divide((BigDecimal)localObject4, 2, 2);
              if (((Integer)localObject11).intValue() == 0)
              {
                localBigDecimal3 = ((BigDecimal)localObject8).multiply((BigDecimal)localObject13).multiply(new BigDecimal(((Integer)localObject1).intValue()).divide(new BigDecimal(12), 2, 2));
                localBigDecimal1 = localBigDecimal1.subtract(localBigDecimal3);
              }
              else
              {
                localObject14 = Integer.valueOf(((GregorianCalendar)localObject10).get(1) - ((GregorianCalendar)localObject5).get(1));
                localObject15 = ((BigDecimal)localObject3).subtract(new BigDecimal(((Integer)localObject14).intValue())).divide((BigDecimal)localObject4, 2, 2);
                localObject16 = Integer.valueOf(YEARS - ((GregorianCalendar)localObject10).get(2));
                localBigDecimal3 = ((BigDecimal)localObject8).multiply((BigDecimal)localObject15).multiply(new BigDecimal(((Integer)localObject16).intValue()).divide(new BigDecimal(12), 2, 2));
                localInteger3 = Integer.valueOf(localGregorianCalendar.get(2) + 1);
                localBigDecimal3 = localBigDecimal3.add(((BigDecimal)localObject8).multiply((BigDecimal)localObject13).multiply(new BigDecimal(localInteger3.intValue()).divide(new BigDecimal(12), 2, 2)));
                localBigDecimal1 = localBigDecimal1.subtract(localBigDecimal3);
              }
              localObject14 = new DepreRecord();
              localObject15 = localGregorianCalendar.getTime();
              ((DepreRecord)localObject14).setCalTime((Date)localObject15);
              ((DepreRecord)localObject14).setFixedAssets(localFixedAssets);
              ((DepreRecord)localObject14).setDepreAmount(localBigDecimal3);
              this.depreRecordService.save(localObject14);
            }
          }
        }
      }
      localFixedAssets.setAssetCurValue(localBigDecimal1);
      this.fixedAssetsService.save(localFixedAssets);
      if (localInteger1.intValue() == 0)
        setJsonString("{success:false,message:'还没到折算时间!'}");
      else
        setJsonString("{success:true}");
    }
    else
    {
      setJsonString("{success:false}");
    }
    return (String)(String)(String)(String)(String)(String)(String)(String)(String)(String)(String)(String)(String)(String)(String)(String)"success";
  }

  public String work()
  {
    String str1 = getRequest().getParameter("ids");
    if (StringUtils.isNotEmpty(str1))
    {
      Long localLong = new Long(str1);
      FixedAssets localFixedAssets = (FixedAssets)this.fixedAssetsService.get(localLong);
      Date localDate1 = this.depreRecordService.findMaxDate(localLong);
      if (localDate1 == null)
        localDate1 = localFixedAssets.getStartDepre();
      if (localDate1 != null)
      {
        Integer localInteger = localFixedAssets.getDepreType().getDeprePeriod();
        GregorianCalendar localGregorianCalendar = new GregorianCalendar();
        localGregorianCalendar.setTime(localDate1);
        localGregorianCalendar.add(2, localInteger.intValue());
        Date localDate2 = localGregorianCalendar.getTime();
        if (localDate2.before(new Date()))
        {
          SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
          String str2 = localSimpleDateFormat.format(localDate1);
          String str3 = localSimpleDateFormat.format(localDate2);
          String str4 = localFixedAssets.getWorkGrossUnit();
          BigDecimal localBigDecimal = localFixedAssets.getDefPerWorkGross();
          setJsonString("{success:true,lastCalTime:'" + str2 + "',cruCalTime:'" + str3 + "',workGrossUnit:'" + str4 + "',defPerWorkGross:'" + localBigDecimal.toString() + "'}");
        }
        else
        {
          setJsonString("{success:false,message:'还没到折算时间!'}");
        }
      }
      else
      {
        setJsonString("{success:false,message:'未设定开始执行折算时间!'}");
      }
    }
    else
    {
      setJsonString("{success:false,message:'请联系管理员!'}");
    }
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.admin.DepreRecordAction
 * JD-Core Version:    0.6.0
 */