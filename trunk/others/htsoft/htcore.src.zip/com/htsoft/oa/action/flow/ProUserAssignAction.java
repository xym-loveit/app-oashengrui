package com.htsoft.oa.action.flow;

import com.google.gson.Gson;
import com.htsoft.core.jbpm.jpdl.Node;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.flow.ProDefinition;
import com.htsoft.oa.model.flow.ProUserAssign;
import com.htsoft.oa.service.flow.JbpmService;
import com.htsoft.oa.service.flow.ProDefinitionService;
import com.htsoft.oa.service.flow.ProUserAssignService;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class ProUserAssignAction extends BaseAction
{

  @Resource
  private ProUserAssignService proUserAssignService;

  @Resource
  private JbpmService jbpmService;

  @Resource
  private ProDefinitionService proDefinitionService;
  private ProUserAssign proUserAssign;
  private Long assignId;

  public void setJbpmService(JbpmService paramJbpmService)
  {
    this.jbpmService = paramJbpmService;
  }

  public Long getAssignId()
  {
    return this.assignId;
  }

  public void setAssignId(Long paramLong)
  {
    this.assignId = paramLong;
  }

  public ProUserAssign getProUserAssign()
  {
    return this.proUserAssign;
  }

  public void setProUserAssign(ProUserAssign paramProUserAssign)
  {
    this.proUserAssign = paramProUserAssign;
  }

  public String list()
  {
    Gson localGson = new Gson();
    String str1 = getRequest().getParameter("defId");
    ProDefinition localProDefinition = (ProDefinition)this.proDefinitionService.get(new Long(str1));
    List localList1 = this.jbpmService.getTaskNodesByDefId(new Long(str1));
    List localList2 = this.proUserAssignService.getByDeployId(localProDefinition.getDeployId());
    StringBuffer localStringBuffer = new StringBuffer("{result:[");
    for (int i = 0; i < localList1.size(); i++)
    {
      String str2 = ((Node)localList1.get(i)).getName();
      localStringBuffer.append("{activityName:'").append(str2).append("',deployId:'" + localProDefinition.getDeployId()).append("'");
      for (int j = 0; j < localList2.size(); j++)
      {
        ProUserAssign localProUserAssign = (ProUserAssign)localList2.get(j);
        if (!str2.equals(localProUserAssign.getActivityName()))
          continue;
        localStringBuffer.append(",assignId:'").append(localGson.toJson(localProUserAssign.getAssignId()).replace("\"", "")).append("',userId:'").append(localProUserAssign.getUserId() == null ? "" : localProUserAssign.getUserId()).append("',username:'").append(localGson.toJson(localProUserAssign.getUsername()).replace("\"", "")).append("',roleId:'").append(localProUserAssign.getRoleId() == null ? "" : localProUserAssign.getRoleId()).append("',roleName:'").append(localGson.toJson(localProUserAssign.getRoleName()).replace("\"", "")).append("',jobId:'").append(localProUserAssign.getJobId() == null ? "" : localProUserAssign.getJobId()).append("',jobName:'").append(localProUserAssign.getJobName() == null ? "" : localProUserAssign.getJobName()).append("',reJobId:'").append(localProUserAssign.getReJobId() == null ? "" : localProUserAssign.getReJobId()).append("',reJobName:'").append(localProUserAssign.getReJobName() == null ? "" : localProUserAssign.getReJobName()).append("',isSigned:'").append(localProUserAssign.getIsSigned() == null ? 0 : localProUserAssign.getIsSigned().shortValue()).append("'");
        break;
      }
      localStringBuffer.append("},");
    }
    if (!localList1.isEmpty())
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String get()
  {
    ProUserAssign localProUserAssign = (ProUserAssign)this.proUserAssignService.get(this.assignId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localProUserAssign));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    String str = getRequest().getParameter("data");
    if (StringUtils.isNotEmpty(str))
    {
      Gson localGson = new Gson();
      ProUserAssign[] arrayOfProUserAssign1 = (ProUserAssign[])localGson.fromJson(str, [Lcom.htsoft.oa.model.flow.ProUserAssign.class);
      for (ProUserAssign localProUserAssign : arrayOfProUserAssign1)
      {
        if (localProUserAssign.getAssignId().longValue() == -1L)
          localProUserAssign.setAssignId(null);
        this.proUserAssignService.save(localProUserAssign);
      }
    }
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.flow.ProUserAssignAction
 * JD-Core Version:    0.6.0
 */