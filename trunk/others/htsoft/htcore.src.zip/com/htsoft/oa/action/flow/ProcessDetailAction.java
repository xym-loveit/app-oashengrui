package com.htsoft.oa.action.flow;

import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.flow.ProDefinition;
import com.htsoft.oa.service.flow.ProDefinitionService;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class ProcessDetailAction extends BaseAction
{

  @Resource
  private ProDefinitionService proDefinitionService;
  private ProDefinition proDefinition;

  public ProDefinition getProDefinition()
  {
    return this.proDefinition;
  }

  public void setProDefinition(ProDefinition paramProDefinition)
  {
    this.proDefinition = paramProDefinition;
  }

  public String execute()
    throws Exception
  {
    String str = getRequest().getParameter("defId");
    this.proDefinition = ((ProDefinition)this.proDefinitionService.get(new Long(str)));
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.flow.ProcessDetailAction
 * JD-Core Version:    0.6.0
 */