package com.htsoft.oa.action.personal;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.jbpm.pv.ParamField;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.action.flow.FlowRunInfo;
import com.htsoft.oa.action.flow.ProcessActivityAssistant;
import com.htsoft.oa.model.flow.ProDefinition;
import com.htsoft.oa.model.flow.ProcessForm;
import com.htsoft.oa.model.flow.ProcessModule;
import com.htsoft.oa.model.flow.ProcessRun;
import com.htsoft.oa.model.personal.ErrandsRegister;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.flow.JbpmService;
import com.htsoft.oa.service.flow.ProcessModuleService;
import com.htsoft.oa.service.flow.ProcessRunService;
import com.htsoft.oa.service.personal.ErrandsRegisterService;
import com.htsoft.oa.service.system.AppUserService;
import flexjson.JSONSerializer;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;
import org.jbpm.api.task.Task;

public class ErrandsRegisterAction extends BaseAction
{

  @Resource
  private ProcessRunService processRunService;

  @Resource
  private JbpmService jbpmService;

  @Resource
  private ErrandsRegisterService errandsRegisterService;

  @Resource
  private ProcessModuleService processModuleService;

  @Resource
  private AppUserService appUserService;
  private ErrandsRegister errandsRegister;
  private Long dateId;

  public Long getDateId()
  {
    return this.dateId;
  }

  public void setDateId(Long paramLong)
  {
    this.dateId = paramLong;
  }

  public ErrandsRegister getErrandsRegister()
  {
    return this.errandsRegister;
  }

  public void setErrandsRegister(ErrandsRegister paramErrandsRegister)
  {
    this.errandsRegister = paramErrandsRegister;
  }

  public String list()
  {
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList1 = this.errandsRegisterService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:[");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "startTime", "endTime" });
    Iterator localIterator1 = localList1.iterator();
    while (localIterator1.hasNext())
    {
      ErrandsRegister localErrandsRegister = (ErrandsRegister)localIterator1.next();
      localStringBuffer.append(localJSONSerializer.prettyPrint(true).serialize(localErrandsRegister));
      if (localErrandsRegister.getRunId() != null)
      {
        ProcessRun localProcessRun = (ProcessRun)this.processRunService.get(localErrandsRegister.getRunId());
        if (localProcessRun.getPiId() != null)
        {
          localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
          List localList2 = this.jbpmService.getTasksByPiId(localProcessRun.getPiId());
          localStringBuffer.append(",tasks:[");
          Iterator localIterator2 = localList2.iterator();
          while (localIterator2.hasNext())
          {
            Task localTask = (Task)localIterator2.next();
            localStringBuffer.append("{taskId:").append(localTask.getId()).append(",taskName:").append(localGson.toJson(localTask.getName()));
            if (localTask.getAssignee() != null)
            {
              AppUser localAppUser = (AppUser)this.appUserService.get(new Long(localTask.getAssignee()));
              if (localAppUser != null)
                localStringBuffer.append(",userId:").append(localTask.getAssignee()).append(",fullname:").append(localGson.toJson(localAppUser.getFullname()));
            }
            localStringBuffer.append("},");
          }
          if (localList2.size() > 0)
            localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
          localStringBuffer.append("]");
          localStringBuffer.append("}");
        }
      }
      localStringBuffer.append(",");
    }
    if (localList1.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.errandsRegisterService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    ErrandsRegister localErrandsRegister = (ErrandsRegister)this.errandsRegisterService.get(this.dateId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localErrandsRegister));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    Object localObject;
    if (this.errandsRegister.getDateId() != null)
    {
      localObject = (ErrandsRegister)this.errandsRegisterService.get(this.errandsRegister.getDateId());
      try
      {
        BeanUtil.copyNotNullProperties(localObject, this.errandsRegister);
        this.errandsRegisterService.save(localObject);
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    else
    {
      this.errandsRegister.setAppUser(ContextUtil.getCurrentUser());
      this.errandsRegister.setStatus(Short.valueOf(0));
      this.errandsRegisterService.save(this.errandsRegister);
      localObject = constructStartFlowMap(this.errandsRegister);
      ProcessModule localProcessModule = this.processModuleService.getByKey("ERRANDS_REGISTER");
      ProDefinition localProDefinition = null;
      if (localProcessModule != null)
        localProDefinition = localProcessModule.getProDefinition();
      if (localProDefinition != null)
      {
        ProcessRun localProcessRun = this.processRunService.getInitNewProcessRun(localProDefinition);
        ProcessForm localProcessForm = new ProcessForm();
        localProcessForm.setActivityName("开始");
        localProcessForm.setProcessRun(localProcessRun);
        FlowRunInfo localFlowRunInfo = new FlowRunInfo();
        localFlowRunInfo.setParamFields((Map)localObject);
        localFlowRunInfo.setStartFlow(true);
        localFlowRunInfo.setDefId(localProDefinition.getDefId().toString());
        localFlowRunInfo.getVariables().put("dateId", this.errandsRegister.getDateId());
        localFlowRunInfo.setdAssignId(this.errandsRegister.getApprovalId().toString());
        localProcessRun = this.jbpmService.doStartProcess(localFlowRunInfo);
        this.errandsRegister.setRunId(localProcessRun.getRunId());
        this.errandsRegisterService.save(this.errandsRegister);
      }
      else
      {
        this.logger.error("请假流程没有定义！");
      }
    }
    setJsonString("{success:true}");
    return (String)"success";
  }

  protected Map<String, ParamField> constructStartFlowMap(ErrandsRegister paramErrandsRegister)
  {
    String str1 = "开始";
    String str2 = "请假外出";
    Map localMap = ProcessActivityAssistant.constructFieldMap(str2, str1);
    ParamField localParamField1 = (ParamField)localMap.get("dateId");
    if (localParamField1 != null)
      localParamField1.setValue(paramErrandsRegister.getDateId().toString());
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    ParamField localParamField2 = (ParamField)localMap.get("reqDesc");
    if (localParamField2 != null)
      localParamField2.setValue(paramErrandsRegister.getDescp());
    ParamField localParamField3 = (ParamField)localMap.get("startTime");
    if (localParamField3 != null)
      localParamField3.setValue(localSimpleDateFormat.format(paramErrandsRegister.getStartTime()));
    ParamField localParamField4 = (ParamField)localMap.get("endTime");
    if (localParamField4 != null)
      localParamField4.setValue(localSimpleDateFormat.format(paramErrandsRegister.getEndTime()));
    ParamField localParamField5 = (ParamField)localMap.get("approvalName");
    if (localParamField5 != null)
      localParamField5.setValue(paramErrandsRegister.getApprovalName());
    return localMap;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.personal.ErrandsRegisterAction
 * JD-Core Version:    0.6.0
 */