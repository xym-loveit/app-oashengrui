package com.htsoft.oa.action.admin;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.admin.ConfSummary;
import com.htsoft.oa.model.admin.Conference;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.admin.ConfSummaryService;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class ConfSummaryAction extends BaseAction
{

  @Resource
  private ConfSummaryService confSummaryService;
  private ConfSummary confSummary;
  private Long sumId;
  private Date endtime;
  private String fileIds;

  public String getFileIds()
  {
    return this.fileIds;
  }

  public void setFileIds(String paramString)
  {
    this.fileIds = paramString;
  }

  public Date getEndtime()
  {
    return this.endtime;
  }

  public void setEndtime(Date paramDate)
  {
    this.endtime = paramDate;
  }

  public Long getSumId()
  {
    return this.sumId;
  }

  public void setSumId(Long paramLong)
  {
    this.sumId = paramLong;
  }

  public ConfSummary getConfSummary()
  {
    return this.confSummary;
  }

  public void setConfSummary(ConfSummary paramConfSummary)
  {
    this.confSummary = paramConfSummary;
  }

  public String list()
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyy-MM-dd HH:mm:ss");
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    if (this.endtime != null)
      localQueryFilter.addFilter("Q_createtime_D_LE", localSimpleDateFormat.format(this.endtime));
    List localList = this.confSummaryService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.confSummaryService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String del()
  {
    String str = getRequest().getParameter("sumId");
    this.confSummaryService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    ConfSummary localConfSummary = (ConfSummary)this.confSummaryService.get(this.sumId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localConfSummary));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String send()
  {
    String str = this.confSummary.getSumContent();
    if ((str == null) || (str.isEmpty()) || (str.equals(" ")))
    {
      setJsonString("{failure:true,msg:'读不起，会议纪要内容不能为空，请输入！'}");
    }
    else
    {
      this.confSummary.setCreatetime(new Date());
      this.confSummary.setCreator(ContextUtil.getCurrentUser().getUsername());
      this.confSummary.setStatus(Short.valueOf(1));
      this.confSummaryService.send(this.confSummary, this.fileIds);
      setJsonString("{success:true}");
    }
    return "success";
  }

  public String save()
  {
    String str = this.confSummary.getSumContent();
    if ((str == null) || (str.isEmpty()) || (str.equals(" ")))
    {
      setJsonString("{failure:true,msg:'对不起，会议纪要内容不能为空，请重新输入！'}");
    }
    else
    {
      this.confSummary.setCreatetime(new Date());
      this.confSummary.setCreator(ContextUtil.getCurrentUser().getUsername());
      this.confSummary.setStatus(Short.valueOf(0));
      this.confSummaryService.save(this.confSummary, this.fileIds);
      setJsonString("{success:true}");
    }
    return "success";
  }

  public String edit()
  {
    this.confSummaryService.save(this.confSummary, this.fileIds);
    setJsonString("{success:true}");
    return "success";
  }

  public String display()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_status_SN_EQ", "1");
    localQueryFilter.addSorted("createtime", "DESC");
    List localList = this.confSummaryService.getAll(localQueryFilter);
    for (int i = 0; i < localList.size(); i++)
    {
      ConfSummary localConfSummary = (ConfSummary)localList.get(i);
      Conference localConference = localConfSummary.getConfId();
      if ((localConfSummary.getStatus().shortValue() != 1) && (myConfSummary(localConference.getCompere())) && (myConfSummary(localConference.getRecorder())) && (myConfSummary(localConference.getAttendUsers())))
        localList.remove(i);
      if (i <= 7)
        continue;
      for (int j = 8; j < localList.size(); j++)
        localList.remove(j);
    }
    getRequest().setAttribute("confSummaryList", localList);
    return "display";
  }

  private boolean myConfSummary(String paramString)
  {
    int i = 1;
    Long localLong = ContextUtil.getCurrentUserId();
    int j = paramString.indexOf(localLong.toString());
    if ((j > 1) && (paramString.substring(j - 1, j).equals(",")))
      i = 0;
    else if (j == 0)
      i = 0;
    return i;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.admin.ConfSummaryAction
 * JD-Core Version:    0.6.0
 */