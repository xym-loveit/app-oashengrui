package com.htsoft.oa.action.system;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.AppUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.system.Department;
import com.htsoft.oa.service.system.AppUserService;
import com.htsoft.oa.service.system.DepartmentService;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class DepartmentAction extends BaseAction
{
  private Department department;

  @Resource
  private DepartmentService departmentService;

  @Resource
  private AppUserService appUserService;

  public Department getDepartment()
  {
    return this.department;
  }

  public void setDepartment(Department paramDepartment)
  {
    this.department = paramDepartment;
  }

  public String select()
  {
    String str = getRequest().getParameter("depId");
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    if ((StringUtils.isNotEmpty(str)) && (!"0".equals(str)))
    {
      this.department = ((Department)this.departmentService.get(new Long(str)));
      localQueryFilter.addFilter("Q_path_S_LFK", this.department.getPath());
    }
    localQueryFilter.addSorted("path", "asc");
    List localList = this.departmentService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String list()
  {
    String str = getRequest().getParameter("opt");
    StringBuffer localStringBuffer = new StringBuffer();
    if (StringUtils.isNotEmpty(str))
      localStringBuffer.append("[");
    else
      localStringBuffer.append("[{id:'0',text:'" + AppUtil.getCompanyName() + "',expanded:true,children:[");
    List localList = this.departmentService.findByParentId(new Long(0L));
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Department localDepartment = (Department)localIterator.next();
      localStringBuffer.append("{id:'" + localDepartment.getDepId() + "',text:'" + localDepartment.getDepName() + "',");
      localStringBuffer.append(findChild(localDepartment.getDepId()));
    }
    if (!localList.isEmpty())
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    if (StringUtils.isNotEmpty(str))
      localStringBuffer.append("]");
    else
      localStringBuffer.append("]}]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String findChild(Long paramLong)
  {
    StringBuffer localStringBuffer = new StringBuffer("");
    List localList = this.departmentService.findByParentId(paramLong);
    if (localList.size() == 0)
    {
      localStringBuffer.append("leaf:true},");
      return localStringBuffer.toString();
    }
    localStringBuffer.append("children:[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Department localDepartment = (Department)localIterator.next();
      localStringBuffer.append("{id:'" + localDepartment.getDepId() + "',text:'" + localDepartment.getDepName() + "',");
      localStringBuffer.append(findChild(localDepartment.getDepId()));
    }
    localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]},");
    return localStringBuffer.toString();
  }

  public String add()
  {
    Long localLong = this.department.getParentId();
    String str = "";
    int i = 0;
    if (localLong.longValue() < 1L)
    {
      localLong = new Long(0L);
      str = "0.";
    }
    else
    {
      str = ((Department)this.departmentService.get(localLong)).getPath();
      i = ((Department)this.departmentService.get(localLong)).getDepLevel().intValue();
    }
    if (i < 1)
      i = 1;
    this.department.setDepLevel(Integer.valueOf(i + 1));
    this.departmentService.save(this.department);
    if (this.department != null)
    {
      str = str + this.department.getDepId().toString() + ".";
      this.department.setPath(str);
      this.departmentService.save(this.department);
      setJsonString("{success:true}");
    }
    else
    {
      setJsonString("{success:false}");
    }
    return "success";
  }

  public String remove()
  {
    PagingBean localPagingBean = getInitPagingBean();
    Long localLong = Long.valueOf(Long.parseLong(getRequest().getParameter("depId")));
    Department localDepartment1 = (Department)this.departmentService.get(localLong);
    List localList1 = this.appUserService.findByDepartment(localDepartment1.getPath(), localPagingBean);
    if (localList1.size() > 0)
    {
      setJsonString("{success:false,message:'该部门还有人员，请将人员转移后再删除部门!'}");
      return "success";
    }
    this.departmentService.remove(localLong);
    List localList2 = this.departmentService.findByParentId(localLong);
    Iterator localIterator = localList2.iterator();
    while (localIterator.hasNext())
    {
      Department localDepartment2 = (Department)localIterator.next();
      List localList3 = this.appUserService.findByDepartment(localDepartment2.getPath(), localPagingBean);
      if (localList3.size() > 0)
      {
        setJsonString("{success:false,message:'该部门还有人员，请将人员转移后再删除部门!'}");
        return "success";
      }
      this.departmentService.remove(localDepartment2.getDepId());
    }
    setJsonString("{success:true}");
    return "success";
  }

  public String detail()
  {
    Long localLong = Long.valueOf(Long.parseLong(getRequest().getParameter("depId")));
    setDepartment((Department)this.departmentService.get(localLong));
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:[");
    localStringBuffer.append(localGson.toJson(this.department));
    localStringBuffer.append("]}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.DepartmentAction
 * JD-Core Version:    0.6.0
 */