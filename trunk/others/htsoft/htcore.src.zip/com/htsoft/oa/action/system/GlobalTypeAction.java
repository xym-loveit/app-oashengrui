package com.htsoft.oa.action.system;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.GlobalType;
import com.htsoft.oa.service.system.GlobalTypeService;
import java.io.PrintStream;
import java.lang.reflect.Type;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;

public class GlobalTypeAction extends BaseAction
{

  @Resource
  private GlobalTypeService globalTypeService;
  private GlobalType globalType;
  private Long proTypeId;
  private String catKey = "PT";

  public String getCatKey()
  {
    return this.catKey;
  }

  public void setCatKey(String paramString)
  {
    this.catKey = paramString;
  }

  public Long getProTypeId()
  {
    return this.proTypeId;
  }

  public void setProTypeId(Long paramLong)
  {
    this.proTypeId = paramLong;
  }

  public GlobalType getGlobalType()
  {
    return this.globalType;
  }

  public void setGlobalType(GlobalType paramGlobalType)
  {
    this.globalType = paramGlobalType;
  }

  public String sub()
  {
    Long localLong = null;
    String str = getRequest().getParameter("parentId");
    if (StringUtils.isNotEmpty(str))
      localLong = new Long(str);
    List localList = this.globalTypeService.getByParentIdCatKey(localLong, this.catKey);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String mulSave()
  {
    String str = getRequest().getParameter("data");
    this.logger.info("data:" + str);
    if (StringUtils.isNotEmpty(str))
    {
      Gson localGson = new Gson();
      GlobalType[] arrayOfGlobalType = (GlobalType[])localGson.fromJson(str, [Lcom.htsoft.oa.model.system.GlobalType.class);
      for (int i = 0; i < arrayOfGlobalType.length; i++)
      {
        GlobalType localGlobalType = (GlobalType)this.globalTypeService.get(arrayOfGlobalType[i].getProTypeId());
        try
        {
          BeanUtil.copyNotNullProperties(localGlobalType, arrayOfGlobalType[i]);
          localGlobalType.setSn(Integer.valueOf(i + 1));
          this.globalTypeService.save(localGlobalType);
        }
        catch (Exception localException)
        {
          this.logger.error(localException.getMessage());
        }
      }
    }
    this.jsonString = "{success:true}";
    return "success";
  }

  public String tree()
  {
    StringBuffer localStringBuffer = new StringBuffer("[{id:'0',text:'总分类',expanded:true,children:[");
    List localList = this.globalTypeService.getByParentIdCatKey(new Long(0L), this.catKey);
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      GlobalType localGlobalType = (GlobalType)localIterator.next();
      localStringBuffer.append("{id:'" + localGlobalType.getProTypeId()).append("',text:'" + localGlobalType.getTypeName()).append("',");
      localStringBuffer.append(getChildType(localGlobalType.getProTypeId(), this.catKey));
    }
    if (!localList.isEmpty())
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}]");
    setJsonString(localStringBuffer.toString());
    this.logger.info("tree json:" + localStringBuffer.toString());
    return "success";
  }

  public String proTree()
  {
    StringBuffer localStringBuffer = new StringBuffer("[{id:'0',text:'总分类',expanded:true,children:[");
    List localList = this.globalTypeService.getByParentIdCatKey(new Long(0L), this.catKey);
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      GlobalType localGlobalType = (GlobalType)localIterator.next();
      localStringBuffer.append("{id:'" + localGlobalType.getProTypeId()).append("',text:'" + localGlobalType.getTypeName()).append("',");
      localStringBuffer.append("leaf:true,expanded:true},");
    }
    if (!localList.isEmpty())
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}]");
    setJsonString(localStringBuffer.toString());
    this.logger.info("tree json:" + localStringBuffer.toString());
    return "success";
  }

  public String pwTree()
  {
    StringBuffer localStringBuffer = new StringBuffer("[{id:'0',text:'总分类',expanded:true,children:[");
    List localList = this.globalTypeService.getByParentIdCatKeyUserId(new Long(0L), this.catKey, ContextUtil.getCurrentUserId());
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      GlobalType localGlobalType = (GlobalType)localIterator.next();
      localStringBuffer.append("{id:'" + localGlobalType.getProTypeId()).append("',text:'" + localGlobalType.getTypeName()).append("',");
      localStringBuffer.append("leaf:true,expanded:true},");
    }
    if (!localList.isEmpty())
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}]");
    setJsonString(localStringBuffer.toString());
    this.logger.info("tree json:" + localStringBuffer.toString());
    return "success";
  }

  public String combo()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    List localList = this.globalTypeService.getByParentIdCatKeyUserId(new Long(0L), this.catKey, ContextUtil.getCurrentUserId());
    localStringBuffer.append("[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      GlobalType localGlobalType = (GlobalType)localIterator.next();
      localStringBuffer.append("['").append(localGlobalType.getProTypeId()).append("','").append(localGlobalType.getTypeName()).append("'],");
    }
    if (localList.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String getChildType(Long paramLong, String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    List localList = this.globalTypeService.getByParentIdCatKey(paramLong, paramString);
    if (localList.size() == 0)
    {
      localStringBuffer.append("leaf:true,expanded:true},");
      return localStringBuffer.toString();
    }
    localStringBuffer.append("expanded:true,children:[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      GlobalType localGlobalType = (GlobalType)localIterator.next();
      localStringBuffer.append("{id:'" + localGlobalType.getProTypeId()).append("',text:'" + localGlobalType.getTypeName()).append("',");
      localStringBuffer.append(getChildType(localGlobalType.getProTypeId(), paramString));
    }
    localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]},");
    return localStringBuffer.toString();
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.globalTypeService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.globalTypeService.mulDel(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    GlobalType localGlobalType = (GlobalType)this.globalTypeService.get(this.proTypeId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localGlobalType));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    Object localObject1;
    if ((this.globalType != null) && (this.globalType.getProTypeId() != null))
    {
      localObject1 = (GlobalType)this.globalTypeService.get(this.globalType.getProTypeId());
      try
      {
        BeanUtil.copyNotNullProperties(localObject1, this.globalType);
        this.globalTypeService.save(localObject1);
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    else
    {
      localObject1 = "0.";
      int i = 1;
      if ((this.globalType != null) && (this.globalType.getParentId() != null) && (this.globalType.getParentId().longValue() != 0L))
      {
        localObject2 = (GlobalType)this.globalTypeService.get(this.globalType.getParentId());
        if (localObject2 != null)
        {
          localObject1 = ((GlobalType)localObject2).getPath();
          i = ((GlobalType)localObject2).getDepth().intValue() + 1;
        }
      }
      this.globalType.setDepth(Integer.valueOf(i));
      Object localObject2 = this.globalTypeService.getCountsByParentId(this.globalType.getParentId());
      this.globalType.setSn(Integer.valueOf(((Integer)localObject2).intValue() + 1));
      this.globalTypeService.save(this.globalType);
      this.globalType.setPath((String)localObject1 + this.globalType.getProTypeId() + ".");
      this.globalTypeService.save(this.globalType);
    }
    setJsonString("{success:true}");
    return (String)(String)"success";
  }

  public String flowTree()
  {
    StringBuffer localStringBuffer = new StringBuffer("[{id:'0',text:'总分类',expanded:true,children:[");
    AppUser localAppUser = ContextUtil.getCurrentUser();
    List localList = null;
    if (localAppUser.isSupperManage())
      localList = this.globalTypeService.getByParentIdCatKey(new Long(0L), this.catKey);
    else
      localList = this.globalTypeService.getByRightsCatKey(localAppUser, this.catKey);
    HashSet localHashSet = new HashSet();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      GlobalType localGlobalType = (GlobalType)localIterator.next();
      if (!localHashSet.contains(localGlobalType))
      {
        localHashSet.add(localGlobalType);
        localStringBuffer.append("{id:'" + localGlobalType.getProTypeId()).append("',text:'" + localGlobalType.getTypeName()).append("',");
        localStringBuffer.append(getTypeByRights(localGlobalType.getProTypeId(), this.catKey, localHashSet));
      }
    }
    if (!localList.isEmpty())
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}]");
    setJsonString(localStringBuffer.toString());
    this.logger.info("tree json:" + localStringBuffer.toString());
    return "success";
  }

  private String getTypeByRights(Long paramLong, String paramString, Set<GlobalType> paramSet)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    List localList = this.globalTypeService.getByParentIdCatKey(paramLong, paramString);
    if (localList.size() == 0)
    {
      localStringBuffer.append("leaf:true,expanded:true},");
      return localStringBuffer.toString();
    }
    localStringBuffer.append("expanded:true,children:[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      GlobalType localGlobalType = (GlobalType)localIterator.next();
      if (!paramSet.contains(localGlobalType))
      {
        paramSet.add(localGlobalType);
        System.out.println(localGlobalType.getPath());
        localStringBuffer.append("{id:'" + localGlobalType.getProTypeId()).append("',text:'" + localGlobalType.getTypeName()).append("',");
        localStringBuffer.append(getTypeByRights(localGlobalType.getProTypeId(), paramString, paramSet));
      }
      else
      {
        System.out.print("已经存在" + localGlobalType.getTypeName());
      }
    }
    localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]},");
    return localStringBuffer.toString();
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.GlobalTypeAction
 * JD-Core Version:    0.6.0
 */