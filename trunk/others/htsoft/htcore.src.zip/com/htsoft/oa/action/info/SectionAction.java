package com.htsoft.oa.action.info;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.info.Section;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.SysConfig;
import com.htsoft.oa.service.info.SectionService;
import com.htsoft.oa.service.system.SysConfigService;
import java.lang.reflect.Type;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;

public class SectionAction extends BaseAction
{

  @Resource
  private SectionService sectionService;

  @Resource
  private SysConfigService sysConfigService;
  private Section section;
  private Long sectionId;

  public Long getSectionId()
  {
    return this.sectionId;
  }

  public void setSectionId(Long paramLong)
  {
    this.sectionId = paramLong;
  }

  public Section getSection()
  {
    return this.section;
  }

  public void setSection(Section paramSection)
  {
    this.section = paramSection;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addSorted("rowNumber", "asc");
    List localList = this.sectionService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    SysConfig localSysConfig = this.sysConfigService.findByKey("sectionColumn");
    localStringBuffer.append(",columnType:");
    if (localSysConfig != null)
      localStringBuffer.append(localSysConfig.getDataValue());
    else
      localStringBuffer.append("2");
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.sectionService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    Section localSection = (Section)this.sectionService.get(this.sectionId);
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setDateFormat("yyyy-MM-dd").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localSection));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    StringBuffer localStringBuffer = new StringBuffer("{success:true");
    Object localObject;
    if (this.section.getSectionId() == null)
    {
      localObject = ContextUtil.getCurrentUser();
      this.section.setCreatetime(new Date());
      this.section.setUserId(((AppUser)localObject).getUserId());
      this.section.setUsername(((AppUser)localObject).getFullname());
      this.section.setColNumber(Section.COLUMN_ONE);
      this.section.setRowNumber(Integer.valueOf(this.sectionService.getLastColumn().intValue() + 1));
      this.sectionService.save(this.section);
      Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setDateFormat("yyyy-MM-dd").create();
      localStringBuffer.append(",data:").append(localGson.toJson(this.section)).append("}");
    }
    else
    {
      localStringBuffer.append("}");
      localObject = (Section)this.sectionService.get(this.section.getSectionId());
      try
      {
        BeanUtil.copyNotNullProperties(localObject, this.section);
        this.sectionService.save(localObject);
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    setJsonString(localStringBuffer.toString());
    return (String)"success";
  }

  public String disable()
  {
    String str = getRequest().getParameter("sectionId");
    if (StringUtils.isNotEmpty(str))
      this.section = ((Section)this.sectionService.get(new Long(str)));
    if (this.section != null)
    {
      this.section.setStatus(Section.STATUS_DISABLE);
      this.sectionService.save(this.section);
    }
    setJsonString("{success:true}");
    return "success";
  }

  public String enable()
  {
    String str1 = getRequest().getParameter("secIds");
    if (StringUtils.isNotEmpty(str1))
    {
      String[] arrayOfString1 = str1.split(",");
      for (String str2 : arrayOfString1)
      {
        this.section = ((Section)this.sectionService.get(new Long(str2)));
        if (this.section == null)
          continue;
        this.section.setStatus(Section.STATUS_ENABLE);
        this.sectionService.save(this.section);
      }
    }
    setJsonString("{success:true}");
    return "success";
  }

  public String position()
  {
    String str = getRequest().getParameter("sections");
    Gson localGson = new Gson();
    Section[] arrayOfSection1 = (Section[])localGson.fromJson(str, [Lcom.htsoft.oa.model.info.Section.class);
    AppUser localAppUser = ContextUtil.getCurrentUser();
    for (Section localSection1 : arrayOfSection1)
    {
      Section localSection2 = (Section)this.sectionService.get(localSection1.getSectionId());
      localSection2.setColNumber(localSection1.getColNumber());
      localSection2.setRowNumber(localSection1.getRowNumber());
      localSection2.setStatus(Section.STATUS_ENABLE);
      this.sectionService.save(localSection2);
    }
    setJsonString("{success:true}");
    return "success";
  }

  public String column()
  {
    String str = getRequest().getParameter("columnType");
    SysConfig localSysConfig = this.sysConfigService.findByKey("sectionColumn");
    if (localSysConfig == null)
    {
      localSysConfig = new SysConfig();
      localSysConfig.setConfigDesc("栏目列数配置");
      localSysConfig.setConfigKey("sectionColumn");
      localSysConfig.setConfigName("栏目列数");
      localSysConfig.setDataType(SysConfig.SYS_DATA_TYPE_INTEGER);
      localSysConfig.setDataValue(str);
      localSysConfig.setTypeKey("sectionColumn");
      localSysConfig.setTypeName("栏目列数配置");
      this.sysConfigService.save(localSysConfig);
    }
    else
    {
      localSysConfig.setDataValue(str);
      this.sysConfigService.save(localSysConfig);
    }
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.info.SectionAction
 * JD-Core Version:    0.6.0
 */