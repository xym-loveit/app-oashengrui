package com.htsoft.oa.action.hrm;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.hrm.EmpProfile;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.hrm.EmpProfileService;
import flexjson.JSONSerializer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class EmpProfileAction extends BaseAction
{

  @Resource
  private EmpProfileService empProfileService;
  private EmpProfile empProfile;
  private Long profileId;

  public Long getProfileId()
  {
    return this.profileId;
  }

  public void setProfileId(Long paramLong)
  {
    this.profileId = paramLong;
  }

  public EmpProfile getEmpProfile()
  {
    return this.empProfile;
  }

  public void setEmpProfile(EmpProfile paramEmpProfile)
  {
    this.empProfile = paramEmpProfile;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.empProfileService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "birthday", "startWorkDate", "checktime", "createtime" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class", "job.class", "job.department" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
      {
        EmpProfile localEmpProfile = (EmpProfile)this.empProfileService.get(new Long(str));
        localEmpProfile.setDelFlag(Short.valueOf(EmpProfile.DELETE_FLAG_HAD));
        this.empProfileService.save(localEmpProfile);
      }
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    EmpProfile localEmpProfile = (EmpProfile)this.empProfileService.get(this.profileId);
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "birthday", "startWorkDate", "createtime", "checktime" });
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:[");
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class", "department" }).serialize(localEmpProfile));
    localStringBuffer.append("]}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    int i = 0;
    StringBuffer localStringBuffer = new StringBuffer("{");
    if (this.empProfile.getProfileId() == null)
    {
      if (this.empProfileService.checkProfileNo(this.empProfile.getProfileNo()))
      {
        this.empProfile.setCreator(ContextUtil.getCurrentUser().getFullname());
        this.empProfile.setCreatetime(new Date());
        this.empProfile.setDelFlag(Short.valueOf(EmpProfile.DELETE_FLAG_NOT));
        i = 1;
      }
      else
      {
        localStringBuffer.append("msg:'档案编号已存在,请重新输入.',");
      }
    }
    else
      i = 1;
    if (i != 0)
    {
      this.empProfile.setApprovalStatus(Short.valueOf(EmpProfile.CHECK_FLAG_NONE));
      this.empProfileService.save(this.empProfile);
      localStringBuffer.append("success:true}");
    }
    else
    {
      localStringBuffer.append("failure:true}");
    }
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String number()
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss-SSSS");
    String str = localSimpleDateFormat.format(new Date());
    setJsonString("{success:true,profileNo:'PN" + str + "'}");
    return "success";
  }

  public String check()
  {
    EmpProfile localEmpProfile = (EmpProfile)this.empProfileService.get(this.profileId);
    localEmpProfile.setCheckName(ContextUtil.getCurrentUser().getFullname());
    localEmpProfile.setChecktime(new Date());
    localEmpProfile.setApprovalStatus(this.empProfile.getApprovalStatus());
    localEmpProfile.setOpprovalOpinion(this.empProfile.getOpprovalOpinion());
    this.empProfileService.save(localEmpProfile);
    return "success";
  }

  public String recovery()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
      {
        EmpProfile localEmpProfile = (EmpProfile)this.empProfileService.get(new Long(str));
        localEmpProfile.setDelFlag(Short.valueOf(EmpProfile.DELETE_FLAG_NOT));
        this.empProfileService.save(localEmpProfile);
      }
    this.jsonString = "{success:true}";
    return "success";
  }

  public String delphoto()
  {
    if (this.profileId != null)
    {
      this.empProfile = ((EmpProfile)this.empProfileService.get(this.profileId));
      this.empProfile.setPhoto("");
      this.empProfileService.save(this.empProfile);
      this.jsonString = "{success:true}";
    }
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.hrm.EmpProfileAction
 * JD-Core Version:    0.6.0
 */