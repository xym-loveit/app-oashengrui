package com.htsoft.oa.action.document;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.log.Action;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.document.DocFolder;
import com.htsoft.oa.model.document.DocPrivilege;
import com.htsoft.oa.model.document.Document;
import com.htsoft.oa.model.document.DocumentFile;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.FileAttach;
import com.htsoft.oa.service.document.DocFolderService;
import com.htsoft.oa.service.document.DocPrivilegeService;
import com.htsoft.oa.service.document.DocumentService;
import java.lang.reflect.Type;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;

public class DocFolderAction extends BaseAction
{

  @Resource
  private DocFolderService docFolderService;

  @Resource
  private DocPrivilegeService docPrivilegeService;

  @Resource
  private DocumentService documentService;
  private DocFolder docFolder;
  private Integer folderNum = Integer.valueOf(0);
  private Integer documentNum = Integer.valueOf(0);
  private Integer attachsNum = Integer.valueOf(0);
  private double filesize = 0.0D;
  private Long folderId;
  private static Integer ALL_RIGHT = Integer.valueOf(7);
  private static Integer NOT_RIGHT = Integer.valueOf(0);
  private static Long ISPARENT = Long.valueOf(0L);

  public Long getFolderId()
  {
    return this.folderId;
  }

  public void setFolderId(Long paramLong)
  {
    this.folderId = paramLong;
  }

  public DocFolder getDocFolder()
  {
    return this.docFolder;
  }

  public void setDocFolder(DocFolder paramDocFolder)
  {
    this.docFolder = paramDocFolder;
  }

  public String list()
  {
    String str = getRequest().getParameter("method");
    StringBuffer localStringBuffer = new StringBuffer();
    int i = 0;
    if (StringUtils.isNotEmpty(str))
    {
      localStringBuffer.append("[");
      i = 1;
    }
    else
    {
      localStringBuffer.append("[{id:'0',text:'我的文件夹',expanded:true,children:[");
    }
    Long localLong = ContextUtil.getCurrentUserId();
    List localList = this.docFolderService.getUserFolderByParentId(localLong, Long.valueOf(0L));
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      DocFolder localDocFolder = (DocFolder)localIterator.next();
      localStringBuffer.append("{id:'" + localDocFolder.getFolderId()).append("',expanded:true,text:'" + localDocFolder.getFolderName()).append("',");
      localStringBuffer.append(findChildsFolder(localLong, localDocFolder.getFolderId()));
    }
    if (!localList.isEmpty())
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    if (i == 1)
      localStringBuffer.append("]");
    else
      localStringBuffer.append("]}]");
    setJsonString(localStringBuffer.toString());
    this.logger.info("tree json:" + localStringBuffer.toString());
    return "success";
  }

  public String tree()
  {
    StringBuffer localStringBuffer = new StringBuffer("[{id:'0',text:'知识目录',expanded:true,children:[");
    List localList = this.docFolderService.getPublicFolderByParentId(Long.valueOf(0L));
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      DocFolder localDocFolder = (DocFolder)localIterator.next();
      localStringBuffer.append("{id:'" + localDocFolder.getFolderId()).append("',text:'" + localDocFolder.getFolderName()).append("',expanded:true,");
      localStringBuffer.append(findChildsFolder(localDocFolder.getFolderId()));
    }
    if (!localList.isEmpty())
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}]");
    setJsonString(localStringBuffer.toString());
    this.logger.info("tree json:" + localStringBuffer.toString());
    return "success";
  }

  public String select()
  {
    AppUser localAppUser = ContextUtil.getCurrentUser();
    StringBuffer localStringBuffer = new StringBuffer("[{id:'0',text:'公共文件夹',expanded:true,children:[");
    List localList1 = this.docFolderService.getPublicFolderByParentId(Long.valueOf(0L));
    Iterator localIterator = localList1.iterator();
    while (localIterator.hasNext())
    {
      DocFolder localDocFolder = (DocFolder)localIterator.next();
      List localList2 = this.docPrivilegeService.getRightsByFolder(localAppUser, localDocFolder.getFolderId());
      Integer localInteger1 = NOT_RIGHT;
      Object localObject = localList2.iterator();
      while (((Iterator)localObject).hasNext())
      {
        Integer localInteger2 = (Integer)((Iterator)localObject).next();
        localInteger1 = Integer.valueOf(localInteger1.intValue() | localInteger2.intValue());
      }
      localObject = localAppUser.getRights();
      if (((Set)localObject).contains("__ALL"))
        localInteger1 = ALL_RIGHT;
      if (localInteger1 == NOT_RIGHT)
      {
        localStringBuffer.append("{id:'" + localDocFolder.getFolderId()).append("',disabled:true,text:'" + localDocFolder.getFolderName()).append("',expanded:true,");
        localStringBuffer.append(findChildsFolderByRight(localDocFolder.getFolderId(), localInteger1, false));
      }
      else
      {
        localStringBuffer.append("{id:'" + localDocFolder.getFolderId()).append("',text:'" + localDocFolder.getFolderName()).append("',expanded:true,");
        if (localInteger1 == ALL_RIGHT)
          localStringBuffer.append(findChildsFolderByRight(localDocFolder.getFolderId(), localInteger1, true));
        else
          localStringBuffer.append(findChildsFolderByRight(localDocFolder.getFolderId(), localInteger1, false));
      }
    }
    if (!localList1.isEmpty())
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}]");
    setJsonString(localStringBuffer.toString());
    return (String)"success";
  }

  public String share()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_isShared_SN_EQ", "1");
    List localList = this.docFolderService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String findChildsFolder(Long paramLong1, Long paramLong2)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    List localList = this.docFolderService.getUserFolderByParentId(paramLong1, paramLong2);
    if (localList.size() == 0)
    {
      localStringBuffer.append("children:[],expanded:true},");
      return localStringBuffer.toString();
    }
    localStringBuffer.append("children:[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      DocFolder localDocFolder = (DocFolder)localIterator.next();
      localStringBuffer.append("{id:'" + localDocFolder.getFolderId() + "',text:'" + localDocFolder.getFolderName() + "',expanded:true,");
      localStringBuffer.append(findChildsFolder(paramLong1, localDocFolder.getFolderId()));
    }
    localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]},");
    return localStringBuffer.toString();
  }

  public String findChildsFolder(Long paramLong)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    List localList = this.docFolderService.getPublicFolderByParentId(paramLong);
    if (localList.size() == 0)
    {
      localStringBuffer.append("leaf:true,expanded:true},");
      return localStringBuffer.toString();
    }
    localStringBuffer.append("children:[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      DocFolder localDocFolder = (DocFolder)localIterator.next();
      localStringBuffer.append("{id:'" + localDocFolder.getFolderId() + "',text:'" + localDocFolder.getFolderName() + "',expanded:true,");
      localStringBuffer.append(findChildsFolder(localDocFolder.getFolderId()));
    }
    localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]},");
    return localStringBuffer.toString();
  }

  public String findChildsFolderByRight(Long paramLong, Integer paramInteger, boolean paramBoolean)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    List localList1 = this.docFolderService.getPublicFolderByParentId(paramLong);
    if (localList1.size() == 0)
    {
      localStringBuffer.append("leaf:true,expanded:true},");
      return localStringBuffer.toString();
    }
    localStringBuffer.append("children:[");
    Iterator localIterator1 = localList1.iterator();
    while (localIterator1.hasNext())
    {
      DocFolder localDocFolder = (DocFolder)localIterator1.next();
      Integer localInteger1 = paramInteger;
      if (paramBoolean)
      {
        localInteger1 = ALL_RIGHT;
      }
      else if (localInteger1 != NOT_RIGHT)
      {
        localInteger1 = NOT_RIGHT;
        AppUser localAppUser = ContextUtil.getCurrentUser();
        List localList2 = this.docPrivilegeService.getRightsByFolder(localAppUser, localDocFolder.getFolderId());
        Iterator localIterator2 = localList2.iterator();
        while (localIterator2.hasNext())
        {
          Integer localInteger2 = (Integer)localIterator2.next();
          localInteger1 = Integer.valueOf(localInteger1.intValue() | localInteger2.intValue());
        }
      }
      if (localInteger1 == NOT_RIGHT)
      {
        localStringBuffer.append("{id:'" + localDocFolder.getFolderId() + "',disabled:true,text:'" + localDocFolder.getFolderName() + "',expanded:true,");
        localStringBuffer.append(findChildsFolderByRight(localDocFolder.getFolderId(), localInteger1, paramBoolean));
      }
      else
      {
        localStringBuffer.append("{id:'" + localDocFolder.getFolderId() + "',text:'" + localDocFolder.getFolderName() + "',expanded:true,");
        localStringBuffer.append(findChildsFolderByRight(localDocFolder.getFolderId(), localInteger1, paramBoolean));
      }
    }
    localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]},");
    return localStringBuffer.toString();
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.docFolderService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String remove()
  {
    String str = getRequest().getParameter("folderId");
    if (StringUtils.isNotEmpty(str))
    {
      DocFolder localDocFolder1 = (DocFolder)this.docFolderService.get(new Long(str));
      List localList1 = this.docFolderService.getFolderLikePath(localDocFolder1.getPath());
      Iterator localIterator1 = localList1.iterator();
      while (localIterator1.hasNext())
      {
        DocFolder localDocFolder2 = (DocFolder)localIterator1.next();
        List localList2 = this.documentService.findByFolder(localDocFolder2.getPath());
        if (localList2.size() > 0)
        {
          this.jsonString = "{success:false,message:'该目录下还有文档，请把文件删除后删除该目录'}";
          return "success";
        }
        QueryFilter localQueryFilter = new QueryFilter(getRequest());
        localQueryFilter.addFilter("Q_docFolder.folderId_L_EQ", localDocFolder2.getFolderId().toString());
        List localList3 = this.docPrivilegeService.getAll(localQueryFilter);
        Iterator localIterator2 = localList3.iterator();
        while (localIterator2.hasNext())
        {
          DocPrivilege localDocPrivilege = (DocPrivilege)localIterator2.next();
          this.docPrivilegeService.remove(localDocPrivilege);
        }
        this.docFolderService.remove(localDocFolder2.getFolderId());
      }
    }
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    DocFolder localDocFolder = (DocFolder)this.docFolderService.get(this.folderId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localDocFolder));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    DocFolder localDocFolder;
    if (this.docFolder.getFolderId() == null)
    {
      if (this.docFolder.getIsShared() == null)
      {
        this.docFolder.setAppUser(ContextUtil.getCurrentUser());
        this.docFolder.setIsShared(DocFolder.IS_NOT_SHARED);
      }
      this.docFolderService.save(this.docFolder);
      if ((this.docFolder.getParentId() == null) || (this.docFolder.getParentId().longValue() == 0L))
      {
        this.docFolder.setPath(this.docFolder.getFolderId() + ".");
      }
      else
      {
        localDocFolder = (DocFolder)this.docFolderService.get(this.docFolder.getParentId());
        if (localDocFolder != null)
          this.docFolder.setPath(localDocFolder.getPath() + this.docFolder.getFolderId() + ".");
      }
      this.docFolderService.save(this.docFolder);
    }
    else
    {
      localDocFolder = (DocFolder)this.docFolderService.get(this.docFolder.getFolderId());
      localDocFolder.setDescp(this.docFolder.getDescp());
      localDocFolder.setFolderName(this.docFolder.getFolderName());
      this.docFolderService.save(localDocFolder);
    }
    setJsonString("{success:true}");
    return "success";
  }

  public String move()
  {
    String str1 = getRequest().getParameter("folderIdOld");
    String str2 = getRequest().getParameter("folderIdNew");
    if ((StringUtils.isNotEmpty(str1)) && (StringUtils.isNotEmpty(str2)))
    {
      Long localLong1 = new Long(str1);
      Long localLong2 = new Long(str2);
      String str3 = null;
      DocFolder localDocFolder1 = (DocFolder)this.docFolderService.get(localLong1);
      DocFolder localDocFolder2 = new DocFolder();
      if (localLong2.longValue() > 0L)
      {
        localDocFolder2 = (DocFolder)this.docFolderService.get(localLong2);
        str3 = localDocFolder2.getPath() + localLong1.toString() + ".";
        boolean bool = Pattern.compile(localDocFolder1.getPath()).matcher(localDocFolder2.getPath()).find();
        if (bool)
        {
          setJsonString("{success:false,msg:'不能移到子文件夹下！'}");
          return "success";
        }
      }
      else
      {
        localLong2 = ISPARENT;
        str3 = localLong1.toString() + ".";
      }
      String str4 = localDocFolder1.getPath();
      localDocFolder1.setParentId(localLong2);
      localDocFolder1.setPath(str3);
      List localList = this.docFolderService.getFolderLikePath(str4);
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        DocFolder localDocFolder3 = (DocFolder)localIterator.next();
        localDocFolder3.setPath(localDocFolder3.getPath().replaceFirst(str4, str3));
        this.docFolderService.save(localDocFolder3);
      }
      this.docFolderService.save(localDocFolder1);
      setJsonString("{success:true}");
    }
    else
    {
      setJsonString("{success:false,msg:'请联系系统管理员！'}");
    }
    return "success";
  }

  @Action(description="显示文件")
  public String folder()
  {
    String str1 = getRequest().getParameter("isUp");
    if (this.folderId == null)
    {
      this.folderId = Long.valueOf(0L);
    }
    else if ((StringUtils.isNotEmpty(str1)) && ("true".equals(str1)))
    {
      localObject1 = (DocFolder)this.docFolderService.get(this.folderId);
      if (localObject1 != null)
        this.folderId = ((DocFolder)localObject1).getParentId();
    }
    Object localObject1 = new ArrayList();
    String str2 = getRequest().getParameter("isSearch");
    Object localObject2 = new ArrayList();
    Object localObject3 = new ArrayList();
    if ((StringUtils.isNotEmpty(str2)) && ("true".equals(str2)))
    {
      localObject4 = getRequest().getParameter("fileName");
      localObject5 = ContextUtil.getCurrentUserId();
      localObject2 = this.docFolderService.findByUserAndName((Long)localObject5, (String)localObject4);
      localObject6 = new Document();
      ((Document)localObject6).setDocName((String)localObject4);
      localObject3 = this.documentService.findByPersonal((Long)localObject5, (Document)localObject6, null, null, null);
    }
    else
    {
      localObject2 = this.docFolderService.getUserFolderByParentId(ContextUtil.getCurrentUserId(), this.folderId);
      localObject3 = this.documentService.findByFolder(this.folderId);
    }
    Object localObject4 = ((List)localObject2).iterator();
    while (((Iterator)localObject4).hasNext())
    {
      localObject5 = (DocFolder)((Iterator)localObject4).next();
      localObject6 = new DocumentFile();
      ((DocumentFile)localObject6).setFileId(((DocFolder)localObject5).getFolderId());
      ((DocumentFile)localObject6).setFileName(((DocFolder)localObject5).getFolderName());
      ((DocumentFile)localObject6).setFileSize("0 bytes");
      ((DocumentFile)localObject6).setFileType("目录");
      ((DocumentFile)localObject6).setParentId(((DocFolder)localObject5).getParentId());
      DocFolder localDocFolder = (DocFolder)this.docFolderService.get(((DocFolder)localObject5).getParentId());
      if (localDocFolder != null)
        ((DocumentFile)localObject6).setParentName(localDocFolder.getFolderName());
      ((DocumentFile)localObject6).setIsFolder(DocumentFile.IS_FOLDER);
      ((List)localObject1).add(localObject6);
    }
    localObject4 = ((List)localObject3).iterator();
    while (((Iterator)localObject4).hasNext())
    {
      localObject5 = (Document)((Iterator)localObject4).next();
      localObject6 = new DocumentFile();
      ((DocumentFile)localObject6).setFileId(((Document)localObject5).getDocId());
      ((DocumentFile)localObject6).setFileName(((Document)localObject5).getDocName());
      ((DocumentFile)localObject6).setFileSize(((Document)localObject5).getContent().getBytes() + " bytes");
      ((DocumentFile)localObject6).setFileType("文档");
      ((DocumentFile)localObject6).setIsFolder(DocumentFile.NOT_FOLDER);
      ((DocumentFile)localObject6).setIsShared(((Document)localObject5).getIsShared());
      ((DocumentFile)localObject6).setAuthor(((Document)localObject5).getAuthor());
      ((DocumentFile)localObject6).setUpdateTime(((Document)localObject5).getUpdatetime());
      ((DocumentFile)localObject6).setKeywords(((Document)localObject5).getKeywords());
      ((List)localObject1).add(localObject6);
    }
    localObject4 = new Gson();
    Object localObject5 = new TypeToken()
    {
    }
    .getType();
    Object localObject6 = new StringBuffer("{success:true,result:");
    ((StringBuffer)localObject6).append(((Gson)localObject4).toJson(localObject1, (Type)localObject5));
    ((StringBuffer)localObject6).append("}");
    setJsonString(((StringBuffer)localObject6).toString());
    return (String)(String)(String)(String)(String)(String)"success";
  }

  public String detail()
  {
    String str1 = getRequest().getParameter("fileId");
    String str2 = getRequest().getParameter("isPersonal");
    String str3 = getRequest().getParameter("isFolder");
    StringBuffer localStringBuffer = new StringBuffer("{success:true,");
    if ((StringUtils.isNotEmpty(str1)) && (StringUtils.isNotEmpty(str3)))
    {
      Object localObject1;
      Object localObject2;
      if ("true".equals(str3))
      {
        if ("0".equals(str1))
        {
          localObject1 = "/";
          localStringBuffer.append("fileId:").append(0).append(",fileName:'").append("我的文件夹").append("'");
          localStringBuffer.append(",descp:'").append("根目录").append("'");
          localStringBuffer.append(",path:'" + (String)localObject1 + "'");
          localStringBuffer.append(",fileType:'目录'");
          localObject2 = new DocFolder();
          ((DocFolder)localObject2).setFolderId(Long.valueOf(0L));
          boolean bool = false;
          if ((StringUtils.isNotEmpty(str2)) && ("true".equals(str2)))
            bool = true;
          sumNum((DocFolder)localObject2, bool);
        }
        else
        {
          localObject1 = (DocFolder)this.docFolderService.get(new Long(str1));
          localObject2 = "";
          if ((((DocFolder)localObject1).getParentId() != null) && (((DocFolder)localObject1).getParentId().longValue() != 0L))
            localObject2 = findPath(((DocFolder)localObject1).getParentId(), (String)localObject2);
          localStringBuffer.append("fileId:").append(((DocFolder)localObject1).getFolderId()).append(",fileName:'").append(((DocFolder)localObject1).getFolderName()).append("'");
          localStringBuffer.append(",descp:'").append(((DocFolder)localObject1).getDescp()).append("'");
          localStringBuffer.append(",path:'" + (String)localObject2 + "'");
          localStringBuffer.append(",fileType:'目录'");
          if (localObject1 != null)
            sumNum((DocFolder)localObject1, false);
        }
      }
      else
      {
        localObject1 = (Document)this.documentService.get(new Long(str1));
        localObject2 = "";
        localObject2 = findPath(((Document)localObject1).getFolderId(), (String)localObject2);
        localStringBuffer.append("fileId:").append(((Document)localObject1).getDocId()).append(",fileName:'").append(((Document)localObject1).getDocName()).append("'");
        localStringBuffer.append(",fileType:'" + ((Document)localObject1).getDocType() + "'").append(",author:'").append(((Document)localObject1).getAuthor()).append("',keywords:'").append(((Document)localObject1).getKeywords()).append("'").append(",path:'").append((String)localObject2).append("'");
        Set localSet = ((Document)localObject1).getAttachFiles();
        this.attachsNum = Integer.valueOf(this.attachsNum.intValue() + localSet.size());
        this.filesize += fileSize((Document)localObject1);
      }
    }
    this.logger.info("folderNum:" + this.folderNum + "documentNum:" + this.documentNum + "attachsNum:" + this.attachsNum);
    localStringBuffer.append(",folderNum:" + this.folderNum + ",documentNum:" + this.documentNum + ",attachsNum:" + this.attachsNum + ",docFileSize:'" + getStrFileSize(this.filesize) + "'");
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    this.logger.info(localStringBuffer.toString());
    return (String)(String)"success";
  }

  private String findPath(Long paramLong, String paramString)
  {
    DocFolder localDocFolder = (DocFolder)this.docFolderService.get(paramLong);
    if (localDocFolder != null)
    {
      paramString = "/" + localDocFolder.getFolderName() + paramString;
      return findPath(localDocFolder.getParentId(), paramString);
    }
    return paramString;
  }

  private void sumNum(DocFolder paramDocFolder, boolean paramBoolean)
  {
    List localList = this.documentService.findByFolder(paramDocFolder.getFolderId());
    Object localObject1 = localList.iterator();
    Object localObject3;
    Integer localInteger1;
    Integer localInteger2;
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (Document)((Iterator)localObject1).next();
      localObject3 = ((Document)localObject2).getAttachFiles();
      this.attachsNum = Integer.valueOf(this.attachsNum.intValue() + ((Set)localObject3).size());
      localInteger1 = this.documentNum;
      localInteger2 = this.documentNum = Integer.valueOf(this.documentNum.intValue() + 1);
      this.filesize += fileSize((Document)localObject2);
    }
    localObject1 = new ArrayList();
    if (!paramBoolean)
      localObject1 = this.docFolderService.findByParentId(paramDocFolder.getFolderId());
    else
      localObject1 = this.docFolderService.getUserFolderByParentId(ContextUtil.getCurrentUserId(), paramDocFolder.getFolderId());
    Object localObject2 = ((List)localObject1).iterator();
    while (((Iterator)localObject2).hasNext())
    {
      localObject3 = (DocFolder)((Iterator)localObject2).next();
      localInteger1 = this.folderNum;
      localInteger2 = this.folderNum = Integer.valueOf(this.folderNum.intValue() + 1);
      sumNum((DocFolder)localObject3, false);
    }
  }

  public void childList(List<DocumentFile> paramList, List<DocFolder> paramList1, AppUser paramAppUser, boolean paramBoolean, String paramString)
  {
    Iterator localIterator = paramList1.iterator();
    while (localIterator.hasNext())
    {
      DocFolder localDocFolder1 = (DocFolder)localIterator.next();
      if ((paramBoolean) || ((StringUtils.isNotEmpty(paramString)) && (localDocFolder1.getFolderName().indexOf(paramString) != -1)))
      {
        localObject = new DocumentFile();
        ((DocumentFile)localObject).setFileId(localDocFolder1.getFolderId());
        ((DocumentFile)localObject).setFileName(localDocFolder1.getFolderName());
        ((DocumentFile)localObject).setFileType("目录");
        ((DocumentFile)localObject).setParentId(localDocFolder1.getParentId());
        DocFolder localDocFolder2 = (DocFolder)this.docFolderService.get(localDocFolder1.getParentId());
        if (localDocFolder2 != null)
          ((DocumentFile)localObject).setParentName(localDocFolder2.getFolderName());
        ((DocumentFile)localObject).setIsFolder(DocumentFile.IS_FOLDER);
        paramList.add(localObject);
      }
      Object localObject = this.docFolderService.getPublicFolderByParentId(localDocFolder1.getFolderId());
      if (((List)localObject).size() > 0)
        childList(paramList, (List)localObject, paramAppUser, paramBoolean, paramString);
    }
  }

  public String knowledge()
  {
    String str1 = getRequest().getParameter("isSearch");
    AppUser localAppUser = ContextUtil.getCurrentUser();
    Set localSet = localAppUser.getRights();
    int i = 0;
    if (localSet.contains("__ALL"))
      i = 1;
    Object localObject2;
    Object localObject9;
    if ((StringUtils.isNotEmpty(str1)) && ("true".equals(str1)))
    {
      str2 = getRequest().getParameter("fileName");
      localObject1 = getRequest().getParameter("author");
      localObject2 = getRequest().getParameter("keywords");
      ArrayList localArrayList = new ArrayList();
      List localList1 = this.docFolderService.getPublicFolderByParentId(Long.valueOf(0L));
      localObject3 = NOT_RIGHT;
      localObject4 = localList1.iterator();
      while (((Iterator)localObject4).hasNext())
      {
        localObject5 = (DocFolder)((Iterator)localObject4).next();
        localObject3 = NOT_RIGHT;
        if (i != 0)
        {
          localObject3 = ALL_RIGHT;
        }
        else
        {
          List localList2 = this.docPrivilegeService.getRightsByFolder(localAppUser, ((DocFolder)localObject5).getFolderId());
          localObject7 = localList2.iterator();
          while (((Iterator)localObject7).hasNext())
          {
            localObject8 = (Integer)((Iterator)localObject7).next();
            localObject3 = Integer.valueOf(((Integer)localObject3).intValue() | ((Integer)localObject8).intValue());
          }
        }
        if (localObject3 != NOT_RIGHT)
        {
          boolean bool = (StringUtils.isEmpty(str2)) && (StringUtils.isEmpty((String)localObject1)) && (StringUtils.isEmpty((String)localObject2));
          if ((bool) || ((StringUtils.isNotEmpty(str2)) && (((DocFolder)localObject5).getFolderName().indexOf(str2) != -1)))
          {
            localObject7 = new DocumentFile();
            ((DocumentFile)localObject7).setFileId(((DocFolder)localObject5).getFolderId());
            ((DocumentFile)localObject7).setFileName(((DocFolder)localObject5).getFolderName());
            ((DocumentFile)localObject7).setFileType("目录");
            ((DocumentFile)localObject7).setParentId(((DocFolder)localObject5).getParentId());
            localObject8 = (DocFolder)this.docFolderService.get(((DocFolder)localObject5).getParentId());
            if (localObject8 != null)
              ((DocumentFile)localObject7).setParentName(((DocFolder)localObject8).getFolderName());
            ((DocumentFile)localObject7).setIsFolder(DocumentFile.IS_FOLDER);
            localArrayList.add(localObject7);
          }
          localObject7 = this.docFolderService.getPublicFolderByParentId(((DocFolder)localObject5).getFolderId());
          if (((List)localObject7).size() > 0)
            childList(localArrayList, (List)localObject7, localAppUser, bool, str2);
        }
      }
      localObject4 = getInitPagingBean();
      ((PagingBean)localObject4).setPageSize(10000);
      localObject5 = new Document();
      ((Document)localObject5).setDocName(str2);
      ((Document)localObject5).setAuthor((String)localObject1);
      ((Document)localObject5).setKeywords((String)localObject2);
      localObject6 = this.documentService.findByPublic(null, (Document)localObject5, null, null, localAppUser, (PagingBean)localObject4);
      localObject7 = ((List)localObject6).iterator();
      while (((Iterator)localObject7).hasNext())
      {
        localObject8 = (Document)((Iterator)localObject7).next();
        short s4 = 0;
        short s5 = 0;
        short s6 = 0;
        Object localObject10;
        if (i != 0)
        {
          s4 = 1;
          s5 = 1;
          s6 = 1;
        }
        else
        {
          localObject10 = ((Document)localObject8).getFolderId();
          localObject3 = NOT_RIGHT;
          Object localObject11;
          Object localObject12;
          if (((Long)localObject10).longValue() != 0L)
          {
            localObject11 = this.docPrivilegeService.getRightsByFolder(localAppUser, (Long)localObject10);
            localObject12 = ((List)localObject11).iterator();
            while (((Iterator)localObject12).hasNext())
            {
              Integer localInteger2 = (Integer)((Iterator)localObject12).next();
              localObject3 = Integer.valueOf(((Integer)localObject3).intValue() | localInteger2.intValue());
            }
            localObject3 = rightOfFolder(localAppUser, (Integer)localObject3, (Long)localObject10);
          }
          if (localObject3 != NOT_RIGHT)
          {
            localObject11 = Integer.toBinaryString(((Integer)localObject3).intValue());
            localObject12 = ((String)localObject11).toCharArray();
            if ((localObject12.length == 2) && (localObject12[0] == '1'))
              s5 = 1;
            if (localObject12.length == 3)
            {
              if (localObject12[0] == '1')
                s4 = 1;
              if (localObject12[1] == '1')
                s5 = 1;
            }
            s6 = 1;
          }
        }
        if (s6 > 0)
        {
          localObject10 = new DocumentFile();
          ((DocumentFile)localObject10).setFileId(((Document)localObject8).getDocId());
          ((DocumentFile)localObject10).setFileName(((Document)localObject8).getDocName());
          ((DocumentFile)localObject10).setFileSize(getStrFileSize(fileSize((Document)localObject8)));
          ((DocumentFile)localObject10).setFileType("文档");
          ((DocumentFile)localObject10).setIsFolder(DocumentFile.NOT_FOLDER);
          ((DocumentFile)localObject10).setIsShared(((Document)localObject8).getIsShared());
          ((DocumentFile)localObject10).setRightRead(Short.valueOf(s6));
          ((DocumentFile)localObject10).setRightMod(Short.valueOf(s5));
          ((DocumentFile)localObject10).setAuthor(((Document)localObject8).getAuthor());
          ((DocumentFile)localObject10).setKeywords(((Document)localObject8).getKeywords());
          ((DocumentFile)localObject10).setUpdateTime(((Document)localObject8).getUpdatetime());
          ((DocumentFile)localObject10).setRightDel(Short.valueOf(s4));
          localArrayList.add(localObject10);
        }
      }
      localObject7 = new Gson();
      localObject8 = new TypeToken()
      {
      }
      .getType();
      localObject9 = new StringBuffer("{success:true,result:");
      ((StringBuffer)localObject9).append(((Gson)localObject7).toJson(localArrayList, (Type)localObject8));
      ((StringBuffer)localObject9).append("}");
      setJsonString(((StringBuffer)localObject9).toString());
      return "success";
    }
    String str2 = getRequest().getParameter("isUp");
    Object localObject1 = NOT_RIGHT;
    if (this.folderId == null)
    {
      this.folderId = Long.valueOf(0L);
    }
    else if ((StringUtils.isNotEmpty(str2)) && ("true".equals(str2)))
    {
      localObject2 = (DocFolder)this.docFolderService.get(this.folderId);
      if (localObject2 != null)
        this.folderId = ((DocFolder)localObject2).getParentId();
    }
    short s1 = 0;
    short s2 = 0;
    short s3 = 0;
    if (i != 0)
    {
      s1 = 1;
      s2 = 1;
      s3 = 1;
    }
    else
    {
      if (this.folderId.longValue() != 0L)
      {
        localObject3 = this.docPrivilegeService.getRightsByFolder(localAppUser, this.folderId);
        localObject4 = ((List)localObject3).iterator();
        while (((Iterator)localObject4).hasNext())
        {
          localObject5 = (Integer)((Iterator)localObject4).next();
          localObject1 = Integer.valueOf(((Integer)localObject1).intValue() | ((Integer)localObject5).intValue());
        }
        localObject1 = rightOfFolder(localAppUser, (Integer)localObject1, this.folderId);
      }
      if (localObject1 != NOT_RIGHT)
      {
        localObject3 = Integer.toBinaryString(((Integer)localObject1).intValue());
        localObject4 = ((String)localObject3).toCharArray();
        if ((localObject4.length == 2) && (localObject4[0] == '1'))
          s2 = 1;
        if (localObject4.length == 3)
        {
          if (localObject4[0] == '1')
            s1 = 1;
          if (localObject4[1] == '1')
            s2 = 1;
        }
        s3 = 1;
      }
    }
    Object localObject3 = new ArrayList();
    Object localObject4 = this.docFolderService.getPublicFolderByParentId(this.folderId);
    Object localObject5 = this.documentService.findByFolder(this.folderId);
    Object localObject6 = ((List)localObject4).iterator();
    while (((Iterator)localObject6).hasNext())
    {
      localObject7 = (DocFolder)((Iterator)localObject6).next();
      if (((DocFolder)localObject7).getParentId().longValue() == 0L)
      {
        localObject1 = NOT_RIGHT;
        if (i != 0)
        {
          localObject1 = ALL_RIGHT;
        }
        else
        {
          localObject8 = this.docPrivilegeService.getRightsByFolder(localAppUser, ((DocFolder)localObject7).getFolderId());
          localObject9 = ((List)localObject8).iterator();
          while (((Iterator)localObject9).hasNext())
          {
            Integer localInteger1 = (Integer)((Iterator)localObject9).next();
            localObject1 = Integer.valueOf(((Integer)localObject1).intValue() | localInteger1.intValue());
          }
        }
      }
      else
      {
        localObject1 = ALL_RIGHT;
      }
      if (localObject1 != NOT_RIGHT)
      {
        localObject8 = new DocumentFile();
        ((DocumentFile)localObject8).setFileId(((DocFolder)localObject7).getFolderId());
        ((DocumentFile)localObject8).setFileName(((DocFolder)localObject7).getFolderName());
        ((DocumentFile)localObject8).setFileType("目录");
        ((DocumentFile)localObject8).setParentId(((DocFolder)localObject7).getParentId());
        localObject9 = (DocFolder)this.docFolderService.get(((DocFolder)localObject7).getParentId());
        if (localObject9 != null)
          ((DocumentFile)localObject8).setParentName(((DocFolder)localObject9).getFolderName());
        ((DocumentFile)localObject8).setIsFolder(DocumentFile.IS_FOLDER);
        ((List)localObject3).add(localObject8);
      }
    }
    localObject6 = ((List)localObject5).iterator();
    while (((Iterator)localObject6).hasNext())
    {
      localObject7 = (Document)((Iterator)localObject6).next();
      localObject8 = new DocumentFile();
      ((DocumentFile)localObject8).setFileId(((Document)localObject7).getDocId());
      ((DocumentFile)localObject8).setFileName(((Document)localObject7).getDocName());
      ((DocumentFile)localObject8).setFileSize(getStrFileSize(fileSize((Document)localObject7)));
      ((DocumentFile)localObject8).setFileType("文档");
      ((DocumentFile)localObject8).setIsFolder(DocumentFile.NOT_FOLDER);
      ((DocumentFile)localObject8).setIsShared(((Document)localObject7).getIsShared());
      ((DocumentFile)localObject8).setRightRead(Short.valueOf(s3));
      ((DocumentFile)localObject8).setRightMod(Short.valueOf(s2));
      ((DocumentFile)localObject8).setAuthor(((Document)localObject7).getAuthor());
      ((DocumentFile)localObject8).setKeywords(((Document)localObject7).getKeywords());
      ((DocumentFile)localObject8).setUpdateTime(((Document)localObject7).getUpdatetime());
      ((DocumentFile)localObject8).setRightDel(Short.valueOf(s1));
      ((List)localObject3).add(localObject8);
    }
    localObject6 = new Gson();
    Object localObject7 = new TypeToken()
    {
    }
    .getType();
    Object localObject8 = new StringBuffer("{success:true,result:");
    ((StringBuffer)localObject8).append(((Gson)localObject6).toJson(localObject3, (Type)localObject7));
    ((StringBuffer)localObject8).append("}");
    setJsonString(((StringBuffer)localObject8).toString());
    return (String)(String)(String)(String)(String)(String)(String)(String)(String)(String)(String)(String)"success";
  }

  private String getStrFileSize(double paramDouble)
  {
    DecimalFormat localDecimalFormat = new DecimalFormat("0.00");
    double d;
    if (paramDouble > 1048576.0D)
    {
      d = paramDouble / 1048576.0D;
      return localDecimalFormat.format(d) + " M";
    }
    if (paramDouble > 1024.0D)
    {
      d = paramDouble / 1024.0D;
      return localDecimalFormat.format(d) + " KB";
    }
    return paramDouble + " bytes";
  }

  private double fileSize(Document paramDocument)
  {
    Set localSet = paramDocument.getAttachFiles();
    Iterator localIterator = localSet.iterator();
    double d = 0.0D;
    while (localIterator.hasNext())
    {
      localObject = (FileAttach)localIterator.next();
      if ((localObject != null) && (((FileAttach)localObject).getTotalBytes() != null))
        d += ((FileAttach)localObject).getTotalBytes().longValue();
    }
    Object localObject = paramDocument.getContent();
    if (StringUtils.isNotEmpty((String)localObject))
    {
      int i = ((String)localObject).getBytes().length;
      d += i;
    }
    return d;
  }

  public Integer rightOfFolder(AppUser paramAppUser, Integer paramInteger, Long paramLong)
  {
    DocFolder localDocFolder = (DocFolder)this.docFolderService.get(paramLong);
    if (localDocFolder != null)
    {
      List localList = this.docPrivilegeService.getRightsByFolder(paramAppUser, localDocFolder.getParentId());
      Object localObject = localList.iterator();
      while (((Iterator)localObject).hasNext())
      {
        Integer localInteger = (Integer)((Iterator)localObject).next();
        paramInteger = Integer.valueOf(paramInteger.intValue() | localInteger.intValue());
      }
      localObject = rightOfFolder(paramAppUser, paramInteger, localDocFolder.getParentId());
      paramInteger = Integer.valueOf(paramInteger.intValue() | ((Integer)localObject).intValue());
    }
    return (Integer)paramInteger;
  }

  public String knowledgeTree()
  {
    AppUser localAppUser = ContextUtil.getCurrentUser();
    StringBuffer localStringBuffer = new StringBuffer("[{id:'0',text:'知识目录',expanded:true,children:[");
    List localList1 = this.docFolderService.getPublicFolderByParentId(Long.valueOf(0L));
    int i = 0;
    Iterator localIterator = localList1.iterator();
    while (localIterator.hasNext())
    {
      DocFolder localDocFolder = (DocFolder)localIterator.next();
      List localList2 = this.docPrivilegeService.getRightsByFolder(localAppUser, localDocFolder.getFolderId());
      Integer localInteger1 = NOT_RIGHT;
      Object localObject = localList2.iterator();
      while (((Iterator)localObject).hasNext())
      {
        Integer localInteger2 = (Integer)((Iterator)localObject).next();
        localInteger1 = Integer.valueOf(localInteger1.intValue() | localInteger2.intValue());
      }
      localObject = localAppUser.getRights();
      if (((Set)localObject).contains("__ALL"))
        localInteger1 = ALL_RIGHT;
      if (localInteger1 != NOT_RIGHT)
      {
        i = 1;
        localStringBuffer.append("{id:'" + localDocFolder.getFolderId()).append("',text:'" + localDocFolder.getFolderName()).append("',expanded:true,");
        localStringBuffer.append(findChildsFolder(localDocFolder.getFolderId()));
      }
    }
    if (i != 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}]");
    setJsonString(localStringBuffer.toString());
    return (String)"success";
  }

  public String findChildsFolderByRights(Long paramLong, Integer paramInteger, boolean paramBoolean)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    List localList1 = this.docFolderService.getPublicFolderByParentId(paramLong);
    if (localList1.size() == 0)
    {
      localStringBuffer.append("leaf:true},");
      return localStringBuffer.toString();
    }
    localStringBuffer.append("children:[");
    int i = 0;
    Iterator localIterator1 = localList1.iterator();
    while (localIterator1.hasNext())
    {
      DocFolder localDocFolder = (DocFolder)localIterator1.next();
      Integer localInteger1 = paramInteger;
      if (paramBoolean)
      {
        localInteger1 = ALL_RIGHT;
      }
      else if (localInteger1 != NOT_RIGHT)
      {
        localInteger1 = NOT_RIGHT;
        AppUser localAppUser = ContextUtil.getCurrentUser();
        List localList2 = this.docPrivilegeService.getRightsByFolder(localAppUser, localDocFolder.getFolderId());
        Iterator localIterator2 = localList2.iterator();
        while (localIterator2.hasNext())
        {
          Integer localInteger2 = (Integer)localIterator2.next();
          localInteger1 = Integer.valueOf(localInteger1.intValue() | localInteger2.intValue());
        }
      }
      if (localInteger1 != NOT_RIGHT)
      {
        i = 1;
        localStringBuffer.append("{id:'" + localDocFolder.getFolderId() + "',text:'" + localDocFolder.getFolderName() + "',expanded:true,");
        localStringBuffer.append(findChildsFolderByRights(localDocFolder.getFolderId(), localInteger1, paramBoolean));
      }
    }
    if (i != 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]},");
    return localStringBuffer.toString();
  }

  public String onlineTree()
  {
    AppUser localAppUser = ContextUtil.getCurrentUser();
    StringBuffer localStringBuffer = new StringBuffer("[{id:'0',text:'在线文档目录',expanded:true,children:[");
    List localList1 = this.docFolderService.getOnlineFolderByParentId(Long.valueOf(0L));
    int i = 0;
    Iterator localIterator = localList1.iterator();
    while (localIterator.hasNext())
    {
      DocFolder localDocFolder = (DocFolder)localIterator.next();
      List localList2 = this.docPrivilegeService.getRightsByFolder(localAppUser, localDocFolder.getFolderId());
      Integer localInteger1 = NOT_RIGHT;
      Object localObject = localList2.iterator();
      while (((Iterator)localObject).hasNext())
      {
        Integer localInteger2 = (Integer)((Iterator)localObject).next();
        localInteger1 = Integer.valueOf(localInteger1.intValue() | localInteger2.intValue());
      }
      localObject = localAppUser.getRights();
      if (((Set)localObject).contains("__ALL"))
        localInteger1 = ALL_RIGHT;
      if (localInteger1 != NOT_RIGHT)
      {
        i = 1;
        localStringBuffer.append("{id:'" + localDocFolder.getFolderId()).append("',text:'" + localDocFolder.getFolderName()).append("',expanded:true,");
        localStringBuffer.append(findOnlineChildsFolder(localDocFolder.getFolderId()));
      }
    }
    if (i != 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}]");
    setJsonString(localStringBuffer.toString());
    return (String)"success";
  }

  public String findOnlineChildsFolder(Long paramLong)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    List localList = this.docFolderService.getOnlineFolderByParentId(paramLong);
    if (localList.size() == 0)
    {
      localStringBuffer.append("leaf:true,expanded:true},");
      return localStringBuffer.toString();
    }
    localStringBuffer.append("children:[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      DocFolder localDocFolder = (DocFolder)localIterator.next();
      localStringBuffer.append("{id:'" + localDocFolder.getFolderId() + "',text:'" + localDocFolder.getFolderName() + "',expanded:true,");
      localStringBuffer.append(findOnlineChildsFolder(localDocFolder.getFolderId()));
    }
    localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]},");
    return localStringBuffer.toString();
  }

  public String onlineList()
  {
    AppUser localAppUser = ContextUtil.getCurrentUser();
    Set localSet = localAppUser.getRights();
    int i = 0;
    if (localSet.contains("__ALL"))
      i = 1;
    String str1 = getRequest().getParameter("isSearch");
    Object localObject2;
    Object localObject11;
    Object localObject12;
    if ((StringUtils.isNotEmpty(str1)) && ("true".equals(str1)))
    {
      str2 = getRequest().getParameter("fileName");
      localObject1 = new ArrayList();
      localObject2 = this.docFolderService.getOnlineFolderByParentId(Long.valueOf(0L));
      Integer localInteger1 = NOT_RIGHT;
      Object localObject3 = ((List)localObject2).iterator();
      while (((Iterator)localObject3).hasNext())
      {
        localObject4 = (DocFolder)((Iterator)localObject3).next();
        localInteger1 = NOT_RIGHT;
        Object localObject7;
        if (i != 0)
        {
          localInteger1 = ALL_RIGHT;
        }
        else
        {
          List localList = this.docPrivilegeService.getRightsByFolder(localAppUser, ((DocFolder)localObject4).getFolderId());
          localObject6 = localList.iterator();
          while (((Iterator)localObject6).hasNext())
          {
            localObject7 = (Integer)((Iterator)localObject6).next();
            localInteger1 = Integer.valueOf(localInteger1.intValue() | ((Integer)localObject7).intValue());
          }
        }
        if (localInteger1 != NOT_RIGHT)
        {
          boolean bool = StringUtils.isEmpty(str2);
          if ((bool) || ((StringUtils.isNotEmpty(str2)) && (((DocFolder)localObject4).getFolderName().indexOf(str2) != -1)))
          {
            localObject6 = new DocumentFile();
            ((DocumentFile)localObject6).setFileId(((DocFolder)localObject4).getFolderId());
            ((DocumentFile)localObject6).setFileName(((DocFolder)localObject4).getFolderName());
            ((DocumentFile)localObject6).setFileType("目录");
            ((DocumentFile)localObject6).setParentId(((DocFolder)localObject4).getParentId());
            localObject7 = (DocFolder)this.docFolderService.get(((DocFolder)localObject4).getParentId());
            if (localObject7 != null)
              ((DocumentFile)localObject6).setParentName(((DocFolder)localObject7).getFolderName());
            ((DocumentFile)localObject6).setIsFolder(DocumentFile.IS_FOLDER);
            ((List)localObject1).add(localObject6);
          }
          localObject6 = this.docFolderService.getOnlineFolderByParentId(((DocFolder)localObject4).getFolderId());
          if (((List)localObject6).size() > 0)
            childOnlineList((List)localObject1, (List)localObject6, localAppUser, bool, str2);
        }
      }
      localObject3 = new Document();
      ((Document)localObject3).setDocName(str2);
      localObject4 = this.documentService.findByOnline((Document)localObject3, null, null, localAppUser);
      localObject5 = ((List)localObject4).iterator();
      while (((Iterator)localObject5).hasNext())
      {
        localObject6 = (Document)((Iterator)localObject5).next();
        short s4 = 0;
        short s5 = 0;
        short s6 = 0;
        if (i != 0)
        {
          s4 = 1;
          s5 = 1;
          s6 = 1;
        }
        else
        {
          localObject11 = ((Document)localObject6).getFolderId();
          localInteger1 = NOT_RIGHT;
          Object localObject13;
          if (((Long)localObject11).longValue() != 0L)
          {
            localObject12 = this.docPrivilegeService.getRightsByFolder(localAppUser, (Long)localObject11);
            localObject13 = ((List)localObject12).iterator();
            while (((Iterator)localObject13).hasNext())
            {
              Integer localInteger2 = (Integer)((Iterator)localObject13).next();
              localInteger1 = Integer.valueOf(localInteger1.intValue() | localInteger2.intValue());
            }
            localInteger1 = rightOfFolder(localAppUser, localInteger1, (Long)localObject11);
          }
          if (localInteger1 != NOT_RIGHT)
          {
            localObject12 = Integer.toBinaryString(localInteger1.intValue());
            localObject13 = ((String)localObject12).toCharArray();
            if ((localObject13.length == 2) && (localObject13[0] == '1'))
              s5 = 1;
            if (localObject13.length == 3)
            {
              if (localObject13[0] == '1')
                s4 = 1;
              if (localObject13[1] == '1')
                s5 = 1;
            }
            s6 = 1;
          }
        }
        if (s6 > 0)
        {
          localObject11 = new DocumentFile();
          ((DocumentFile)localObject11).setFileId(((Document)localObject6).getDocId());
          ((DocumentFile)localObject11).setFileName(((Document)localObject6).getDocName());
          ((DocumentFile)localObject11).setFileSize(getStrFileSize(fileSize((Document)localObject6)));
          ((DocumentFile)localObject11).setFileType(((Document)localObject6).getDocType());
          ((DocumentFile)localObject11).setIsFolder(DocumentFile.NOT_FOLDER);
          ((DocumentFile)localObject11).setIsShared(((Document)localObject6).getIsShared());
          ((DocumentFile)localObject11).setRightRead(Short.valueOf(s6));
          ((DocumentFile)localObject11).setRightMod(Short.valueOf(s5));
          ((DocumentFile)localObject11).setAuthor(((Document)localObject6).getAuthor());
          ((DocumentFile)localObject11).setKeywords(((Document)localObject6).getKeywords());
          ((DocumentFile)localObject11).setUpdateTime(((Document)localObject6).getUpdatetime());
          ((DocumentFile)localObject11).setRightDel(Short.valueOf(s4));
          ((List)localObject1).add(localObject11);
        }
      }
      localObject5 = new Gson();
      localObject6 = new TypeToken()
      {
      }
      .getType();
      localObject8 = new StringBuffer("{success:true,result:");
      ((StringBuffer)localObject8).append(((Gson)localObject5).toJson(localObject1, (Type)localObject6));
      ((StringBuffer)localObject8).append("}");
      setJsonString(((StringBuffer)localObject8).toString());
      return "success";
    }
    String str2 = getRequest().getParameter("isUp");
    Object localObject1 = NOT_RIGHT;
    if (this.folderId == null)
    {
      this.folderId = Long.valueOf(0L);
    }
    else if ((StringUtils.isNotEmpty(str2)) && ("true".equals(str2)))
    {
      localObject2 = (DocFolder)this.docFolderService.get(this.folderId);
      if (localObject2 != null)
        this.folderId = ((DocFolder)localObject2).getParentId();
    }
    short s1 = 0;
    short s2 = 0;
    short s3 = 0;
    if (i != 0)
    {
      s1 = 1;
      s2 = 1;
      s3 = 1;
    }
    else
    {
      if (this.folderId.longValue() != 0L)
      {
        localObject4 = this.docPrivilegeService.getRightsByFolder(localAppUser, this.folderId);
        localObject5 = ((List)localObject4).iterator();
        while (((Iterator)localObject5).hasNext())
        {
          localObject6 = (Integer)((Iterator)localObject5).next();
          localObject1 = Integer.valueOf(((Integer)localObject1).intValue() | ((Integer)localObject6).intValue());
        }
        localObject1 = rightOfFolder(localAppUser, (Integer)localObject1, this.folderId);
      }
      if (localObject1 != NOT_RIGHT)
      {
        localObject4 = Integer.toBinaryString(((Integer)localObject1).intValue());
        localObject5 = ((String)localObject4).toCharArray();
        if ((localObject5.length == 2) && (localObject5[0] == '1'))
          s2 = 1;
        if (localObject5.length == 3)
        {
          if (localObject5[0] == '1')
            s1 = 1;
          if (localObject5[1] == '1')
            s2 = 1;
        }
        s3 = 1;
      }
    }
    Object localObject4 = new ArrayList();
    Object localObject5 = this.docFolderService.getOnlineFolderByParentId(this.folderId);
    Object localObject6 = this.documentService.findByFolder(this.folderId);
    Object localObject8 = ((List)localObject5).iterator();
    while (((Iterator)localObject8).hasNext())
    {
      localObject9 = (DocFolder)((Iterator)localObject8).next();
      if (((DocFolder)localObject9).getParentId().longValue() == 0L)
      {
        localObject1 = NOT_RIGHT;
        if (i != 0)
        {
          localObject1 = ALL_RIGHT;
        }
        else
        {
          localObject10 = this.docPrivilegeService.getRightsByFolder(localAppUser, ((DocFolder)localObject9).getFolderId());
          localObject11 = ((List)localObject10).iterator();
          while (((Iterator)localObject11).hasNext())
          {
            localObject12 = (Integer)((Iterator)localObject11).next();
            localObject1 = Integer.valueOf(((Integer)localObject1).intValue() | ((Integer)localObject12).intValue());
          }
        }
      }
      else
      {
        localObject1 = ALL_RIGHT;
      }
      if (localObject1 != NOT_RIGHT)
      {
        localObject10 = new DocumentFile();
        ((DocumentFile)localObject10).setFileId(((DocFolder)localObject9).getFolderId());
        ((DocumentFile)localObject10).setFileName(((DocFolder)localObject9).getFolderName());
        ((DocumentFile)localObject10).setFileType("目录");
        ((DocumentFile)localObject10).setParentId(((DocFolder)localObject9).getParentId());
        localObject11 = (DocFolder)this.docFolderService.get(((DocFolder)localObject9).getParentId());
        if (localObject11 != null)
          ((DocumentFile)localObject10).setParentName(((DocFolder)localObject11).getFolderName());
        ((DocumentFile)localObject10).setIsFolder(DocumentFile.IS_FOLDER);
        ((List)localObject4).add(localObject10);
      }
    }
    localObject8 = ((List)localObject6).iterator();
    while (((Iterator)localObject8).hasNext())
    {
      localObject9 = (Document)((Iterator)localObject8).next();
      localObject10 = new DocumentFile();
      ((DocumentFile)localObject10).setFileId(((Document)localObject9).getDocId());
      ((DocumentFile)localObject10).setFileName(((Document)localObject9).getDocName());
      ((DocumentFile)localObject10).setFileSize(getStrFileSize(fileSize((Document)localObject9)));
      ((DocumentFile)localObject10).setFileType(((Document)localObject9).getDocType());
      ((DocumentFile)localObject10).setIsFolder(DocumentFile.NOT_FOLDER);
      ((DocumentFile)localObject10).setIsShared(((Document)localObject9).getIsShared());
      ((DocumentFile)localObject10).setRightRead(Short.valueOf(s3));
      ((DocumentFile)localObject10).setRightMod(Short.valueOf(s2));
      ((DocumentFile)localObject10).setAuthor(((Document)localObject9).getAuthor());
      ((DocumentFile)localObject10).setKeywords(((Document)localObject9).getKeywords());
      ((DocumentFile)localObject10).setUpdateTime(((Document)localObject9).getUpdatetime());
      ((DocumentFile)localObject10).setRightDel(Short.valueOf(s1));
      ((List)localObject4).add(localObject10);
    }
    localObject8 = new Gson();
    Object localObject9 = new TypeToken()
    {
    }
    .getType();
    Object localObject10 = new StringBuffer("{success:true,result:");
    ((StringBuffer)localObject10).append(((Gson)localObject8).toJson(localObject4, (Type)localObject9));
    ((StringBuffer)localObject10).append("}");
    setJsonString(((StringBuffer)localObject10).toString());
    return (String)(String)(String)(String)(String)(String)(String)(String)(String)(String)(String)(String)(String)"success";
  }

  public void childOnlineList(List<DocumentFile> paramList, List<DocFolder> paramList1, AppUser paramAppUser, boolean paramBoolean, String paramString)
  {
    Iterator localIterator = paramList1.iterator();
    while (localIterator.hasNext())
    {
      DocFolder localDocFolder1 = (DocFolder)localIterator.next();
      if ((paramBoolean) || ((StringUtils.isNotEmpty(paramString)) && (localDocFolder1.getFolderName().indexOf(paramString) != -1)))
      {
        localObject = new DocumentFile();
        ((DocumentFile)localObject).setFileId(localDocFolder1.getFolderId());
        ((DocumentFile)localObject).setFileName(localDocFolder1.getFolderName());
        ((DocumentFile)localObject).setFileType("目录");
        ((DocumentFile)localObject).setParentId(localDocFolder1.getParentId());
        DocFolder localDocFolder2 = (DocFolder)this.docFolderService.get(localDocFolder1.getParentId());
        if (localDocFolder2 != null)
          ((DocumentFile)localObject).setParentName(localDocFolder2.getFolderName());
        ((DocumentFile)localObject).setIsFolder(DocumentFile.IS_FOLDER);
        paramList.add(localObject);
      }
      Object localObject = this.docFolderService.getOnlineFolderByParentId(localDocFolder1.getFolderId());
      if (((List)localObject).size() > 0)
        childOnlineList(paramList, (List)localObject, paramAppUser, paramBoolean, paramString);
    }
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.document.DocFolderAction
 * JD-Core Version:    0.6.0
 */