package com.htsoft.oa.action.admin;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.admin.GoodsApply;
import com.htsoft.oa.model.admin.OfficeGoods;
import com.htsoft.oa.model.info.ShortMessage;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.admin.GoodsApplyService;
import com.htsoft.oa.service.admin.OfficeGoodsService;
import com.htsoft.oa.service.info.ShortMessageService;
import flexjson.JSONSerializer;
import flexjson.transformer.DateTransformer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class GoodsApplyAction extends BaseAction
{
  private static short PASS_APPLY = 2;
  private static short NOTPASS_APPLY = 3;

  @Resource
  private GoodsApplyService goodsApplyService;
  private GoodsApply goodsApply;

  @Resource
  private ShortMessageService shortMessageService;

  @Resource
  private OfficeGoodsService officeGoodsService;
  private Long applyId;

  public Long getApplyId()
  {
    return this.applyId;
  }

  public void setApplyId(Long paramLong)
  {
    this.applyId = paramLong;
  }

  public GoodsApply getGoodsApply()
  {
    return this.goodsApply;
  }

  public void setGoodsApply(GoodsApply paramGoodsApply)
  {
    this.goodsApply = paramGoodsApply;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.goodsApplyService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "applyDate" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.goodsApplyService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    GoodsApply localGoodsApply = (GoodsApply)this.goodsApplyService.get(this.applyId);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localJSONSerializer.transform(new DateTransformer("yyyy-MM-dd"), new String[] { "applyDate" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localGoodsApply));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    Object localObject;
    if (this.goodsApply.getApplyId() != null)
    {
      localObject = (GoodsApply)this.goodsApplyService.get(this.goodsApply.getApplyId());
      try
      {
        BeanUtil.copyNotNullProperties(localObject, this.goodsApply);
        if (((GoodsApply)localObject).getApprovalStatus().shortValue() == PASS_APPLY)
        {
          OfficeGoods localOfficeGoods = (OfficeGoods)this.officeGoodsService.get(((GoodsApply)localObject).getGoodsId());
          Integer localInteger1 = ((GoodsApply)localObject).getUseCounts();
          Integer localInteger2 = Integer.valueOf(localOfficeGoods.getStockCounts().intValue() - localInteger1.intValue());
          if (localInteger2.intValue() < 0)
          {
            setJsonString("{success:false,message:'库存不足!'}");
            return "success";
          }
          Long localLong = ((GoodsApply)localObject).getUserId();
          String str = "你申请的办公用品为" + localOfficeGoods.getGoodsName() + "已经通过审批，请查收";
          this.shortMessageService.save(AppUser.SYSTEM_USER, localLong.toString(), str, ShortMessage.MSG_TYPE_SYS);
          localOfficeGoods.setStockCounts(localInteger2);
          this.officeGoodsService.save(localOfficeGoods);
        }
        this.goodsApplyService.save(localObject);
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
    }
    else
    {
      localObject = new SimpleDateFormat("yyyyMMddHHmmss-SSSS");
      this.goodsApply.setApplyNo("GA" + ((SimpleDateFormat)localObject).format(new Date()));
      this.goodsApplyService.save(this.goodsApply);
    }
    setJsonString("{success:true}");
    return (String)"success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.admin.GoodsApplyAction
 * JD-Core Version:    0.6.0
 */