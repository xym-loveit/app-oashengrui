package com.htsoft.oa.action.personal;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.personal.DutySystem;
import com.htsoft.oa.model.personal.DutySystemSections;
import com.htsoft.oa.service.personal.DutySystemService;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class DutySystemAction extends BaseAction
{

  @Resource
  private DutySystemService dutySystemService;
  private DutySystem dutySystem;
  private Long systemId;

  public Long getSystemId()
  {
    return this.systemId;
  }

  public void setSystemId(Long paramLong)
  {
    this.systemId = paramLong;
  }

  public DutySystem getDutySystem()
  {
    return this.dutySystem;
  }

  public void setDutySystem(DutySystem paramDutySystem)
  {
    this.dutySystem = paramDutySystem;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.dutySystemService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String setting()
  {
    if (this.systemId != null)
      this.dutySystem = ((DutySystem)this.dutySystemService.get(this.systemId));
    StringBuffer localStringBuffer = new StringBuffer("{success:true,result:[{");
    if (this.dutySystem != null)
    {
      String[] arrayOfString1 = this.dutySystem.getSystemSetting().split("[|]");
      String[] arrayOfString2 = this.dutySystem.getSystemDesc().split("[|]");
      int i;
      if ((arrayOfString2 != null) && (arrayOfString2.length == 7))
        for (i = 0; i < arrayOfString2.length; i++)
          localStringBuffer.append("day").append(i).append(":'").append(arrayOfString2[i]).append("',");
      if ((arrayOfString1 != null) && (arrayOfString1.length == 7))
        for (i = 0; i < arrayOfString1.length; i++)
          localStringBuffer.append("dayId").append(i).append(":'").append(arrayOfString1[i]).append("',");
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    }
    else
    {
      localStringBuffer.append("day0:'',day1:'',day2:'',day3:'',day4:'',day5:'',day6:''").append(",dayId0:'',dayId1:'',dayId2:'',dayId3:'',dayId4:'',dayId5:'',dayId6:''");
    }
    localStringBuffer.append("}]}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.dutySystemService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    DutySystem localDutySystem = (DutySystem)this.dutySystemService.get(this.systemId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localDutySystem));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String combo()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    List localList = this.dutySystemService.getAll();
    localStringBuffer.append("[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      DutySystem localDutySystem = (DutySystem)localIterator.next();
      localStringBuffer.append("['").append(localDutySystem.getSystemId()).append("','").append(localDutySystem.getSystemName()).append("'],");
    }
    if (localList.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    String str = getRequest().getParameter("data");
    Gson localGson = new Gson();
    DutySystemSections[] arrayOfDutySystemSections = (DutySystemSections[])localGson.fromJson(str, [Lcom.htsoft.oa.model.personal.DutySystemSections.class);
    this.dutySystem.setSystemSetting(arrayOfDutySystemSections[0].dayIdToString());
    this.dutySystem.setSystemDesc(arrayOfDutySystemSections[0].dayToString());
    this.dutySystemService.save(this.dutySystem);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.personal.DutySystemAction
 * JD-Core Version:    0.6.0
 */