package com.htsoft.oa.action.customer;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.customer.CusConnection;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.customer.CusConnectionService;
import flexjson.JSONSerializer;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class CusConnectionAction extends BaseAction
{

  @Resource
  private CusConnectionService cusConnectionService;
  private CusConnection cusConnection;
  private Long connId;

  public Long getConnId()
  {
    return this.connId;
  }

  public void setConnId(Long paramLong)
  {
    this.connId = paramLong;
  }

  public CusConnection getCusConnection()
  {
    return this.cusConnection;
  }

  public void setCusConnection(CusConnection paramCusConnection)
  {
    this.cusConnection = paramCusConnection;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.cusConnectionService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "startDate", "endDate" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.cusConnectionService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    CusConnection localCusConnection = (CusConnection)this.cusConnectionService.get(this.connId);
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "startDate", "endDate" });
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localCusConnection));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    int i = 0;
    StringBuffer localStringBuffer = new StringBuffer("{");
    if (this.cusConnection.getStartDate().getTime() < this.cusConnection.getEndDate().getTime())
      i = 1;
    else
      localStringBuffer.append("msg:'交往结束日期不能早于开始日期!',");
    if (i != 0)
    {
      this.cusConnection.setCreator(ContextUtil.getCurrentUser().getFullname());
      this.cusConnectionService.save(this.cusConnection);
      localStringBuffer.append("success:true}");
    }
    else
    {
      localStringBuffer.append("failure:true}");
    }
    setJsonString(localStringBuffer.toString());
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.customer.CusConnectionAction
 * JD-Core Version:    0.6.0
 */