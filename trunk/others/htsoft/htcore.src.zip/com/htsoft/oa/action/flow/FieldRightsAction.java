package com.htsoft.oa.action.flow;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.jbpm.jpdl.Node;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.flow.FieldRights;
import com.htsoft.oa.model.flow.FormDef;
import com.htsoft.oa.model.flow.FormDefMapping;
import com.htsoft.oa.model.flow.FormField;
import com.htsoft.oa.model.flow.FormTable;
import com.htsoft.oa.model.flow.ProDefinition;
import com.htsoft.oa.service.flow.FieldRightsService;
import com.htsoft.oa.service.flow.FormDefMappingService;
import com.htsoft.oa.service.flow.JbpmService;
import com.htsoft.oa.service.flow.ProDefinitionService;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;

public class FieldRightsAction extends BaseAction
{

  @Resource
  private FieldRightsService fieldRightsService;

  @Resource
  private ProDefinitionService proDefinitionService;

  @Resource
  private FormDefMappingService formDefMappingService;

  @Resource
  private JbpmService jbpmService;
  private FieldRights fieldRights;
  private Long rightId;

  public Long getRightId()
  {
    return this.rightId;
  }

  public void setRightId(Long paramLong)
  {
    this.rightId = paramLong;
  }

  public FieldRights getFieldRights()
  {
    return this.fieldRights;
  }

  public void setFieldRights(FieldRights paramFieldRights)
  {
    this.fieldRights = paramFieldRights;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.fieldRightsService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.fieldRightsService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    FieldRights localFieldRights = (FieldRights)this.fieldRightsService.get(this.rightId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localFieldRights));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    if (this.fieldRights.getRightId() == null)
    {
      this.fieldRightsService.save(this.fieldRights);
    }
    else
    {
      FieldRights localFieldRights = (FieldRights)this.fieldRightsService.get(this.fieldRights.getRightId());
      try
      {
        BeanUtil.copyNotNullProperties(localFieldRights, this.fieldRights);
        this.fieldRightsService.save(localFieldRights);
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    setJsonString("{success:true}");
    return "success";
  }

  public String nodes()
  {
    String str = getRequest().getParameter("defId");
    ProDefinition localProDefinition = (ProDefinition)this.proDefinitionService.get(new Long(str));
    FormDefMapping localFormDefMapping = this.formDefMappingService.getByDeployId(localProDefinition.getDeployId());
    StringBuffer localStringBuffer = new StringBuffer();
    if (localFormDefMapping != null)
    {
      List localList1 = this.jbpmService.getFormNodesByDeployId(new Long(localProDefinition.getDeployId()));
      FormDef localFormDef = localFormDefMapping.getFormDef();
      ArrayList localArrayList = new ArrayList();
      if (localFormDef == null)
      {
        setJsonString("{success:false}");
        return "success";
      }
      Set localSet = localFormDef.getFormTables();
      Iterator localIterator1 = localSet.iterator();
      Object localObject2;
      while (localIterator1.hasNext())
      {
        localObject1 = ((FormTable)localIterator1.next()).getFormFields();
        Iterator localIterator2 = ((Set)localObject1).iterator();
        while (localIterator2.hasNext())
        {
          localObject2 = (FormField)localIterator2.next();
          if (FormField.IS_SHOW.compareTo(((FormField)localObject2).getIsDesignShow()) == 0)
            localArrayList.add(localObject2);
        }
      }
      localStringBuffer.append("{success:true,result:[");
      Object localObject1 = new Gson();
      for (int i = 0; i < localList1.size(); i++)
      {
        localObject2 = ((Node)localList1.get(i)).getName();
        for (int j = 0; j < localArrayList.size(); j++)
        {
          FormField localFormField = (FormField)localArrayList.get(j);
          localStringBuffer.append("{taskName:'").append((String)localObject2).append("',mappingId:'" + localFormDefMapping.getMappingId()).append("'");
          List localList2 = this.fieldRightsService.getByMappingFieldTaskName(localFormDefMapping.getMappingId(), localFormField.getFieldId(), (String)localObject2);
          FieldRights localFieldRights = new FieldRights();
          if (localList2.size() > 0)
            localFieldRights = (FieldRights)localList2.get(0);
          localStringBuffer.append(",rightId:'").append(localFieldRights.getRightId() == null ? "" : localFieldRights.getRightId()).append("',readWrite:'").append(localFieldRights.getRightId() == null ? 2 : localFieldRights.getReadWrite().shortValue()).append("'");
          localStringBuffer.append(",refieldId:'").append(localFormField.getFieldId()).append("',fieldName:'").append(((Gson)localObject1).toJson(localFormField.getFieldName()).replace("\"", "")).append("',fieldLabel:'").append(((Gson)localObject1).toJson(localFormField.getFieldLabel()).replace("\"", "")).append("'");
          localStringBuffer.append("},");
        }
      }
      if (!localList1.isEmpty())
        localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
      localStringBuffer.append("]}");
    }
    else
    {
      localStringBuffer.append("{success:false}");
    }
    this.jsonString = localStringBuffer.toString();
    return (String)(String)"success";
  }

  public String multSave()
  {
    String str = getRequest().getParameter("data");
    Gson localGson = new Gson();
    FieldRights[] arrayOfFieldRights1 = (FieldRights[])localGson.fromJson(str, [Lcom.htsoft.oa.model.flow.FieldRights.class);
    for (FieldRights localFieldRights : arrayOfFieldRights1)
    {
      if (localFieldRights.getRightId().longValue() == -1L)
        localFieldRights.setRightId(null);
      localFieldRights.setFieldId(localFieldRights.getRefieldId());
      this.fieldRightsService.save(localFieldRights);
    }
    this.jsonString = "{success:true}";
    return "success";
  }

  public String check()
  {
    String str = getRequest().getParameter("defId");
    ProDefinition localProDefinition = (ProDefinition)this.proDefinitionService.get(new Long(str));
    FormDefMapping localFormDefMapping = this.formDefMappingService.getByDeployId(localProDefinition.getDeployId());
    if (localFormDefMapping != null)
      this.jsonString = "{success:true}";
    else
      this.jsonString = "{success:false,msg:'未绑定表单，请先绑定表单！'}";
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.flow.FieldRightsAction
 * JD-Core Version:    0.6.0
 */