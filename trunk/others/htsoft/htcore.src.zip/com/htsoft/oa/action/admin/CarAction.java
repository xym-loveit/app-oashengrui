package com.htsoft.oa.action.admin;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.admin.Car;
import com.htsoft.oa.service.admin.CarService;
import java.lang.reflect.Type;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class CarAction extends BaseAction
{

  @Resource
  private CarService carService;
  private Car car;
  private Long carId;

  public Long getCarId()
  {
    return this.carId;
  }

  public void setCarId(Long paramLong)
  {
    this.carId = paramLong;
  }

  public Car getCar()
  {
    return this.car;
  }

  public void setCar(Car paramCar)
  {
    this.car = paramCar;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.carService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setDateFormat("yyyy-MM-dd").create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.carService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    Car localCar = (Car)this.carService.get(this.carId);
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localCar));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.carService.save(this.car);
    setJsonString("{success:true}");
    return "success";
  }

  public String delphoto()
  {
    String str = getRequest().getParameter("carId");
    if (StringUtils.isNotEmpty(str))
    {
      this.car = ((Car)this.carService.get(new Long(str)));
      this.car.setCartImage("");
      this.carService.save(this.car);
      setJsonString("{success:true}");
    }
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.admin.CarAction
 * JD-Core Version:    0.6.0
 */