package com.htsoft.oa.action.flow;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.flow.ProDefRights;
import com.htsoft.oa.service.flow.ProDefRightsService;
import java.lang.reflect.Type;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;

public class ProDefRightsAction extends BaseAction
{

  @Resource
  private ProDefRightsService proDefRightsService;
  private ProDefRights proDefRights;
  private Long rightsId;

  public Long getRightsId()
  {
    return this.rightsId;
  }

  public void setRightsId(Long paramLong)
  {
    this.rightsId = paramLong;
  }

  public ProDefRights getProDefRights()
  {
    return this.proDefRights;
  }

  public void setProDefRights(ProDefRights paramProDefRights)
  {
    this.proDefRights = paramProDefRights;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.proDefRightsService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.proDefRightsService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    String str = getRequest().getParameter("proTypeId");
    if (StringUtils.isNotEmpty(str))
    {
      this.proDefRights = this.proDefRightsService.findByTypeId(new Long(str));
    }
    else
    {
      localObject = getRequest().getParameter("defId");
      if (StringUtils.isNotEmpty((String)localObject))
        this.proDefRights = this.proDefRightsService.findByDefId(new Long((String)localObject));
    }
    Object localObject = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(((Gson)localObject).toJson(this.proDefRights));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return (String)"success";
  }

  public String save()
  {
    this.proDefRights.setUserIds(splitIds(this.proDefRights.getUserIds()));
    this.proDefRights.setRoleIds(splitIds(this.proDefRights.getRoleIds()));
    this.proDefRights.setDepIds(splitIds(this.proDefRights.getDepIds()));
    if (this.proDefRights.getRightsId() == null)
    {
      this.proDefRightsService.save(this.proDefRights);
    }
    else
    {
      ProDefRights localProDefRights = (ProDefRights)this.proDefRightsService.get(this.proDefRights.getRightsId());
      try
      {
        BeanUtil.copyNotNullProperties(localProDefRights, this.proDefRights);
        this.proDefRightsService.save(localProDefRights);
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    setJsonString("{success:true}");
    return "success";
  }

  private String splitIds(String paramString)
  {
    if (StringUtils.isNotEmpty(paramString))
    {
      String[] arrayOfString1 = paramString.split(",");
      StringBuffer localStringBuffer = new StringBuffer(",");
      for (String str : arrayOfString1)
      {
        if (!StringUtils.isNotEmpty(str))
          continue;
        localStringBuffer.append(str).append(",");
      }
      return localStringBuffer.toString();
    }
    return "";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.flow.ProDefRightsAction
 * JD-Core Version:    0.6.0
 */