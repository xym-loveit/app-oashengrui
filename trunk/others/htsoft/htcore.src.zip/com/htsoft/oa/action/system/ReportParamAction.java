package com.htsoft.oa.action.system;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.system.ReportParam;
import com.htsoft.oa.service.system.ReportParamService;
import java.lang.reflect.Type;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class ReportParamAction extends BaseAction
{

  @Resource
  private ReportParamService reportParamService;
  private ReportParam reportParam;
  private Long paramId;

  public Long getParamId()
  {
    return this.paramId;
  }

  public void setParamId(Long paramLong)
  {
    this.paramId = paramLong;
  }

  public ReportParam getReportParam()
  {
    return this.reportParam;
  }

  public void setReportParam(ReportParam paramReportParam)
  {
    this.reportParam = paramReportParam;
  }

  public String list()
  {
    String str = getRequest().getParameter("reportId");
    if (StringUtils.isNotEmpty(str))
    {
      List localList = this.reportParamService.findByRepTemp(new Long(str));
      Type localType = new TypeToken()
      {
      }
      .getType();
      StringBuffer localStringBuffer = new StringBuffer("{success:true,").append("result:");
      Gson localGson = new Gson();
      localStringBuffer.append(localGson.toJson(localList, localType));
      localStringBuffer.append("}");
      this.jsonString = localStringBuffer.toString();
    }
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.reportParamService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    ReportParam localReportParam = (ReportParam)this.reportParamService.get(this.paramId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localReportParam));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.reportParamService.save(this.reportParam);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.ReportParamAction
 * JD-Core Version:    0.6.0
 */