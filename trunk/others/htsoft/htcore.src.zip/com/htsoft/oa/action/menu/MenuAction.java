package com.htsoft.oa.action.menu;

import com.google.gson.Gson;
import com.htsoft.core.util.AppUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.system.AppUser;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;

public class MenuAction extends BaseAction
{
  private Document getCurDocument()
  {
    Document localDocument1 = getModuleDocument();
    Set localSet = ContextUtil.getCurrentUser().getRights();
    if (localSet.contains("__ALL"))
      return localDocument1;
    Document localDocument2 = DocumentHelper.createDocument();
    Element localElement = localDocument2.addElement("Menus");
    createSubMenus(localSet, localDocument1.getRootElement(), localElement);
    if (this.logger.isDebugEnabled())
      this.logger.debug("XML:" + localDocument2.asXML());
    return localDocument2;
  }

  private Document getModuleDocument()
  {
    String str = getRequest().getParameter("topMenuId");
    if (StringUtils.isEmpty(str))
      str = "oa";
    Document localDocument = (Document)AppUtil.getItemsMenus().get(str.toLowerCase());
    return localDocument;
  }

  private void createSubMenus(Set<String> paramSet, Element paramElement1, Element paramElement2)
  {
    List localList = paramElement1.elements();
    if (localList.size() == 0)
      return;
    for (int i = 0; i < localList.size(); i++)
    {
      Element localElement1 = (Element)localList.get(i);
      String str = localElement1.attributeValue("id");
      if ((str == null) || (!paramSet.contains(str)))
        continue;
      Element localElement2 = paramElement2.addElement(localElement1.getName());
      Iterator localIterator = localElement1.attributeIterator();
      while (localIterator.hasNext())
      {
        Attribute localAttribute = (Attribute)localIterator.next();
        localElement2.addAttribute(localAttribute.getName(), localAttribute.getValue());
      }
      createSubMenus(paramSet, localElement1, localElement2);
    }
  }

  public String panelTree()
  {
    String str = getRequest().getParameter("isReload");
    if ("true".equals(str))
      AppUtil.reloadMenu();
    Gson localGson = new Gson();
    Document localDocument = getCurDocument();
    StringBuffer localStringBuffer = new StringBuffer("[");
    if (localDocument != null)
    {
      Element localElement1 = localDocument.getRootElement();
      List localList = localElement1.elements();
      for (int i = 0; i < localList.size(); i++)
      {
        Element localElement2 = (Element)localList.get(i);
        Attribute localAttribute1 = localElement2.attribute("id");
        Attribute localAttribute2 = localElement2.attribute("text");
        Attribute localAttribute3 = localElement2.attribute("iconCls");
        localStringBuffer.append("{id:'").append(localAttribute1 == null ? "" : localAttribute1.getValue()).append("',");
        localStringBuffer.append("text:'").append(localAttribute2 == null ? "" : localAttribute2.getValue()).append("',");
        localStringBuffer.append("iconCls:'").append(localAttribute3 == null ? "" : localAttribute3.getValue()).append("',");
        localStringBuffer.append("subXml:").append(localGson.toJson(getModelXml(localDocument, localAttribute1.getValue()))).append("},");
      }
      if (localList.size() > 0)
        localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    }
    localStringBuffer.append("]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  protected String getModelXml(Document paramDocument, String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r");
    Element localElement = paramDocument.getRootElement();
    List localList = localElement.selectNodes("/Menus/Items[@id='" + paramString + "']/*");
    localStringBuffer.append("<Menus>\r");
    for (int i = 0; i < localList.size(); i++)
    {
      Node localNode = (Node)localList.get(i);
      localStringBuffer.append(localNode.asXML());
    }
    localStringBuffer.append("\r</Menus>\r");
    return localStringBuffer.toString();
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.menu.MenuAction
 * JD-Core Version:    0.6.0
 */