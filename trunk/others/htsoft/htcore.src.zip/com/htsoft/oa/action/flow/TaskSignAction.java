package com.htsoft.oa.action.flow;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.flow.ProUserAssign;
import com.htsoft.oa.model.flow.TaskSign;
import com.htsoft.oa.service.flow.ProUserAssignService;
import com.htsoft.oa.service.flow.TaskSignService;
import java.lang.reflect.Type;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;

public class TaskSignAction extends BaseAction
{

  @Resource
  private TaskSignService taskSignService;

  @Resource
  private ProUserAssignService proUserAssignService;
  private TaskSign taskSign;
  private Long signId;
  private Long assignId;

  public Long getSignId()
  {
    return this.signId;
  }

  public void setSignId(Long paramLong)
  {
    this.signId = paramLong;
  }

  public TaskSign getTaskSign()
  {
    return this.taskSign;
  }

  public void setTaskSign(TaskSign paramTaskSign)
  {
    this.taskSign = paramTaskSign;
  }

  public Long getAssignId()
  {
    return this.assignId;
  }

  public void setAssignId(Long paramLong)
  {
    this.assignId = paramLong;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.taskSignService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.taskSignService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    TaskSign localTaskSign = (TaskSign)this.taskSignService.get(this.signId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localTaskSign));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String find()
  {
    TaskSign localTaskSign = this.taskSignService.findByAssignId(this.assignId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    if (localTaskSign != null)
      localStringBuffer.append(localGson.toJson(localTaskSign));
    else
      localStringBuffer.append("[]");
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    Object localObject;
    if (this.taskSign.getSignId() == null)
    {
      localObject = (ProUserAssign)this.proUserAssignService.get(this.assignId);
      this.taskSign.setProUserAssign((ProUserAssign)localObject);
      this.taskSignService.save(this.taskSign);
    }
    else
    {
      localObject = (TaskSign)this.taskSignService.get(this.taskSign.getSignId());
      try
      {
        BeanUtil.copyNotNullProperties(localObject, this.taskSign);
        this.taskSignService.save(localObject);
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    setJsonString("{success:true}");
    return (String)"success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.flow.TaskSignAction
 * JD-Core Version:    0.6.0
 */