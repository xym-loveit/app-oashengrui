package com.htsoft.oa.action.flow;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.flow.ProcessModule;
import com.htsoft.oa.service.flow.ProcessModuleService;
import flexjson.JSONSerializer;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;

public class ProcessModuleAction extends BaseAction
{

  @Resource
  private ProcessModuleService processModuleService;
  private ProcessModule processModule;
  private Long moduleid;

  public Long getModuleid()
  {
    return this.moduleid;
  }

  public void setModuleid(Long paramLong)
  {
    this.moduleid = paramLong;
  }

  public ProcessModule getProcessModule()
  {
    return this.processModule;
  }

  public void setProcessModule(ProcessModule paramProcessModule)
  {
    this.processModule = paramProcessModule;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.processModuleService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "createtime" });
    localStringBuffer.append(localJSONSerializer.serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.processModuleService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    ProcessModule localProcessModule = (ProcessModule)this.processModuleService.get(this.moduleid);
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "createtime" });
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localJSONSerializer.serialize(localProcessModule));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    if (this.processModule.getModuleid() == null)
    {
      this.processModule.setCreatetime(new Date());
      this.processModuleService.save(this.processModule);
    }
    else
    {
      ProcessModule localProcessModule = (ProcessModule)this.processModuleService.get(this.processModule.getModuleid());
      try
      {
        BeanUtil.copyNotNullProperties(localProcessModule, this.processModule);
        this.processModuleService.save(localProcessModule);
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.flow.ProcessModuleAction
 * JD-Core Version:    0.6.0
 */