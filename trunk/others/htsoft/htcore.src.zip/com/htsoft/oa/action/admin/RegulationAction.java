package com.htsoft.oa.action.admin;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.admin.Regulation;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.Department;
import com.htsoft.oa.model.system.FileAttach;
import com.htsoft.oa.model.system.GlobalType;
import com.htsoft.oa.service.admin.RegulationService;
import com.htsoft.oa.service.system.FileAttachService;
import flexjson.JSONSerializer;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;

public class RegulationAction extends BaseAction
{

  @Resource
  private RegulationService regulationService;

  @Resource
  private FileAttachService fileAttachService;
  private Regulation regulation;
  private Long regId;

  public Long getRegId()
  {
    return this.regId;
  }

  public void setRegId(Long paramLong)
  {
    this.regId = paramLong;
  }

  public Regulation getRegulation()
  {
    return this.regulation;
  }

  public void setRegulation(Regulation paramRegulation)
  {
    this.regulation = paramRegulation;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.regulationService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "issueDate" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "content" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String scan()
  {
    AppUser localAppUser = ContextUtil.getCurrentUser();
    Department localDepartment = localAppUser.getDepartment();
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.setFilterName("GetRegulationWithRights");
    localQueryFilter.addParamValue(Regulation.STATUS_EFFECT);
    if (localDepartment != null)
      localQueryFilter.addParamValue("%," + localAppUser.getDepartment().getDepId() + ",%");
    else
      localQueryFilter.addParamValue("%,0,%");
    localQueryFilter.addParamValue("%," + ContextUtil.getCurrentUserId() + ",%");
    List localList = this.regulationService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "issueDate" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "content" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.regulationService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    Regulation localRegulation = (Regulation)this.regulationService.get(this.regId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localRegulation));
    GlobalType localGlobalType = localRegulation.getGlobalType();
    if (localGlobalType != null)
    {
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
      localStringBuffer.append(",proTypeId:").append(localGlobalType.getProTypeId()).append(",proTypeName:'").append(localGlobalType.getTypeName()).append("'}");
    }
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    String str1 = getRequest().getParameter("regAttachsFileIds");
    HashSet localHashSet = new HashSet();
    Object localObject3;
    if (StringUtils.isNotEmpty(str1))
    {
      localObject1 = str1.split(",");
      for (int i = 0; i < localObject1.length; i++)
      {
        localObject3 = (FileAttach)this.fileAttachService.get(new Long(localObject1[i]));
        localHashSet.add(localObject3);
      }
    }
    Object localObject1 = this.regulation.getRecDepIds();
    if (StringUtils.isNotEmpty((String)localObject1))
    {
      localObject2 = ((String)localObject1).split(",");
      localObject3 = new StringBuffer(",");
      for (String str2 : localObject2)
        ((StringBuffer)localObject3).append(str2).append(",");
      this.regulation.setRecDepIds(((StringBuffer)localObject3).toString());
    }
    Object localObject2 = this.regulation.getRecUserIds();
    if (StringUtils.isNotEmpty((String)localObject2))
    {
      localObject3 = ((String)localObject2).split(",");
      ??? = new StringBuffer(",");
      for (String str3 : localObject3)
        ((StringBuffer)???).append(str3).append(",");
      this.regulation.setRecUserIds(((StringBuffer)???).toString());
    }
    if (this.regulation.getRegId() == null)
    {
      this.regulation.setRegAttachs(localHashSet);
      this.regulationService.save(this.regulation);
    }
    else
    {
      localObject3 = (Regulation)this.regulationService.get(this.regulation.getRegId());
      try
      {
        BeanUtil.copyNotNullProperties(localObject3, this.regulation);
        ((Regulation)localObject3).setRegAttachs(localHashSet);
        this.regulationService.save(localObject3);
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    setJsonString("{success:true}");
    return (String)(String)(String)(String)"success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.admin.RegulationAction
 * JD-Core Version:    0.6.0
 */