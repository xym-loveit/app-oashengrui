package com.htsoft.oa.action.mobile;

import com.htsoft.core.util.StringUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.system.AppUserService;
import javax.annotation.Resource;
import org.apache.commons.lang.StringUtils;
import org.springframework.security.AuthenticationManager;
import org.springframework.security.context.SecurityContext;
import org.springframework.security.context.SecurityContextHolder;
import org.springframework.security.providers.UsernamePasswordAuthenticationToken;

public class SignInAction extends BaseAction
{

  @Resource
  private AppUserService userService;

  @Resource(name="authenticationManager")
  private AuthenticationManager authenticationManager = null;
  private String username;
  private String password;

  public String getUsername()
  {
    return this.username;
  }

  public void setUsername(String paramString)
  {
    this.username = paramString;
  }

  public String getPassword()
  {
    return this.password;
  }

  public void setPassword(String paramString)
  {
    this.password = paramString;
  }

  public String execute()
    throws Exception
  {
    if ((StringUtils.isNotEmpty(this.username)) && (StringUtils.isNotEmpty(this.password)))
    {
      AppUser localAppUser = this.userService.findByUserName(this.username);
      if (localAppUser != null)
      {
        String str = StringUtil.encryptSha256(this.password);
        if (str.equals(localAppUser.getPassword()))
        {
          UsernamePasswordAuthenticationToken localUsernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(this.username, this.password);
          SecurityContext localSecurityContext = SecurityContextHolder.getContext();
          localSecurityContext.setAuthentication(this.authenticationManager.authenticate(localUsernamePasswordAuthenticationToken));
          SecurityContextHolder.setContext(localSecurityContext);
          return "success";
        }
      }
    }
    return "input";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.mobile.SignInAction
 * JD-Core Version:    0.6.0
 */