package com.htsoft.oa.action.customer;

import com.google.gson.Gson;
import com.htsoft.core.engine.MailEngine;
import com.htsoft.core.util.AppUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.customer.Customer;
import com.htsoft.oa.model.customer.CustomerMail;
import com.htsoft.oa.model.customer.Provider;
import com.htsoft.oa.model.system.Company;
import com.htsoft.oa.model.system.FileAttach;
import com.htsoft.oa.service.customer.CustomerService;
import com.htsoft.oa.service.customer.ProviderService;
import com.htsoft.oa.service.system.CompanyService;
import com.htsoft.oa.service.system.FileAttachService;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import org.apache.commons.lang.StringUtils;
import org.apache.velocity.app.VelocityEngine;
import org.springframework.ui.velocity.VelocityEngineUtils;

public class MutilMailAction extends BaseAction
{

  @Resource
  private MailEngine mailEngine;

  @Resource
  private ProviderService providerService;

  @Resource
  private FileAttachService fileAttachService;

  @Resource
  private CustomerService customerService;

  @Resource
  private CompanyService companyService;
  private CustomerMail customerMail;

  public CustomerMail getCustomerMail()
  {
    return this.customerMail;
  }

  public void setCustomerMail(CustomerMail paramCustomerMail)
  {
    this.customerMail = paramCustomerMail;
  }

  public String send()
  {
    Short localShort = this.customerMail.getType();
    String str1 = this.customerMail.getIds();
    String str2 = this.customerMail.getFiles();
    ArrayList localArrayList1 = new ArrayList();
    ArrayList localArrayList2 = new ArrayList();
    if (StringUtils.isNotEmpty(str2))
    {
      arrayOfString1 = str2.split(",");
      for (int i = 0; i < arrayOfString1.length; i++)
      {
        FileAttach localFileAttach = (FileAttach)this.fileAttachService.get(new Long(arrayOfString1[i]));
        localObject = new File(getSession().getServletContext().getRealPath("/attachFiles/") + "/" + localFileAttach.getFilePath());
        localArrayList2.add(localFileAttach.getFileName());
        localArrayList1.add(localObject);
      }
    }
    String[] arrayOfString1 = str1.split(",");
    ArrayList localArrayList3 = new ArrayList();
    int j;
    if (localShort.shortValue() == 0)
      for (j = 0; j < arrayOfString1.length; j++)
      {
        localObject = (Customer)this.customerService.get(new Long(arrayOfString1[j]));
        localArrayList3.add(((Customer)localObject).getEmail());
      }
    if (localShort.shortValue() == 1)
      for (j = 0; j < arrayOfString1.length; j++)
      {
        localObject = (Provider)this.providerService.get(new Long(arrayOfString1[j]));
        localArrayList3.add(((Provider)localObject).getEmail());
      }
    String str3 = null;
    Object localObject = null;
    String str4 = this.customerMail.getMailContent();
    String str5 = this.customerMail.getSubject();
    String[] arrayOfString2 = new String[0];
    String[] arrayOfString3 = (String[])localArrayList2.toArray(arrayOfString2);
    File[] arrayOfFile1 = new File[0];
    File[] arrayOfFile2 = (File[])localArrayList1.toArray(arrayOfFile1);
    String str6 = null;
    String[] arrayOfString4 = (String[])localArrayList3.toArray(arrayOfString2);
    if (arrayOfString4.length > 0)
    {
      Map localMap = AppUtil.getSysConfig();
      if ((StringUtils.isNotEmpty((String)localMap.get("host"))) && (StringUtils.isNotEmpty((String)localMap.get("username"))) && (StringUtils.isNotEmpty((String)localMap.get("password"))) && (StringUtils.isNotEmpty((String)localMap.get("from"))))
      {
        this.mailEngine.setFrom((String)localMap.get("from"));
        this.mailEngine.sendMimeMessage(str3, arrayOfString4, (String)localObject, str6, str5, str4, arrayOfString3, arrayOfFile2, false);
        setJsonString("{success:true}");
      }
      else
      {
        setJsonString("{success:false,message:'未配置好邮箱配置!'}");
      }
    }
    else
    {
      setJsonString("{success:false}");
    }
    return (String)"success";
  }

  public String loadVm()
  {
    VelocityEngine localVelocityEngine = (VelocityEngine)AppUtil.getBean("velocityEngine");
    String str1 = "mail/sendMsg.vm";
    HashMap localHashMap = new HashMap();
    localHashMap.put("appUser", ContextUtil.getCurrentUser());
    List localList = this.companyService.findCompany();
    if (localList.size() > 0)
    {
      Company localCompany = (Company)localList.get(0);
      if (localCompany != null)
        localHashMap.put("company", localCompany);
      String str2 = VelocityEngineUtils.mergeTemplateIntoString(localVelocityEngine, str1, localHashMap);
      Gson localGson = new Gson();
      setJsonString("{success:true,data:" + localGson.toJson(str2) + "}");
    }
    else
    {
      setJsonString("{success:false,message:'你的公司信息还不完整！请填写好公司信息!'}");
    }
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.customer.MutilMailAction
 * JD-Core Version:    0.6.0
 */