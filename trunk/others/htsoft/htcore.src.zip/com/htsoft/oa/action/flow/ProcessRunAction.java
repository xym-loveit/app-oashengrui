package com.htsoft.oa.action.flow;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.jbpm.pv.TaskInfo;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.util.StringUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.flow.ProDefinition;
import com.htsoft.oa.model.flow.ProcessRun;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.flow.HistoryTaskService;
import com.htsoft.oa.service.flow.JbpmService;
import com.htsoft.oa.service.flow.ProcessRunService;
import com.htsoft.oa.service.system.AppUserService;
import flexjson.JSONSerializer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;
import org.jbpm.api.ProcessInstance;
import org.jbpm.api.model.Activity;
import org.jbpm.api.model.Transition;
import org.jbpm.api.task.Task;
import org.jbpm.pvm.internal.history.model.HistoryTaskInstanceImpl;
import org.jbpm.pvm.internal.task.ParticipationImpl;
import org.jbpm.pvm.internal.task.TaskImpl;

public class ProcessRunAction extends BaseAction
{

  @Resource
  private ProcessRunService processRunService;
  private ProcessRun processRun;

  @Resource
  private JbpmService jbpmService;

  @Resource
  private HistoryTaskService historyTaskService;

  @Resource
  private AppUserService appUserService;
  private Long runId;

  public Long getRunId()
  {
    return this.runId;
  }

  public void setRunId(Long paramLong)
  {
    this.runId = paramLong;
  }

  public ProcessRun getProcessRun()
  {
    return this.processRun;
  }

  public void setProcessRun(ProcessRun paramProcessRun)
  {
    this.processRun = paramProcessRun;
  }

  public String myRunning()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.setFilterName("myRunning");
    localQueryFilter.addParamValue(ContextUtil.getCurrentUserId());
    localQueryFilter.addParamValue(ProcessRun.RUN_STATUS_RUNNING);
    List localList1 = this.processRunService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:[");
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    Iterator localIterator1 = localList1.iterator();
    while (localIterator1.hasNext())
    {
      ProcessRun localProcessRun = (ProcessRun)localIterator1.next();
      localStringBuffer.append("{runId:'").append(localProcessRun.getRunId()).append("',subject:'").append(localProcessRun.getSubject()).append("',createtime:'").append(localSimpleDateFormat.format(localProcessRun.getCreatetime())).append("',piId:'").append(localProcessRun.getPiId()).append("',defId:'").append(localProcessRun.getProDefinition().getDefId()).append("',runStatus:'").append(localProcessRun.getRunStatus()).append("'");
      List localList2 = this.jbpmService.getTasksByPiId(localProcessRun.getPiId());
      if (localList2 != null)
      {
        String str1 = "";
        String str2 = "";
        int i = 0;
        Iterator localIterator2 = localList2.iterator();
        while (localIterator2.hasNext())
        {
          Task localTask = (Task)localIterator2.next();
          if (i++ > 0)
          {
            str1 = str1 + ",";
            str2 = str2 + ",";
          }
          str1 = str1 + localTask.getName();
          Object localObject1;
          if ((localTask.getAssignee() != null) && (StringUtil.isNumeric(localTask.getAssignee())))
          {
            localObject1 = (AppUser)this.appUserService.get(new Long(localTask.getAssignee()));
            str2 = str2 + ((AppUser)localObject1).getFullname();
          }
          else
          {
            localObject1 = (TaskImpl)localTask;
            Iterator localIterator3 = ((TaskImpl)localObject1).getParticipations().iterator();
            while (localIterator3.hasNext())
            {
              ParticipationImpl localParticipationImpl = (ParticipationImpl)localIterator3.next();
              Object localObject2;
              if (localParticipationImpl.getUserId() != null)
              {
                if (StringUtil.isNumeric(localParticipationImpl.getUserId()))
                {
                  localObject2 = (AppUser)this.appUserService.get(new Long(localParticipationImpl.getUserId()));
                  str2 = str2 + ((AppUser)localObject2).getFullname();
                }
              }
              else if ((localParticipationImpl.getGroupId() != null) && (StringUtil.isNumeric(localParticipationImpl.getGroupId())))
              {
                localObject2 = this.appUserService.getUsersByRoleId(new Long(localParticipationImpl.getGroupId()));
                Iterator localIterator4 = ((List)localObject2).iterator();
                while (localIterator4.hasNext())
                {
                  AppUser localAppUser = (AppUser)localIterator4.next();
                  str2 = str2 + localAppUser.getFullname();
                }
              }
            }
          }
        }
        localStringBuffer.append(",tasks:'").append(str1).append("'");
        localStringBuffer.append(",exeUsers:'").append(str2).append("'");
      }
      localStringBuffer.append("},");
    }
    if (localList1.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]");
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return (String)(String)"success";
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_appUser.userId_L_EQ", ContextUtil.getCurrentUserId().toString());
    List localList = this.processRunService.getAll(localQueryFilter);
    this.jsonString = formatRunList(localList, Integer.valueOf(localQueryFilter.getPagingBean().getTotalItems()));
    return "success";
  }

  private String formatRunList(List<ProcessRun> paramList, Integer paramInteger)
  {
    Gson localGson = JsonUtil.getGson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(paramInteger).append(",result:[");
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      ProcessRun localProcessRun = (ProcessRun)localIterator.next();
      localStringBuffer.append("{runId:").append(localGson.toJson(localProcessRun.getRunId())).append(",subject:").append(localGson.toJson(localProcessRun.getSubject())).append(",createtime:").append(localGson.toJson(localProcessRun.getCreatetime())).append(",piId:").append(localGson.toJson(localProcessRun.getPiId())).append(",defId:").append(localGson.toJson(localProcessRun.getProDefinition().getDefId())).append(",runStatus:").append(localGson.toJson(localProcessRun.getRunStatus())).append("},");
    }
    if (paramList.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]");
    localStringBuffer.append("}");
    return localStringBuffer.toString();
  }

  public String my()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.setFilterName("MyAttendProcessRun");
    localQueryFilter.addParamValue(ContextUtil.getCurrentUserId());
    List localList = this.processRunService.getAll(localQueryFilter);
    this.jsonString = formatRunList(localList, Integer.valueOf(localQueryFilter.getPagingBean().getTotalItems()));
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.processRunService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    ProcessRun localProcessRun = (ProcessRun)this.processRunService.get(this.runId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localProcessRun));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.processRunService.save(this.processRun);
    setJsonString("{success:true}");
    return "success";
  }

  public String instance()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.processRunService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "createtime" }).exclude(new String[] { "appUser", "processForms" });
    localStringBuffer.append(localJSONSerializer.serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String tasks()
  {
    String str1 = getRequest().getParameter("runId");
    ProcessRun localProcessRun = (ProcessRun)this.processRunService.get(new Long(str1));
    String str2 = localProcessRun.getPiId();
    List localList = this.jbpmService.getTasksByPiId(str2);
    ArrayList localArrayList = new ArrayList();
    Object localObject1 = localList.iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (Task)((Iterator)localObject1).next();
      localArrayList.add((TaskImpl)localObject2);
    }
    localObject1 = constructTaskInfos(localArrayList, localProcessRun);
    Object localObject2 = new StringBuffer("{success:true,'totalCounts':").append(localArrayList.size()).append(",result:");
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    ((StringBuffer)localObject2).append(localGson.toJson(localObject1));
    ((StringBuffer)localObject2).append("}");
    this.jsonString = ((StringBuffer)localObject2).toString();
    return (String)(String)"success";
  }

  protected List<TaskInfo> constructTaskInfos(List<TaskImpl> paramList, ProcessRun paramProcessRun)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      TaskImpl localTaskImpl = (TaskImpl)localIterator.next();
      TaskInfo localTaskInfo = new TaskInfo(localTaskImpl);
      if ((localTaskImpl.getAssignee() != null) && (!localTaskImpl.getAssignee().trim().equalsIgnoreCase("null")))
        try
        {
          AppUser localAppUser = (AppUser)this.appUserService.get(new Long(localTaskImpl.getAssignee()));
          localTaskInfo.setAssignee(localAppUser.getFullname());
        }
        catch (Exception localException)
        {
          this.logger.error(localException);
        }
      if (localTaskImpl.getSuperTask() != null)
        localTaskImpl = localTaskImpl.getSuperTask();
      if (paramProcessRun != null)
      {
        localTaskInfo.setTaskName(paramProcessRun.getSubject() + "--" + localTaskImpl.getActivityName());
        localTaskInfo.setActivityName(localTaskImpl.getActivityName());
      }
      localArrayList.add(localTaskInfo);
    }
    return localArrayList;
  }

  public String end()
  {
    String str1 = getRequest().getParameter("runIds");
    String[] arrayOfString1 = str1.split(",");
    for (String str2 : arrayOfString1)
    {
      ProcessRun localProcessRun = (ProcessRun)this.processRunService.get(new Long(str2));
      if (localProcessRun == null)
        continue;
      String str3 = localProcessRun.getPiId();
      try
      {
        ProcessInstance localProcessInstance = this.jbpmService.getProcessInstance(str3);
        if (localProcessInstance != null)
          this.jbpmService.endProcessInstance(str3);
        localProcessRun.setRunStatus(ProcessRun.RUN_STATUS_FINISHED);
        this.processRunService.save(localProcessRun);
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
        setJsonString("{success:false}");
        return "success";
      }
    }
    setJsonString("{success:true}");
    return "success";
  }

  public String rollback()
  {
    String str1 = null;
    ProcessRun localProcessRun = (ProcessRun)this.processRunService.get(this.runId);
    List localList1 = this.jbpmService.getTasksByPiId(localProcessRun.getPiId());
    String str2 = ContextUtil.getCurrentUserId().toString();
    Iterator localIterator1 = localList1.iterator();
    while (localIterator1.hasNext())
    {
      Task localTask = (Task)localIterator1.next();
      List localList2 = this.jbpmService.getInTransForTask(localTask.getId());
      Iterator localIterator2 = localList2.iterator();
      while (localIterator2.hasNext())
      {
        Transition localTransition = (Transition)localIterator2.next();
        String str3 = localTransition.getSource().getType();
        this.logger.info("pre node type:" + str3);
        Object localObject1;
        Object localObject2;
        Object localObject3;
        if (("decision".equals(str3)) || ("fork".equals(str3)))
        {
          localObject1 = localTransition.getSource();
          localObject2 = ((Activity)localObject1).getIncomingTransitions();
          for (int i = 0; i < ((List)localObject2).size(); i++)
          {
            localObject3 = (Transition)((List)localObject2).get(i);
            String str4 = ((Transition)localObject3).getName();
            String str5 = ((Transition)localObject3).getSource().getName();
            List localList4 = this.historyTaskService.getByPiIdAssigneeOutcome(localProcessRun.getPiId(), str2, str5, str4);
            if (localList4.size() <= 0)
              continue;
            HistoryTaskInstanceImpl localHistoryTaskInstanceImpl = (HistoryTaskInstanceImpl)localList4.get(0);
            str1 = localHistoryTaskInstanceImpl.getActivityName();
            this.logger.info("allow back 2:" + localHistoryTaskInstanceImpl.getActivityName());
            break;
          }
        }
        else if ("task".equals(str3))
        {
          localObject1 = localTransition.getName();
          localObject2 = localTransition.getSource().getName();
          List localList3 = this.historyTaskService.getByPiIdAssigneeOutcome(localProcessRun.getPiId(), str2, (String)localObject2, (String)localObject1);
          if (localList3.size() > 0)
          {
            localObject3 = (HistoryTaskInstanceImpl)localList3.get(0);
            str1 = ((HistoryTaskInstanceImpl)localObject3).getActivityName();
            this.logger.info("allow back :" + ((HistoryTaskInstanceImpl)localObject3).getActivityName());
            break;
          }
        }
      }
    }
    if (str1 != null)
    {
      this.logger.info("prepared to jump previous task node");
      this.jbpmService.jumpToPreTask(localProcessRun.getPiId(), str2, str1);
      this.jsonString = "{success:true}";
    }
    else
    {
      this.jsonString = "{success:false}";
    }
    return (String)(String)(String)"success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.flow.ProcessRunAction
 * JD-Core Version:    0.6.0
 */