package com.htsoft.oa.action.flow;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.XmlUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.flow.ProDefinition;
import com.htsoft.oa.model.flow.ProHandleComp;
import com.htsoft.oa.service.flow.JbpmService;
import com.htsoft.oa.service.flow.ProDefinitionService;
import com.htsoft.oa.service.flow.ProHandleCompService;
import java.io.PrintStream;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.Element;

public class ProHandleCompAction extends BaseAction
{

  @Resource
  private ProHandleCompService proHandleCompService;

  @Resource
  private ProDefinitionService proDefinitionService;

  @Resource
  private JbpmService jbpmService;
  private ProHandleComp proHandleComp;
  private Long handleId;

  public Long getHandleId()
  {
    return this.handleId;
  }

  public void setHandleId(Long paramLong)
  {
    this.handleId = paramLong;
  }

  public ProHandleComp getProHandleComp()
  {
    return this.proHandleComp;
  }

  public void setProHandleComp(ProHandleComp paramProHandleComp)
  {
    this.proHandleComp = paramProHandleComp;
  }

  public String getDecision()
  {
    String str1 = getRequest().getParameter("defId");
    String str2 = getRequest().getParameter("activityName");
    ProDefinition localProDefinition = (ProDefinition)this.proDefinitionService.get(new Long(str1));
    List localList = this.proHandleCompService.getByDeployIdActivityNameHandleType(localProDefinition.getDeployId(), str2, ProHandleComp.HANDLE_TYPE_HANDLER);
    String str3 = "";
    if (localList.size() > 0)
    {
      localObject = (ProHandleComp)localList.get(0);
      str3 = ((ProHandleComp)localObject).getExeCode();
    }
    Object localObject = new Gson();
    this.jsonString = ("{success:true,data:{exeCode:" + ((Gson)localObject).toJson(str3) + "}}");
    return (String)"success";
  }

  public String getCode()
  {
    HttpServletRequest localHttpServletRequest = getRequest();
    String str1 = localHttpServletRequest.getParameter("activityName");
    String str2 = localHttpServletRequest.getParameter("defId");
    String str3 = localHttpServletRequest.getParameter("includeDecision");
    String str4 = "";
    String str5 = "";
    String str6 = "";
    ProDefinition localProDefinition = (ProDefinition)this.proDefinitionService.get(new Long(str2));
    ProHandleComp localProHandleComp1 = this.proHandleCompService.getProHandleComp(localProDefinition.getDeployId(), str1, "start");
    ProHandleComp localProHandleComp2 = this.proHandleCompService.getProHandleComp(localProDefinition.getDeployId(), str1, "end");
    if ((localProHandleComp1 != null) && (StringUtils.isNotEmpty(localProHandleComp1.getExeCode())))
      str4 = localProHandleComp1.getExeCode();
    if ((localProHandleComp2 != null) && (StringUtils.isNotEmpty(localProHandleComp2.getExeCode())))
      str5 = localProHandleComp2.getExeCode();
    if ("true".equals(str3))
    {
      localObject = this.proHandleCompService.getByDeployIdActivityNameHandleType(localProDefinition.getDeployId(), str1, ProHandleComp.HANDLE_TYPE_HANDLER);
      if (((List)localObject).size() > 0)
      {
        ProHandleComp localProHandleComp3 = (ProHandleComp)((List)localObject).get(0);
        if (StringUtils.isNotEmpty(localProHandleComp3.getExeCode()))
          str6 = localProHandleComp3.getExeCode();
      }
    }
    Object localObject = new Gson();
    this.jsonString = ("{success:true,startExeCode:" + ((Gson)localObject).toJson(str4) + ",endExeCode:" + ((Gson)localObject).toJson(str5) + ",decisionExeCode:" + ((Gson)localObject).toJson(str6) + "}");
    return (String)"success";
  }

  public String saveCode()
  {
    HttpServletRequest localHttpServletRequest = getRequest();
    String str1 = localHttpServletRequest.getParameter("startExeCode");
    String str2 = localHttpServletRequest.getParameter("endExeCode");
    String str3 = localHttpServletRequest.getParameter("decisionExeCode");
    String str4 = localHttpServletRequest.getParameter("activityName");
    String str5 = localHttpServletRequest.getParameter("defId");
    ProDefinition localProDefinition = (ProDefinition)this.proDefinitionService.get(new Long(str5));
    String str6 = this.jbpmService.getDefinitionXmlByDpId(localProDefinition.getDeployId());
    Document localDocument = XmlUtil.stringToDocument(str6);
    ProHandleComp localProHandleComp1 = this.proHandleCompService.getProHandleComp(localProDefinition.getDeployId(), str4, "start");
    if (localProHandleComp1 == null)
    {
      localProHandleComp1 = new ProHandleComp();
      localProHandleComp1.setActivityName(str4);
      localProHandleComp1.setDeployId(localProDefinition.getDeployId());
      localProHandleComp1.setEventName("start");
      localProHandleComp1.setHandleType(ProHandleComp.HANDLE_TYPE_LISTENER);
    }
    localProHandleComp1.setExeCode(str1);
    this.proHandleCompService.save(localProHandleComp1);
    if (StringUtils.isNotEmpty(str1))
      writeXml(localDocument, str4, "start");
    ProHandleComp localProHandleComp2 = this.proHandleCompService.getProHandleComp(localProDefinition.getDeployId(), str4, "end");
    if (localProHandleComp2 == null)
    {
      localProHandleComp2 = new ProHandleComp();
      localProHandleComp2.setActivityName(str4);
      localProHandleComp2.setDeployId(localProDefinition.getDeployId());
      localProHandleComp2.setEventName("end");
      localProHandleComp2.setHandleType(ProHandleComp.HANDLE_TYPE_LISTENER);
    }
    localProHandleComp2.setExeCode(str2);
    this.proHandleCompService.save(localProHandleComp2);
    if (StringUtils.isNotEmpty(str2))
      writeXml(localDocument, str4, "end");
    List localList = this.proHandleCompService.getByDeployIdActivityNameHandleType(localProDefinition.getDeployId(), str4, ProHandleComp.HANDLE_TYPE_HANDLER);
    ProHandleComp localProHandleComp3 = null;
    if (localList.size() > 0)
    {
      localProHandleComp3 = (ProHandleComp)localList.get(0);
    }
    else
    {
      localProHandleComp3 = new ProHandleComp();
      localProHandleComp3.setActivityName(str4);
      localProHandleComp3.setDeployId(localProDefinition.getDeployId());
      localProHandleComp3.setHandleType(ProHandleComp.HANDLE_TYPE_HANDLER);
    }
    localProHandleComp3.setExeCode(str3);
    this.proHandleCompService.save(localProHandleComp3);
    if (StringUtils.isNotEmpty(str3))
      writeXml(localDocument, str4, "decision");
    str6 = XmlUtil.docToString(localDocument);
    this.jbpmService.wirteDefXml(localProDefinition.getDeployId(), str6);
    localProDefinition.setDefXml(str6);
    this.proDefinitionService.save(localProDefinition);
    return "success";
  }

  public String saveDecision()
  {
    String str1 = getRequest().getParameter("exeCode");
    String str2 = getRequest().getParameter("defId");
    String str3 = getRequest().getParameter("activityName");
    ProDefinition localProDefinition = (ProDefinition)this.proDefinitionService.get(new Long(str2));
    List localList = this.proHandleCompService.getByDeployIdActivityNameHandleType(localProDefinition.getDeployId(), str3, ProHandleComp.HANDLE_TYPE_HANDLER);
    ProHandleComp localProHandleComp = null;
    if (localList.size() > 0)
    {
      localProHandleComp = (ProHandleComp)localList.get(0);
    }
    else
    {
      localProHandleComp = new ProHandleComp();
      localProHandleComp.setActivityName(str3);
      localProHandleComp.setDeployId(localProDefinition.getDeployId());
      localProHandleComp.setHandleType(ProHandleComp.HANDLE_TYPE_HANDLER);
    }
    localProHandleComp.setExeCode(str1);
    this.proHandleCompService.save(localProHandleComp);
    String str4 = this.jbpmService.getDefinitionXmlByDpId(localProHandleComp.getDeployId());
    Document localDocument = XmlUtil.stringToDocument(str4);
    Element localElement1 = localDocument.getRootElement();
    Iterator localIterator = localElement1.elementIterator();
    while (localIterator.hasNext())
    {
      Element localElement2 = (Element)localIterator.next();
      if ("decision".equals(localElement2.getName()))
      {
        String str5 = localElement2.attributeValue("name");
        if (str5.equals(str3))
        {
          Attribute localAttribute = localElement2.attribute("expr");
          if (localAttribute != null)
            localElement2.remove(localAttribute);
          Element localElement3 = (Element)localElement2.selectSingleNode("./handler");
          if (localElement3 != null)
            break;
          localElement3 = localElement2.addElement("handler");
          localElement3.addAttribute("class", "com.htsoft.oa.workflow.handler.DecisionHandlerImpl");
          break;
        }
      }
    }
    str4 = localDocument.asXML();
    this.logger.info("xml:" + str4);
    try
    {
      str4 = new String(str4.getBytes(), "UTF-8");
    }
    catch (Exception localException)
    {
      this.logger.error(localException);
    }
    this.logger.debug("lastXml:" + str4);
    this.jbpmService.wirteDefXml(localProHandleComp.getDeployId(), str4);
    localProDefinition.setDefXml(str4);
    this.proDefinitionService.save(localProDefinition);
    return "success";
  }

  private void writeXml(Document paramDocument, String paramString1, String paramString2)
  {
    Element localElement1 = paramDocument.getRootElement();
    Iterator localIterator1 = localElement1.elementIterator();
    while (localIterator1.hasNext())
    {
      Element localElement2 = (Element)localIterator1.next();
      String str;
      Object localObject;
      Element localElement3;
      if ("decision".equals(paramString2))
      {
        if ("decision".equals(localElement2.getName()))
        {
          str = localElement2.attributeValue("name");
          if (str.equals(paramString1))
          {
            Attribute localAttribute = localElement2.attribute("expr");
            if (localAttribute != null)
              localElement2.remove(localAttribute);
            int j = 0;
            localObject = localElement2.elementIterator();
            while (((Iterator)localObject).hasNext())
            {
              localElement3 = (Element)((Iterator)localObject).next();
              if ("handler".equals(localElement3.getName()))
              {
                j = 1;
                break;
              }
            }
            if (j != 0)
              break;
            localElement3 = localElement2.addElement("handler");
            localElement3.addAttribute("class", "com.htsoft.oa.workflow.handler.DecisionHandlerImpl");
            break;
          }
        }
      }
      else
      {
        int i;
        Iterator localIterator2;
        Element localElement4;
        Element localElement5;
        Element localElement6;
        if ("start".equals(paramString2))
        {
          str = localElement2.attributeValue("name");
          if (str.equals(paramString1))
          {
            i = 0;
            localIterator2 = localElement2.elementIterator();
            while (localIterator2.hasNext())
            {
              localObject = (Element)localIterator2.next();
              if (("on".equals(((Element)localObject).getName())) && ("start".equals(((Element)localObject).attributeValue("event"))))
              {
                i = 1;
                break;
              }
            }
            if (i != 0)
              break;
            localObject = localElement2.addElement("on");
            localElement3 = ((Element)localObject).addAttribute("event", "start");
            localElement4 = localElement3.addElement("event-listener");
            localElement4.addAttribute("class", "com.htsoft.oa.workflow.event.NodeEventListener");
            localElement5 = localElement4.addElement("field");
            localElement5.addAttribute("name", "eventType");
            localElement6 = localElement5.addElement("string");
            localElement6.addAttribute("value", "start");
            break;
          }
        }
        else if ("end".equals(paramString2))
        {
          str = localElement2.attributeValue("name");
          if (str.equals(paramString1))
          {
            i = 0;
            localIterator2 = localElement2.elementIterator();
            while (localIterator2.hasNext())
            {
              localObject = (Element)localIterator2.next();
              if (("on".equals(((Element)localObject).getName())) && ("end".equals(((Element)localObject).attributeValue("event"))))
              {
                i = 1;
                break;
              }
            }
            if (i != 0)
              break;
            localObject = localElement2.addElement("on");
            localElement3 = ((Element)localObject).addAttribute("event", "end");
            localElement4 = localElement3.addElement("event-listener");
            localElement4.addAttribute("class", "com.htsoft.oa.workflow.event.NodeEventListener");
            localElement5 = localElement4.addElement("field");
            localElement5.addAttribute("name", "eventType");
            localElement6 = localElement5.addElement("string");
            localElement6.addAttribute("value", "end");
            break;
          }
        }
      }
    }
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.proHandleCompService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.proHandleCompService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    ProHandleComp localProHandleComp = (ProHandleComp)this.proHandleCompService.get(this.handleId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localProHandleComp));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    if (this.proHandleComp.getHandleId() == null)
    {
      this.proHandleCompService.save(this.proHandleComp);
    }
    else
    {
      ProHandleComp localProHandleComp = (ProHandleComp)this.proHandleCompService.get(this.proHandleComp.getHandleId());
      try
      {
        BeanUtil.copyNotNullProperties(localProHandleComp, this.proHandleComp);
        this.proHandleCompService.save(localProHandleComp);
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    setJsonString("{success:true}");
    return "success";
  }

  public static void main(String[] paramArrayOfString)
  {
    String str1 = "D:/tools/jbpm/jbpm-4.4/jbpm-4.4/examples/src/org/jbpm/examples/decision/expression/process.jpdl.xml";
    Document localDocument = XmlUtil.load(str1);
    System.out.println("xml:" + localDocument.asXML());
    Element localElement1 = localDocument.getRootElement();
    Iterator localIterator = localElement1.elementIterator();
    while (localIterator.hasNext())
    {
      Element localElement2 = (Element)localIterator.next();
      System.out.println("el:" + localElement2.getName());
      if ("decision".equals(localElement2.getName()))
      {
        String str2 = localElement2.attributeValue("name");
        if ("evaluate document".equals(str2))
        {
          Attribute localAttribute = localElement2.attribute("expr");
          if (localAttribute != null)
            localElement2.remove(localAttribute);
          Element localElement3 = (Element)localElement2.selectSingleNode("./handler");
          if (localElement3 != null)
            break;
          localElement3 = localElement2.addElement("handler");
          localElement3.addAttribute("class", "com.htsoft.oa.workflow.handler.DecisionHandlerImpl");
          break;
        }
      }
    }
    System.out.println("xml:" + localDocument.asXML());
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.flow.ProHandleCompAction
 * JD-Core Version:    0.6.0
 */