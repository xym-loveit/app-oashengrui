package com.htsoft.oa.action.communicate;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.AppUtil;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.CertUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.util.FileUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.communicate.OutMail;
import com.htsoft.oa.model.communicate.OutMailFolder;
import com.htsoft.oa.model.communicate.OutMailUserSeting;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.FileAttach;
import com.htsoft.oa.service.communicate.OutMailFolderService;
import com.htsoft.oa.service.communicate.OutMailService;
import com.htsoft.oa.service.communicate.OutMailUserSetingService;
import com.htsoft.oa.service.system.AppUserService;
import com.htsoft.oa.service.system.FileAttachService;
import com.sun.mail.pop3.POP3Folder;
import com.sun.net.ssl.internal.ssl.Provider;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.security.Security;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.annotation.Resource;
import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.FetchProfile;
import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.NoSuchProviderException;
import javax.mail.Part;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.UIDFolder.FetchProfileItem;
import javax.mail.URLName;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;

public class OutMailAction extends BaseAction
{
  static long FOLDER_ID_RECEIVE = 1L;
  static long FOLDER_ID_SEND = 2L;
  static long FOLDER_ID_DRAFT = 3L;
  static long FOLDER_ID_DELETE = 4L;
  static long FOLDER_TYPE_OTHER = 10L;
  static short OTHER_FOLDER_TYPE = 10;
  static int FIRST_LEVEL = 1;
  static long FIRST_PARENTID = 0L;
  static short HAVE_DELETE = 1;
  static short NOT_DELETE = 0;
  static short HAVE_READ = 1;
  static short NOT_READ = 0;
  static Short HAVE_REPLY = Short.valueOf(1);
  static short NOT_REPLY = 0;
  static String sendType = "smtp";
  static String FILE_PATH_ROOT = AppUtil.getAppAbsolutePath() + "/attachFiles/";
  static String OUT_MAIL_TEMP = FILE_PATH_ROOT + "/outMailTemp/";

  @Resource
  private OutMailService outMailService;
  private OutMail outMail;

  @Resource
  private FileAttachService fileAttachService;

  @Resource
  private OutMailUserSetingService outMailUserSetingService;
  private OutMailUserSeting outMailUserSeting;

  @Resource
  private AppUserService appUserService;
  private AppUser appUser;

  @Resource
  private OutMailFolderService outMailFolderService;
  private OutMailFolder outMailFolder;
  private Long mailId;
  private String outMailIds;
  private Long fileId;
  private Long folderId;

  public OutMailUserSeting getOutMailUserSeting()
  {
    return this.outMailUserSeting;
  }

  public void setOutMailUserSeting(OutMailUserSeting paramOutMailUserSeting)
  {
    this.outMailUserSeting = paramOutMailUserSeting;
  }

  public AppUser getAppUser()
  {
    return this.appUser;
  }

  public void setAppUser(AppUser paramAppUser)
  {
    this.appUser = paramAppUser;
  }

  public Long getFileId()
  {
    return this.fileId;
  }

  public void setFileId(Long paramLong)
  {
    this.fileId = paramLong;
  }

  public String getOutMailIds()
  {
    return this.outMailIds;
  }

  public void setOutMailIds(String paramString)
  {
    this.outMailIds = paramString;
  }

  public Long getFolderId()
  {
    return this.folderId;
  }

  public void setFolderId(Long paramLong)
  {
    this.folderId = paramLong;
  }

  public Long getMailId()
  {
    return this.mailId;
  }

  public void setMailId(Long paramLong)
  {
    this.mailId = paramLong;
  }

  public OutMail getOutMail()
  {
    return this.outMail;
  }

  public void setOutMail(OutMail paramOutMail)
  {
    this.outMail = paramOutMail;
  }

  public String list()
  {
    if ((this.folderId == null) || (this.folderId.longValue() == FOLDER_ID_RECEIVE))
      setFolderId(new Long(FOLDER_ID_RECEIVE));
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_userId_L_EQ", ContextUtil.getCurrentUserId().toString());
    localQueryFilter.addFilter("Q_outMailFolder.folderId_L_EQ", this.folderId.toString());
    localQueryFilter.addSorted("mailId", "desc");
    List localList = this.outMailService.getAll(localQueryFilter);
    getOutMailJsonStr(localList, localQueryFilter.getPagingBean().getTotalItems());
    return "success";
  }

  public String multiDel()
  {
    OutMailFolder localOutMailFolder = (OutMailFolder)this.outMailFolderService.get(Long.valueOf(FOLDER_ID_DELETE));
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
    {
      String str;
      if (getFolderId().longValue() == FOLDER_ID_DELETE)
        for (str : arrayOfString1)
        {
          this.outMail = ((OutMail)this.outMailService.get(new Long(str)));
          if (this.outMail == null)
            continue;
          Set localSet = this.outMail.getOutMailFiles();
          this.outMailService.remove(this.outMail);
          if ((localSet == null) || (localSet.size() <= 0))
            continue;
          Iterator localIterator = localSet.iterator();
          while (localIterator.hasNext())
          {
            FileAttach localFileAttach = (FileAttach)localIterator.next();
            delPhysicalFile(localFileAttach);
            this.fileAttachService.remove(localFileAttach);
          }
        }
      else
        for (str : arrayOfString1)
        {
          this.outMail = ((OutMail)this.outMailService.get(new Long(str)));
          this.outMail.setOutMailFolder(localOutMailFolder);
          this.outMailService.save(this.outMail);
        }
    }
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    String str = getRequest().getParameter("opt");
    Object localObject;
    if ((str == null) || ("".equals(str)))
    {
      this.outMail = ((OutMail)this.outMailService.get(this.mailId));
      getRequest().setAttribute("__haveNextOutMailFlag", "");
    }
    else
    {
      localObject = getRequest().getParameter("folderId");
      if ((localObject == null) || ("".equals(localObject)))
        localObject = String.valueOf(FOLDER_ID_RECEIVE);
      List localList = null;
      QueryFilter localQueryFilter = new QueryFilter(getRequest());
      localQueryFilter.getPagingBean().setPageSize(1);
      localQueryFilter.addFilter("Q_userId_L_EQ", ContextUtil.getCurrentUserId().toString());
      localQueryFilter.addFilter("Q_outMailFolder.folderId_L_EQ", (String)localObject);
      if (str.equals("_next"))
      {
        localQueryFilter.addFilter("Q_mailId_L_GT", this.mailId.toString());
        localList = this.outMailService.getAll(localQueryFilter);
        if (localQueryFilter.getPagingBean().getStart().intValue() + 1 == localQueryFilter.getPagingBean().getTotalItems())
          getRequest().setAttribute("__haveNextOutMailFlag", "endNext");
      }
      else if (str.equals("_pre"))
      {
        localQueryFilter.addFilter("Q_mailId_L_LT", this.mailId.toString());
        localQueryFilter.addSorted("mailId", "desc");
        localList = this.outMailService.getAll(localQueryFilter);
        if (localQueryFilter.getPagingBean().getStart().intValue() + 1 == localQueryFilter.getPagingBean().getTotalItems())
          getRequest().setAttribute("__haveNextOutMailFlag", "endPre");
      }
      if (localList.size() > 0)
        this.outMail = ((OutMail)localList.get(0));
      else
        this.outMail = ((OutMail)this.outMailService.get(this.mailId));
    }
    setOutMail(this.outMail);
    this.outMail.setReadFlag(Short.valueOf(HAVE_READ));
    this.outMailService.save(this.outMail);
    if (this.outMail.getFolderId().longValue() == FOLDER_ID_DRAFT)
    {
      localObject = new ArrayList();
      ((List)localObject).add(this.outMail);
      setJsonString(getOutMailJsonStr((List)localObject, 1));
      return "success";
    }
    if ((this.outMail.getReceiverNames() == null) || (this.outMail.getReceiverNames().equals("null")))
      this.outMail.setReceiverNames("(收信人未写)");
    getRequest().setAttribute("outMail_view", this.outMail);
    getRequest().setAttribute("outMailFiles", this.outMail.getOutMailFiles());
    return (String)"detail";
  }

  public String save()
  {
    this.logger.debug("save start...");
    setJsonString("{success:true}");
    String str1 = getRequest().getParameter("opt");
    this.appUser = ((AppUser)this.appUserService.get(new Long(ContextUtil.getCurrentUserId().longValue())));
    this.outMailUserSeting = this.outMailUserSetingService.getByLoginId(ContextUtil.getCurrentUserId());
    this.outMailUserSeting.setAppUser(this.appUser);
    this.outMail.setUserId(this.outMailUserSeting.getAppUser().getUserId());
    this.outMail.setSenderAddresses(this.outMailUserSeting.getMailAddress());
    this.outMail.setSenderName(this.outMailUserSeting.getUserName());
    this.outMail.setMailDate(new Date());
    this.outMail.setReceiverAddresses(getAddressesToStr(this.outMail.getReceiverNames()));
    this.outMail.setReceiverNames(getNamesToStr(this.outMail.getReceiverNames()));
    this.outMail.setcCAddresses(getAddressesToStr(this.outMail.getcCNames()));
    this.outMail.setcCNames(getNamesToStr(this.outMail.getcCNames()));
    this.outMail.setReadFlag(new Short("0"));
    this.outMail.setReplyFlag(new Short("0"));
    HashSet localHashSet = new HashSet();
    String[] arrayOfString = this.outMail.getFileIds().split(",");
    for (String str2 : arrayOfString)
    {
      if ((str2.equals("")) || (str2.equals("null")))
        continue;
      localHashSet.add(this.fileAttachService.get(new Long(str2)));
    }
    this.outMail.setOutMailFiles(localHashSet);
    try
    {
      if ((str1 != null) && (str1.trim().equals("attach")))
      {
        this.outMailFolder = ((OutMailFolder)this.outMailFolderService.get(Long.valueOf(FOLDER_ID_DRAFT)));
        this.outMail.setOutMailFolder(this.outMailFolder);
        this.outMailService.save(this.outMail);
      }
      else
      {
        ??? = new OutMail();
        BeanUtil.copyNotNullProperties(???, this.outMail);
        if ((((OutMail)???).getContent() == null) || (((OutMail)???).getContent().equals("")))
          ((OutMail)???).setContent("\t\t");
        ((OutMail)???).setMailId(null);
        this.outMailFolder = ((OutMailFolder)this.outMailFolderService.get(Long.valueOf(FOLDER_ID_SEND)));
        ((OutMail)???).setOutMailFolder(this.outMailFolder);
        List localList1 = getEMailStrToList(((OutMail)???).getReceiverAddresses(), ((OutMail)???).getReceiverNames());
        List localList2 = null;
        if ((((OutMail)???).getcCAddresses() != null) && (!((OutMail)???).getcCAddresses().trim().equals("")) && (!((OutMail)???).getcCAddresses().trim().equals("null")) && (((OutMail)???).getcCAddresses().length() > 2))
          localList2 = getEMailStrToList(((OutMail)???).getcCAddresses(), ((OutMail)???).getcCNames());
        send((OutMail)???, localList1, localList2, this.outMailUserSeting);
        this.outMailService.save(???);
      }
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      setJsonString("{failure:true,msg:'发送邮件失败!请检查书写的邮件格式是否正确!!'}");
      return "success";
    }
    this.logger.debug("save end...");
    return (String)"success";
  }

  public String attach()
  {
    String str1 = getRequest().getParameter("fileIds");
    String str2 = getRequest().getParameter("filenames");
    setOutMail((OutMail)this.outMailService.get(this.mailId));
    Set localSet = this.outMail.getOutMailFiles();
    FileAttach localFileAttach = (FileAttach)this.fileAttachService.get(this.fileId);
    delPhysicalFile(localFileAttach);
    localSet.remove(localFileAttach);
    this.outMail.setOutMailFiles(localSet);
    this.outMail.setFileIds(str1);
    this.outMail.setFileNames(str2);
    this.outMailService.save(this.outMail);
    this.fileAttachService.remove(this.fileId);
    return "success";
  }

  public String move()
  {
    StringBuffer localStringBuffer = new StringBuffer("{");
    if ((this.outMailIds != null) && (this.outMailIds.length() > 0) && (this.folderId != null))
    {
      OutMailFolder localOutMailFolder = (OutMailFolder)this.outMailFolderService.get(new Long(this.folderId.longValue()));
      String[] arrayOfString1 = this.outMailIds.split(",");
      int i = 1;
      if ((arrayOfString1 != null) && (arrayOfString1.length > 0))
        if (i != 0)
        {
          for (String str : arrayOfString1)
          {
            if ("".equals(str))
              continue;
            this.outMail = ((OutMail)this.outMailService.get(new Long(str)));
            this.outMail.setOutMailFolder(localOutMailFolder);
            this.outMailService.save(this.outMail);
          }
          localStringBuffer.append("success:true}");
          setJsonString(localStringBuffer.toString());
        }
        else
        {
          localStringBuffer.append("failure:true}");
          setJsonString(localStringBuffer.toString());
        }
    }
    else
    {
      localStringBuffer.append("msg:'请选择要移动的邮件及文件夹!'");
      localStringBuffer.append(",failure:true}");
      setJsonString(localStringBuffer.toString());
    }
    return "success";
  }

  public String opt()
  {
    setOutMail((OutMail)this.outMailService.get(this.mailId));
    String str1 = getRequest().getParameter("opt");
    this.outMail.setReadFlag(Short.valueOf(HAVE_READ));
    if ((str1 != null) && (str1.trim().equals("回复")))
      this.outMail.setReplyFlag(HAVE_REPLY);
    this.outMailService.save(this.outMail);
    StringBuffer localStringBuffer = new StringBuffer("<br><br><br><br><br><br><br><hr>");
    localStringBuffer.append("<br>----<strong>" + str1 + "邮件</strong>----");
    localStringBuffer.append("<br><strong>发件人</strong>:" + this.outMail.getSenderName());
    localStringBuffer.append("<br><strong>发送时间</strong>:" + this.outMail.getMailDate());
    localStringBuffer.append("<br><strong>收件人</strong>:" + this.outMail.getReceiverNames());
    String str2 = this.outMail.getcCNames();
    if ((!"".equals(str2)) && (str2 != null))
      localStringBuffer.append("<br><strong>抄送人</strong>:" + str2);
    localStringBuffer.append("<br><strong>主题</strong>:" + this.outMail.getTitle());
    localStringBuffer.append("<br><strong>内容</strong>:<br><br>" + this.outMail.getContent());
    this.outMail.setContent(localStringBuffer.toString());
    this.outMail.setTitle(str1 + ":" + this.outMail.getTitle());
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(this.outMail);
    setJsonString(getOutMailJsonStr(localArrayList, 1));
    return "success";
  }

  protected String getOutMailJsonStr(List<OutMail> paramList, int paramInt)
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    StringBuffer localStringBuffer = new StringBuffer("{success:true,\"totalCounts\":").append(paramInt).append(",result:[");
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      OutMail localOutMail = (OutMail)localIterator.next();
      localStringBuffer.append("{").append("\"mailId\":").append(localOutMail.getMailId()).append(",\"title\":").append("\"" + changSpecialCharacters(localOutMail.getTitle()) + "\"").append(",\"content\":").append("\"" + changSpecialCharacters(localOutMail.getContent()) + "\"").append(",\"senderAddresses\":").append("\"" + localOutMail.getSenderAddresses() + "\"").append(",\"receiverAddresses\":").append("\"" + localOutMail.getReceiverAddresses() + "\"").append(",\"cCAddresses\":").append("\"" + localOutMail.getcCAddresses() + "\"").append(",\"cCNames\":").append("\"" + changSpecialCharacters(localOutMail.getcCNames()) + "\"").append(",\"receiverNames\":").append("\"" + changSpecialCharacters(localOutMail.getReceiverNames()) + "\"").append(",\"senderName\":").append("\"" + changSpecialCharacters(localOutMail.getSenderName()) + "\"").append(",\"mailDate\":").append("\"" + localSimpleDateFormat.format(localOutMail.getMailDate()) + "\"").append(",\"readFlag\":").append(localOutMail.getReadFlag()).append(",\"replyFlag\":").append(localOutMail.getReplyFlag()).append(",\"fileIds\":").append("\"" + localOutMail.getFileIds() + "\"").append(",\"fileNames\":").append("\"" + changSpecialCharacters(localOutMail.getFileNames()) + "\"");
      localStringBuffer.append("},");
    }
    if (paramList.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}");
    this.jsonString = localStringBuffer.toString();
    return this.jsonString;
  }

  protected static String changSpecialCharacters(String paramString)
  {
    if (paramString == null)
      return "";
    paramString = paramString.replace("\"", "'").replace("\t", "\\t").replace("\n", "\\n").replace(":", "\\:").replace("[", "\\[").replace("]", "\\]").replace("{", "\\{").replace("}", "\\}").replace(",", "\\,").replace("\r", "\\r").replace("null", "");
    return paramString;
  }

  protected void send(OutMail paramOutMail, List paramList1, List paramList2, OutMailUserSeting paramOutMailUserSeting)
    throws Exception
  {
    this.logger.debug("send start...");
    String str1 = paramOutMailUserSeting.getMailAddress();
    String str2 = paramOutMailUserSeting.getMailPass();
    String str3 = paramOutMailUserSeting.getSmtpHost();
    String str4 = paramOutMailUserSeting.getSmtpPort();
    String str5 = "true";
    this.logger.debug(paramOutMailUserSeting);
    Properties localProperties = new Properties();
    localProperties.setProperty("mail.smtp.host", str3);
    localProperties.setProperty("mail.smtp.port", str4);
    localProperties.put("mail.smtp.auth", str5);
    localProperties.setProperty("mail.smtp.socketFactory.fallback", "false");
    localProperties.setProperty("mail.smtp.socketFactory.port", str4);
    File localFile1 = null;
    localFile1 = CertUtil.get(str3, Integer.parseInt(str4));
    if (localFile1 != null)
    {
      this.logger.debug("ssl connection...");
      Security.addProvider(new Provider());
      localProperties.setProperty("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
      System.setProperty("javax.net.ssl.trustStore", localFile1.getAbsolutePath());
      localProperties.put("javax.net.ssl.trustStore", localFile1.getAbsolutePath());
    }
    else
    {
      this.logger.debug("plaintext connection or tls connection...");
      localProperties.put("mail.smtp.starttls.enable", "true");
    }
    String str6 = str1;
    String str7 = str2;
    Session localSession = Session.getInstance(localProperties, new Authenticator(str6, str7)
    {
      protected PasswordAuthentication getPasswordAuthentication()
      {
        return new PasswordAuthentication(this.val$username, this.val$password);
      }
    });
    this.logger.debug("connetion session:" + localSession);
    EmailAddress localEmailAddress = new EmailAddress(paramOutMailUserSeting.getMailAddress(), paramOutMailUserSeting.getUserName());
    MimeBodyPart localMimeBodyPart1 = new MimeBodyPart();
    localMimeBodyPart1.setHeader("Content-Transfer-Encoding", "base64");
    localMimeBodyPart1.setContent(paramOutMail.getContent(), "text/html;charset=utf-8");
    MimeMessage localMimeMessage = new MimeMessage(localSession);
    MimeMultipart localMimeMultipart = new MimeMultipart();
    localMimeMessage.setSubject(paramOutMail.getTitle(), "utf-8");
    localMimeMessage.setText("utf-8", "utf-8");
    localMimeMessage.setSentDate(paramOutMail.getMailDate() == null ? new Date() : paramOutMail.getMailDate());
    localMimeMultipart.addBodyPart(localMimeBodyPart1);
    localMimeMessage.setFrom(localEmailAddress.toInternetAddress());
    InternetAddress[] arrayOfInternetAddress = getAddressByType(paramList1);
    if (arrayOfInternetAddress != null)
      localMimeMessage.addRecipients(Message.RecipientType.TO, arrayOfInternetAddress);
    if ((paramList2 != null) && (paramList2.size() > 0))
    {
      arrayOfInternetAddress = getAddressByType(paramList2);
      if (arrayOfInternetAddress != null)
        localMimeMessage.addRecipients(Message.RecipientType.CC, arrayOfInternetAddress);
    }
    if ((paramOutMail.getFileIds() != null) && (paramOutMail.getFileIds().length() > 0))
    {
      localObject = paramOutMail.getFileIds();
      String[] arrayOfString = ((String)localObject).split(",");
      for (int i = 0; i < arrayOfString.length; i++)
      {
        if ((arrayOfString[i].equals("")) || (arrayOfString[i].equals("null")))
          continue;
        FileAttach localFileAttach = (FileAttach)this.fileAttachService.get(new Long(arrayOfString[i]));
        if (localFileAttach == null)
          continue;
        File localFile2 = new File(FILE_PATH_ROOT + localFileAttach.getFilePath());
        MimeBodyPart localMimeBodyPart2 = new MimeBodyPart();
        FileDataSource localFileDataSource = new FileDataSource(localFile2);
        localMimeBodyPart2.setDataHandler(new DataHandler(localFileDataSource));
        localMimeBodyPart2.setFileName(MimeUtility.encodeWord(localFileAttach.getFileName(), "UTF-8", "Q"));
        localMimeMultipart.addBodyPart(localMimeBodyPart2);
      }
    }
    localMimeMessage.setContent(localMimeMultipart);
    if (sendType == null)
      sendType = "smtp";
    Object localObject = localSession.getTransport(sendType);
    ((Transport)localObject).connect(paramOutMailUserSeting.getSmtpHost().toString(), str6, str7);
    Transport.send(localMimeMessage);
    ((Transport)localObject).close();
    this.logger.debug("send end");
  }

  protected static InternetAddress[] getAddressByType(List<EmailAddress> paramList)
    throws Exception
  {
    if (paramList != null)
    {
      InternetAddress[] arrayOfInternetAddress = new InternetAddress[paramList.size()];
      for (int i = 0; i < paramList.size(); i++)
      {
        if (((EmailAddress)paramList.get(i)).toInternetAddress() == null)
          continue;
        arrayOfInternetAddress[i] = ((EmailAddress)paramList.get(i)).toInternetAddress();
      }
      return arrayOfInternetAddress;
    }
    return null;
  }

  protected static String getAddressesToStr(String paramString)
  {
    String str = "";
    String[] arrayOfString1;
    if ((paramString != null) && (paramString.length() > 0) && (paramString.indexOf(";") >= 0))
    {
      arrayOfString1 = paramString.split(";");
      for (int i = 0; i < arrayOfString1.length; i++)
        if ((arrayOfString1[i].length() > 1) && (arrayOfString1[i].indexOf("<") >= 0) && (arrayOfString1[i].indexOf(">") > 0))
        {
          String[] arrayOfString2 = arrayOfString1[i].split("<");
          str = str + arrayOfString2[1].substring(0, arrayOfString2[1].length() - 1) + ",";
        }
        else
        {
          str = str + arrayOfString1[i] + ",";
        }
    }
    else if ((paramString != null) && (paramString.indexOf("<") >= 0) && (paramString.indexOf(">") > 0))
    {
      arrayOfString1 = paramString.split("<");
      str = str + arrayOfString1[1].substring(0, arrayOfString1[1].length() - 1) + ",";
    }
    else
    {
      str = paramString + ",";
    }
    if ((str != null) && (str.length() > 1))
      str = str.substring(0, str.length() - 1);
    return str;
  }

  protected static String getNamesToStr(String paramString)
  {
    String str = "";
    String[] arrayOfString1;
    if ((paramString != null) && (paramString.length() > 0) && (paramString.indexOf(";") >= 0))
    {
      arrayOfString1 = paramString.split(";");
      for (int i = 0; i < arrayOfString1.length; i++)
        if ((arrayOfString1[i].indexOf("<") >= 0) && (arrayOfString1[i].indexOf(">") > 0))
        {
          String[] arrayOfString2 = arrayOfString1[i].split("<");
          str = str + arrayOfString2[0] + ",";
        }
        else
        {
          str = str + arrayOfString1[i] + ",";
        }
    }
    else if ((paramString != null) && (paramString.indexOf("<") >= 0) && (paramString.indexOf(">") > 0))
    {
      arrayOfString1 = paramString.split("<");
      str = str + arrayOfString1[0] + ",";
    }
    else
    {
      str = paramString + ",";
    }
    if ((str != null) && (str.length() > 1))
      str = str.substring(0, str.length() - 1);
    if (str == null)
      str = " ";
    return str;
  }

  protected List<EmailAddress> getEMailStrToList(String paramString1, String paramString2)
  {
    ArrayList localArrayList = new ArrayList();
    if ((paramString1 != null) && (paramString1.length() > 1))
    {
      String[] arrayOfString1 = paramString1.split(",");
      if ((paramString2 != null) && (paramString2.length() > 1))
      {
        String[] arrayOfString2 = paramString2.split(",");
        for (int j = 0; j < arrayOfString1.length; j++)
          if ((arrayOfString1[j] != null) && (arrayOfString1[j].length() > 1) && (arrayOfString1[j].indexOf("@") > 0))
          {
            EmailAddress localEmailAddress2;
            if (arrayOfString2.length > j)
            {
              localEmailAddress2 = new EmailAddress(arrayOfString1[j].trim(), arrayOfString2[j]);
              localArrayList.add(localEmailAddress2);
            }
            else
            {
              localEmailAddress2 = new EmailAddress(arrayOfString1[j].trim(), arrayOfString1[j].trim());
              localArrayList.add(localEmailAddress2);
            }
          }
          else
          {
            setJsonString("{failure:true,msg:'收件人地址有误!'}");
            return null;
          }
      }
      else
      {
        for (int i = 0; i < arrayOfString1.length; i++)
          if ((arrayOfString1[i] != null) && (arrayOfString1[i].length() > 1) && (arrayOfString1[i].indexOf("@") > 0))
          {
            EmailAddress localEmailAddress1 = new EmailAddress(arrayOfString1[i].trim(), arrayOfString1[i].trim());
            localArrayList.add(localEmailAddress1);
          }
          else
          {
            return null;
          }
      }
    }
    else
    {
      setJsonString("{failure:true,msg:'收件人不能为空!'}");
      return null;
    }
    return localArrayList;
  }

  public String fetch()
  {
    this.logger.debug("fectch start...");
    this.outMailUserSeting = this.outMailUserSetingService.getByLoginId(ContextUtil.getCurrentUserId());
    if (this.outMailUserSeting != null)
    {
      this.logger.debug(this.outMailUserSeting);
      Properties localProperties = new Properties();
      localProperties.setProperty("mail.pop3.socketFactory.fallback", "false");
      localProperties.setProperty("mail.pop3.port", this.outMailUserSeting.getPopPort());
      localProperties.setProperty("mail.pop3.socketFactory.port", this.outMailUserSeting.getPopPort());
      File localFile = null;
      localFile = CertUtil.get(this.outMailUserSeting.getPopHost(), Integer.parseInt(this.outMailUserSeting.getPopPort()));
      if (localFile != null)
      {
        Security.addProvider(new Provider());
        this.logger.debug("ssl connection...");
        localProperties.setProperty("mail.pop3.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        System.setProperty("javax.net.ssl.trustStore", localFile.getAbsolutePath());
        localProperties.put("javax.net.ssl.trustStore", localFile.getAbsolutePath());
      }
      else
      {
        this.logger.debug("plaintext connection or tls connection...");
        localProperties.put("mail.smtp.starttls.enable", "true");
      }
      Session localSession = Session.getInstance(localProperties, new Authenticator()
      {
        protected PasswordAuthentication getPasswordAuthentication()
        {
          return new PasswordAuthentication(OutMailAction.this.outMailUserSeting.getMailAddress(), OutMailAction.this.outMailUserSeting.getMailPass());
        }
      });
      URLName localURLName = new URLName("pop3", this.outMailUserSeting.getPopHost(), Integer.parseInt(this.outMailUserSeting.getPopPort()), null, this.outMailUserSeting.getMailAddress(), this.outMailUserSeting.getMailPass());
      Store localStore = null;
      POP3Folder localPOP3Folder = null;
      OutMailFolder localOutMailFolder = (OutMailFolder)this.outMailFolderService.get(Long.valueOf(FOLDER_ID_RECEIVE));
      try
      {
        localStore = localSession.getStore(localURLName);
        localStore.connect();
        localPOP3Folder = (POP3Folder)localStore.getFolder("INBOX");
        localPOP3Folder.open(1);
        FetchProfile localFetchProfile = new FetchProfile();
        localFetchProfile.add(UIDFolder.FetchProfileItem.UID);
        Message[] arrayOfMessage = localPOP3Folder.getMessages();
        localPOP3Folder.fetch(arrayOfMessage, localFetchProfile);
        Map localMap = this.outMailService.getUidByUserId(ContextUtil.getCurrentUserId());
        int i = arrayOfMessage.length;
        this.logger.debug("mail counts :\t" + i);
        for (int j = 0; j < i; j++)
          try
          {
            if (localMap.get(localPOP3Folder.getUID(arrayOfMessage[j])) == null)
              try
              {
                this.logger.debug("");
                this.logger.debug("开始接收邮件:\t" + arrayOfMessage[j].getSubject());
                OutMail localOutMail = new OutMail();
                localOutMail.setUid(localPOP3Folder.getUID(arrayOfMessage[j]));
                String str1 = arrayOfMessage[j].getFrom()[0].toString();
                InternetAddress localInternetAddress = new InternetAddress(str1);
                String str2 = localInternetAddress.getAddress();
                if ((str2 == null) || (str2.equals("")))
                  str2 = "\t";
                localOutMail.setSenderAddresses(str2);
                localOutMail.setSenderName(localInternetAddress.getPersonal());
                InternetAddress[] arrayOfInternetAddress1 = null;
                try
                {
                  arrayOfInternetAddress1 = (InternetAddress[])(InternetAddress[])arrayOfMessage[j].getRecipients(Message.RecipientType.TO);
                }
                catch (AddressException localAddressException1)
                {
                  localAddressException1.printStackTrace();
                }
                String str3 = "\t\t";
                String str4 = "\t\t";
                if ((arrayOfInternetAddress1 != null) && (arrayOfInternetAddress1.length > 0))
                {
                  for (int k = 0; k < arrayOfInternetAddress1.length; k++)
                  {
                    str3 = str3 + arrayOfInternetAddress1[k].getAddress() + ",";
                    if ((arrayOfInternetAddress1[k].getPersonal() != null) && (!arrayOfInternetAddress1[k].getPersonal().equals("")))
                      str4 = str4 + arrayOfInternetAddress1[k].getPersonal() + ",";
                    else
                      str4 = str4 + arrayOfInternetAddress1[k].getAddress() + ",";
                  }
                  if ((str3 != null) && (str3.length() > 1))
                    str3 = str3.substring(0, str3.length() - 1);
                  if ((str4 != null) && (str4.length() > 1))
                    str4 = str4.substring(0, str4.length() - 1);
                }
                localOutMail.setReceiverAddresses(str3);
                localOutMail.setReceiverNames(str4);
                InternetAddress[] arrayOfInternetAddress2 = null;
                try
                {
                  arrayOfInternetAddress2 = (InternetAddress[])(InternetAddress[])arrayOfMessage[j].getRecipients(Message.RecipientType.CC);
                }
                catch (AddressException localAddressException2)
                {
                  localAddressException2.printStackTrace();
                }
                String str5 = "\t";
                String str6 = "\t";
                if ((arrayOfInternetAddress2 != null) && (arrayOfInternetAddress2.length > 0))
                {
                  for (int m = 0; m < arrayOfInternetAddress2.length; m++)
                  {
                    str5 = str5 + arrayOfInternetAddress2[m].getAddress() + ",";
                    str6 = str6 + arrayOfInternetAddress2[m].getPersonal() + ",";
                  }
                  if ((str5 != null) && (str5.length() > 1))
                    str5 = str5.substring(0, str5.length() - 1);
                  if ((str6 != null) && (str6.length() > 1))
                    str6 = str6.substring(0, str6.length() - 1);
                }
                localOutMail.setcCAddresses(str5);
                localOutMail.setcCNames(str6);
                InternetAddress[] arrayOfInternetAddress3 = null;
                try
                {
                  arrayOfInternetAddress3 = (InternetAddress[])(InternetAddress[])arrayOfMessage[j].getRecipients(Message.RecipientType.BCC);
                }
                catch (AddressException localAddressException3)
                {
                  localAddressException3.printStackTrace();
                }
                String str7 = "\t";
                String str8 = "\t";
                if ((arrayOfInternetAddress3 != null) && (arrayOfInternetAddress3.length > 0))
                {
                  for (int n = 0; n < arrayOfInternetAddress3.length; n++)
                  {
                    str7 = str7 + arrayOfInternetAddress3[n].getAddress() + ",";
                    str8 = str8 + arrayOfInternetAddress3[n].getPersonal() + ",";
                  }
                  if ((str7 != null) && (str7.length() > 1))
                    str7 = str7.substring(0, str7.length() - 1);
                  if ((str8 != null) && (str8.length() > 1))
                    str8 = str8.substring(0, str8.length() - 1);
                }
                localOutMail.setbCCAddresses(str7);
                localOutMail.setbCCAnames(str8);
                localOutMail.setTitle(arrayOfMessage[j].getSubject());
                Date localDate = null;
                if (arrayOfMessage[j].getSentDate() != null)
                  localDate = arrayOfMessage[j].getSentDate();
                else
                  localDate = new Date();
                localOutMail.setMailDate(localDate);
                String str9 = getMailContent(arrayOfMessage[j]);
                if ((str9 == null) || (str9.equals("")))
                  str9 = "\t";
                localOutMail.setContent(str9);
                Set localSet1 = saveFileForFetch(arrayOfMessage[j]);
                localOutMail.setOutMailFiles(localSet1);
                localOutMail.setReadFlag(new Short("0"));
                localOutMail.setReplyFlag(new Short("0"));
                localOutMail.setOutMailFolder(localOutMailFolder);
                localOutMail.setUserId(ContextUtil.getCurrentUserId());
                this.outMailService.save(localOutMail);
                this.outMail = ((OutMail)this.outMailService.get(localOutMail.getMailId()));
                Set localSet2 = this.outMail.getOutMailFiles();
                String str10 = "";
                String str11 = "";
                if ((localSet2 != null) && (localSet2.size() > 0))
                {
                  Iterator localIterator = localSet2.iterator();
                  while (localIterator.hasNext())
                  {
                    FileAttach localFileAttach = (FileAttach)localIterator.next();
                    str10 = str10 + localFileAttach.getFileId().toString() + ",";
                    str11 = str11 + localFileAttach.getFileName().toString() + ",";
                  }
                  if (str10.length() > 1)
                    str10 = str10.substring(0, str10.length() - 1);
                  if (str11.length() > 1)
                    str11 = str11.substring(0, str11.length() - 1);
                }
                this.outMail.setFileIds(str10);
                this.outMail.setFileNames(str11);
                this.outMailService.save(this.outMail);
                this.logger.debug("接收邮件成功:\t" + arrayOfMessage[j].getSubject());
              }
              catch (IOException localIOException)
              {
                localIOException.printStackTrace();
              }
              finally
              {
                System.gc();
              }
          }
          catch (MessagingException localMessagingException2)
          {
            localMessagingException2.printStackTrace();
          }
      }
      catch (NoSuchProviderException localException4)
      {
        localNoSuchProviderException.printStackTrace();
      }
      catch (MessagingException localException6)
      {
        localMessagingException1.printStackTrace();
      }
      finally
      {
        try
        {
          localPOP3Folder.close(false);
        }
        catch (Exception localException7)
        {
          localException7.printStackTrace();
        }
        try
        {
          localStore.close();
        }
        catch (Exception localException8)
        {
          localException8.printStackTrace();
        }
      }
    }
    setJsonString("{success:true,msg:'收取邮件完成！'}");
    this.logger.debug("fectch end...");
    return "success";
  }

  protected boolean delPhysicalFile(FileAttach paramFileAttach)
  {
    String str1 = FILE_PATH_ROOT;
    String str2 = str1 + paramFileAttach.getFilePath();
    File localFile = new File(str2);
    if (localFile.delete())
      this.logger.info("删除文件：" + str2);
    else
      this.logger.info("文件不存在：" + str2);
    return true;
  }

  protected static String decodeText(String paramString)
  {
    try
    {
      if (paramString == null)
        return "";
      if ((paramString.startsWith("=?GB")) || (paramString.startsWith("=?gb")))
        paramString = MimeUtility.decodeText(paramString);
      else if ((paramString.startsWith("=?ISO-8859-1")) || (paramString.startsWith("=?iso-8859-1")))
        paramString = MimeUtility.decodeText(paramString);
      else
        paramString = new String(paramString.getBytes("ISO8859_1"));
    }
    catch (Exception localException)
    {
      System.out.println("转换字附编号出错!");
      localException.printStackTrace();
    }
    return paramString;
  }

  protected String getMailContent(Part paramPart)
  {
    String str1 = ContextUtil.getCurrentUser().getUsername();
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append(new String(""));
    try
    {
      if ((paramPart.isMimeType("text/plain")) || (paramPart.isMimeType("text/html")))
      {
        localStringBuffer.append(paramPart.getContent());
      }
      else
      {
        Object localObject1;
        Object localObject3;
        Object localObject2;
        if (paramPart.isMimeType("multipart/*"))
        {
          if (paramPart.isMimeType("multipart/alternative"))
          {
            localObject1 = (Multipart)paramPart.getContent();
            int i = 0;
            if (((Multipart)localObject1).getCount() > 1)
              i = 1;
            localObject3 = ((Multipart)localObject1).getBodyPart(i);
            localStringBuffer.append(((Part)localObject3).getContent());
          }
          else
          {
            if (paramPart.isMimeType("multipart/related"))
            {
              localObject1 = (Multipart)paramPart.getContent();
              localObject2 = ((Multipart)localObject1).getBodyPart(0);
              localObject3 = getMailContent((Part)localObject2);
              int j = ((Multipart)localObject1).getCount();
              for (int k = 1; (j > 1) && (k < j); k++)
              {
                BodyPart localBodyPart = ((Multipart)localObject1).getBodyPart(k);
                String str2 = localBodyPart.getFileName();
                if (str2 != null)
                  str2 = MimeUtility.decodeText(str2);
                else
                  str2 = "\t";
                try
                {
                  File localFile = new File(FILE_PATH_ROOT, str1.concat(str2));
                  localFile.createNewFile();
                  localObject4 = new FileOutputStream(localFile);
                  InputStream localInputStream = localBodyPart.getInputStream();
                  BufferedOutputStream localBufferedOutputStream = new BufferedOutputStream((OutputStream)localObject4);
                  byte[] arrayOfByte = new byte[localBodyPart.getSize()];
                  localInputStream.read(arrayOfByte);
                  localBufferedOutputStream.write(arrayOfByte);
                  localBufferedOutputStream.close();
                }
                catch (Exception localException2)
                {
                  this.logger.error("Error occurred when to get the photos from server");
                }
                String[] arrayOfString = localBodyPart.getHeader("Content-ID");
                if ((arrayOfString == null) || (arrayOfString.length <= 0))
                  continue;
                Object localObject4 = arrayOfString[0].replaceAll("<", "").replaceAll(">", "");
                localObject3 = ((String)localObject3).replaceAll("cid:" + (String)localObject4, FILE_PATH_ROOT.concat("/").concat(str1.concat(str2)));
              }
              localStringBuffer.append((String)localObject3);
              return localStringBuffer.toString();
            }
            localObject1 = ((Multipart)paramPart.getContent()).getBodyPart(0);
            return getMailContent((Part)localObject1);
          }
        }
        else
        {
          if (paramPart.isMimeType("message/rfc822"))
            return getMailContent((Message)paramPart.getContent());
          localObject1 = paramPart.getContent();
          if ((localObject1 instanceof String))
          {
            localStringBuffer.append(localObject1);
          }
          else
          {
            localObject2 = (Multipart)localObject1;
            localObject3 = ((Multipart)localObject2).getBodyPart(0);
            return getMailContent((Part)localObject3);
          }
        }
      }
    }
    catch (Exception localException1)
    {
      localException1.printStackTrace();
      return "解析正文错误!";
    }
    return (String)(String)(String)(String)localStringBuffer.toString();
  }

  protected Set<FileAttach> saveFileForFetch(Message paramMessage)
    throws IOException, MessagingException
  {
    String str1 = paramMessage.getContentType();
    if (str1.startsWith("multipart/mixed"))
    {
      SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyyMM");
      HashSet localHashSet = new HashSet();
      Multipart localMultipart = (Multipart)paramMessage.getContent();
      int i = 0;
      int j = localMultipart.getCount();
      while (i < j)
      {
        BodyPart localBodyPart = localMultipart.getBodyPart(i);
        String str2 = localBodyPart.getDisposition();
        if (str2 != null)
        {
          FileAttach localFileAttach = new FileAttach();
          localFileAttach.setCreatetime(new Date());
          localFileAttach.setCreator(ContextUtil.getCurrentUser().getFullname());
          String str3 = localBodyPart.getFileName();
          if (str3 != null)
            str3 = MimeUtility.decodeText(str3);
          else
            str3 = "\t";
          String[] arrayOfString = str3.split("\\.");
          localFileAttach.setFileName(str3);
          localFileAttach.setExt(arrayOfString[(arrayOfString.length - 1)]);
          localFileAttach.setFileType("communicate/outmail/download");
          localFileAttach.setNote(String.valueOf(localBodyPart.getSize()) + " bytes");
          String str4 = localSimpleDateFormat.format(new Date());
          InputStream localInputStream = localBodyPart.getInputStream();
          String str5 = FILE_PATH_ROOT;
          String str6 = "communicate\\outmail\\download\\" + ContextUtil.getCurrentUser().getUsername() + "\\" + str4 + "\\";
          str5 = str5.replace("\\", "/");
          str6 = str6.replace("\\", "/");
          String str7 = FileUtil.generateFilename(localFileAttach.getFileName());
          str7 = str7.substring(str7.indexOf("/") + 1, str7.length());
          localFileAttach.setFilePath(str6 + str7.trim());
          File localFile = new File(str5, str6);
          if ((!localFile.exists()) && (!localFile.mkdirs()))
            this.logger.info("目录不存在，创建失败！");
          String str8 = str5 + localFileAttach.getFilePath();
          str8 = str8.replace("\\", "/");
          FileOutputStream localFileOutputStream = new FileOutputStream(str8);
          int k;
          while ((k = localInputStream.read()) != -1)
            localFileOutputStream.write(k);
          localInputStream.close();
          localFileOutputStream.close();
          localHashSet.add(localFileAttach);
          this.logger.debug("附件:" + localFileAttach.getFileName() + "," + localFileAttach.getFilePath());
        }
        i++;
      }
      return localHashSet;
    }
    return null;
  }

  protected class EmailAddress
  {
    protected String address;
    protected String name;

    public String getAddress()
    {
      return this.address;
    }

    public void setAddress(String paramString)
    {
      this.address = paramString;
    }

    public String getName()
    {
      return this.name;
    }

    public void setName(String paramString)
    {
      this.name = paramString;
    }

    public EmailAddress()
    {
    }

    public EmailAddress(String paramString1, String arg3)
    {
      this.address = paramString1;
      Object localObject;
      this.name = localObject;
    }

    public InternetAddress toInternetAddress()
      throws Exception
    {
      if ((this.name != null) && (!this.name.trim().equals("")))
        return new InternetAddress(this.address, MimeUtility.encodeWord(this.name, "utf-8", "Q"));
      return new InternetAddress(this.address);
    }
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.communicate.OutMailAction
 * JD-Core Version:    0.6.0
 */