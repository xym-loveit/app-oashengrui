package com.htsoft.oa.action.task;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.Department;
import com.htsoft.oa.model.system.FileAttach;
import com.htsoft.oa.model.task.PlanAttend;
import com.htsoft.oa.model.task.WorkPlan;
import com.htsoft.oa.service.system.AppUserService;
import com.htsoft.oa.service.system.DepartmentService;
import com.htsoft.oa.service.system.FileAttachService;
import com.htsoft.oa.service.task.PlanAttendService;
import com.htsoft.oa.service.task.WorkPlanService;
import flexjson.JSONSerializer;
import java.util.List;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class WorkPlanAction extends BaseAction
{

  @Resource
  private WorkPlanService workPlanService;
  private WorkPlan workPlan;

  @Resource
  private FileAttachService fileAttachService;

  @Resource
  private DepartmentService departmentService;

  @Resource
  private PlanAttendService planAttendService;

  @Resource
  private AppUserService appUserService;
  private Long planId;
  static short ISDEPARTMENT = 1;
  static short NOTDEPARTMENT = 0;
  static short ISPRIMARY = 1;
  static short NOTPRIMARY = 0;

  public Long getPlanId()
  {
    return this.planId;
  }

  public void setPlanId(Long paramLong)
  {
    this.planId = paramLong;
  }

  public WorkPlan getWorkPlan()
  {
    return this.workPlan;
  }

  public void setWorkPlan(WorkPlan paramWorkPlan)
  {
    this.workPlan = paramWorkPlan;
  }

  public String list()
  {
    Long localLong = ContextUtil.getCurrentUserId();
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_appUser.userId_L_EQ", localLong.toString());
    List localList = this.workPlanService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "startTime", "endTime" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class", "appUser.password" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String personal()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    Long localLong = ContextUtil.getCurrentUserId();
    localQueryFilter.addFilter("Q_appUser.userId_L_EQ", localLong.toString());
    localQueryFilter.addFilter("Q_isPersonal_SN_EQ", "1");
    localQueryFilter.addFilter("Q_status_SN_EQ", "1");
    List localList = this.workPlanService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "startTime", "endTime" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class", "appUser.password", "department" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String department()
  {
    PagingBean localPagingBean = getInitPagingBean();
    AppUser localAppUser = ContextUtil.getCurrentUser();
    List localList = this.workPlanService.findByDepartment(this.workPlan, localAppUser, localPagingBean);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localPagingBean.getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "startTime", "endTime" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class", "appUser.password", "department" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.workPlanService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    WorkPlan localWorkPlan = (WorkPlan)this.workPlanService.get(this.planId);
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localWorkPlan));
    localStringBuffer.append(",proTypeId:" + localWorkPlan.getProTypeId());
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    String str1 = getRequest().getParameter("issueScopeIds");
    String str2 = getRequest().getParameter("participantsIds");
    String str3 = getRequest().getParameter("principalIds");
    String str4 = getRequest().getParameter("planFileIds");
    int i = this.workPlan.getIsPersonal().shortValue();
    this.workPlan.getPlanFiles().clear();
    Object localObject2;
    if (StringUtils.isNotEmpty(str4))
    {
      localObject1 = str4.split(",");
      for (int j = 0; j < localObject1.length; j++)
      {
        localObject2 = (FileAttach)this.fileAttachService.get(new Long(localObject1[j]));
        this.workPlan.getPlanFiles().add(localObject2);
      }
    }
    this.workPlan.setPlanFiles(this.workPlan.getPlanFiles());
    Object localObject1 = ContextUtil.getCurrentUser();
    this.workPlan.setAppUser((AppUser)localObject1);
    if (i == 1)
      this.workPlan.setPrincipal(((AppUser)localObject1).getFullname());
    this.workPlanService.save(this.workPlan);
    if (i != 1)
    {
      boolean bool;
      int k;
      Long localLong;
      PlanAttend localPlanAttend;
      if (StringUtils.isNotEmpty(str1))
      {
        bool = this.planAttendService.deletePlanAttend(this.workPlan.getPlanId(), Short.valueOf(ISDEPARTMENT), Short.valueOf(NOTPRIMARY));
        if (bool)
        {
          localObject2 = str1.split(",");
          for (k = 0; k < localObject2.length; k++)
          {
            if (!StringUtils.isNotEmpty(localObject2[k]))
              continue;
            localLong = new Long(localObject2[k]);
            localPlanAttend = new PlanAttend();
            localPlanAttend.setDepartment((Department)this.departmentService.get(localLong));
            localPlanAttend.setWorkPlan(this.workPlan);
            localPlanAttend.setIsDep(Short.valueOf(ISDEPARTMENT));
            localPlanAttend.setIsPrimary(Short.valueOf(NOTPRIMARY));
            this.planAttendService.save(localPlanAttend);
          }
        }
      }
      if (StringUtils.isNotEmpty(str2))
      {
        bool = this.planAttendService.deletePlanAttend(this.workPlan.getPlanId(), Short.valueOf(NOTDEPARTMENT), Short.valueOf(NOTPRIMARY));
        if (bool)
        {
          localObject2 = str2.split(",");
          for (k = 0; k < localObject2.length; k++)
          {
            if (!StringUtils.isNotEmpty(localObject2[k]))
              continue;
            localLong = new Long(localObject2[k]);
            localPlanAttend = new PlanAttend();
            localPlanAttend.setAppUser((AppUser)this.appUserService.get(localLong));
            localPlanAttend.setIsDep(Short.valueOf(NOTDEPARTMENT));
            localPlanAttend.setWorkPlan(this.workPlan);
            localPlanAttend.setIsPrimary(Short.valueOf(NOTPRIMARY));
            this.planAttendService.save(localPlanAttend);
          }
        }
      }
      if (StringUtils.isNotEmpty(str3))
      {
        bool = this.planAttendService.deletePlanAttend(this.workPlan.getPlanId(), Short.valueOf(NOTDEPARTMENT), Short.valueOf(ISPRIMARY));
        if (bool)
        {
          localObject2 = str3.split(",");
          for (k = 0; k < localObject2.length; k++)
          {
            if (!StringUtils.isNotEmpty(localObject2[k]))
              continue;
            localLong = new Long(localObject2[k]);
            localPlanAttend = new PlanAttend();
            localPlanAttend.setAppUser((AppUser)this.appUserService.get(localLong));
            localPlanAttend.setIsDep(Short.valueOf(NOTDEPARTMENT));
            localPlanAttend.setWorkPlan(this.workPlan);
            localPlanAttend.setIsPrimary(Short.valueOf(ISPRIMARY));
            this.planAttendService.save(localPlanAttend);
          }
        }
      }
    }
    setJsonString("{success:true}");
    return (String)(String)"success";
  }

  public String show()
  {
    String str = getRequest().getParameter("planId");
    if (StringUtils.isNotEmpty(str))
    {
      Long localLong = new Long(str);
      this.workPlan = ((WorkPlan)this.workPlanService.get(localLong));
    }
    return "show";
  }

  public String display()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    Long localLong = ContextUtil.getCurrentUserId();
    localQueryFilter.addFilter("Q_appUser.userId_L_EQ", localLong.toString());
    localQueryFilter.addFilter("Q_isPersonal_SN_EQ", "1");
    localQueryFilter.addFilter("Q_status_SN_EQ", "1");
    localQueryFilter.addSorted("planId", "desc");
    List localList = this.workPlanService.getAll(localQueryFilter);
    getRequest().setAttribute("planList", localList);
    return "display";
  }

  public String displayDep()
  {
    PagingBean localPagingBean = new PagingBean(0, 8);
    AppUser localAppUser = ContextUtil.getCurrentUser();
    List localList = this.workPlanService.findByDepartment(this.workPlan, localAppUser, localPagingBean);
    getRequest().setAttribute("planList", localList);
    return "displayDep";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.task.WorkPlanAction
 * JD-Core Version:    0.6.0
 */