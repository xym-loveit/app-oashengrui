package com.htsoft.oa.action.system;

import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.system.FileAttach;
import com.htsoft.oa.service.system.FileAttachService;
import javax.annotation.Resource;

public class FileAttachDetailAction extends BaseAction
{

  @Resource
  private FileAttachService fileAttachService;
  private Long fileId;
  private FileAttach fileAttach;

  public Long getFileId()
  {
    return this.fileId;
  }

  public void setFileId(Long paramLong)
  {
    this.fileId = paramLong;
  }

  public FileAttach getFileAttach()
  {
    return this.fileAttach;
  }

  public void setFileAttach(FileAttach paramFileAttach)
  {
    this.fileAttach = paramFileAttach;
  }

  public String execute()
    throws Exception
  {
    this.fileAttach = ((FileAttach)this.fileAttachService.get(this.fileId));
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.FileAttachDetailAction
 * JD-Core Version:    0.6.0
 */