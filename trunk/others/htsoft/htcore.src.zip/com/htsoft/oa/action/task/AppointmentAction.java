package com.htsoft.oa.action.task;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.jms.MailMessageProducer;
import com.htsoft.core.jms.MobileMessageProducer;
import com.htsoft.core.model.MailModel;
import com.htsoft.core.util.AppUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.communicate.SmsMobile;
import com.htsoft.oa.model.info.ShortMessage;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.task.Appointment;
import com.htsoft.oa.service.communicate.SmsMobileService;
import com.htsoft.oa.service.info.ShortMessageService;
import com.htsoft.oa.service.task.AppointmentService;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;

public class AppointmentAction extends BaseAction
{

  @Resource
  private AppointmentService appointmentService;

  @Resource
  private ShortMessageService shortMessageService;

  @Resource
  private MailMessageProducer mailMessageProducer;

  @Resource
  private MobileMessageProducer mobileMessageProducer;

  @Resource
  private SmsMobileService smsMobileService;
  private Appointment appointment;
  private String sendMessage;
  private Long appointId;
  private List<Appointment> list;

  public String getSendMessage()
  {
    return this.sendMessage;
  }

  public void setSendMessage(String paramString)
  {
    this.sendMessage = paramString;
  }

  public List<Appointment> getList()
  {
    return this.list;
  }

  public void setList(List<Appointment> paramList)
  {
    this.list = paramList;
  }

  public Long getAppointId()
  {
    return this.appointId;
  }

  public void setAppointId(Long paramLong)
  {
    this.appointId = paramLong;
  }

  public Appointment getAppointment()
  {
    return this.appointment;
  }

  public void setAppointment(Appointment paramAppointment)
  {
    this.appointment = paramAppointment;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_appUser.userId_L_EQ", ContextUtil.getCurrentUserId().toString());
    List localList = this.appointmentService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").excludeFieldsWithoutExposeAnnotation().create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.appointmentService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    Appointment localAppointment = (Appointment)this.appointmentService.get(this.appointId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localAppointment));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    AppUser localAppUser = ContextUtil.getCurrentUser();
    this.appointment.setAppUser(localAppUser);
    String str1 = ContextUtil.getCurrentUserId().toString();
    String str2 = getRequest().getParameter("appointment.sendMessage");
    String str3 = getRequest().getParameter("appointment.sendMail");
    StringBuffer localStringBuffer = new StringBuffer("您的约会主题为:<font color=\"green\">");
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
    localStringBuffer.append(this.appointment.getSubject()).append(",地点：").append(this.appointment.getLocation()).append("</font>").append(",请在<font color=\"red\">").append(localSimpleDateFormat.format(this.appointment.getStartTime())).append(" 至 ").append(localSimpleDateFormat.format(this.appointment.getEndTime())).append("</font>").append("这时间段中,准时参加您的约会！");
    if ((StringUtils.isNotEmpty(str2)) && (localAppUser.getMobile() != null))
    {
      if (this.logger.isDebugEnabled())
        this.logger.info("Notice " + localAppUser.getFullname() + " by mobile:" + localAppUser.getMobile());
      localObject = new SmsMobile();
      ((SmsMobile)localObject).setPhoneNumber(localAppUser.getMobile());
      ((SmsMobile)localObject).setSmsContent(localStringBuffer.toString());
      ((SmsMobile)localObject).setSendTime(new Date());
      ((SmsMobile)localObject).setUserId(Long.valueOf(-1L));
      ((SmsMobile)localObject).setUserName("system user");
      ((SmsMobile)localObject).setStatus(SmsMobile.STATUS_NOT_SENDED);
      this.smsMobileService.save(localObject);
      this.mobileMessageProducer.send((SmsMobile)localObject);
    }
    Object localObject = new Date();
    String str4 = localSimpleDateFormat.format((Date)localObject);
    if ((StringUtils.isNotEmpty(str3)) && (localAppUser.getEmail() != null))
    {
      if (this.logger.isDebugEnabled())
        this.logger.info("Notice " + localAppUser.getFullname() + " by mail:" + localAppUser.getEmail());
      String str5 = "mail/flowMail.vm";
      HashMap localHashMap = new HashMap();
      localHashMap.put("curDateStr", str4);
      localHashMap.put("appUser", localAppUser);
      localHashMap.put("appointment", this.appointment);
      String str6 = "来自" + AppUtil.getCompanyName() + "我的约会(" + this.appointment.getSubject() + "--地址:" + this.appointment.getLocation() + ")提醒";
      MailModel localMailModel = new MailModel();
      localMailModel.setContent(localStringBuffer.toString());
      localMailModel.setSubject(str6);
      this.mailMessageProducer.send(localMailModel);
    }
    this.shortMessageService.save(AppUser.SYSTEM_USER, str1, localStringBuffer.toString(), ShortMessage.MSG_TYPE_SYS);
    this.appointmentService.save(this.appointment);
    setJsonString("{success:true}");
    return (String)"success";
  }

  public String display()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_appUser.userId_L_EQ", ContextUtil.getCurrentUserId().toString());
    localQueryFilter.addSorted("appointId", "desc");
    List localList = this.appointmentService.getAll(localQueryFilter);
    getRequest().setAttribute("appointmentList", localList);
    return "display";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.task.AppointmentAction
 * JD-Core Version:    0.6.0
 */