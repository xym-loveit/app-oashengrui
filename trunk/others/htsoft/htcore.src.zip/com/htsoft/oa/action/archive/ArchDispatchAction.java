package com.htsoft.oa.action.archive;

import com.google.gson.Gson;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.archive.ArchDispatch;
import com.htsoft.oa.model.archive.Archives;
import com.htsoft.oa.model.archive.ArchivesDep;
import com.htsoft.oa.model.system.AppRole;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.archive.ArchDispatchService;
import com.htsoft.oa.service.archive.ArchivesDepService;
import com.htsoft.oa.service.archive.ArchivesService;
import com.htsoft.oa.service.flow.JbpmService;
import com.htsoft.oa.service.system.AppRoleService;
import com.htsoft.oa.service.system.AppUserService;
import flexjson.JSONSerializer;
import java.util.Date;
import java.util.List;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.jbpm.api.TaskService;
import org.jbpm.pvm.internal.task.TaskImpl;

public class ArchDispatchAction extends BaseAction
{

  @Resource
  private ArchDispatchService archDispatchService;
  private ArchDispatch archDispatch;

  @Resource
  private ArchivesService archivesService;

  @Resource
  private AppUserService appUserService;

  @Resource
  private AppRoleService appRoleService;

  @Resource
  private ArchivesDepService archivesDepService;

  @Resource
  private JbpmService jbpmService;

  @Resource
  private TaskService taskService;
  private Long dispatchId;
  private Long archivesId;
  private Short archUserType;
  private String readFeedback;
  private String taskName;
  private String taskId;

  public String getTaskName()
  {
    return this.taskName;
  }

  public void setTaskName(String paramString)
  {
    this.taskName = paramString;
  }

  public Short getArchUserType()
  {
    return this.archUserType;
  }

  public void setArchUserType(Short paramShort)
  {
    this.archUserType = paramShort;
  }

  public String getReadFeedback()
  {
    return this.readFeedback;
  }

  public void setReadFeedback(String paramString)
  {
    this.readFeedback = paramString;
  }

  public Long getArchivesId()
  {
    return this.archivesId;
  }

  public void setArchivesId(Long paramLong)
  {
    this.archivesId = paramLong;
  }

  public Long getDispatchId()
  {
    return this.dispatchId;
  }

  public void setDispatchId(Long paramLong)
  {
    this.dispatchId = paramLong;
  }

  public ArchDispatch getArchDispatch()
  {
    return this.archDispatch;
  }

  public void setArchDispatch(ArchDispatch paramArchDispatch)
  {
    this.archDispatch = paramArchDispatch;
  }

  public String getTaskId()
  {
    return this.taskId;
  }

  public void setTaskId(String paramString)
  {
    this.taskId = paramString;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_userId_L_EQ", ContextUtil.getCurrentUserId().toString());
    List localList = this.archDispatchService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "dispatchTime", "archives.issueDate", "archives.createtime" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String disList()
  {
    PagingBean localPagingBean = getInitPagingBean();
    List localList = this.archDispatchService.findByUser(ContextUtil.getCurrentUser(), localPagingBean);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localPagingBean.getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "dispatchTime" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.archDispatchService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    ArchDispatch localArchDispatch = (ArchDispatch)this.archDispatchService.get(this.dispatchId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localArchDispatch));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    Archives localArchives = (Archives)this.archivesService.get(this.archivesId);
    if (localArchives != null)
    {
      ArchDispatch localArchDispatch = new ArchDispatch();
      AppUser localAppUser = ContextUtil.getCurrentUser();
      localArchDispatch.setArchives(localArchives);
      localArchDispatch.setArchUserType(this.archUserType);
      localArchDispatch.setUserId(localAppUser.getUserId());
      localArchDispatch.setFullname(localAppUser.getFullname());
      localArchDispatch.setDispatchTime(new Date());
      localArchDispatch.setSubject(localArchives.getSubject());
      localArchDispatch.setIsRead(ArchDispatch.HAVE_READ);
      localArchDispatch.setReadFeedback(this.readFeedback);
      this.archDispatchService.save(localArchDispatch);
      Object localObject1;
      Object localObject2;
      if (this.taskId != null)
      {
        localObject1 = (TaskImpl)this.taskService.getTask(this.taskId);
        localObject2 = ((TaskImpl)localObject1).getSuperTask();
        if ((localObject2 != null) && (((TaskImpl)localObject2).getSubTasks() != null) && (((TaskImpl)localObject2).getSubTasks().size() == 1))
        {
          localArchives.setStatus(this.taskName);
          this.archivesService.save(localArchives);
        }
      }
      else
      {
        localArchives.setStatus(this.taskName);
        this.archivesService.save(localArchives);
      }
      if (ArchDispatch.IS_OVER.compareTo(this.archUserType) == 0)
      {
        localObject1 = getRequest().getParameter("cruArchDepId");
        if ((StringUtils.isNotEmpty((String)localObject1)) && (((String)localObject1).indexOf("$") == -1))
        {
          localObject2 = (ArchivesDep)this.archivesDepService.get(new Long((String)localObject1));
          ((ArchivesDep)localObject2).setHandleFeedback(this.readFeedback);
          this.archivesDepService.save(localObject2);
        }
      }
      setJsonString("{success:true}");
    }
    else
    {
      setJsonString("{success:false}");
    }
    return (String)(String)"success";
  }

  public String read()
  {
    ArchDispatch localArchDispatch = (ArchDispatch)this.archDispatchService.get(this.dispatchId);
    if (localArchDispatch != null)
    {
      localArchDispatch.setReadFeedback(this.readFeedback);
      localArchDispatch.setIsRead(ArchDispatch.HAVE_READ);
      localArchDispatch.setDispatchTime(new Date());
      this.archDispatchService.save(localArchDispatch);
      setJsonString("{success:true}");
    }
    else
    {
      setJsonString("{success:false}");
    }
    return "success";
  }

  public String dispatch()
  {
    String str1 = getRequest().getParameter("disUserIds");
    String str2 = getRequest().getParameter("disRoleIds");
    Archives localArchives = (Archives)this.archivesService.get(this.archivesId);
    if (localArchives != null)
    {
      String[] arrayOfString1;
      String str3;
      Object localObject;
      ArchDispatch localArchDispatch;
      if (StringUtils.isNotEmpty(str1))
      {
        arrayOfString1 = str1.split(",");
        for (str3 : arrayOfString1)
        {
          localObject = (AppUser)this.appUserService.get(new Long(str3));
          localArchDispatch = new ArchDispatch();
          localArchDispatch.setArchives(localArchives);
          localArchDispatch.setUserId(((AppUser)localObject).getUserId());
          localArchDispatch.setFullname(((AppUser)localObject).getFullname());
          localArchDispatch.setDispatchTime(new Date());
          localArchDispatch.setSubject(localArchives.getSubject());
          localArchDispatch.setIsRead(ArchDispatch.NOT_READ);
          localArchDispatch.setArchUserType(ArchDispatch.IS_DISPATCH);
          this.archDispatchService.save(localArchDispatch);
        }
      }
      if (StringUtils.isNotEmpty(str2))
      {
        arrayOfString1 = str2.split(",");
        for (str3 : arrayOfString1)
        {
          localObject = (AppRole)this.appRoleService.get(new Long(str3));
          localArchDispatch = new ArchDispatch();
          localArchDispatch.setArchives(localArchives);
          localArchDispatch.setDisRoleId(((AppRole)localObject).getRoleId());
          localArchDispatch.setDisRoleName(((AppRole)localObject).getRoleName());
          localArchDispatch.setDispatchTime(new Date());
          localArchDispatch.setSubject(localArchives.getSubject());
          localArchDispatch.setIsRead(ArchDispatch.NOT_READ);
          localArchDispatch.setArchUserType(ArchDispatch.IS_DISPATCH);
          this.archDispatchService.save(localArchDispatch);
        }
      }
      setJsonString("{success:true}");
    }
    else
    {
      setJsonString("{success:false}");
    }
    return (String)"success";
  }

  public String applicate()
  {
    ArchDispatch localArchDispatch = (ArchDispatch)this.archDispatchService.get(this.dispatchId);
    if (localArchDispatch.getUserId() == null)
    {
      AppUser localAppUser = ContextUtil.getCurrentUser();
      localArchDispatch.setUserId(localAppUser.getUserId());
      localArchDispatch.setFullname(localAppUser.getFullname());
      this.archDispatchService.save(localArchDispatch);
      setJsonString("{success:true}");
    }
    else
    {
      setJsonString("{success:false}");
    }
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.archive.ArchDispatchAction
 * JD-Core Version:    0.6.0
 */