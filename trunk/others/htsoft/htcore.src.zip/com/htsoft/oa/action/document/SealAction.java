package com.htsoft.oa.action.document;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.document.Seal;
import com.htsoft.oa.service.document.SealService;
import flexjson.JSONSerializer;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;

public class SealAction extends BaseAction
{

  @Resource
  private SealService sealService;
  private Seal seal;
  private Long sealId;

  public Long getSealId()
  {
    return this.sealId;
  }

  public void setSealId(Long paramLong)
  {
    this.sealId = paramLong;
  }

  public Seal getSeal()
  {
    return this.seal;
  }

  public void setSeal(Seal paramSeal)
  {
    this.seal = paramSeal;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.sealService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer();
    localStringBuffer.append(localJSONSerializer.serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.sealService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    Seal localSeal = (Seal)this.sealService.get(this.sealId);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer();
    localJSONSerializer.exclude(new String[] { "class" });
    localStringBuffer.append(localJSONSerializer.serialize(localSeal));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.seal.setBelongId(ContextUtil.getCurrentUserId());
    if (this.seal.getSealId() == null)
    {
      this.sealService.save(this.seal);
    }
    else
    {
      Seal localSeal = (Seal)this.sealService.get(this.seal.getSealId());
      try
      {
        BeanUtil.copyNotNullProperties(localSeal, this.seal);
        this.sealService.save(localSeal);
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.document.SealAction
 * JD-Core Version:    0.6.0
 */