package com.htsoft.oa.action.bpm;

import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.flow.ProDefinition;
import com.htsoft.oa.service.flow.ProDefinitionService;
import com.htsoft.oa.service.system.GlobalTypeService;
import java.util.ArrayList;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class BpmDesignAction extends BaseAction
{

  @Resource
  private ProDefinitionService proDefinitionService;

  @Resource
  private GlobalTypeService globalTypeService;
  private Long defId;
  private String name;

  public Long getDefId()
  {
    return this.defId;
  }

  public void setDefId(Long paramLong)
  {
    this.defId = paramLong;
  }

  public String getName()
  {
    return this.name;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public String execute()
    throws Exception
  {
    HttpServletRequest localHttpServletRequest = getRequest();
    String str1 = localHttpServletRequest.getParameter("defId");
    if (StringUtils.isNotEmpty(str1))
    {
      localObject1 = (ProDefinition)this.proDefinitionService.get(new Long(str1));
      localHttpServletRequest.setAttribute("proDefinition", localObject1);
      localHttpServletRequest.setAttribute("title", ((ProDefinition)localObject1).getName());
    }
    else
    {
      localHttpServletRequest.setAttribute("title", "未命名");
    }
    Object localObject1 = ContextUtil.getCurrentUserId();
    Object localObject2 = new ArrayList();
    String str2 = "FLOW";
    localObject2 = this.globalTypeService.getByCatKeyUserId(ContextUtil.getCurrentUser(), str2);
    localHttpServletRequest.setAttribute("record", localObject2);
    localHttpServletRequest.setAttribute("uId", localObject1);
    return (String)(String)"success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.bpm.BpmDesignAction
 * JD-Core Version:    0.6.0
 */