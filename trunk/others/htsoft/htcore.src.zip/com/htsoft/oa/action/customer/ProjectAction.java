package com.htsoft.oa.action.customer;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.customer.Customer;
import com.htsoft.oa.model.customer.Project;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.FileAttach;
import com.htsoft.oa.service.customer.ProjectService;
import com.htsoft.oa.service.system.FileAttachService;
import flexjson.JSONSerializer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class ProjectAction extends BaseAction
{

  @Resource
  private ProjectService projectService;

  @Resource
  private FileAttachService fileAttachService;
  private Project project;
  private Long projectId;
  private String projectNo;
  private String projectAttachIDs;

  public Long getProjectId()
  {
    return this.projectId;
  }

  public void setProjectId(Long paramLong)
  {
    this.projectId = paramLong;
  }

  public Project getProject()
  {
    return this.project;
  }

  public void setProject(Project paramProject)
  {
    this.project = paramProject;
  }

  public String getProjectNo()
  {
    return this.projectNo;
  }

  public void setProjectNo(String paramString)
  {
    this.projectNo = paramString;
  }

  public String getProjectAttachIDs()
  {
    return this.projectAttachIDs;
  }

  public void setProjectAttachIDs(String paramString)
  {
    this.projectAttachIDs = paramString;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.projectService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class", "appUser.department", "contracts" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.projectService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    Project localProject = (Project)this.projectService.get(this.projectId);
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localProject));
    localStringBuffer.append(",userId:'" + localProject.getAppUser().getUserId() + "'");
    localStringBuffer.append(",salesman:'" + localProject.getAppUser().getFullname() + "'");
    localStringBuffer.append(",customerName:'" + localProject.getCustomer().getCustomerName() + "'");
    localStringBuffer.append(",customerId:'" + localProject.getCustomerId() + "'");
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    int i = 0;
    StringBuffer localStringBuffer = new StringBuffer("{");
    if (this.projectId != null)
    {
      if (this.projectService.checkProjectNo(this.project.getProjectNo()))
        i = 1;
      else
        localStringBuffer.append("msg:'项目号已存在,请重新填写!',");
    }
    else
      i = 1;
    if (i != 0)
    {
      String[] arrayOfString1 = getProjectAttachIDs().split(",");
      HashSet localHashSet = new HashSet();
      for (String str : arrayOfString1)
      {
        if (str.equals(""))
          continue;
        localHashSet.add(this.fileAttachService.get(new Long(str)));
      }
      this.project.setProjectFiles(localHashSet);
      this.projectService.save(this.project);
      localStringBuffer.append("success:true,projectId:" + this.project.getProjectId() + "}");
    }
    else
    {
      localStringBuffer.append("failure:true}");
    }
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String number()
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss-SSS");
    String str = localSimpleDateFormat.format(new Date());
    setJsonString("{success:true,projectNo:'" + str + "'}");
    return "success";
  }

  public String check()
  {
    boolean bool = false;
    bool = this.projectService.checkProjectNo(this.projectNo);
    if (bool)
      setJsonString("{success:true,pass:true}");
    else
      setJsonString("{success:true,pass:false}");
    return "success";
  }

  public String removeFile()
  {
    setProject((Project)this.projectService.get(this.projectId));
    Set localSet = this.project.getProjectFiles();
    FileAttach localFileAttach = (FileAttach)this.fileAttachService.get(new Long(this.projectAttachIDs));
    localSet.remove(localFileAttach);
    this.project.setProjectFiles(localSet);
    this.projectService.save(this.project);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.customer.ProjectAction
 * JD-Core Version:    0.6.0
 */