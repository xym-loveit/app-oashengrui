package com.htsoft.oa.action.admin;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.admin.Book;
import com.htsoft.oa.model.admin.BookBorRet;
import com.htsoft.oa.model.admin.BookSn;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.admin.BookBorRetService;
import com.htsoft.oa.service.admin.BookService;
import com.htsoft.oa.service.admin.BookSnService;
import flexjson.JSONSerializer;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class BookBorRetAction extends BaseAction
{

  @Resource
  private BookBorRetService bookBorRetService;
  private BookBorRet bookBorRet;

  @Resource
  private BookSnService bookSnService;

  @Resource
  private BookService bookService;
  private Long recordId;
  private Long bookSnId;

  public Long getBookSnId()
  {
    return this.bookSnId;
  }

  public void setBookSnId(Long paramLong)
  {
    this.bookSnId = paramLong;
  }

  public Long getRecordId()
  {
    return this.recordId;
  }

  public void setRecordId(Long paramLong)
  {
    this.recordId = paramLong;
  }

  public BookBorRet getBookBorRet()
  {
    return this.bookBorRet;
  }

  public void setBookBorRet(BookBorRet paramBookBorRet)
  {
    this.bookBorRet = paramBookBorRet;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.bookBorRetService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "borrowTime", "returnTime", "lastReturnTime" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String listBorrow()
  {
    PagingBean localPagingBean = getInitPagingBean();
    List localList = this.bookBorRetService.getBorrowInfo(localPagingBean);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localPagingBean.getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "borrowTime", "returnTime", "lastReturnTime" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String listReturn()
  {
    PagingBean localPagingBean = getInitPagingBean();
    List localList = this.bookBorRetService.getReturnInfo(localPagingBean);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localPagingBean.getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "borrowTime", "returnTime", "lastReturnTime" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.bookBorRetService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    BookBorRet localBookBorRet = (BookBorRet)this.bookBorRetService.get(this.recordId);
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "borrowTime", "returnTime", "lastReturnTime" });
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localBookBorRet));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String saveBorrow()
  {
    Long localLong1 = this.bookBorRet.getBookSn().getBookSnId();
    Long localLong2 = this.bookBorRetService.getBookBorRetId(localLong1);
    if (localLong2 != null)
      this.bookBorRetService.remove(localLong2);
    this.bookBorRet.setBorrowTime(new Date());
    AppUser localAppUser = ContextUtil.getCurrentUser();
    this.bookBorRet.setRegisterName(localAppUser.getFullname());
    this.bookBorRetService.save(this.bookBorRet);
    BookSn localBookSn = (BookSn)this.bookSnService.get(this.bookBorRet.getBookSnId());
    localBookSn.setStatus(new Short(1));
    this.bookSnService.save(localBookSn);
    Book localBook = (Book)this.bookService.get(localBookSn.getBookId());
    localBook.setLeftAmount(Integer.valueOf(localBook.getLeftAmount().intValue() - 1));
    this.bookService.save(localBook);
    setJsonString("{success:true}");
    return "success";
  }

  public String saveReturn()
  {
    this.bookBorRet.setLastReturnTime(new Date());
    AppUser localAppUser = ContextUtil.getCurrentUser();
    this.bookBorRet.setRegisterName(localAppUser.getFullname());
    this.bookBorRetService.save(this.bookBorRet);
    BookSn localBookSn = (BookSn)this.bookSnService.get(this.bookBorRet.getBookSnId());
    localBookSn.setStatus(new Short(0));
    this.bookSnService.save(localBookSn);
    Book localBook = (Book)this.bookService.get(localBookSn.getBookId());
    localBook.setLeftAmount(Integer.valueOf(localBook.getLeftAmount().intValue() + 1));
    this.bookService.save(localBook);
    setJsonString("{success:true}");
    return "success";
  }

  public String getBorRetTime()
  {
    Long localLong = Long.valueOf(getRequest().getParameter("bookSnId"));
    BookBorRet localBookBorRet = this.bookBorRetService.getByBookSnId(localLong);
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "borrowTime", "returnTime" });
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localBookBorRet));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.admin.BookBorRetAction
 * JD-Core Version:    0.6.0
 */