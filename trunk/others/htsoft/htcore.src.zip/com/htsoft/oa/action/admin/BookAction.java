package com.htsoft.oa.action.admin;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.admin.Book;
import com.htsoft.oa.model.admin.BookSn;
import com.htsoft.oa.model.admin.BookType;
import com.htsoft.oa.service.admin.BookService;
import com.htsoft.oa.service.admin.BookSnService;
import com.htsoft.oa.service.admin.BookTypeService;
import flexjson.JSONSerializer;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class BookAction extends BaseAction
{

  @Resource
  private BookService bookService;

  @Resource
  private BookTypeService bookTypeService;

  @Resource
  private BookSnService bookSnService;
  private Book book;
  private Long bookId;
  private Long typeId;
  private BookType bookType;

  public Long getTypeId()
  {
    return this.typeId;
  }

  public void setTypeId(Long paramLong)
  {
    this.typeId = paramLong;
  }

  public BookType getBookType()
  {
    return this.bookType;
  }

  public void setBookType(BookType paramBookType)
  {
    this.bookType = paramBookType;
  }

  public Long getBookId()
  {
    return this.bookId;
  }

  public void setBookId(Long paramLong)
  {
    this.bookId = paramLong;
  }

  public Book getBook()
  {
    return this.book;
  }

  public void setBook(Book paramBook)
  {
    this.book = paramBook;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.bookService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.bookService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    Book localBook = (Book)this.bookService.get(this.bookId);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localBook));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    String str = "";
    if (this.book.getBookId() == null)
    {
      this.book.setLeftAmount(this.book.getAmount());
      this.bookService.save(this.book);
      for (int i = 1; i <= this.book.getAmount().intValue(); i++)
      {
        BookSn localBookSn = new BookSn();
        str = this.book.getIsbn() + "-" + i;
        localBookSn.setBookId(this.book.getBookId());
        localBookSn.setBookSN(str);
        localBookSn.setStatus(new Short(0));
        this.bookSnService.save(localBookSn);
      }
    }
    else
    {
      this.bookService.save(this.book);
    }
    setJsonString("{success:true,bookSnNumber:'" + str + "'}");
    return "success";
  }

  public String updateAmount()
  {
    Long localLong = Long.valueOf(getRequest().getParameter("bookId"));
    this.book = ((Book)this.bookService.get(localLong));
    int i = Integer.parseInt(getRequest().getParameter("addAmount"));
    int j = this.book.getAmount().intValue() + i;
    BookSn localBookSn = null;
    String str = "";
    for (int k = this.book.getAmount().intValue() + 1; k <= this.book.getAmount().intValue() + i; k++)
    {
      localBookSn = new BookSn();
      str = this.book.getIsbn() + "-" + k;
      localBookSn.setBookId(this.book.getBookId());
      localBookSn.setBookSN(str);
      localBookSn.setStatus(new Short(0));
      this.bookSnService.save(localBookSn);
    }
    this.book.setAmount(Integer.valueOf(j));
    this.book.setLeftAmount(Integer.valueOf(this.book.getLeftAmount().intValue() + i));
    this.bookService.save(this.book);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(this.book));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String updateAmountAndLeftAmount()
  {
    Long localLong = Long.valueOf(getRequest().getParameter("bookId"));
    this.book = ((Book)this.bookService.get(localLong));
    int i = this.book.getAmount().intValue() - 1;
    int j = this.book.getLeftAmount().intValue() - 1;
    this.book.setAmount(Integer.valueOf(i));
    this.book.setLeftAmount(Integer.valueOf(j));
    this.bookService.save(this.book);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(this.book));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.admin.BookAction
 * JD-Core Version:    0.6.0
 */