package com.htsoft.oa.action.archive;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.jbpm.jpdl.Node;
import com.htsoft.core.util.AppUtil;
import com.htsoft.core.util.XmlUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.archive.ArchFlowConf;
import com.htsoft.oa.model.flow.ProDefinition;
import com.htsoft.oa.service.archive.ArchFlowConfService;
import com.htsoft.oa.service.flow.JbpmService;
import com.htsoft.oa.service.flow.ProDefinitionService;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.Element;
import org.jbpm.api.ProcessDefinition;

public class ArchFlowConfAction extends BaseAction
{

  @Resource
  private ArchFlowConfService archFlowConfService;

  @Resource
  private JbpmService jbpmService;

  @Resource
  private ProDefinitionService proDefinitionService;
  private ArchFlowConf archFlowConf;
  private Long configId;

  public Long getConfigId()
  {
    return this.configId;
  }

  public void setConfigId(Long paramLong)
  {
    this.configId = paramLong;
  }

  public ArchFlowConf getArchFlowConf()
  {
    return this.archFlowConf;
  }

  public void setArchFlowConf(ArchFlowConf paramArchFlowConf)
  {
    this.archFlowConf = paramArchFlowConf;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.archFlowConfService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.archFlowConfService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    ArchFlowConf localArchFlowConf1 = this.archFlowConfService.getByFlowType(ArchFlowConf.ARCH_SEND_TYPE);
    ArchFlowConf localArchFlowConf2 = this.archFlowConfService.getByFlowType(ArchFlowConf.ARCH_REC_TYPE);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    if (localArchFlowConf1 != null)
      localStringBuffer.append("{'sendProcessId':'" + localArchFlowConf1.getDefId() + "','sendProcessName':'" + localArchFlowConf1.getProcessName() + "'");
    else
      localStringBuffer.append("{'sendProcessId':'','sendProcessName':''");
    if (localArchFlowConf2 != null)
      localStringBuffer.append(",'recProcessId':'" + localArchFlowConf2.getDefId() + "','recProcessName':'" + localArchFlowConf2.getProcessName() + "'}}");
    else
      localStringBuffer.append(",'recProcessId':'','recProcessName':''}}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    String str1 = getRequest().getParameter("sendProcessId");
    String str2 = getRequest().getParameter("sendProcessName");
    String str3 = getRequest().getParameter("recProcessId");
    String str4 = getRequest().getParameter("recProcessName");
    if ((StringUtils.isNotEmpty(str1)) && (StringUtils.isNotEmpty(str2)))
    {
      this.archFlowConf = this.archFlowConfService.getByFlowType(ArchFlowConf.ARCH_SEND_TYPE);
      if (this.archFlowConf == null)
      {
        this.archFlowConf = new ArchFlowConf();
        this.archFlowConf.setArchType(ArchFlowConf.ARCH_SEND_TYPE);
      }
      this.archFlowConf.setDefId(new Long(str1));
      this.archFlowConf.setProcessName(str2);
      this.archFlowConfService.save(this.archFlowConf);
    }
    if ((StringUtils.isNotEmpty(str3)) && (StringUtils.isNotEmpty(str4)))
    {
      this.archFlowConf = this.archFlowConfService.getByFlowType(ArchFlowConf.ARCH_REC_TYPE);
      if (this.archFlowConf == null)
      {
        this.archFlowConf = new ArchFlowConf();
        this.archFlowConf.setArchType(ArchFlowConf.ARCH_REC_TYPE);
      }
      this.archFlowConf.setDefId(new Long(str3));
      this.archFlowConf.setProcessName(str4);
      this.archFlowConfService.save(this.archFlowConf);
    }
    setJsonString("{success:true}");
    return "success";
  }

  public String getFlow()
  {
    String str = getRequest().getParameter("flowType");
    StringBuffer localStringBuffer = new StringBuffer();
    if (str.equals(ArchFlowConf.ARCH_SEND_TYPE.toString()))
      this.archFlowConf = this.archFlowConfService.getByFlowType(ArchFlowConf.ARCH_SEND_TYPE);
    else
      this.archFlowConf = this.archFlowConfService.getByFlowType(ArchFlowConf.ARCH_REC_TYPE);
    if (this.archFlowConf != null)
      localStringBuffer.append("{success:true,defId:").append(this.archFlowConf.getDefId()).append("}");
    else
      localStringBuffer.append("{success:false,'message':'你还没设定流程'}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String setting()
  {
    String str1 = getRequest().getParameter("defId");
    String str2 = getRequest().getParameter("settingType");
    Short localShort = null;
    if (str2.equals("send"))
      localShort = ArchFlowConf.ARCH_SEND_TYPE;
    else
      localShort = ArchFlowConf.ARCH_REC_TYPE;
    if (StringUtils.isNotEmpty(str1))
    {
      ProDefinition localProDefinition = (ProDefinition)this.proDefinitionService.get(new Long(str1));
      ProcessDefinition localProcessDefinition = this.jbpmService.getProcessDefinitionByDefId(new Long(str1));
      List localList = this.jbpmService.getTaskNodesByDefId(new Long(str1), false, true);
      if (localShort.shortValue() == ArchFlowConf.ARCH_SEND_TYPE.shortValue())
        this.archFlowConf = this.archFlowConfService.getByFlowType(ArchFlowConf.ARCH_SEND_TYPE);
      else
        this.archFlowConf = this.archFlowConfService.getByFlowType(ArchFlowConf.ARCH_REC_TYPE);
      String str3 = AppUtil.getAppAbsolutePath() + "/js/menu/menu-archives.xml";
      Document localDocument = XmlUtil.load(str3);
      Element localElement1 = localDocument.getRootElement();
      Element localElement2 = localElement1.element("Items");
      if (this.archFlowConf == null)
      {
        this.archFlowConf = new ArchFlowConf();
      }
      else
      {
        localObject1 = this.jbpmService.getProcessDefinitionByDefId(this.archFlowConf.getDefId());
        localObject2 = localElement2.elements();
        localObject3 = ((List)localObject2).iterator();
        while (((Iterator)localObject3).hasNext())
        {
          localElement3 = (Element)((Iterator)localObject3).next();
          if (localElement3.attribute("id").getData().equals(((ProcessDefinition)localObject1).getKey()))
            localElement3.getParent().remove(localElement3);
        }
      }
      this.archFlowConf.setArchType(localShort);
      this.archFlowConf.setDefId(new Long(str1));
      this.archFlowConf.setProcessName(localProDefinition.getName());
      this.archFlowConfService.save(this.archFlowConf);
      Object localObject1 = localElement2.addElement("Items");
      ((Element)localObject1).addAttribute("id", localProcessDefinition.getKey());
      ((Element)localObject1).addAttribute("text", localProDefinition.getName());
      Object localObject2 = new SimpleDateFormat("yyyyMMddHHmmss");
      Object localObject3 = ((SimpleDateFormat)localObject2).format(new Date());
      Element localElement3 = ((Element)localObject1).addElement("Item");
      localElement3.addAttribute("id", localProcessDefinition.getKey() + (String)localObject3);
      localElement3.addAttribute("text", "流程启动");
      localElement3.addAttribute("defId", str1);
      localElement3.addAttribute("flowName", localProDefinition.getName());
      if (localShort.shortValue() == ArchFlowConf.ARCH_REC_TYPE.shortValue())
      {
        StringBuffer localStringBuffer = new StringBuffer("{defId:");
        localStringBuffer.append(str1).append(",flowName:'").append(localProDefinition.getName()).append("'}");
        localObject4 = ((Element)localObject1).addElement("Item");
        ((Element)localObject4).addAttribute("id", "ArchivesSignView");
        ((Element)localObject4).addAttribute("text", "公文签收待办");
        ((Element)localObject4).addAttribute("iconCls", "menu-archive-sign");
        ((Element)localObject4).addAttribute("params", localStringBuffer.toString());
      }
      int i = 1;
      Object localObject4 = localList.iterator();
      while (((Iterator)localObject4).hasNext())
      {
        Node localNode = (Node)((Iterator)localObject4).next();
        Element localElement4 = ((Element)localObject1).addElement("Item");
        localElement4.addAttribute("id", localProcessDefinition.getKey() + "Node" + i);
        localElement4.addAttribute("text", localNode.getName());
        localElement4.addAttribute("flowNode", "true");
        i++;
      }
      XmlUtil.docToXmlFile(localDocument, str3);
    }
    return (String)(String)(String)(String)"success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.archive.ArchFlowConfAction
 * JD-Core Version:    0.6.0
 */