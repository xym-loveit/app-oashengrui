package com.htsoft.oa.action.document;

import com.google.gson.Gson;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.document.DocFolder;
import com.htsoft.oa.model.document.DocPrivilege;
import com.htsoft.oa.model.system.AppRole;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.Department;
import com.htsoft.oa.service.document.DocPrivilegeService;
import com.htsoft.oa.service.system.AppRoleService;
import com.htsoft.oa.service.system.AppUserService;
import com.htsoft.oa.service.system.DepartmentService;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class DocPrivilegeAction extends BaseAction
{

  @Resource
  private DocPrivilegeService docPrivilegeService;
  private DocPrivilege docPrivilege;

  @Resource
  private AppRoleService appRoleService;

  @Resource
  private AppUserService appUserService;

  @Resource
  private DepartmentService departmentService;
  private Long privilegeId;

  public Long getPrivilegeId()
  {
    return this.privilegeId;
  }

  public void setPrivilegeId(Long paramLong)
  {
    this.privilegeId = paramLong;
  }

  public DocPrivilege getDocPrivilege()
  {
    return this.docPrivilege;
  }

  public void setDocPrivilege(DocPrivilege paramDocPrivilege)
  {
    this.docPrivilege = paramDocPrivilege;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.docPrivilegeService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      DocPrivilege localDocPrivilege = (DocPrivilege)localIterator.next();
      Integer localInteger1 = localDocPrivilege.getRights();
      String str = Integer.toBinaryString(localInteger1.intValue());
      Integer localInteger2 = null;
      Integer localInteger3 = null;
      Integer localInteger4 = null;
      char[] arrayOfChar = str.toCharArray();
      if ((arrayOfChar.length == 1) && (arrayOfChar[0] == '1'))
        localInteger2 = Integer.valueOf(1);
      if (arrayOfChar.length == 2)
      {
        if (arrayOfChar[0] == '1')
          localInteger3 = Integer.valueOf(1);
        if (arrayOfChar[1] == '1')
          localInteger2 = Integer.valueOf(1);
      }
      if (arrayOfChar.length == 3)
      {
        if (arrayOfChar[0] == '1')
          localInteger4 = Integer.valueOf(1);
        if (arrayOfChar[1] == '1')
          localInteger3 = Integer.valueOf(1);
        if (arrayOfChar[2] == '1')
          localInteger2 = Integer.valueOf(1);
      }
      localStringBuffer.append("{'privilegeId':" + localDocPrivilege.getPrivilegeId() + ",'udrId':" + localDocPrivilege.getUdrId() + ",'udrName':'" + localDocPrivilege.getUdrName() + "','folderName':'" + localDocPrivilege.getDocFolder().getFolderName() + "','flag':" + localDocPrivilege.getFlag() + ",'rightR':" + localInteger2 + ",'rightU':" + localInteger3 + ",'rightD':" + localInteger4 + "},");
    }
    if (localList.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.docPrivilegeService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    DocPrivilege localDocPrivilege = (DocPrivilege)this.docPrivilegeService.get(this.privilegeId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localDocPrivilege));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String change()
  {
    String str1 = getRequest().getParameter("privilegeId");
    String str2 = getRequest().getParameter("field");
    String str3 = getRequest().getParameter("fieldValue");
    if (StringUtils.isNotEmpty(str1))
    {
      this.docPrivilege = ((DocPrivilege)this.docPrivilegeService.get(Long.valueOf(Long.parseLong(str1))));
      Integer localInteger = this.docPrivilege.getRights();
      if (localInteger.intValue() > 0)
      {
        String str4 = Integer.toBinaryString(localInteger.intValue());
        StringBuffer localStringBuffer = new StringBuffer(str4);
        if (localStringBuffer.length() == 1)
          localStringBuffer.insert(0, "00");
        if (localStringBuffer.length() == 2)
          localStringBuffer.insert(0, "0");
        if (localStringBuffer.length() <= 0)
          localStringBuffer.insert(0, "000");
        String str5 = "";
        if ("rightR".equals(str2))
        {
          localObject = new StringBuffer();
          if ("true".equals(str3))
            ((StringBuffer)localObject).append(localStringBuffer.deleteCharAt(2).toString()).append("1");
          else
            ((StringBuffer)localObject).append(localStringBuffer.deleteCharAt(2).toString()).append("0");
          str5 = ((StringBuffer)localObject).toString();
        }
        if ("rightU".equals(str2))
        {
          localObject = new StringBuffer();
          if ("true".equals(str3))
            ((StringBuffer)localObject).append(localStringBuffer.charAt(0)).append("1").append(localStringBuffer.charAt(2));
          else
            ((StringBuffer)localObject).append(localStringBuffer.charAt(0)).append("0").append(localStringBuffer.charAt(2));
          str5 = ((StringBuffer)localObject).toString();
        }
        if ("rightD".equals(str2))
        {
          localObject = new StringBuffer();
          if ("true".equals(str3))
            ((StringBuffer)localObject).append("1").append(localStringBuffer.deleteCharAt(0).toString());
          else
            ((StringBuffer)localObject).append("0").append(localStringBuffer.deleteCharAt(0).toString());
          str5 = ((StringBuffer)localObject).toString();
        }
        Object localObject = Integer.valueOf(Integer.parseInt(str5, 2));
        this.docPrivilege.setRights((Integer)localObject);
        this.docPrivilegeService.save(this.docPrivilege);
        setJsonString("{success:true}");
      }
    }
    else
    {
      setJsonString("{success:false}");
    }
    return (String)"success";
  }

  public String save()
  {
    this.docPrivilegeService.save(this.docPrivilege);
    setJsonString("{success:true}");
    return "success";
  }

  public String add()
  {
    String str1 = getRequest().getParameter("folderId");
    String str2 = getRequest().getParameter("roleIds");
    String str3 = getRequest().getParameter("userIds");
    String str4 = getRequest().getParameter("depIds");
    String str5 = getRequest().getParameter("rightR");
    String str6 = getRequest().getParameter("rightU");
    String str7 = getRequest().getParameter("rightD");
    StringBuffer localStringBuffer = new StringBuffer();
    if (StringUtils.isNotEmpty(str7))
      localStringBuffer.append("1");
    else
      localStringBuffer.append("0");
    if (StringUtils.isNotEmpty(str6))
      localStringBuffer.append("1");
    else
      localStringBuffer.append("0");
    if (StringUtils.isNotEmpty(str5))
      localStringBuffer.append("1");
    else
      localStringBuffer.append("0");
    Integer localInteger1 = Integer.valueOf(Integer.parseInt(localStringBuffer.toString(), 2));
    if (StringUtils.isNotEmpty(str1))
    {
      Long localLong = Long.valueOf(Long.parseLong(str1));
      String[] arrayOfString;
      int i;
      DocPrivilege localDocPrivilege;
      Integer localInteger2;
      Object localObject;
      if (StringUtils.isNotEmpty(str2))
      {
        arrayOfString = str2.split(",");
        if (arrayOfString.length > 0)
          for (i = 0; i < arrayOfString.length; i++)
          {
            localDocPrivilege = new DocPrivilege();
            localDocPrivilege.setFolderId(localLong);
            localDocPrivilege.setFlag(Short.valueOf(3));
            localInteger2 = Integer.valueOf(Integer.parseInt(arrayOfString[i]));
            localObject = (AppRole)this.appRoleService.get(Long.valueOf(localInteger2.longValue()));
            localDocPrivilege.setUdrId(localInteger2);
            localDocPrivilege.setUdrName(((AppRole)localObject).getName());
            localDocPrivilege.setRights(localInteger1);
            localDocPrivilege.setFdFlag(Short.valueOf(0));
            this.docPrivilegeService.save(localDocPrivilege);
          }
      }
      if (StringUtils.isNotEmpty(str3))
      {
        arrayOfString = str3.split(",");
        if (arrayOfString.length > 0)
          for (i = 0; i < arrayOfString.length; i++)
          {
            localDocPrivilege = new DocPrivilege();
            localDocPrivilege.setFolderId(localLong);
            localDocPrivilege.setFlag(Short.valueOf(1));
            localInteger2 = Integer.valueOf(Integer.parseInt(arrayOfString[i]));
            localObject = (AppUser)this.appUserService.get(Long.valueOf(localInteger2.longValue()));
            localDocPrivilege.setUdrId(localInteger2);
            localDocPrivilege.setUdrName(((AppUser)localObject).getFullname());
            localDocPrivilege.setRights(localInteger1);
            localDocPrivilege.setFdFlag(Short.valueOf(0));
            this.docPrivilegeService.save(localDocPrivilege);
          }
      }
      if (StringUtils.isNotEmpty(str4))
      {
        arrayOfString = str4.split(",");
        if (arrayOfString.length > 0)
          for (i = 0; i < arrayOfString.length; i++)
          {
            localDocPrivilege = new DocPrivilege();
            localDocPrivilege.setFolderId(localLong);
            localDocPrivilege.setFlag(Short.valueOf(2));
            localInteger2 = Integer.valueOf(Integer.parseInt(arrayOfString[i]));
            localObject = (Department)this.departmentService.get(Long.valueOf(localInteger2.longValue()));
            localDocPrivilege.setUdrId(localInteger2);
            localDocPrivilege.setUdrName(((Department)localObject).getDepName());
            localDocPrivilege.setRights(localInteger1);
            localDocPrivilege.setFdFlag(Short.valueOf(0));
            this.docPrivilegeService.save(localDocPrivilege);
          }
      }
    }
    setJsonString("{success:true}");
    return (String)"success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.document.DocPrivilegeAction
 * JD-Core Version:    0.6.0
 */