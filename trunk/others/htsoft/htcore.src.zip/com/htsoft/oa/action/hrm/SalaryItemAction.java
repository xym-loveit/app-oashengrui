package com.htsoft.oa.action.hrm;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.hrm.SalaryItem;
import com.htsoft.oa.service.hrm.SalaryItemService;
import java.lang.reflect.Type;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class SalaryItemAction extends BaseAction
{

  @Resource
  private SalaryItemService salaryItemService;
  private SalaryItem salaryItem;
  private Long salaryItemId;

  public Long getSalaryItemId()
  {
    return this.salaryItemId;
  }

  public void setSalaryItemId(Long paramLong)
  {
    this.salaryItemId = paramLong;
  }

  public SalaryItem getSalaryItem()
  {
    return this.salaryItem;
  }

  public void setSalaryItem(SalaryItem paramSalaryItem)
  {
    this.salaryItem = paramSalaryItem;
  }

  public String list()
  {
    String str = getRequest().getParameter("exclude");
    if (StringUtils.isNotEmpty(str))
      str = str.substring(0, str.length() - 1);
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.salaryItemService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String search()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.salaryItemService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.salaryItemService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    SalaryItem localSalaryItem = (SalaryItem)this.salaryItemService.get(this.salaryItemId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localSalaryItem));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.salaryItemService.save(this.salaryItem);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.hrm.SalaryItemAction
 * JD-Core Version:    0.6.0
 */