package com.htsoft.oa.action.system;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.AppUtil;
import com.htsoft.core.util.XmlUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.system.FileAttach;
import com.htsoft.oa.service.system.FileAttachService;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.Element;

public class FileAttachAction extends BaseAction
{

  @Resource
  private FileAttachService fileAttachService;
  private FileAttach fileAttach;
  private Long fileId;
  private String filePath;

  public Long getFileId()
  {
    return this.fileId;
  }

  public void setFileId(Long paramLong)
  {
    this.fileId = paramLong;
  }

  public FileAttach getFileAttach()
  {
    return this.fileAttach;
  }

  public void setFileAttach(FileAttach paramFileAttach)
  {
    this.fileAttach = paramFileAttach;
  }

  public String getFilePath()
  {
    return this.filePath;
  }

  public void setFilePath(String paramString)
  {
    this.filePath = paramString;
  }

  public String list()
  {
    int i = new QueryFilter(getRequest()).getPagingBean().getStart().intValue();
    PagingBean localPagingBean = new PagingBean(i, 20);
    String str1 = getRequest().getParameter("type");
    boolean bool = true;
    if ((str1 != null) && (str1.toLowerCase().equals("image")))
    {
      bool = false;
      localPagingBean = new PagingBean(i, 16);
    }
    String str2 = getRequest().getParameter("fileType");
    List localList = this.fileAttachService.fileList(localPagingBean, str2, bool);
    return listToJson(localList, localPagingBean);
  }

  public String listAll()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addSorted("fileType", "DESC");
    List localList = this.fileAttachService.getAll(localQueryFilter);
    return listToJson(localList, localQueryFilter.getPagingBean());
  }

  public String multiDel()
  {
    String str1 = getRequest().getParameter("ids");
    if (str1 != null)
      for (String str2 : str1.split(","))
        this.fileAttachService.remove(new Long(str2));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    FileAttach localFileAttach = (FileAttach)this.fileAttachService.get(this.fileId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localFileAttach));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.fileAttachService.save(this.fileAttach);
    setJsonString("{success:true}");
    return "success";
  }

  public String delete()
  {
    this.fileAttachService.removeByPath(this.filePath);
    return "success";
  }

  private String listToJson(List<FileAttach> paramList, PagingBean paramPagingBean)
  {
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(paramPagingBean.getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(paramList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String treeLoad()
  {
    String str1 = AppUtil.getAppAbsolutePath().replace("\\", "/") + "WEB-INF/classes/attach-file.xml";
    StringBuffer localStringBuffer = new StringBuffer("");
    localStringBuffer.append("[{id:'0',text:'" + AppUtil.getCompanyName() + "',expanded:true,children:[");
    try
    {
      Document localDocument = XmlUtil.load(str1);
      if (localDocument != null)
      {
        Element localElement1 = localDocument.getRootElement();
        List localList = localElement1.elements();
        Iterator localIterator = localList.iterator();
        while (localIterator.hasNext())
        {
          Element localElement2 = (Element)localIterator.next();
          String str2 = localElement2.attribute("id").getValue();
          String str3 = localElement2.attribute("text").getValue();
          localStringBuffer.append("{id:'" + str2).append("',text:'" + str3).append("',");
          localStringBuffer.append(findChild(localElement2));
        }
        if ((localList != null) && (localList.size() > 0))
          localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
      }
    }
    catch (Exception localException)
    {
      this.logger.debug("FileAttachAction中，加载xml文件失败！");
      localException.printStackTrace();
    }
    localStringBuffer.append("]}]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  private String findChild(Element paramElement)
  {
    List localList = paramElement.elements();
    StringBuffer localStringBuffer = new StringBuffer("");
    if ((localList == null) || (localList.size() == 0))
    {
      localStringBuffer.append("leaf:true},");
    }
    else
    {
      localStringBuffer.append("children:[");
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        Element localElement = (Element)localIterator.next();
        String str1 = localElement.attribute("id").getValue();
        String str2 = localElement.attribute("text").getValue();
        localStringBuffer.append("{id:'" + str1).append("',text:'" + str2).append("',");
        localStringBuffer.append(findChild(localElement));
      }
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
      localStringBuffer.append("]},");
    }
    return localStringBuffer.toString();
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.FileAttachAction
 * JD-Core Version:    0.6.0
 */