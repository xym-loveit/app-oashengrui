package com.htsoft.oa.action.hrm;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.hrm.HireIssue;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.hrm.HireIssueService;
import java.lang.reflect.Type;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class HireIssueAction extends BaseAction
{

  @Resource
  private HireIssueService hireIssueService;
  private HireIssue hireIssue;
  private Long hireId;

  public Long getHireId()
  {
    return this.hireId;
  }

  public void setHireId(Long paramLong)
  {
    this.hireId = paramLong;
  }

  public HireIssue getHireIssue()
  {
    return this.hireIssue;
  }

  public void setHireIssue(HireIssue paramHireIssue)
  {
    this.hireIssue = paramHireIssue;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.hireIssueService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.hireIssueService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    HireIssue localHireIssue = (HireIssue)this.hireIssueService.get(this.hireId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:[");
    localStringBuffer.append(localGson.toJson(localHireIssue));
    localStringBuffer.append("]}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    AppUser localAppUser = ContextUtil.getCurrentUser();
    if (this.hireIssue.getHireId() == null)
    {
      this.hireIssue.setRegFullname(localAppUser.getFullname());
      this.hireIssue.setRegDate(new Date());
    }
    else
    {
      this.hireIssue.setModifyFullname(localAppUser.getFullname());
      this.hireIssue.setModifyDate(new Date());
    }
    this.hireIssue.setStatus(HireIssue.NOTYETPASS_CHECK);
    this.hireIssueService.save(this.hireIssue);
    setJsonString("{success:true}");
    return "success";
  }

  public String load()
  {
    String str = getRequest().getParameter("hireId");
    if (StringUtils.isNotEmpty(str))
      this.hireIssue = ((HireIssue)this.hireIssueService.get(new Long(str)));
    return "load";
  }

  public String check()
  {
    String str1 = getRequest().getParameter("status");
    String str2 = getRequest().getParameter("hireId");
    String str3 = getRequest().getParameter("checkOpinion");
    if (StringUtils.isNotEmpty(str2))
    {
      AppUser localAppUser = ContextUtil.getCurrentUser();
      this.hireIssue = ((HireIssue)this.hireIssueService.get(new Long(str2)));
      this.hireIssue.setCheckFullname(localAppUser.getFullname());
      this.hireIssue.setCheckDate(new Date());
      this.hireIssue.setCheckOpinion(str3);
      if (StringUtils.isNotEmpty(str1))
      {
        this.hireIssue.setStatus(Short.valueOf(str1));
        this.hireIssueService.save(this.hireIssue);
        setJsonString("{success:true}");
      }
      else
      {
        setJsonString("{success:false}");
      }
    }
    else
    {
      setJsonString("{success:false}");
    }
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.hrm.HireIssueAction
 * JD-Core Version:    0.6.0
 */