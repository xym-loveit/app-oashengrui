package com.htsoft.oa.action.task;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.util.DateUtil;
import com.htsoft.core.util.StringUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.task.CalendarPlan;
import com.htsoft.oa.model.task.PlanInfo;
import com.htsoft.oa.service.system.AppUserService;
import com.htsoft.oa.service.task.CalendarPlanService;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.logging.Log;

public class CalendarPlanAction extends BaseAction
{

  @Resource
  private CalendarPlanService calendarPlanService;
  private CalendarPlan calendarPlan;

  @Resource
  private AppUserService appUserService;
  private List<CalendarPlan> list;
  private Long planId;

  public Long getPlanId()
  {
    return this.planId;
  }

  public void setPlanId(Long paramLong)
  {
    this.planId = paramLong;
  }

  public CalendarPlan getCalendarPlan()
  {
    return this.calendarPlan;
  }

  public void setCalendarPlan(CalendarPlan paramCalendarPlan)
  {
    this.calendarPlan = paramCalendarPlan;
  }

  public List<CalendarPlan> getList()
  {
    return this.list;
  }

  public void setList(List<CalendarPlan> paramList)
  {
    this.list = paramList;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    if (getRequest().getParameter("Q_assignerId_L_EQ") == null)
      localQueryFilter.addFilter("Q_userId_L_EQ", ContextUtil.getCurrentUserId().toString());
    List localList = this.calendarPlanService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String display()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_userId_L_EQ", ContextUtil.getCurrentUserId().toString());
    localQueryFilter.addSorted("planId", "desc");
    List localList = this.calendarPlanService.getAll(localQueryFilter);
    getRequest().setAttribute("calendarList", localList);
    return "display";
  }

  public String today()
  {
    PagingBean localPagingBean = new PagingBean(this.start.intValue(), this.limit.intValue());
    List localList = this.calendarPlanService.getTodayPlans(ContextUtil.getCurrentUserId(), localPagingBean);
    ArrayList localArrayList = new ArrayList();
    Object localObject1 = localList.iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (CalendarPlan)((Iterator)localObject1).next();
      localArrayList.add(new PlanInfo((CalendarPlan)localObject2));
    }
    localObject1 = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    Object localObject2 = new StringBuffer("{success:true,'totalCounts':").append(localPagingBean.getTotalItems()).append(",result:");
    Type localType = new TypeToken()
    {
    }
    .getType();
    ((StringBuffer)localObject2).append(((Gson)localObject1).toJson(localArrayList, localType));
    ((StringBuffer)localObject2).append("}");
    setJsonString(((StringBuffer)localObject2).toString());
    return (String)(String)"success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.calendarPlanService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    CalendarPlan localCalendarPlan = (CalendarPlan)this.calendarPlanService.get(this.planId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localCalendarPlan));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String oldsave()
  {
    Object localObject;
    if (this.calendarPlan.getPlanId() == null)
    {
      this.calendarPlan.setStatus(CalendarPlan.STATUS_UNFINISHED);
      localObject = ContextUtil.getCurrentUser();
      this.calendarPlan.setAssignerId(((AppUser)localObject).getUserId());
      this.calendarPlan.setAssignerName(((AppUser)localObject).getFullname());
      this.calendarPlanService.save(this.calendarPlan);
    }
    else
    {
      localObject = (CalendarPlan)this.calendarPlanService.get(this.calendarPlan.getPlanId());
      try
      {
        BeanUtil.copyNotNullProperties(localObject, this.calendarPlan);
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
      this.calendarPlanService.save(localObject);
    }
    setJsonString("{success:true}");
    return (String)"success";
  }

  public String oldmy()
  {
    HttpServletRequest localHttpServletRequest = getRequest();
    String str = localHttpServletRequest.getParameter("action");
    Date localDate1 = null;
    Date localDate2 = null;
    Object localObject3;
    Object localObject4;
    Object localObject5;
    if ("month".equals(str))
    {
      localObject1 = localHttpServletRequest.getParameter("monthday");
      try
      {
        Date localDate3 = DateUtils.parseDate((String)localObject1, new String[] { "MM/dd/yyyy" });
        localObject3 = Calendar.getInstance();
        ((Calendar)localObject3).setTime(localDate3);
        ((Calendar)localObject3).set(5, 1);
        localDate1 = DateUtil.setStartDay((Calendar)localObject3).getTime();
        ((Calendar)localObject3).add(2, 1);
        ((Calendar)localObject3).add(5, -1);
        localDate2 = DateUtil.setEndDay((Calendar)localObject3).getTime();
      }
      catch (Exception localException1)
      {
        this.logger.error(localException1.getMessage());
      }
    }
    else if ("day".equals(str))
    {
      localObject1 = localHttpServletRequest.getParameter("day");
      this.logger.info("day:" + (String)localObject1);
      try
      {
        Date localDate4 = DateUtils.parseDate((String)localObject1, new String[] { "MM/dd/yyyy" });
        localObject3 = Calendar.getInstance();
        ((Calendar)localObject3).setTime(localDate4);
        localDate1 = DateUtil.setStartDay((Calendar)localObject3).getTime();
        ((Calendar)localObject3).add(2, 1);
        ((Calendar)localObject3).add(5, -1);
        localDate2 = DateUtil.setEndDay((Calendar)localObject3).getTime();
      }
      catch (Exception localException2)
      {
        this.logger.error(localException2.getMessage());
      }
    }
    else if ("week".equals(str))
    {
      localObject1 = localHttpServletRequest.getParameter("startweek");
      localObject2 = localHttpServletRequest.getParameter("endweek");
      try
      {
        localObject3 = DateUtils.parseDate((String)localObject1, new String[] { "MM/dd/yyyy" });
        localObject4 = DateUtils.parseDate((String)localObject2, new String[] { "MM/dd/yyyy" });
        localObject5 = Calendar.getInstance();
        ((Calendar)localObject5).setTime((Date)localObject3);
        localDate1 = DateUtil.setStartDay((Calendar)localObject5).getTime();
        ((Calendar)localObject5).setTime((Date)localObject4);
        localDate2 = DateUtil.setEndDay((Calendar)localObject5).getTime();
      }
      catch (Exception localException3)
      {
        this.logger.error(localException3.getMessage());
      }
    }
    else if ("period".equals(str))
    {
      localObject1 = localHttpServletRequest.getParameter("start");
      localObject2 = localHttpServletRequest.getParameter("end");
      try
      {
        Date localDate5 = DateUtils.parseDate((String)localObject1, new String[] { "MM/dd/yyyy" });
        localObject4 = DateUtils.parseDate((String)localObject2, new String[] { "MM/dd/yyyy" });
        localObject5 = Calendar.getInstance();
        ((Calendar)localObject5).setTime(localDate5);
        localDate1 = DateUtil.setStartDay((Calendar)localObject5).getTime();
        ((Calendar)localObject5).setTime((Date)localObject4);
        localDate2 = DateUtil.setEndDay((Calendar)localObject5).getTime();
      }
      catch (Exception localException4)
      {
        this.logger.info(localException4.getMessage());
      }
    }
    else
    {
      this.jsonString = "{success:false,errors:'there's enough arguments to generate data'}";
    }
    Object localObject1 = new StringBuffer();
    Object localObject2 = this.calendarPlanService.getByPeriod(ContextUtil.getCurrentUserId(), localDate1, localDate2);
    ((StringBuffer)localObject1).append("{success:true,totalCount:").append(((List)localObject2).size()).append(",records:[");
    Iterator localIterator = ((List)localObject2).iterator();
    while (localIterator.hasNext())
    {
      localObject4 = (CalendarPlan)localIterator.next();
      ((StringBuffer)localObject1).append("{id:'").append(((CalendarPlan)localObject4).getPlanId()).append("',");
      localObject5 = ((CalendarPlan)localObject4).getContent();
      if (((String)localObject5).length() > 12)
        localObject5 = ((String)localObject5).substring(1, 12) + "...";
      Date localDate6 = ((CalendarPlan)localObject4).getEndTime();
      if (localDate6 == null)
      {
        localObject6 = Calendar.getInstance();
        ((Calendar)localObject6).add(1, 50);
        localDate6 = ((Calendar)localObject6).getTime();
      }
      Object localObject6 = ((CalendarPlan)localObject4).getStartTime();
      if (this.start == null)
      {
        Calendar localCalendar = Calendar.getInstance();
        localObject6 = localCalendar.getTime();
      }
      ((StringBuffer)localObject1).append("subject:'").append(StringUtil.convertQuot((String)localObject5)).append("',");
      ((StringBuffer)localObject1).append("description:'").append(StringUtil.convertQuot(((CalendarPlan)localObject4).getContent())).append("',");
      ((StringBuffer)localObject1).append("startdate:'").append(DateUtil.formatEnDate((Date)localObject6)).append("',");
      ((StringBuffer)localObject1).append("enddate:'").append(DateUtil.formatEnDate(localDate6)).append("',");
      ((StringBuffer)localObject1).append("color:'").append(((CalendarPlan)localObject4).getColor()).append("',");
      ((StringBuffer)localObject1).append("parent:'0',");
      ((StringBuffer)localObject1).append("priority:'").append(((CalendarPlan)localObject4).getUrgent()).append("'},");
    }
    if (((List)localObject2).size() > 0)
      ((StringBuffer)localObject1).deleteCharAt(((StringBuffer)localObject1).length() - 1);
    ((StringBuffer)localObject1).append("]}");
    this.jsonString = ((StringBuffer)localObject1).toString();
    return (String)(String)(String)(String)(String)(String)"success";
  }

  public String save(CalendarPlan paramCalendarPlan)
  {
    String str = "更新任务失败";
    Object localObject;
    if (paramCalendarPlan.getPlanId().longValue() == 0L)
    {
      paramCalendarPlan.setPlanId(null);
      paramCalendarPlan.setStatus(CalendarPlan.STATUS_UNFINISHED);
      localObject = ContextUtil.getCurrentUser();
      paramCalendarPlan.setAssignerId(((AppUser)localObject).getUserId());
      paramCalendarPlan.setAssignerName(((AppUser)localObject).getFullname());
      paramCalendarPlan.setFullname(((AppUser)localObject).getFullname());
      paramCalendarPlan.setStatus(new Short("0"));
      paramCalendarPlan.setUserId(((AppUser)localObject).getUserId());
      paramCalendarPlan.setShowStyle(new Short("1"));
      this.calendarPlanService.save(paramCalendarPlan);
      str = "提交任务成功";
    }
    else
    {
      localObject = (CalendarPlan)this.calendarPlanService.get(paramCalendarPlan.getPlanId());
      try
      {
        ((CalendarPlan)localObject).setFeedback("");
        ((CalendarPlan)localObject).setStatus(paramCalendarPlan.getStatus());
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
      this.calendarPlanService.save(localObject);
      str = "完成任务成功";
    }
    return (String)str;
  }

  public String my(Object paramObject)
  {
    Map localMap = (Map)paramObject;
    String str1 = (String)localMap.get("mode");
    String str2 = (String)localMap.get("startDate");
    String str3 = (String)localMap.get("endDate");
    Date localDate1 = null;
    Date localDate2 = null;
    if ("month".equals(str1))
      try
      {
        Date localDate3 = DateUtils.parseDate(str2, new String[] { "MM/dd/yyyy" });
        localObject1 = Calendar.getInstance();
        ((Calendar)localObject1).setTime(localDate3);
        localDate1 = DateUtil.setStartDay((Calendar)localObject1).getTime();
        localDate3 = DateUtils.parseDate(str3, new String[] { "MM/dd/yyyy" });
        ((Calendar)localObject1).setTime(localDate3);
        localDate2 = DateUtil.setEndDay((Calendar)localObject1).getTime();
      }
      catch (Exception localException1)
      {
        this.logger.error(localException1.getMessage());
      }
    else if ("day".equals(str1))
      try
      {
        Date localDate4 = DateUtils.parseDate(str2, new String[] { "MM/dd/yyyy" });
        localObject1 = Calendar.getInstance();
        ((Calendar)localObject1).setTime(localDate4);
        localDate1 = DateUtil.setStartDay((Calendar)localObject1).getTime();
        ((Calendar)localObject1).add(2, 1);
        ((Calendar)localObject1).add(5, -1);
        localDate2 = DateUtil.setEndDay((Calendar)localObject1).getTime();
      }
      catch (Exception localException2)
      {
        this.logger.error(localException2.getMessage());
      }
    else if ("week".equals(str1))
      try
      {
        Date localDate5 = DateUtils.parseDate(str2, new String[] { "MM/dd/yyyy" });
        localObject1 = DateUtils.parseDate(str3, new String[] { "MM/dd/yyyy" });
        localObject2 = Calendar.getInstance();
        ((Calendar)localObject2).setTime(localDate5);
        localDate1 = DateUtil.setStartDay((Calendar)localObject2).getTime();
        ((Calendar)localObject2).setTime((Date)localObject1);
        localDate2 = DateUtil.setEndDay((Calendar)localObject2).getTime();
      }
      catch (Exception localException3)
      {
        this.logger.error(localException3.getMessage());
      }
    else if ("workweek".equals(str1))
      try
      {
        Date localDate6 = DateUtils.parseDate(str2, new String[] { "MM/dd/yyyy" });
        localObject1 = DateUtils.parseDate(str3, new String[] { "MM/dd/yyyy" });
        localObject2 = Calendar.getInstance();
        ((Calendar)localObject2).setTime(localDate6);
        localDate1 = DateUtil.setStartDay((Calendar)localObject2).getTime();
        ((Calendar)localObject2).setTime((Date)localObject1);
        localDate2 = DateUtil.setEndDay((Calendar)localObject2).getTime();
      }
      catch (Exception localException4)
      {
        this.logger.error(localException4.getMessage());
      }
    else
      this.jsonString = "{success:false,errors:'there's enough arguments to generate data'}";
    List localList = this.calendarPlanService.getByPeriod(ContextUtil.getCurrentUser().getUserId(), localDate1, localDate2);
    Object localObject1 = new StringBuffer();
    ((StringBuffer)localObject1).append("[");
    Object localObject2 = localList.iterator();
    while (((Iterator)localObject2).hasNext())
    {
      CalendarPlan localCalendarPlan = (CalendarPlan)((Iterator)localObject2).next();
      ((StringBuffer)localObject1).append("{\"id\":\"").append(localCalendarPlan.getPlanId()).append("\",");
      Date localDate7 = localCalendarPlan.getEndTime();
      if (localDate7 == null)
      {
        localObject3 = Calendar.getInstance();
        ((Calendar)localObject3).add(1, 50);
        localDate7 = ((Calendar)localObject3).getTime();
      }
      Object localObject3 = localCalendarPlan.getStartTime();
      if (this.start == null)
      {
        Calendar localCalendar = Calendar.getInstance();
        localObject3 = localCalendar.getTime();
      }
      ((StringBuffer)localObject1).append("\"taskType\":\"").append(localCalendarPlan.getTaskType()).append("\",");
      ((StringBuffer)localObject1).append("\"startTime\":\"").append(DateUtil.formatEnDate((Date)localObject3)).append("\",");
      ((StringBuffer)localObject1).append("\"endTime\":\"").append(DateUtil.formatEnDate(localDate7)).append("\",");
      ((StringBuffer)localObject1).append("\"summary\":\"").append(localCalendarPlan.getSummary()).append("\",");
      ((StringBuffer)localObject1).append("\"description\":\"").append(StringUtil.convertQuot(localCalendarPlan.getContent())).append("\",");
      ((StringBuffer)localObject1).append("\"status\":\"").append(localCalendarPlan.getStatus()).append("\",");
      ((StringBuffer)localObject1).append("\"urgent\":\"").append(localCalendarPlan.getUrgent()).append("\"},");
    }
    if (localList.size() > 0)
      ((StringBuffer)localObject1).deleteCharAt(((StringBuffer)localObject1).length() - 1);
    ((StringBuffer)localObject1).append("]");
    this.jsonString = ((StringBuffer)localObject1).toString();
    return (String)(String)(String)this.jsonString;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.task.CalendarPlanAction
 * JD-Core Version:    0.6.0
 */