package com.htsoft.oa.action.system;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.IndexDisplay;
import com.htsoft.oa.model.system.PanelItem;
import com.htsoft.oa.service.system.IndexDisplayService;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class IndexDisplayAction extends BaseAction
{

  @Resource
  private IndexDisplayService indexDisplayService;
  private IndexDisplay indexDisplay;
  private Long indexId;

  public Long getIndexId()
  {
    return this.indexId;
  }

  public void setIndexId(Long paramLong)
  {
    this.indexId = paramLong;
  }

  public IndexDisplay getIndexDisplay()
  {
    return this.indexDisplay;
  }

  public void setIndexDisplay(IndexDisplay paramIndexDisplay)
  {
    this.indexDisplay = paramIndexDisplay;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.indexDisplayService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.indexDisplayService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    IndexDisplay localIndexDisplay = (IndexDisplay)this.indexDisplayService.get(this.indexId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localIndexDisplay));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    String str = getRequest().getParameter("items");
    Gson localGson = new Gson();
    PanelItem[] arrayOfPanelItem = (PanelItem[])localGson.fromJson(str, [Lcom.htsoft.oa.model.system.PanelItem.class);
    AppUser localAppUser = ContextUtil.getCurrentUser();
    List localList = this.indexDisplayService.findByUser(localAppUser.getUserId());
    Object localObject1 = localList.iterator();
    while (((Iterator)localObject1).hasNext())
    {
      IndexDisplay localIndexDisplay1 = (IndexDisplay)((Iterator)localObject1).next();
      this.indexDisplayService.remove(localIndexDisplay1);
    }
    for (Object localObject2 : arrayOfPanelItem)
    {
      IndexDisplay localIndexDisplay2 = new IndexDisplay();
      localIndexDisplay2.setAppUser(localAppUser);
      localIndexDisplay2.setPortalId(localObject2.getPanelId());
      localIndexDisplay2.setColNum(Integer.valueOf(localObject2.getColumn()));
      localIndexDisplay2.setRowNum(Integer.valueOf(localObject2.getRow()));
      this.indexDisplayService.save(localIndexDisplay2);
    }
    setJsonString("{success:true}");
    return (String)"success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.IndexDisplayAction
 * JD-Core Version:    0.6.0
 */