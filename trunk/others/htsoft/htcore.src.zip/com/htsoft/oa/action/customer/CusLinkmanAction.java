package com.htsoft.oa.action.customer;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.customer.CusLinkman;
import com.htsoft.oa.model.customer.Customer;
import com.htsoft.oa.service.customer.CusLinkmanService;
import com.htsoft.oa.service.customer.CustomerService;
import flexjson.JSONSerializer;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class CusLinkmanAction extends BaseAction
{
  private Short isPrimary = Short.valueOf(1);

  @Resource
  private CusLinkmanService cusLinkmanService;

  @Resource
  private CustomerService customerService;
  private CusLinkman cusLinkman;
  private Long linkmanId;

  public Long getLinkmanId()
  {
    return this.linkmanId;
  }

  public void setLinkmanId(Long paramLong)
  {
    this.linkmanId = paramLong;
  }

  public CusLinkman getCusLinkman()
  {
    return this.cusLinkman;
  }

  public void setCusLinkman(CusLinkman paramCusLinkman)
  {
    this.cusLinkman = paramCusLinkman;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.cusLinkmanService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.cusLinkmanService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    CusLinkman localCusLinkman = (CusLinkman)this.cusLinkmanService.get(this.linkmanId);
    JSONSerializer localJSONSerializer = new JSONSerializer();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class", "custoemr.class" }).serialize(localCusLinkman));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    int i = 0;
    StringBuffer localStringBuffer = new StringBuffer("{");
    if (this.cusLinkman.getCustomerId() != null)
    {
      if (this.cusLinkman.getIsPrimary().shortValue() != 1)
        i = 1;
      else if (this.cusLinkmanService.checkMainCusLinkman(this.cusLinkman.getCustomerId(), this.cusLinkman.getLinkmanId()))
        i = 1;
      else
        localStringBuffer.append("msg:'该客户的主要联系人已存在,请保存为普通联系人!',");
    }
    else
      localStringBuffer.append("msg:'所属客户不能为空.',");
    if (i != 0)
    {
      this.cusLinkman.setCustomer((Customer)this.customerService.get(this.cusLinkman.getCustomerId()));
      this.cusLinkmanService.save(this.cusLinkman);
      localStringBuffer.append("success:true}");
    }
    else
    {
      localStringBuffer.append("failure:true}");
    }
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String find()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addSorted("isPrimary", "desc");
    List localList = this.cusLinkmanService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      CusLinkman localCusLinkman = (CusLinkman)localIterator.next();
      localStringBuffer.append("['" + localCusLinkman.getLinkmanId() + "','" + localCusLinkman.getFullname() + "'],");
    }
    if (localList.size() != 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.customer.CusLinkmanAction
 * JD-Core Version:    0.6.0
 */