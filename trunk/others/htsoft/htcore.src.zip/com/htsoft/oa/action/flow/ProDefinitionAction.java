package com.htsoft.oa.action.flow;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.jbpm.jpdl.Node;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.util.XmlUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.flow.FormDefMapping;
import com.htsoft.oa.model.flow.ProDefinition;
import com.htsoft.oa.model.flow.ProcessRun;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.GlobalType;
import com.htsoft.oa.service.bpm.ILog.factory.BpmFactory;
import com.htsoft.oa.service.flow.FormDefMappingService;
import com.htsoft.oa.service.flow.FormTemplateService;
import com.htsoft.oa.service.flow.JbpmService;
import com.htsoft.oa.service.flow.ProDefinitionService;
import com.htsoft.oa.service.flow.ProcessRunService;
import com.htsoft.oa.service.system.GlobalTypeService;
import flexjson.JSONSerializer;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.dom4j.Document;
import org.dom4j.Element;

public class ProDefinitionAction extends BaseAction
{

  @Resource
  private ProDefinitionService proDefinitionService;

  @Resource
  private GlobalTypeService globalTypeService;

  @Resource
  private JbpmService jbpmService;

  @Resource
  private FormDefMappingService formDefMappingService;

  @Resource
  private FormTemplateService formTemplateService;

  @Resource
  private ProcessRunService processRunService;
  private ProDefinition proDefinition;
  private Long defId;

  public Long getDefId()
  {
    return this.defId;
  }

  public void setDefId(Long paramLong)
  {
    this.defId = paramLong;
  }

  public ProDefinition getProDefinition()
  {
    return this.proDefinition;
  }

  public void setProDefinition(ProDefinition paramProDefinition)
  {
    this.proDefinition = paramProDefinition;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    String str = getRequest().getParameter("typeId");
    List localList = null;
    if ((StringUtils.isNotEmpty(str)) && (!"0".equals(str)))
    {
      localObject = (GlobalType)this.globalTypeService.get(new Long(str));
      localQueryFilter.addFilter("Q_proType.path_S_LK", ((GlobalType)localObject).getPath());
      localList = this.proDefinitionService.getAll(localQueryFilter);
    }
    else
    {
      localObject = ContextUtil.getCurrentUser();
      if (((AppUser)localObject).isSupperManage())
        localList = this.proDefinitionService.getAll(localQueryFilter);
      else
        localList = this.proDefinitionService.getByRights((AppUser)localObject, this.proDefinition, localQueryFilter);
    }
    Object localObject = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "createtime" }).exclude(new String[] { "defXml" });
    ((StringBuffer)localObject).append(localJSONSerializer.serialize(localList));
    ((StringBuffer)localObject).append("}");
    this.jsonString = ((StringBuffer)localObject).toString();
    return (String)"success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.jbpmService.doUnDeployProDefinition(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    if (this.defId != null)
    {
      this.proDefinition = ((ProDefinition)this.proDefinitionService.get(this.defId));
    }
    else
    {
      this.proDefinition = new ProDefinition();
      localObject1 = getRequest().getParameter("proTypeId");
      if (StringUtils.isNotEmpty((String)localObject1))
      {
        localObject2 = (GlobalType)this.globalTypeService.get(new Long((String)localObject1));
        this.proDefinition.setProType((GlobalType)localObject2);
      }
    }
    Object localObject1 = JsonUtil.getJSONSerializer(new String[] { "createtime" });
    Object localObject2 = new StringBuffer("{success:true,data:");
    ((StringBuffer)localObject2).append(((JSONSerializer)localObject1).serialize(this.proDefinition));
    ((StringBuffer)localObject2).append("}");
    setJsonString(((StringBuffer)localObject2).toString());
    return (String)(String)"success";
  }

  public String flexGet()
  {
    if (this.defId != null)
    {
      this.proDefinition = ((ProDefinition)this.proDefinitionService.get(this.defId));
    }
    else
    {
      this.proDefinition = new ProDefinition();
      localObject = getRequest().getParameter("proTypeId");
      if (StringUtils.isNotEmpty((String)localObject))
      {
        GlobalType localGlobalType = (GlobalType)this.globalTypeService.get(new Long((String)localObject));
        this.proDefinition.setProType(localGlobalType);
      }
    }
    Object localObject = new StringBuffer("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Result>");
    ((StringBuffer)localObject).append("<defId>" + this.proDefinition.getDefId() + "</defId>");
    ((StringBuffer)localObject).append("<drawDefXml>" + this.proDefinition.getDrawDefXml() + "</drawDefXml>");
    if (this.proDefinition.getProType() != null)
    {
      ((StringBuffer)localObject).append("<proTypeName>" + this.proDefinition.getProType().getTypeName() + "</proTypeName>");
      ((StringBuffer)localObject).append("<proTypeId>" + this.proDefinition.getProType().getProTypeId() + "</proTypeId>");
    }
    ((StringBuffer)localObject).append("<name>" + this.proDefinition.getName() + "</name>");
    ((StringBuffer)localObject).append("<processName>" + this.proDefinition.getProcessName() + "</processName>");
    ((StringBuffer)localObject).append("<status>" + this.proDefinition.getStatus() + "</status>");
    ((StringBuffer)localObject).append("<description>" + this.proDefinition.getDescription() + "</description>");
    ((StringBuffer)localObject).append("<newVersion>" + this.proDefinition.getNewVersion() + "</newVersion>");
    ((StringBuffer)localObject).append("</Result>");
    setJsonString(((StringBuffer)localObject).toString());
    return (String)"success";
  }

  public String flexDefSave()
  {
    this.logger.info("...eneter defSave......");
    boolean bool = Boolean.parseBoolean(getRequest().getParameter("deploy"));
    Object localObject;
    if ((this.proDefinition.getDrawDefXml() != null) && (!this.proDefinition.getDrawDefXml().equals("")))
    {
      localObject = convertFlexXmlToJbpmXml(this.proDefinition.getDrawDefXml(), this.proDefinition.getProcessName());
      this.proDefinition.setDefXml((String)localObject);
      this.logger.debug("解析的JBPM对应的xml文件：\n" + (String)localObject);
    }
    if (!this.proDefinitionService.checkNameByVo(this.proDefinition))
    {
      setJsonString("流程名称(系统中使用)已存在,请重新填写.");
      return "success";
    }
    if (!this.proDefinitionService.checkProcessNameByVo(this.proDefinition))
    {
      setJsonString("流程名称(定义中使用)已存在,请重新填写.");
      return "success";
    }
    if (bool)
    {
      save();
    }
    else
    {
      localObject = this.proDefinition.getProTypeId();
      if (localObject != null)
      {
        GlobalType localGlobalType = (GlobalType)this.globalTypeService.get((Serializable)localObject);
        this.proDefinition.setProType(localGlobalType);
      }
      this.proDefinition.setCreatetime(new Date());
      this.proDefinitionService.save(this.proDefinition);
      setJsonString("true");
    }
    return (String)"success";
  }

  public String defSave()
  {
    return custSave();
  }

  private String custSave()
  {
    this.logger.info("...eneter defSave......");
    boolean bool = Boolean.parseBoolean(getRequest().getParameter("deploy"));
    Object localObject;
    if ((this.proDefinition.getDrawDefXml() != null) && (!this.proDefinition.getDrawDefXml().equals("")))
    {
      localObject = convertFlexXmlToJbpmXml(this.proDefinition.getDrawDefXml(), this.proDefinition.getProcessName());
      this.proDefinition.setDefXml((String)localObject);
      this.logger.debug("解析的JBPM对应的xml文件：\n" + (String)localObject);
    }
    if (!this.proDefinitionService.checkNameByVo(this.proDefinition))
    {
      setJsonString("{success:false,msg:'流程名称(系统中使用)已存在,请重新填写.'}");
      return "success";
    }
    if (!this.proDefinitionService.checkProcessNameByVo(this.proDefinition))
    {
      setJsonString("{success:false,msg:'流程名称(定义中使用)已存在,请重新填写.'}");
      return "success";
    }
    if (bool)
    {
      save();
    }
    else
    {
      localObject = this.proDefinition.getProTypeId();
      if (localObject != null)
      {
        GlobalType localGlobalType = (GlobalType)this.globalTypeService.get((Serializable)localObject);
        this.proDefinition.setProType(localGlobalType);
      }
      this.proDefinition.setCreatetime(new Date());
      this.proDefinitionService.save(this.proDefinition);
      setJsonString("{success:true}");
    }
    return (String)"success";
  }

  private String convertFlexXmlToJbpmXml(String paramString1, String paramString2)
  {
    String str1 = "";
    if ((paramString1 != null) && (!paramString1.equals("")))
    {
      Document localDocument = XmlUtil.stringToDocument(paramString1);
      Element localElement1 = localDocument.getRootElement();
      BpmFactory localBpmFactory = new BpmFactory(localDocument);
      Iterator localIterator = localElement1.elements().iterator();
      String str2;
      for (str1 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?> \n <process name=\"" + paramString2 + "\" xmlns=\"http://jbpm.org/4.4/jpdl\">"; localIterator.hasNext(); str1 = str1 + str2)
      {
        Element localElement2 = (Element)localIterator.next();
        str2 = localBpmFactory.getInfo(localElement2, localElement2.getName());
      }
      str1 = str1 + "</process>";
    }
    return str1;
  }

  public String save()
  {
    Long localLong = this.proDefinition.getProTypeId();
    if (localLong != null)
    {
      localObject = (GlobalType)this.globalTypeService.get(localLong);
      this.proDefinition.setProType((GlobalType)localObject);
    }
    Object localObject = getRequest().getParameter("deploy");
    if (this.logger.isDebugEnabled())
      this.logger.debug("---deploy---" + (String)localObject);
    if (this.proDefinition.getDefId() != null)
    {
      ProDefinition localProDefinition = (ProDefinition)this.proDefinitionService.get(this.proDefinition.getDefId());
      try
      {
        BeanUtil.copyNotNullProperties(localProDefinition, this.proDefinition);
        if ("true".equals(localObject))
          this.jbpmService.saveOrUpdateDeploy(localProDefinition);
        else
          this.proDefinitionService.save(localProDefinition);
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    else
    {
      this.proDefinition.setCreatetime(new Date());
      if (this.logger.isDebugEnabled())
        this.logger.debug("---start deploy---");
      if ("true".equals(localObject))
        this.jbpmService.saveOrUpdateDeploy(this.proDefinition);
      else
        this.proDefinitionService.save(this.proDefinition);
    }
    setJsonString("{success:true}");
    return (String)"success";
  }

  public String formTemp()
  {
    StringBuffer localStringBuffer = new StringBuffer("{success:true");
    Short localShort = FormDefMapping.NOT_USE_TEMPLATE;
    ProDefinition localProDefinition = (ProDefinition)this.proDefinitionService.get(this.defId);
    if ((localProDefinition != null) && (localProDefinition.getDeployId() != null))
    {
      FormDefMapping localFormDefMapping = this.formDefMappingService.getByDeployId(localProDefinition.getDeployId());
      if (localFormDefMapping != null)
      {
        localShort = localFormDefMapping.getUseTemplate();
        localStringBuffer.append(",mappingId:").append(localFormDefMapping.getMappingId());
      }
    }
    localStringBuffer.append(",isUseTemplate:" + localShort + "}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String saveFm()
  {
    ProDefinition localProDefinition = (ProDefinition)this.proDefinitionService.get(this.defId);
    String str = getRequest().getParameter("useTemplate");
    if ((localProDefinition != null) && (localProDefinition.getDeployId() != null))
    {
      FormDefMapping localFormDefMapping = this.formDefMappingService.getByDeployId(localProDefinition.getDeployId());
      Short localShort = FormDefMapping.NOT_USE_TEMPLATE;
      if ("true".equals(str))
        localShort = FormDefMapping.USE_TEMPLATE;
      if (localFormDefMapping != null)
      {
        localFormDefMapping.setUseTemplate(localShort);
      }
      else
      {
        localFormDefMapping = new FormDefMapping();
        localFormDefMapping.setUseTemplate(localShort);
        localFormDefMapping.setDefId(localProDefinition.getDefId());
        localFormDefMapping.setDeployId(localProDefinition.getDeployId());
        localFormDefMapping.setVersionNo(localProDefinition.getNewVersion());
      }
      this.formDefMappingService.save(localFormDefMapping);
      if ("true".equals(str))
      {
        List localList1 = this.formTemplateService.getByMappingId(localFormDefMapping.getMappingId());
        if (localList1.size() == 0)
        {
          List localList2 = this.jbpmService.getFormNodesByDeployId(new Long(localProDefinition.getDeployId()));
          ArrayList localArrayList = new ArrayList();
          Iterator localIterator = localList2.iterator();
          while (localIterator.hasNext())
          {
            Node localNode = (Node)localIterator.next();
            localArrayList.add(localNode.getName());
          }
          this.formTemplateService.batchAddDefault(localArrayList, localFormDefMapping);
        }
      }
      setJsonString("{success:true,mappingId:" + localFormDefMapping.getMappingId() + "}");
    }
    return "success";
  }

  public String getDecision()
  {
    this.jsonString = "{success:true,data:{decisionExpr:''}}";
    return "success";
  }

  public String saveDecision()
  {
    this.jsonString = "{success:true}";
    return "success";
  }

  public String getFormMapping()
  {
    ProDefinition localProDefinition = (ProDefinition)this.proDefinitionService.get(this.defId);
    StringBuffer localStringBuffer = new StringBuffer();
    Short localShort = FormDefMapping.NOT_USE_TEMPLATE;
    if ((localProDefinition != null) && (localProDefinition.getDeployId() != null))
    {
      FormDefMapping localFormDefMapping = this.formDefMappingService.getByDeployId(localProDefinition.getDeployId());
      if (localFormDefMapping == null);
    }
    return "success";
  }

  public String update()
  {
    ProDefinition localProDefinition = (ProDefinition)this.proDefinitionService.get(this.proDefinition.getDefId());
    localProDefinition.setStatus(this.proDefinition.getStatus());
    this.proDefinitionService.save(localProDefinition);
    setJsonString("{success:true}");
    return "success";
  }

  public String checkRun()
  {
    boolean bool = this.processRunService.checkRun(this.defId).booleanValue();
    String str = "{success:true}";
    if (bool)
      str = "{failure:true,msg:'对不起，该流程正在运行不能设置，请谅解！'}";
    setJsonString(str);
    return "success";
  }

  public String inList()
  {
    PagingBean localPagingBean = getInitPagingBean();
    List localList = this.proDefinitionService.findRunningPro(this.proDefinition, ProcessRun.RUN_STATUS_RUNNING, localPagingBean);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localPagingBean.getTotalItems()).append(",result:[");
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      ProDefinition localProDefinition = (ProDefinition)localIterator.next();
      localStringBuffer.append("{defId:'").append(localProDefinition.getDefId()).append("',subTotal:").append(this.processRunService.countRunningProcess(localProDefinition.getDefId())).append(",typeName:'").append(localProDefinition.getProType() == null ? "" : localProDefinition.getProType().getTypeName()).append("',name:'").append(localProDefinition.getName()).append("',createtime:'").append(localSimpleDateFormat.format(localProDefinition.getCreatetime())).append("',deployId:'").append(localProDefinition.getDeployId()).append("',status:").append(localProDefinition.getStatus()).append("},");
    }
    if (localList.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.flow.ProDefinitionAction
 * JD-Core Version:    0.6.0
 */