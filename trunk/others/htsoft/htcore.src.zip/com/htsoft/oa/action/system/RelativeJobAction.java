package com.htsoft.oa.action.system;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.AppUtil;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.system.RelativeJob;
import com.htsoft.oa.service.system.RelativeJobService;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;

public class RelativeJobAction extends BaseAction
{

  @Resource
  private RelativeJobService relativeJobService;
  private RelativeJob relativeJob;
  private Long reJobId;

  public Long getReJobId()
  {
    return this.reJobId;
  }

  public void setReJobId(Long paramLong)
  {
    this.reJobId = paramLong;
  }

  public RelativeJob getRelativeJob()
  {
    return this.relativeJob;
  }

  public void setRelativeJob(RelativeJob paramRelativeJob)
  {
    this.relativeJob = paramRelativeJob;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.relativeJobService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String treeLoad()
  {
    StringBuffer localStringBuffer = new StringBuffer("");
    localStringBuffer.append("[{id:'0',text:'" + AppUtil.getCompanyName() + "',expanded:true,children:[");
    List localList = this.relativeJobService.findByParentId(new Long(0L));
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      RelativeJob localRelativeJob = (RelativeJob)localIterator.next();
      localStringBuffer.append("{id:'" + localRelativeJob.getReJobId() + "',text:'" + localRelativeJob.getJobName() + "',");
      localStringBuffer.append(findChildren(localRelativeJob.getReJobId()));
    }
    if (!localList.isEmpty())
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.relativeJobService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String delete()
  {
    this.relativeJobService.remove(this.reJobId);
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    RelativeJob localRelativeJob = (RelativeJob)this.relativeJobService.get(this.reJobId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:[");
    localStringBuffer.append(localGson.toJson(localRelativeJob));
    localStringBuffer.append("]}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    if (this.relativeJob.getReJobId() == null)
    {
      add();
    }
    else
    {
      RelativeJob localRelativeJob = (RelativeJob)this.relativeJobService.get(this.relativeJob.getReJobId());
      try
      {
        BeanUtil.copyNotNullProperties(localRelativeJob, this.relativeJob);
        this.relativeJobService.save(localRelativeJob);
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    setJsonString("{success:true}");
    return "success";
  }

  private String add()
  {
    int i = this.relativeJob.getParent().longValue() < 1L ? 1 : 0;
    if (i != 0)
    {
      this.relativeJob.setDepath(Integer.valueOf(2));
    }
    else
    {
      localObject = ((RelativeJob)this.relativeJobService.get(this.relativeJob.getParent())).getDepath();
      this.relativeJob.setDepath(Integer.valueOf(((Integer)localObject).intValue() + 1));
    }
    Object localObject = (RelativeJob)this.relativeJobService.save(this.relativeJob);
    if (i != 0)
    {
      ((RelativeJob)localObject).setPath("0." + ((RelativeJob)localObject).getReJobId() + ".");
    }
    else
    {
      String str = ((RelativeJob)this.relativeJobService.get(((RelativeJob)localObject).getParent())).getPath();
      ((RelativeJob)localObject).setPath(str + ((RelativeJob)localObject).getReJobId() + ".");
    }
    ((RelativeJob)localObject).setJobCode("0");
    this.relativeJobService.save(localObject);
    setJsonString("{success:true}");
    return (String)"success";
  }

  private String findChildren(Long paramLong)
  {
    StringBuffer localStringBuffer = new StringBuffer("");
    List localList = this.relativeJobService.findByParentId(paramLong);
    if ((localList.isEmpty()) || (localList.size() == 0))
    {
      localStringBuffer.append("leaf:true},");
      return localStringBuffer.toString();
    }
    localStringBuffer.append("children:[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      RelativeJob localRelativeJob = (RelativeJob)localIterator.next();
      localStringBuffer.append("{id:'" + localRelativeJob.getReJobId() + "',text:'" + localRelativeJob.getJobName() + "',");
      localStringBuffer.append(findChildren(localRelativeJob.getReJobId()));
    }
    localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]},");
    return localStringBuffer.toString();
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.RelativeJobAction
 * JD-Core Version:    0.6.0
 */