package com.htsoft.oa.action.admin;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.admin.BoardRoo;
import com.htsoft.oa.model.admin.BoardType;
import com.htsoft.oa.model.admin.Conference;
import com.htsoft.oa.service.admin.BoardRooService;
import com.htsoft.oa.service.admin.BoardTypeService;
import com.htsoft.oa.service.admin.ConferenceService;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class ConferenceAction extends BaseAction
{
  private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

  @Resource
  private ConferenceService conferenceService;

  @Resource
  private BoardRooService boardRooService;

  @Resource
  private BoardTypeService boardTypeService;
  private Long confId;
  private String filePath;
  private String checkReason;
  private String updater;
  private Conference conference;

  public String getUpdater()
  {
    return this.updater;
  }

  public void setUpdater(String paramString)
  {
    this.updater = paramString;
  }

  public String getFilePath()
  {
    return this.filePath;
  }

  public void setFilePath(String paramString)
  {
    this.filePath = paramString;
  }

  public Long getConfId()
  {
    return this.confId;
  }

  public void setConfId(Long paramLong)
  {
    this.confId = paramLong;
  }

  public Conference getConference()
  {
    return this.conference;
  }

  public void setConference(Conference paramConference)
  {
    this.conference = paramConference;
  }

  public String getCheckReason()
  {
    return this.checkReason;
  }

  public void setCheckReason(String paramString)
  {
    this.checkReason = paramString;
  }

  public String displayMyconf()
  {
    if (this.conference == null)
      this.conference = new Conference();
    this.conference.setStatus(Short.valueOf(1));
    PagingBean localPagingBean = getInitPagingBean();
    List localList = this.conferenceService.myJoin(this.conference, Boolean.valueOf(false), localPagingBean);
    for (int i = 0; i < localList.size(); i++)
    {
      if (i <= 7)
        continue;
      for (int j = 7; j < localList.size(); j++)
        localList.remove(j);
    }
    getRequest().setAttribute("myConferenceList", localList);
    return "display";
  }

  public String zanCun()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_status_SN_EQ", "0");
    return filter(localQueryFilter);
  }

  public String myJoin()
  {
    if (this.conference == null)
      this.conference = new Conference();
    this.conference.setStatus(Short.valueOf(1));
    PagingBean localPagingBean = getInitPagingBean();
    List localList = this.conferenceService.myJoin(this.conference, Boolean.valueOf(false), localPagingBean);
    return toJson(localPagingBean, localList);
  }

  public String myJoined()
  {
    if (this.conference == null)
      this.conference = new Conference();
    this.conference.setStatus(Short.valueOf(1));
    PagingBean localPagingBean = getInitPagingBean();
    List localList = this.conferenceService.myJoin(this.conference, Boolean.valueOf(true), localPagingBean);
    return toJson(localPagingBean, localList);
  }

  public String daiKai()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_startTime_D_GE", this.sdf.format(new Date()));
    localQueryFilter.addFilter("Q_status_SN_EQ", "1");
    return filter(localQueryFilter);
  }

  public String yiKai()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_endTime_D_LE", this.sdf.format(new Date()));
    localQueryFilter.addFilter("Q_status_SN_EQ", "1");
    return filter(localQueryFilter);
  }

  public String getConfTopic()
  {
    PagingBean localPagingBean = getInitPagingBean();
    String str = getRequest().getParameter("Q_confTopic_S_LK");
    List localList = this.conferenceService.getConfTopic(str, localPagingBean);
    return toJson(localPagingBean, localList);
  }

  public String send()
  {
    String str = this.conferenceService.judgeBoardRoomNotUse(this.conference.getStartTime(), this.conference.getEndTime(), this.conference.getRoomId());
    if (str.equalsIgnoreCase("success"))
      return customSave(Conference.Apply);
    setJsonString("{failure:true,msg:'" + str + "'}");
    return "success";
  }

  public String temp()
  {
    return customSave(Conference.TEMP);
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    return filter(localQueryFilter);
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.conferenceService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    Conference localConference = (Conference)this.conferenceService.get(this.confId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localConference));
    setJsonString(localStringBuffer.append("}").toString());
    return "success";
  }

  public String save()
  {
    this.conferenceService.save(this.conference);
    setJsonString("{success:true}");
    return "success";
  }

  public String getBoardroo()
  {
    List localList = this.boardRooService.getAll();
    StringBuffer localStringBuffer = new StringBuffer("[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      BoardRoo localBoardRoo = (BoardRoo)localIterator.next();
      localStringBuffer.append("['").append(localBoardRoo.getRoomId()).append("','").append(localBoardRoo.getRoomName()).append("'],");
    }
    localStringBuffer.deleteCharAt(localStringBuffer.length() - 1).append("]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String getTypeAll()
  {
    List localList = this.boardTypeService.getAll();
    StringBuffer localStringBuffer = new StringBuffer("[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      BoardType localBoardType = (BoardType)localIterator.next();
      localStringBuffer.append("['").append(localBoardType.getTypeId()).append("','").append(localBoardType.getTypeName()).append("'],");
    }
    localStringBuffer.deleteCharAt(localStringBuffer.length() - 1).append("]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String apply()
  {
    String str1 = "{success:true}";
    String str2 = getRequest().getParameter("status");
    boolean bool = (str2 != null) && (str2.equals("1"));
    if (bool)
    {
      String str3 = judgeBoardRoomUse();
      if (str3.equalsIgnoreCase("success"))
      {
        this.conferenceService.apply(this.confId, this.checkReason, bool);
      }
      else
      {
        Conference localConference = (Conference)this.conferenceService.get(this.confId);
        localConference.setStatus(Conference.UNAPPLY);
        localConference.setCheckReason("审核未通过," + str3);
        this.conferenceService.save(localConference);
        str1 = "{failure:true,msg:'" + str3 + "'}";
      }
    }
    else
    {
      this.conferenceService.apply(this.confId, this.checkReason, bool);
    }
    setJsonString(str1);
    return "success";
  }

  public String daiConfApply()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_checkUserId_L_EQ", ContextUtil.getCurrentUserId().toString());
    localQueryFilter.addFilter("Q_status_SN_EQ", "2");
    localQueryFilter.addSorted("createtime", "DESC");
    return filter(localQueryFilter);
  }

  public String unThrought()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_status_SN_EQ", "3");
    localQueryFilter.addSorted("createtime", "DESC");
    return filter(localQueryFilter);
  }

  public String displyApply()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_checkUserId_L_EQ", ContextUtil.getCurrentUserId().toString());
    localQueryFilter.addFilter("Q_status_SN_EQ", "2");
    localQueryFilter.addFilter("Q_startTime_D_GE", this.sdf.format(new Date()));
    localQueryFilter.addSorted("createtime", "DESC");
    List localList = this.conferenceService.getAll(localQueryFilter);
    if (localList.size() > 8)
      for (int i = 7; i < localList.size(); i++)
        localList.remove(i);
    getRequest().setAttribute("applyConferenceList", localList);
    return "displayApply";
  }

  private String toJson(PagingBean paramPagingBean, List<Conference> paramList)
  {
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(paramPagingBean.getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd hh:mm:ss").create();
    localStringBuffer.append(localGson.toJson(paramList, localType));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  private String filter(QueryFilter paramQueryFilter)
  {
    paramQueryFilter.addSorted("startTime", "DESC");
    List localList = this.conferenceService.getAll(paramQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(paramQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm").create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  private String customSave(Short paramShort)
  {
    if (this.conference.getIsEmail() == null)
      this.conference.setIsEmail(Conference.ISNOEMAIL);
    if (this.conference.getIsMobile() == null)
      this.conference.setIsMobile(Conference.ISNOMOBILE);
    this.conference.setStatus(paramShort);
    String str = this.conference.getCompere() + "," + this.conference.getRecorder() + "," + this.conference.getAttendUsers() + "," + ContextUtil.getCurrentUserId() + "," + this.conference.getCheckUserId();
    str = removeRepeatUserId(str);
    this.updater = (this.updater + "," + ContextUtil.getCurrentUserId());
    this.updater = removeRepeatUserId(this.updater);
    if (paramShort == Conference.Apply)
      this.conferenceService.send(this.conference, str, this.updater, this.conference.getRecorder(), this.filePath);
    else
      this.conferenceService.temp(this.conference, str, this.updater, this.conference.getRecorder(), this.filePath);
    setJsonString("{success:true}");
    return "success";
  }

  private String judgeBoardRoomUse()
  {
    Conference localConference = (Conference)this.conferenceService.get(this.confId);
    String str = this.conferenceService.judgeBoardRoomNotUse(localConference.getStartTime(), localConference.getEndTime(), localConference.getRoomId());
    return str;
  }

  private String removeRepeatUserId(String paramString)
  {
    String str1 = "";
    HashMap localHashMap = new HashMap();
    for (String str2 : paramString.split(","))
    {
      if (localHashMap.containsKey(str2))
        continue;
      localHashMap.put(str2, str2);
      str1 = str1 + str2 + ",";
    }
    str1 = str1.substring(0, str1.length() - 1);
    return str1;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.admin.ConferenceAction
 * JD-Core Version:    0.6.0
 */