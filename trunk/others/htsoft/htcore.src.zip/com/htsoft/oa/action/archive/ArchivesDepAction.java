package com.htsoft.oa.action.archive;

import com.google.gson.Gson;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.archive.ArchivesDep;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.Department;
import com.htsoft.oa.service.archive.ArchivesDepService;
import flexjson.JSONSerializer;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class ArchivesDepAction extends BaseAction
{

  @Resource
  private ArchivesDepService archivesDepService;
  private ArchivesDep archivesDep;
  private Long archDepId;

  public Long getArchDepId()
  {
    return this.archDepId;
  }

  public void setArchDepId(Long paramLong)
  {
    this.archDepId = paramLong;
  }

  public ArchivesDep getArchivesDep()
  {
    return this.archivesDep;
  }

  public void setArchivesDep(ArchivesDep paramArchivesDep)
  {
    this.archivesDep = paramArchivesDep;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    AppUser localAppUser = ContextUtil.getCurrentUser();
    localQueryFilter.addFilter("Q_department.depId_L_EQ", localAppUser.getDepartment().getDepId().toString());
    localQueryFilter.addFilter("Q_status_SN_EQ", ArchivesDep.STATUS_UNSIGNED.toString());
    List localList = this.archivesDepService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "archives.createtime" });
    localStringBuffer.append(localJSONSerializer.serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.archivesDepService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    ArchivesDep localArchivesDep = (ArchivesDep)this.archivesDepService.get(this.archDepId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localArchivesDep));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.archivesDepService.save(this.archivesDep);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.archive.ArchivesDepAction
 * JD-Core Version:    0.6.0
 */