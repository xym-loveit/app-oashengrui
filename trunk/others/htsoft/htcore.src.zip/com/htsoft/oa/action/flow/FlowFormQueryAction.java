package com.htsoft.oa.action.flow;

import com.google.gson.Gson;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.service.DynamicService;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.flow.FormField;
import com.htsoft.oa.model.flow.FormTable;
import com.htsoft.oa.service.flow.FormFieldService;
import com.htsoft.oa.service.flow.FormTableService;
import flexjson.JSONSerializer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;

public class FlowFormQueryAction extends BaseAction
{

  @Resource
  private FormTableService formTableService;
  private FormTable formTable;

  @Resource
  private FormFieldService formFieldService;
  private static final String packageStr = "com.htsoft.oa.entity.";
  private Long tableId;

  public Long getTableId()
  {
    return this.tableId;
  }

  public void setTableId(Long paramLong)
  {
    this.tableId = paramLong;
  }

  public FormTable getFormTable()
  {
    return this.formTable;
  }

  public void setFormTable(FormTable paramFormTable)
  {
    this.formTable = paramFormTable;
  }

  public String queryForms()
  {
    String str1 = getRequest().getParameter("typeId");
    String str2 = getRequest().getParameter("Q_tableName_S_LK");
    PagingBean localPagingBean = getInitPagingBean();
    String str3 = getRequest().getParameter("start");
    String str4 = getRequest().getParameter("limit");
    if ((str3 != null) && (!str3.equals("")))
      localPagingBean.setStart(Integer.valueOf(Integer.parseInt(str3)));
    if ((str4 != null) && (!str4.equals("")))
      localPagingBean.setPageSize(Integer.parseInt(str4));
    String str5 = getRequest().getParameter("sort");
    String str6 = getRequest().getParameter("dir");
    List localList = this.formTableService.getListFromPro(str1, str2, ContextUtil.getCurrentUser(), localPagingBean);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localPagingBean.getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localStringBuffer.append(localJSONSerializer.serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String queryEntity()
  {
    String str1 = getRequest().getParameter("tableKey");
    String str2 = "WF_" + str1;
    try
    {
      DynamicService localDynamicService = BeanUtil.getDynamicServiceBean(str2);
      QueryFilter localQueryFilter = new QueryFilter(getRequest());
      List localList = localDynamicService.getAll(localQueryFilter);
      StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
      localStringBuffer.append(JsonUtil.listEntity2Json(localList, str2));
      localStringBuffer.append("}");
      this.jsonString = localStringBuffer.toString();
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    this.logger.debug(this.jsonString);
    return "success";
  }

  public String fieldList()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.formFieldService.getAll(localQueryFilter);
    Iterator localIterator = localList.iterator();
    ArrayList localArrayList = new ArrayList();
    while (localIterator.hasNext())
    {
      localObject1 = (FormField)localIterator.next();
      if ((!StringUtils.isNotEmpty(((FormField)localObject1).getForeignTable())) || (!StringUtils.isNotEmpty(((FormField)localObject1).getForeignKey())))
      {
        localObject2 = new HashMap();
        ((Map)localObject2).put("fieldSize", ((FormField)localObject1).getFieldSize());
        ((Map)localObject2).put("showFormat", ((FormField)localObject1).getShowFormat());
        if (((FormField)localObject1).getFieldLabel() != null)
          ((Map)localObject2).put("fieldDscp", ((FormField)localObject1).getFieldLabel());
        else
          ((Map)localObject2).put("fieldDscp", ((FormField)localObject1).getFieldName());
        ((Map)localObject2).put("fieldType", ((FormField)localObject1).getFieldType().trim());
        ((Map)localObject2).put("isList", ((FormField)localObject1).getIsList());
        ((Map)localObject2).put("isQuery", ((FormField)localObject1).getIsQuery());
        String str = ((FormField)localObject1).getFieldName();
        ((Map)localObject2).put("property", str);
        localArrayList.add(localObject2);
      }
    }
    if ((localArrayList != null) && (localArrayList.size() > 0))
    {
      localObject1 = new HashMap();
      ((Map)localObject1).put("fieldDscp", "任务ID");
      ((Map)localObject1).put("fieldType", "bigint");
      ((Map)localObject1).put("isList", Integer.valueOf(1));
      ((Map)localObject1).put("isQuery", Integer.valueOf(0));
      ((Map)localObject1).put("property", "runId");
      localArrayList.add(localObject1);
    }
    Object localObject1 = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Object localObject2 = new Gson();
    ((StringBuffer)localObject1).append(((Gson)localObject2).toJson(localArrayList));
    ((StringBuffer)localObject1).append("}");
    this.jsonString = ((StringBuffer)localObject1).toString();
    return (String)(String)"success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.flow.FlowFormQueryAction
 * JD-Core Version:    0.6.0
 */