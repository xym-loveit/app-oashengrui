package com.htsoft.oa.action.admin;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.admin.DepreType;
import com.htsoft.oa.service.admin.DepreTypeService;
import com.htsoft.oa.service.admin.FixedAssetsService;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class DepreTypeAction extends BaseAction
{

  @Resource
  private DepreTypeService depreTypeService;
  private DepreType depreType;

  @Resource
  private FixedAssetsService fixedAssetsService;
  private Long depreTypeId;

  public Long getDepreTypeId()
  {
    return this.depreTypeId;
  }

  public void setDepreTypeId(Long paramLong)
  {
    this.depreTypeId = paramLong;
  }

  public DepreType getDepreType()
  {
    return this.depreType;
  }

  public void setDepreType(DepreType paramDepreType)
  {
    this.depreType = paramDepreType;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.depreTypeService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
      {
        QueryFilter localQueryFilter = new QueryFilter(getRequest());
        localQueryFilter.addFilter("Q_depreType.depreTypeId_L_EQ", str);
        List localList = this.fixedAssetsService.getAll(localQueryFilter);
        if (localList.size() > 0)
        {
          this.jsonString = "{success:false,message:'该折算类型下还有资产，请把该资产移走后，再进行删除！'}";
          return "success";
        }
        this.depreTypeService.remove(new Long(str));
      }
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    DepreType localDepreType = (DepreType)this.depreTypeService.get(this.depreTypeId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localDepreType));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.depreTypeService.save(this.depreType);
    setJsonString("{success:true}");
    return "success";
  }

  public String combox()
  {
    List localList = this.depreTypeService.getAll();
    StringBuffer localStringBuffer = new StringBuffer("[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      DepreType localDepreType = (DepreType)localIterator.next();
      localStringBuffer.append("['" + localDepreType.getDepreTypeId() + "','" + localDepreType.getTypeName() + "','" + localDepreType.getCalMethod() + "'],");
    }
    if (localList.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.admin.DepreTypeAction
 * JD-Core Version:    0.6.0
 */