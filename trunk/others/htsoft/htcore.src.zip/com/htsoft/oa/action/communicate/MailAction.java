package com.htsoft.oa.action.communicate;

import com.google.gson.Gson;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.util.StringUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.communicate.Mail;
import com.htsoft.oa.model.communicate.MailBox;
import com.htsoft.oa.model.communicate.MailFolder;
import com.htsoft.oa.model.info.ShortMessage;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.FileAttach;
import com.htsoft.oa.service.communicate.MailBoxService;
import com.htsoft.oa.service.communicate.MailFolderService;
import com.htsoft.oa.service.communicate.MailService;
import com.htsoft.oa.service.info.InMessageService;
import com.htsoft.oa.service.info.ShortMessageService;
import com.htsoft.oa.service.system.AppUserService;
import com.htsoft.oa.service.system.FileAttachService;
import flexjson.JSONSerializer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;

public class MailAction extends BaseAction
{
  static long FOLDER_ID_RECEIVE = 1L;
  static long FOLDER_ID_SEND = 2L;
  static long FOLDER_ID_DRAFT = 3L;
  static long FOLDER_ID_DELETE = 4L;
  static short HAVE_DELETE = 1;
  static short NOT_DELETE = 0;
  static short HAVE_READ = 1;
  static short NOT_READ = 0;
  static Short HAVE_REPLY = Short.valueOf(1);
  static short NOT_REPLY = 0;
  static short SYSTEM_MESSAGE = 4;
  static short COMMON = 1;
  static short IS_DRAFT = 0;
  static short IS_MAIL = 1;

  @Resource
  private MailService mailService;

  @Resource
  private FileAttachService fileAttachService;

  @Resource
  private AppUserService appUserService;

  @Resource
  private MailFolderService mailFolderService;

  @Resource
  private MailBoxService mailBoxService;

  @Resource
  private ShortMessageService shortMessageService;

  @Resource
  private InMessageService inMessageService;
  private Mail mail;
  private Long mailId;
  private AppUser appUser;
  private Long folderId;
  private Long boxId;
  private String sendMessage;
  private Long replyBoxId;
  private String boxIds;
  private Long fileId;

  public Long getMailId()
  {
    return this.mailId;
  }

  public void setMailId(Long paramLong)
  {
    this.mailId = paramLong;
  }

  public Mail getMail()
  {
    return this.mail;
  }

  public void setMail(Mail paramMail)
  {
    this.mail = paramMail;
  }

  public AppUser getAppUser()
  {
    return this.appUser;
  }

  public void setAppUser(AppUser paramAppUser)
  {
    this.appUser = paramAppUser;
  }

  public Long getFolderId()
  {
    if (this.folderId == null)
      return Long.valueOf(1L);
    return this.folderId;
  }

  public void setFolderId(Long paramLong)
  {
    this.folderId = paramLong;
  }

  public Long getBoxId()
  {
    return this.boxId;
  }

  public void setBoxId(Long paramLong)
  {
    this.boxId = paramLong;
  }

  public String getBoxIds()
  {
    return this.boxIds;
  }

  public void setBoxIds(String paramString)
  {
    this.boxIds = paramString;
  }

  public String getSendMessage()
  {
    return this.sendMessage;
  }

  public void setSendMessage(String paramString)
  {
    this.sendMessage = paramString;
  }

  public Long getReplyBoxId()
  {
    return this.replyBoxId;
  }

  public void setReplyBoxId(Long paramLong)
  {
    this.replyBoxId = paramLong;
  }

  public Long getFileId()
  {
    return this.fileId;
  }

  public void setFileId(Long paramLong)
  {
    this.fileId = paramLong;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    if ((this.folderId == null) || (this.folderId.longValue() == FOLDER_ID_RECEIVE))
      setFolderId(new Long(FOLDER_ID_RECEIVE));
    localQueryFilter.addFilter("Q_appUser.userId_L_EQ", ContextUtil.getCurrentUserId().toString());
    localQueryFilter.addFilter("Q_mailFolder.folderId_L_EQ", this.folderId.toString());
    if (this.folderId.longValue() != FOLDER_ID_DELETE)
      localQueryFilter.addFilter("Q_delFlag_SN_EQ", "0");
    localQueryFilter.addSorted("sendTime", "desc");
    List localList = this.mailBoxService.getAll(localQueryFilter);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      MailBox localMailBox = (MailBox)localIterator.next();
      Mail localMail = localMailBox.getMail();
      localStringBuffer.append("{boxId:'").append(localMailBox.getBoxId()).append("',sendTime:'").append(localMailBox.getSendTime()).append("',delFlag:'").append(localMailBox.getDelFlag()).append("',readFlag:'").append(localMailBox.getReadFlag()).append("',replyFlag:'").append(localMailBox.getReplyFlag()).append("',mailId:'").append(localMail.getMailId()).append("',importantFlag:'").append(localMail.getImportantFlag()).append("',mailStatus:'").append(localMail.getMailStatus()).append("',fileIds:'").append(localMail.getFileIds()).append("',subject:'").append(localGson.toJson(localMail.getSubject()).replace("\"", "")).append("',recipientNames:'").append(localMail.getRecipientNames()).append("',sender:'").append(localMail.getSender()).append("',content:'");
      String str = StringUtil.html2Text(localMail.getContent().replace("&nbsp;", ""));
      if (str.length() > 100)
        str = str.substring(0, 100) + "...";
      str = localGson.toJson(str).replace("\"", "");
      localStringBuffer.append(str);
      localStringBuffer.append("'},");
    }
    if (localList.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    MailFolder localMailFolder = (MailFolder)this.mailFolderService.get(Long.valueOf(FOLDER_ID_DELETE));
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
    {
      String str;
      if (getFolderId().longValue() == FOLDER_ID_DELETE)
        for (str : arrayOfString1)
          this.mailBoxService.remove(new Long(str));
      else
        for (str : arrayOfString1)
        {
          MailBox localMailBox = (MailBox)this.mailBoxService.get(new Long(str));
          localMailBox.setDelFlag(Short.valueOf(HAVE_DELETE));
          localMailBox.setMailFolder(localMailFolder);
          this.mailBoxService.save(localMailBox);
        }
    }
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    String str = getRequest().getParameter("opt");
    MailBox localMailBox = null;
    Object localObject1;
    Object localObject2;
    if ((str == null) || ("".equals(str)))
    {
      localMailBox = (MailBox)this.mailBoxService.get(this.boxId);
      getRequest().setAttribute("__haveNextMailFlag", "");
    }
    else
    {
      localObject1 = getRequest().getParameter("folderId");
      if ((localObject1 == null) || ("".equals(localObject1)))
        localObject1 = "1";
      localObject2 = new QueryFilter(getRequest());
      ((QueryFilter)localObject2).getPagingBean().setPageSize(1);
      List localList = null;
      ((QueryFilter)localObject2).addFilter("Q_appUser.userId_L_EQ", ContextUtil.getCurrentUserId().toString());
      ((QueryFilter)localObject2).addFilter("Q_delFlag_SN_EQ", "0");
      ((QueryFilter)localObject2).addFilter("Q_mailFolder.folderId_L_EQ", (String)localObject1);
      if (str.equals("_next"))
      {
        ((QueryFilter)localObject2).addFilter("Q_boxId_L_GT", this.boxId.toString());
        localList = this.mailBoxService.getAll((QueryFilter)localObject2);
        if (((QueryFilter)localObject2).getPagingBean().getStart().intValue() + 1 == ((QueryFilter)localObject2).getPagingBean().getTotalItems())
          getRequest().setAttribute("__haveNextMailFlag", "endNext");
      }
      else if (str.equals("_pre"))
      {
        ((QueryFilter)localObject2).addFilter("Q_boxId_L_LT", this.boxId.toString());
        ((QueryFilter)localObject2).addSorted("boxId", "desc");
        localList = this.mailBoxService.getAll((QueryFilter)localObject2);
        if (((QueryFilter)localObject2).getPagingBean().getStart().intValue() + 1 == ((QueryFilter)localObject2).getPagingBean().getTotalItems())
          getRequest().setAttribute("__haveNextMailFlag", "endPre");
      }
      if (localList.size() > 0)
        localMailBox = (MailBox)localList.get(0);
      else
        localMailBox = (MailBox)this.mailBoxService.get(this.boxId);
    }
    setMail(localMailBox.getMail());
    localMailBox.setReadFlag(Short.valueOf(HAVE_READ));
    this.mailBoxService.save(localMailBox);
    if (this.mail.getMailStatus().shortValue() != 1)
    {
      localObject1 = new JSONSerializer();
      localObject2 = new StringBuffer("{success:true,totalCounts:1,data:[");
      ((StringBuffer)localObject2).append(((JSONSerializer)localObject1).exclude(new String[] { "class", "mail.appUser", "appUser.department", "mailFolder.appUser" }).serialize(this.mail));
      ((StringBuffer)localObject2).append("]}");
      setJsonString(((StringBuffer)localObject2).toString());
      return "success";
    }
    getRequest().setAttribute("mail", this.mail);
    getRequest().setAttribute("boxId", localMailBox.getBoxId());
    getRequest().setAttribute("mailAttachs", this.mail.getMailAttachs());
    return (String)(String)"detail";
  }

  public String save()
  {
    Object localObject1;
    Object localObject2;
    if (this.mail.getMailStatus().shortValue() == IS_MAIL)
    {
      if (StringUtils.isEmpty(this.mail.getRecipientIDs()))
      {
        setJsonString("{failure:true,msg:'收件人不能为空!'}");
        return "success";
      }
      if (StringUtils.isEmpty(this.mail.getSubject()))
      {
        setJsonString("{failure:true,msg:'邮件主题不能为空!'}");
        return "success";
      }
      if (StringUtils.isEmpty(this.mail.getContent()))
      {
        setJsonString("{failure:true,msg:'邮件内容不能为空!'}");
        return "success";
      }
      if ((this.replyBoxId != null) && (!"".equals(this.replyBoxId)))
      {
        localObject1 = (MailBox)this.mailBoxService.get(this.replyBoxId);
        ((MailBox)localObject1).setReplyFlag(Short.valueOf(HAVE_READ));
        this.mailBoxService.save(localObject1);
      }
      localObject1 = (MailFolder)this.mailFolderService.get(Long.valueOf(FOLDER_ID_RECEIVE));
      localObject2 = (MailFolder)this.mailFolderService.get(Long.valueOf(FOLDER_ID_SEND));
      String[] arrayOfString1 = this.mail.getRecipientIDs().split(",");
      String[] arrayOfString2 = this.mail.getCopyToIDs().split(",");
      Object localObject3;
      Object localObject4;
      if (this.mail.getMailId() == null)
      {
        SaveMail();
        localObject3 = new MailBox();
        ((MailBox)localObject3).setMail(this.mail);
        ((MailBox)localObject3).setMailFolder((MailFolder)localObject2);
        ((MailBox)localObject3).setAppUser(ContextUtil.getCurrentUser());
        ((MailBox)localObject3).setSendTime(this.mail.getSendTime());
        ((MailBox)localObject3).setDelFlag(Short.valueOf(NOT_DELETE));
        ((MailBox)localObject3).setReadFlag(Short.valueOf(NOT_READ));
        ((MailBox)localObject3).setNote("已发送的邮件");
        ((MailBox)localObject3).setReplyFlag(Short.valueOf(NOT_REPLY));
        this.mailBoxService.save(localObject3);
      }
      else
      {
        localObject3 = (Mail)this.mailService.get(this.mail.getMailId());
        try
        {
          BeanUtil.copyNotNullProperties(localObject3, this.mail);
          HashSet localHashSet = new HashSet();
          ((Mail)localObject3).setSendTime(new Date());
          String[] arrayOfString3 = this.mail.getFileIds().split(",");
          for (String str : arrayOfString3)
          {
            if (str.equals(""))
              continue;
            localHashSet.add(this.fileAttachService.get(new Long(str)));
          }
          ((Mail)localObject3).setMailAttachs(localHashSet);
          setMail((Mail)localObject3);
          this.mailService.save(localObject3);
        }
        catch (Exception localException)
        {
          this.logger.error(localException.getMessage());
        }
        localObject4 = (MailBox)this.mailBoxService.get(this.boxId);
        ((MailBox)localObject4).setMailFolder((MailFolder)localObject2);
        ((MailBox)localObject4).setNote("已发送的邮件");
        this.mailBoxService.save(localObject4);
      }
      if ((this.sendMessage != null) && (this.sendMessage.equals("on")))
      {
        localObject3 = new StringBuffer("<font color=\"green\">");
        localObject4 = new SimpleDateFormat("yyyy-MM-dd");
        ((StringBuffer)localObject3).append(this.mail.getSender()).append("</font>").append("在<font color=\"red\">").append(((SimpleDateFormat)localObject4).format(this.mail.getSendTime())).append("</font>").append("给您发了一封邮件，请注意查收。");
        this.shortMessageService.save(AppUser.SYSTEM_USER, this.mail.getRecipientIDs(), ((StringBuffer)localObject3).toString(), ShortMessage.MSG_TYPE_SYS);
      }
      MailBox localMailBox;
      for (??? : arrayOfString1)
      {
        if ("".equals(???))
          continue;
        localMailBox = new MailBox();
        localMailBox.setMail(this.mail);
        localMailBox.setMailFolder((MailFolder)localObject1);
        localMailBox.setAppUser((AppUser)this.appUserService.get(new Long(???)));
        localMailBox.setSendTime(this.mail.getSendTime());
        localMailBox.setDelFlag(Short.valueOf(NOT_DELETE));
        localMailBox.setReadFlag(Short.valueOf(NOT_READ));
        localMailBox.setNote("发送出去的邮件");
        localMailBox.setReplyFlag(Short.valueOf(NOT_REPLY));
        this.mailBoxService.save(localMailBox);
      }
      for (??? : arrayOfString2)
      {
        if ("".equals(???))
          continue;
        localMailBox = new MailBox();
        localMailBox.setMail(this.mail);
        localMailBox.setMailFolder((MailFolder)localObject1);
        localMailBox.setAppUser((AppUser)this.appUserService.get(new Long(???)));
        localMailBox.setSendTime(this.mail.getSendTime());
        localMailBox.setDelFlag(Short.valueOf(NOT_DELETE));
        localMailBox.setReadFlag(Short.valueOf(NOT_READ));
        localMailBox.setNote("抄送出去的邮件");
        localMailBox.setReplyFlag(Short.valueOf(NOT_REPLY));
        this.mailBoxService.save(localMailBox);
      }
    }
    else
    {
      if (StringUtils.isEmpty(this.mail.getSubject()))
      {
        setJsonString("{failure:true,msg:'邮件主题不能为空!'}");
        return "success";
      }
      SaveMail();
      localObject1 = (MailFolder)this.mailFolderService.get(Long.valueOf(FOLDER_ID_DRAFT));
      localObject2 = new MailBox();
      ((MailBox)localObject2).setMail(this.mail);
      ((MailBox)localObject2).setMailFolder((MailFolder)localObject1);
      ((MailBox)localObject2).setAppUser(ContextUtil.getCurrentUser());
      ((MailBox)localObject2).setSendTime(this.mail.getSendTime());
      ((MailBox)localObject2).setDelFlag(Short.valueOf(NOT_DELETE));
      ((MailBox)localObject2).setReadFlag(Short.valueOf(NOT_READ));
      ((MailBox)localObject2).setNote("存草稿");
      ((MailBox)localObject2).setReplyFlag(Short.valueOf(NOT_REPLY));
      this.mailBoxService.save(localObject2);
    }
    setJsonString("{success:true}");
    return (String)(String)(String)(String)"success";
  }

  public void SaveMail()
  {
    HashSet localHashSet = new HashSet();
    setAppUser(ContextUtil.getCurrentUser());
    this.mail.setAppSender(this.appUser);
    this.mail.setSendTime(new Date());
    this.mail.setSender(this.appUser.getFullname());
    String[] arrayOfString1 = this.mail.getFileIds().split(",");
    for (String str : arrayOfString1)
    {
      if (str.equals(""))
        continue;
      localHashSet.add(this.fileAttachService.get(new Long(str)));
    }
    this.mail.setMailAttachs(localHashSet);
    this.mailService.save(this.mail);
  }

  public String opt()
  {
    setMail((Mail)this.mailService.get(this.mailId));
    String str1 = getRequest().getParameter("opt");
    Mail localMail = new Mail();
    StringBuffer localStringBuffer1 = new StringBuffer("<br><br><br><br><br><br><br><hr>");
    localStringBuffer1.append("<br>----<strong>" + str1 + "邮件</strong>----");
    localStringBuffer1.append("<br><strong>发件人</strong>:" + this.mail.getSender());
    localStringBuffer1.append("<br><strong>发送时间</strong>:" + this.mail.getSendTime());
    localStringBuffer1.append("<br><strong>收件人</strong>:" + this.mail.getRecipientNames());
    String str2 = this.mail.getCopyToNames();
    if ((!"".equals(str2)) && (str2 != null))
      localStringBuffer1.append("<br><strong>抄送人</strong>:" + str2);
    localStringBuffer1.append("<br><strong>主题</strong>:" + this.mail.getSubject());
    localStringBuffer1.append("<br><strong>内容</strong>:<br><br>" + this.mail.getContent());
    localMail.setContent(localStringBuffer1.toString());
    localMail.setSubject(str1 + ":" + this.mail.getSubject());
    localMail.setImportantFlag(Short.valueOf(COMMON));
    if (str1.equals("回复"))
    {
      localObject = (MailBox)this.mailBoxService.get(this.boxId);
      ((MailBox)localObject).setReplyFlag(HAVE_REPLY);
      this.mailBoxService.save(localObject);
      localMail.setRecipientIDs("" + this.mail.getAppSender().getUserId());
      localMail.setRecipientNames(this.mail.getSender());
    }
    Object localObject = new JSONSerializer();
    StringBuffer localStringBuffer2 = new StringBuffer("{success:true,data:[");
    localStringBuffer2.append(((JSONSerializer)localObject).exclude(new String[] { "class", "appUser" }).serialize(localMail));
    localStringBuffer2.append("]}");
    setJsonString(localStringBuffer2.toString());
    return (String)"success";
  }

  public String move()
  {
    MailFolder localMailFolder = (MailFolder)this.mailFolderService.get(new Long(this.folderId.longValue()));
    String[] arrayOfString = this.boxIds.split(",");
    StringBuffer localStringBuffer = new StringBuffer("{");
    int i = 0;
    Object localObject1;
    if ((arrayOfString[0] != null) && (!"".equals(arrayOfString[0])))
    {
      localObject1 = ((MailBox)this.mailBoxService.get(new Long(arrayOfString[0]))).getMail();
      if (((Mail)localObject1).getMailStatus().shortValue() == IS_DRAFT)
      {
        if ((this.folderId.longValue() == FOLDER_ID_DRAFT) || (this.folderId.longValue() == FOLDER_ID_DELETE))
          i = 1;
        else
          localStringBuffer.append("msg:'草稿只能移至草稿箱或是垃圾箱(移至垃圾箱相当于删除,请注意!)'");
      }
      else if (((Mail)localObject1).getMailStatus().shortValue() == IS_MAIL)
        if (this.folderId.longValue() != FOLDER_ID_DRAFT)
          i = 1;
        else
          localStringBuffer.append("msg:'正式邮件不能移至草稿箱'");
    }
    if (i != 0)
    {
      for (Object localObject2 : arrayOfString)
      {
        if ("".equals(localObject2))
          continue;
        MailBox localMailBox = (MailBox)this.mailBoxService.get(new Long(localObject2));
        localMailBox.setMailFolder(localMailFolder);
        if (this.folderId.longValue() != FOLDER_ID_DELETE)
          localMailBox.setDelFlag(Short.valueOf(NOT_DELETE));
        else
          localMailBox.setDelFlag(Short.valueOf(HAVE_DELETE));
        this.mailBoxService.save(localMailBox);
      }
      localStringBuffer.append("success:true}");
      setJsonString(localStringBuffer.toString());
    }
    else
    {
      localStringBuffer.append(",failure:true}");
      setJsonString(localStringBuffer.toString());
    }
    return (String)"success";
  }

  public String attach()
  {
    String str1 = getRequest().getParameter("fileIds");
    String str2 = getRequest().getParameter("filenames");
    setMail((Mail)this.mailService.get(this.mailId));
    Set localSet = this.mail.getMailAttachs();
    FileAttach localFileAttach = (FileAttach)this.fileAttachService.get(this.fileId);
    localSet.remove(localFileAttach);
    this.mail.setMailAttachs(localSet);
    this.mail.setFileIds(str1);
    this.mail.setFilenames(str2);
    this.mailService.save(this.mail);
    this.fileAttachService.remove(this.fileId);
    return "success";
  }

  public String search()
  {
    PagingBean localPagingBean = getInitPagingBean();
    String str1 = getRequest().getParameter("searchContent");
    List localList = this.mailBoxService.findBySearch(str1, localPagingBean);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localList.size()).append(",result:[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      MailBox localMailBox = (MailBox)localIterator.next();
      Mail localMail = localMailBox.getMail();
      localStringBuffer.append("{boxId:'").append(localMailBox.getBoxId()).append("',sendTime:'").append(localMailBox.getSendTime()).append("',delFlag:'").append(localMailBox.getDelFlag()).append("',readFlag:'").append(localMailBox.getReadFlag()).append("',replyFlag:'").append(localMailBox.getReplyFlag()).append("',mailId:'").append(localMail.getMailId()).append("',importantFlag:'").append(localMail.getImportantFlag()).append("',mailStatus:'").append(localMail.getMailStatus()).append("',fileIds:'").append(localMail.getFileIds()).append("',subject:'").append(localGson.toJson(localMail.getSubject())).append("',recipientNames:'").append(localMail.getRecipientNames()).append("',sender:'").append(localMail.getSender()).append("',content:'");
      String str2 = StringUtil.html2Text(localMail.getContent().replace("&nbsp;", ""));
      str2 = localGson.toJson(str2);
      if (str2.length() > 100)
        str2 = str2.substring(0, 100) + "...";
      localStringBuffer.append(str2);
      localStringBuffer.append("'},");
    }
    if (localList.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String display()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_appUser.userId_L_EQ", ContextUtil.getCurrentUserId().toString());
    localQueryFilter.addFilter("Q_mailFolder.folderId_L_EQ", Long.toString(FOLDER_ID_RECEIVE));
    localQueryFilter.addFilter("Q_delFlag_SN_EQ", Short.toString(NOT_DELETE));
    localQueryFilter.addSorted("sendTime", "desc");
    localQueryFilter.addSorted("readFlag", "desc");
    List localList = this.mailBoxService.getAll(localQueryFilter);
    getRequest().setAttribute("mailBoxList", localList);
    return "display";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.communicate.MailAction
 * JD-Core Version:    0.6.0
 */