package com.htsoft.oa.action.flow;

import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.info.ShortMessage;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.flow.JbpmService;
import com.htsoft.oa.service.info.ShortMessageService;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.logging.Log;
import org.jbpm.api.task.Task;
import org.jbpm.pvm.internal.model.ExecutionImpl;
import org.jbpm.pvm.internal.task.TaskImpl;

public class TaskAction extends BaseAction
{

  @Resource(name="flowTaskService")
  private com.htsoft.oa.service.flow.TaskService flowTaskService;

  @Resource
  private org.jbpm.api.TaskService taskService;

  @Resource
  private ShortMessageService shortMessageService;

  @Resource
  private JbpmService jbpmService;

  public String all()
  {
    String str = getRequest().getParameter("taskName");
    PagingBean localPagingBean = new PagingBean(this.start.intValue(), this.limit.intValue());
    List localList = this.flowTaskService.getAllTaskInfos(str, localPagingBean);
    setJsonString(gsonFormat(localList, localPagingBean.getTotalItems()));
    return "success";
  }

  public String users()
  {
    String str1 = getRequest().getParameter("taskId");
    String str2 = getRequest().getParameter("activityName");
    Set localSet = this.jbpmService.getNodeHandlerUsers(str1, str2);
    StringBuffer localStringBuffer1 = new StringBuffer();
    StringBuffer localStringBuffer2 = new StringBuffer();
    Iterator localIterator = localSet.iterator();
    for (int i = 0; localIterator.hasNext(); i++)
    {
      AppUser localAppUser = (AppUser)localIterator.next();
      if (i > 0)
      {
        localStringBuffer1.append(",");
        localStringBuffer2.append(",");
      }
      localStringBuffer1.append(localAppUser.getUserId());
      localStringBuffer2.append(localAppUser.getFullname());
    }
    this.jsonString = ("{success:true,userIds:'" + localStringBuffer1.toString() + "',userNames:'" + localStringBuffer2.toString() + "'}");
    return "success";
  }

  public String due()
  {
    String str1 = getRequest().getParameter("taskIds");
    String str2 = getRequest().getParameter("dueDate");
    if (this.logger.isDebugEnabled())
      this.logger.debug("taskIds:" + str1 + " dueDate:" + str2);
    if (StringUtils.isNotEmpty(str1))
    {
      String[] arrayOfString1 = str1.split("[,]");
      try
      {
        Date localDate = DateUtils.parseDate(str2, new String[] { "yyyy-MM-dd HH:mm:ss" });
        for (String str3 : arrayOfString1)
        {
          Task localTask = this.taskService.getTask(str3);
          localTask.setDuedate(localDate);
          this.taskService.saveTask(localTask);
        }
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    return "success";
  }

  public String handler()
  {
    String str1 = getRequest().getParameter("taskIds");
    String str2 = getRequest().getParameter("userId");
    if (this.logger.isDebugEnabled())
      this.logger.debug("taskIds:" + str1 + " userId:" + str2);
    if (StringUtils.isNotEmpty(str1))
    {
      String[] arrayOfString1 = str1.split("[,]");
      for (String str3 : arrayOfString1)
        this.taskService.assignTask(str3, str2);
    }
    return "success";
  }

  public String list()
  {
    PagingBean localPagingBean = new PagingBean(this.start.intValue(), this.limit.intValue());
    List localList = this.flowTaskService.getTaskInfosByUserId(ContextUtil.getCurrentUserId().toString(), localPagingBean);
    setJsonString(gsonFormat(localList, localPagingBean.getTotalItems()));
    return "success";
  }

  public String change()
  {
    HttpServletRequest localHttpServletRequest = getRequest();
    String str1 = localHttpServletRequest.getParameter("taskId");
    String str2 = localHttpServletRequest.getParameter("userId");
    String str3 = ContextUtil.getCurrentUserId().toString();
    Task localTask = this.taskService.getTask(str1);
    if ((localTask != null) && (str3.equals(localTask.getAssignee())))
    {
      this.taskService.assignTask(str1, str2);
      String str4 = localHttpServletRequest.getParameter("msg");
      if (StringUtils.isNotEmpty(str4))
        this.shortMessageService.save(AppUser.SYSTEM_USER, str2, str4, ShortMessage.MSG_TYPE_TASK);
    }
    setJsonString("{success:true}");
    return "success";
  }

  public String unlock()
  {
    String str1 = getRequest().getParameter("taskId");
    Task localTask = this.taskService.getTask(str1);
    String str2 = ContextUtil.getCurrentUserId().toString();
    if ((localTask != null) && (str2.equals(localTask.getAssignee())))
    {
      this.taskService.assignTask(localTask.getId(), null);
      setJsonString("{success:true,unlocked:true}");
    }
    else
    {
      setJsonString("{success:true,unlocked:false}");
    }
    return "success";
  }

  public String lock()
  {
    String str = getRequest().getParameter("taskId");
    Task localTask = this.taskService.getTask(str);
    if ((localTask != null) && (localTask.getAssignee() == null))
    {
      this.taskService.assignTask(localTask.getId(), ContextUtil.getCurrentUserId().toString());
      setJsonString("{success:true,hasAssigned:false}");
    }
    else
    {
      setJsonString("{success:true,hasAssigned:true}");
    }
    return "success";
  }

  public String display()
  {
    PagingBean localPagingBean = new PagingBean(0, 8);
    List localList = this.flowTaskService.getTaskInfosByUserId(ContextUtil.getCurrentUserId().toString(), localPagingBean);
    getRequest().setAttribute("taskList", localList);
    return "display";
  }

  public String check()
  {
    String str1 = getRequest().getParameter("taskId");
    TaskImpl localTaskImpl = (TaskImpl)this.taskService.getTask(str1);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,isSubFlow:");
    boolean bool = false;
    if ((localTaskImpl != null) && (localTaskImpl.getExecution() != null) && (localTaskImpl.getExecution().getSuperProcessExecution() != null))
      bool = true;
    localStringBuffer.append(bool);
    String str2 = ContextUtil.getCurrentUserId().toString();
    if ((localTaskImpl == null) || (localTaskImpl.getAssignee() == null) || (!localTaskImpl.getAssignee().equals(str2)))
      if ((localTaskImpl != null) && (localTaskImpl.getAssignee() == null))
      {
        this.taskService.assignTask(localTaskImpl.getId(), str2);
        localStringBuffer.append(",assigned:true");
      }
      else
      {
        localStringBuffer.append(",assigned:false");
      }
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.flow.TaskAction
 * JD-Core Version:    0.6.0
 */