package com.htsoft.oa.action.arch;

import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.arch.ArchFond;
import com.htsoft.oa.model.arch.ArchRoll;
import com.htsoft.oa.model.arch.BorrowFileList;
import com.htsoft.oa.model.arch.BorrowRecord;
import com.htsoft.oa.model.arch.RollFile;
import com.htsoft.oa.model.arch.RollFileList;
import com.htsoft.oa.model.system.FileAttach;
import com.htsoft.oa.service.arch.ArchFondService;
import com.htsoft.oa.service.arch.ArchRollService;
import com.htsoft.oa.service.arch.BorrowFileListService;
import com.htsoft.oa.service.arch.BorrowRecordService;
import com.htsoft.oa.service.arch.RollFileListService;
import com.htsoft.oa.service.arch.RollFileService;
import com.htsoft.oa.service.system.FileAttachService;
import flexjson.JSONSerializer;
import flexjson.transformer.DateTransformer;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;

public class ArchFondAction extends BaseAction
{

  @Resource
  private ArchFondService archFondService;

  @Resource
  private ArchRollService archRollService;

  @Resource
  private RollFileService rollFileService;

  @Resource
  private RollFileListService rollFileListService;

  @Resource
  private FileAttachService fileAttachService;

  @Resource
  private BorrowRecordService borrowRecordService;

  @Resource
  private BorrowFileListService borrowFileListService;
  private ArchFond archFond;
  private Long archFondId;

  public Long getArchFondId()
  {
    return this.archFondId;
  }

  public void setArchFondId(Long paramLong)
  {
    this.archFondId = paramLong;
  }

  public ArchFond getArchFond()
  {
    return this.archFond;
  }

  public void setArchFond(ArchFond paramArchFond)
  {
    this.archFond = paramArchFond;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.archFondService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localJSONSerializer.transform(new DateTransformer("yyyy-MM-dd"), new String[] { "createTime", "updateTime" });
    localStringBuffer.append(localJSONSerializer.serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String listRollTree()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.archRollService.getAll(localQueryFilter);
    if ((localList != null) && (localList.size() > 0))
    {
      ArchRoll localArchRoll1 = (ArchRoll)localList.get(0);
      StringBuffer localStringBuffer = new StringBuffer("[{id:'0',text:'" + localArchRoll1.getAfNo() + "',expanded:true,children:[");
      if (localList.size() > 0)
      {
        Iterator localIterator = localList.iterator();
        while (localIterator.hasNext())
        {
          ArchRoll localArchRoll2 = (ArchRoll)localIterator.next();
          localStringBuffer.append("{id:'" + localArchRoll2.getRollNo()).append("',text:'" + localArchRoll2.getRollNo()).append("',allowChildren:false,leaf :true},");
        }
        localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
      }
      localStringBuffer.append("]}]");
      this.jsonString = localStringBuffer.toString();
    }
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
      {
        this.archFond = ((ArchFond)this.archFondService.get(new Long(str)));
        Set localSet1 = this.archFond.getBorrowFileList();
        Iterator localIterator1 = localSet1.iterator();
        Object localObject3;
        while (localIterator1.hasNext())
        {
          localObject1 = (BorrowFileList)localIterator1.next();
          this.borrowFileListService.remove(localObject1);
          this.borrowFileListService.flush();
          localObject2 = ((BorrowFileList)localObject1).getBorrowRecord();
          localObject3 = ((BorrowRecord)localObject2).getBorrowFileLists();
          if ((localObject3 == null) || (((Set)localObject3).size() == 0))
            this.borrowRecordService.remove(localObject2);
        }
        Object localObject1 = this.archFond.getArchRolls();
        Object localObject2 = ((Set)localObject1).iterator();
        while (((Iterator)localObject2).hasNext())
        {
          localObject3 = (ArchRoll)((Iterator)localObject2).next();
          Set localSet2 = ((ArchRoll)localObject3).getBorrowFileList();
          Iterator localIterator2 = localSet2.iterator();
          Object localObject6;
          while (localIterator2.hasNext())
          {
            localObject4 = (BorrowFileList)localIterator2.next();
            this.borrowFileListService.remove(localObject4);
            this.borrowFileListService.flush();
            localObject5 = ((BorrowFileList)localObject4).getBorrowRecord();
            localObject6 = ((BorrowRecord)localObject5).getBorrowFileLists();
            if ((localObject6 == null) || (((Set)localObject6).size() == 0))
              this.borrowRecordService.remove(localObject5);
          }
          Object localObject4 = ((ArchRoll)localObject3).getRollFiles();
          Object localObject5 = ((Set)localObject4).iterator();
          while (((Iterator)localObject5).hasNext())
          {
            localObject6 = (RollFile)((Iterator)localObject5).next();
            Set localSet3 = ((RollFile)localObject6).getRollFileLists();
            Iterator localIterator3 = localSet3.iterator();
            while (localIterator3.hasNext())
            {
              localObject7 = (RollFileList)localIterator3.next();
              localObject8 = ((RollFileList)localObject7).getFileAttach();
              this.rollFileListService.remove(localObject7);
              this.rollFileListService.flush();
              this.fileAttachService.removeByPath(((FileAttach)localObject8).getFilePath());
            }
            Object localObject7 = ((RollFile)localObject6).getBorrowFileList();
            Object localObject8 = ((Set)localObject7).iterator();
            while (((Iterator)localObject8).hasNext())
            {
              BorrowFileList localBorrowFileList = (BorrowFileList)((Iterator)localObject8).next();
              this.borrowFileListService.remove(localBorrowFileList);
              this.borrowFileListService.flush();
              BorrowRecord localBorrowRecord = localBorrowFileList.getBorrowRecord();
              Set localSet4 = localBorrowRecord.getBorrowFileLists();
              if ((localSet4 == null) || (localSet4.size() == 0))
                this.borrowRecordService.remove(localBorrowRecord);
            }
            this.rollFileService.remove(localObject6);
            this.rollFileService.flush();
          }
          this.archRollService.remove(localObject3);
          this.archRollService.flush();
        }
        this.archFondService.remove(this.archFond);
        this.archFondService.flush();
      }
    this.jsonString = "{success:true}";
    return (String)(String)(String)(String)(String)(String)(String)(String)"success";
  }

  public String get()
  {
    ArchFond localArchFond = (ArchFond)this.archFondService.get(this.archFondId);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localJSONSerializer.transform(new DateTransformer("yyyy-MM-dd"), new String[] { "createTime", "updateTime" });
    localStringBuffer.append(localJSONSerializer.serialize(localArchFond));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    if (this.archFond.getArchFondId() == null)
    {
      this.archFondService.save(this.archFond);
    }
    else
    {
      ArchFond localArchFond = (ArchFond)this.archFondService.get(this.archFond.getArchFondId());
      try
      {
        Set localSet1 = localArchFond.getArchRolls();
        Set localSet2 = localArchFond.getBorrowFileList();
        BeanUtil.copyNotNullProperties(localArchFond, this.archFond);
        localArchFond.setArchRolls(localSet1);
        localArchFond.setBorrowFileList(localSet2);
        this.archFondService.save(localArchFond);
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.arch.ArchFondAction
 * JD-Core Version:    0.6.0
 */