package com.htsoft.oa.action.archive;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.archive.ArchivesDoc;
import com.htsoft.oa.model.archive.DocHistory;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.archive.ArchivesDocService;
import com.htsoft.oa.service.archive.DocHistoryService;
import com.htsoft.oa.service.system.FileAttachService;
import flexjson.JSONSerializer;
import java.lang.reflect.Type;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class ArchivesDocAction extends BaseAction
{

  @Resource
  private ArchivesDocService archivesDocService;

  @Resource
  private DocHistoryService docHistoryService;

  @Resource
  private FileAttachService fileAttachService;
  private ArchivesDoc archivesDoc;
  private Long docId;

  public Long getDocId()
  {
    return this.docId;
  }

  public void setDocId(Long paramLong)
  {
    this.docId = paramLong;
  }

  public ArchivesDoc getArchivesDoc()
  {
    return this.archivesDoc;
  }

  public void setArchivesDoc(ArchivesDoc paramArchivesDoc)
  {
    this.archivesDoc = paramArchivesDoc;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    String str = getRequest().getParameter("archivesId");
    if ((str != null) && (!"".equals(str)))
      localQueryFilter.addFilter("Q_archives.archivesId_L_EQ", str);
    List localList = this.archivesDocService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
      {
        if ((!StringUtils.isNotEmpty(str)) || ("0".equals(str)))
          continue;
        this.archivesDocService.remove(new Long(str));
      }
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    ArchivesDoc localArchivesDoc = (ArchivesDoc)this.archivesDocService.get(this.docId);
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localArchivesDoc));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    AppUser localAppUser = ContextUtil.getCurrentUser();
    if ((this.archivesDoc.getDocId() == null) || (this.archivesDoc.getDocId().longValue() == 0L))
    {
      this.archivesDoc.initUsers(localAppUser);
      this.archivesDoc.setDocStatus(Short.valueOf(ArchivesDoc.STATUS_MODIFY));
      this.archivesDoc.setUpdatetime(new Date());
      this.archivesDoc.setCreatetime(new Date());
      this.archivesDoc.setCurVersion(Integer.valueOf(ArchivesDoc.ORI_VERSION));
      this.archivesDoc.setFileAttach(this.fileAttachService.getByPath(this.archivesDoc.getDocPath()));
      this.archivesDocService.save(this.archivesDoc);
    }
    else
    {
      localObject = (ArchivesDoc)this.archivesDocService.get(this.archivesDoc.getDocId());
      this.archivesDoc.setCreatetime(((ArchivesDoc)localObject).getCreatetime());
      this.archivesDoc.setArchives(((ArchivesDoc)localObject).getArchives());
      this.archivesDoc.setCreatorId(((ArchivesDoc)localObject).getCreatorId());
      this.archivesDoc.setFileAttach(this.fileAttachService.getByPath(this.archivesDoc.getDocPath()));
      this.archivesDoc.setCreator(((ArchivesDoc)localObject).getCreator());
      this.archivesDoc.setDocStatus(Short.valueOf(ArchivesDoc.STATUS_MODIFY));
      this.archivesDoc.setUpdatetime(new Date());
      this.archivesDoc.setCurVersion(Integer.valueOf(((ArchivesDoc)localObject).getCurVersion().intValue() + 1));
      this.archivesDoc.setMender(localAppUser.getFullname());
      this.archivesDoc.setMenderId(localAppUser.getUserId());
      this.archivesDoc.setDocHistorys(((ArchivesDoc)localObject).getDocHistorys());
      this.archivesDoc.setFileAttach(this.fileAttachService.getByPath(this.archivesDoc.getDocPath()));
      this.archivesDocService.merge(this.archivesDoc);
    }
    Object localObject = new DocHistory();
    ((DocHistory)localObject).setArchivesDoc(this.archivesDoc);
    ((DocHistory)localObject).setFileAttach(this.fileAttachService.getByPath(this.archivesDoc.getDocPath()));
    ((DocHistory)localObject).setDocName(this.archivesDoc.getDocName());
    ((DocHistory)localObject).setPath(this.archivesDoc.getDocPath());
    ((DocHistory)localObject).setVersion(this.archivesDoc.getCurVersion());
    ((DocHistory)localObject).setUpdatetime(new Date());
    ((DocHistory)localObject).setMender(localAppUser.getFullname());
    this.docHistoryService.save(localObject);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class", "docHistorys" }).serialize(this.archivesDoc));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return (String)"success";
  }

  public String copy()
  {
    String str = getRequest().getParameter("historyId");
    DocHistory localDocHistory1 = (DocHistory)this.docHistoryService.get(new Long(str));
    DocHistory localDocHistory2 = new DocHistory();
    this.archivesDoc = localDocHistory1.getArchivesDoc();
    localDocHistory2.setDocName(localDocHistory1.getDocName());
    localDocHistory2.setFileAttach(localDocHistory1.getFileAttach());
    localDocHistory2.setMender(ContextUtil.getCurrentUser().getFullname());
    localDocHistory2.setPath(localDocHistory1.getPath());
    localDocHistory2.setUpdatetime(new Date());
    localDocHistory2.setVersion(Integer.valueOf(this.archivesDoc.getCurVersion().intValue() + 1));
    localDocHistory2.setArchivesDoc(this.archivesDoc);
    this.docHistoryService.save(localDocHistory2);
    this.archivesDoc.setCurVersion(localDocHistory2.getVersion());
    this.archivesDoc.setDocPath(localDocHistory2.getPath());
    this.archivesDoc.setFileAttach(localDocHistory2.getFileAttach());
    this.archivesDocService.save(this.archivesDoc);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class", "docHistorys" }).serialize(this.archivesDoc));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.archive.ArchivesDocAction
 * JD-Core Version:    0.6.0
 */