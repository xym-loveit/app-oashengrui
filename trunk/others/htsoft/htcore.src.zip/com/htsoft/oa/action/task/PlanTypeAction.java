package com.htsoft.oa.action.task;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.task.PlanType;
import com.htsoft.oa.service.task.PlanTypeService;
import com.htsoft.oa.service.task.WorkPlanService;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class PlanTypeAction extends BaseAction
{

  @Resource
  private PlanTypeService planTypeService;
  private PlanType planType;

  @Resource
  private WorkPlanService workPlanService;
  private Long typeId;

  public Long getTypeId()
  {
    return this.typeId;
  }

  public void setTypeId(Long paramLong)
  {
    this.typeId = paramLong;
  }

  public PlanType getPlanType()
  {
    return this.planType;
  }

  public void setPlanType(PlanType paramPlanType)
  {
    this.planType = paramPlanType;
  }

  public String combo()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    List localList = this.planTypeService.getAll();
    localStringBuffer.append("[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      PlanType localPlanType = (PlanType)localIterator.next();
      localStringBuffer.append("['").append(localPlanType.getTypeId()).append("','").append(localPlanType.getTypeName()).append("'],");
    }
    if (localList.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.planTypeService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new Gson();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
      {
        QueryFilter localQueryFilter = new QueryFilter(getRequest());
        localQueryFilter.addFilter("Q_planType.typeId_L_EQ", str);
        List localList = this.workPlanService.getAll(localQueryFilter);
        if (localList.size() > 0)
        {
          this.jsonString = "{success:false,message:'类型下还有计划，请移走该类型的计划任务后，再删除类型！'}";
          return "success";
        }
        this.planTypeService.remove(new Long(str));
      }
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    PlanType localPlanType = (PlanType)this.planTypeService.get(this.typeId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localPlanType));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.planTypeService.save(this.planType);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.task.PlanTypeAction
 * JD-Core Version:    0.6.0
 */