package com.htsoft.oa.action.hrm;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.AppUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.hrm.Job;
import com.htsoft.oa.service.hrm.JobService;
import flexjson.JSONSerializer;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class JobAction extends BaseAction
{

  @Resource
  private JobService jobService;
  private Job job;
  private Long jobId;

  public Long getJobId()
  {
    return this.jobId;
  }

  public void setJobId(Long paramLong)
  {
    this.jobId = paramLong;
  }

  public Job getJob()
  {
    return this.job;
  }

  public void setJob(Job paramJob)
  {
    this.job = paramJob;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.jobService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class", "department.appUser" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
      {
        Job localJob = (Job)this.jobService.get(new Long(str));
        localJob.setDelFlag(Short.valueOf(Job.DELFLAG_HAD));
        this.jobService.save(localJob);
      }
    this.jsonString = "{success:true}";
    return "success";
  }

  public String delete()
  {
    Job localJob = (Job)this.jobService.get(this.jobId);
    localJob.setDelFlag(Short.valueOf(Job.DELFLAG_HAD));
    this.jobService.save(localJob);
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    Job localJob = (Job)this.jobService.get(this.jobId);
    JSONSerializer localJSONSerializer = new JSONSerializer();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localJob));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.job.setDelFlag(Short.valueOf(Job.DELFLAG_NOT));
    this.jobService.save(this.job);
    setJsonString("{success:true}");
    return "success";
  }

  public String combo()
  {
    String str = getRequest().getParameter("depId");
    if (StringUtils.isNotEmpty(str))
    {
      List localList = this.jobService.findByDep(new Long(str));
      StringBuffer localStringBuffer = new StringBuffer("[");
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        Job localJob = (Job)localIterator.next();
        localStringBuffer.append("['").append(localJob.getJobId()).append("','").append(localJob.getJobName()).append("'],");
      }
      if (localList.size() > 0)
        localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
      localStringBuffer.append("]");
      setJsonString(localStringBuffer.toString());
    }
    else
    {
      setJsonString("{success:false}");
    }
    return "success";
  }

  public String recovery()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
      {
        Job localJob = (Job)this.jobService.get(new Long(str));
        localJob.setDelFlag(Short.valueOf(Job.DELFLAG_NOT));
        this.jobService.save(localJob);
      }
    this.jsonString = "{success:true}";
    return "success";
  }

  public String add()
  {
    this.job.setDelFlag(Short.valueOf(Job.DELFLAG_NOT));
    if ((this.job.getJobId() != null) && (this.job.getJobId().longValue() > 0L))
    {
      this.jobService.edit(this.job);
    }
    else
    {
      int i = this.job.getParentId().longValue() > 0L ? 1 : 0;
      if (i != 0)
      {
        localJob1 = (Job)this.jobService.get(this.job.getParentId());
        this.job.setDepth(Long.valueOf(localJob1.getDepth().longValue() + 1L));
      }
      else
      {
        this.job.setDepth(new Long(2L));
      }
      Job localJob1 = (Job)this.jobService.save(this.job);
      if (i != 0)
      {
        Job localJob2 = (Job)this.jobService.get(this.job.getParentId());
        localJob1.setPath(localJob2.getPath() + localJob1.getJobId() + ".");
      }
      else
      {
        localJob1.setPath("0." + localJob1.getJobId() + ".");
      }
      this.jobService.save(localJob1);
    }
    setJsonString("{success:true}");
    return "success";
  }

  public String treeLoad()
  {
    StringBuffer localStringBuffer = new StringBuffer("[{id:'0',text:'" + AppUtil.getCompanyName() + "',expanded:true,children:[");
    List localList = this.jobService.findByCondition(new Long(0L));
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Job localJob = (Job)localIterator.next();
      localStringBuffer.append("{id:'" + localJob.getJobId() + "',text:'" + localJob.getJobName() + "',");
      localStringBuffer.append(findChildren(localJob.getJobId()));
    }
    if (!localList.isEmpty())
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}]");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  private String findChildren(Long paramLong)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    List localList = this.jobService.findByCondition(paramLong);
    if ((localList.isEmpty()) || (localList.size() == 0))
    {
      localStringBuffer.append("leaf:true},");
      return localStringBuffer.toString();
    }
    localStringBuffer.append("expanded:true,children:[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Job localJob = (Job)localIterator.next();
      localStringBuffer.append("{id:'" + localJob.getJobId() + "',text:'" + localJob.getJobName() + "',");
      localStringBuffer.append(findChildren(localJob.getJobId()));
    }
    localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]},");
    return localStringBuffer.toString();
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.hrm.JobAction
 * JD-Core Version:    0.6.0
 */