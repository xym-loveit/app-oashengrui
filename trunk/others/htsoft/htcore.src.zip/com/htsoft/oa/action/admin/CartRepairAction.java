package com.htsoft.oa.action.admin;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.admin.CartRepair;
import com.htsoft.oa.service.admin.CartRepairService;
import flexjson.JSONSerializer;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class CartRepairAction extends BaseAction
{

  @Resource
  private CartRepairService cartRepairService;
  private CartRepair cartRepair;
  private Long repairId;

  public Long getRepairId()
  {
    return this.repairId;
  }

  public void setRepairId(Long paramLong)
  {
    this.repairId = paramLong;
  }

  public CartRepair getCartRepair()
  {
    return this.cartRepair;
  }

  public void setCartRepair(CartRepair paramCartRepair)
  {
    this.cartRepair = paramCartRepair;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.cartRepairService.getAll(localQueryFilter);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "repairDate" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.cartRepairService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    CartRepair localCartRepair = (CartRepair)this.cartRepairService.get(this.repairId);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    JSONSerializer localJSONSerializer = JsonUtil.getJSONSerializer(new String[] { "repairDate" });
    localStringBuffer.append(localJSONSerializer.exclude(new String[] { "class", "car.cartRepairs" }).serialize(localCartRepair));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.cartRepairService.save(this.cartRepair);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.admin.CartRepairAction
 * JD-Core Version:    0.6.0
 */