package com.htsoft.oa.action.system;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.Diary;
import com.htsoft.oa.service.system.AppUserService;
import com.htsoft.oa.service.system.DiaryService;
import flexjson.JSONSerializer;
import flexjson.transformer.DateTransformer;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class DiaryAction extends BaseAction
{

  @Resource
  private DiaryService diaryService;

  @Resource
  private AppUserService appUserService;
  private Diary diary;
  private Date from;
  private Date to;
  private Long diaryId;

  public Date getFrom()
  {
    return this.from;
  }

  public void setFrom(Date paramDate)
  {
    this.from = paramDate;
  }

  public Date getTo()
  {
    return this.to;
  }

  public void setTo(Date paramDate)
  {
    this.to = paramDate;
  }

  public Long getDiaryId()
  {
    return this.diaryId;
  }

  public void setDiaryId(Long paramLong)
  {
    this.diaryId = paramLong;
  }

  public Diary getDiary()
  {
    return this.diary;
  }

  public void setDiary(Diary paramDiary)
  {
    this.diary = paramDiary;
  }

  public String list()
  {
    AppUser localAppUser = ContextUtil.getCurrentUser();
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_appUser.userId_L_EQ", localAppUser.getId().toString());
    List localList = this.diaryService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").excludeFieldsWithoutExposeAnnotation().create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String subUser()
  {
    PagingBean localPagingBean = getInitPagingBean();
    String str = getRequest().getParameter("userId");
    StringBuffer localStringBuffer = new StringBuffer();
    if (StringUtils.isNotEmpty(str))
      localStringBuffer.append(str);
    List localList = this.appUserService.findRelativeUsersByUserId(ContextUtil.getCurrentUserId(), Short.valueOf(0));
    if (localList != null)
    {
      localObject1 = localList.iterator();
      while (((Iterator)localObject1).hasNext())
      {
        localObject2 = (AppUser)((Iterator)localObject1).next();
        localStringBuffer.append(((AppUser)localObject2).getUserId()).append(",");
      }
      if (localList.size() > 0)
        localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    }
    Object localObject1 = new ArrayList();
    Object localObject2 = new StringBuffer("{success:true,'totalCounts':");
    if (localStringBuffer.length() > 0)
    {
      localObject1 = this.diaryService.getSubDiary(localStringBuffer.toString(), localPagingBean);
      ((StringBuffer)localObject2).append(localPagingBean.getTotalItems());
    }
    else
    {
      ((StringBuffer)localObject2).append("0");
    }
    ((StringBuffer)localObject2).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localJSONSerializer.transform(new DateTransformer("yyyy-MM-dd"), new String[] { "dayTime" });
    ((StringBuffer)localObject2).append(localJSONSerializer.exclude(new String[] { "class" }).serialize(localObject1));
    ((StringBuffer)localObject2).append("}");
    this.jsonString = ((StringBuffer)localObject2).toString();
    return (String)(String)"success";
  }

  public String search()
  {
    AppUser localAppUser = ContextUtil.getCurrentUser();
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_appUser.userId_L_EQ", localAppUser.getId().toString());
    if (getRequest().getParameter("from") != "")
      localQueryFilter.addFilter("Q_dayTime_D_GE", getRequest().getParameter("from"));
    if (getRequest().getParameter("to") != "")
      localQueryFilter.addFilter("Q_dayTime_D_LE", getRequest().getParameter("to"));
    localQueryFilter.addFilter("Q_content_S_LK", this.diary.getContent());
    if (this.diary.getDiaryType() != null)
      localQueryFilter.addFilter("Q_diaryType_SN_EQ", this.diary.getDiaryType().toString());
    List localList = this.diaryService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.diaryService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    Diary localDiary = (Diary)this.diaryService.get(this.diaryId);
    Gson localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localDiary));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    AppUser localAppUser = ContextUtil.getCurrentUser();
    this.diary.setAppUser(localAppUser);
    this.diaryService.save(this.diary);
    setJsonString("{success:true}");
    return "success";
  }

  public String check()
  {
    String str = getRequest().getParameter("diaryId");
    if (StringUtils.isNotEmpty(str))
      this.diary = ((Diary)this.diaryService.get(new Long(str)));
    return "check";
  }

  public String display()
  {
    AppUser localAppUser = ContextUtil.getCurrentUser();
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_appUser.userId_L_EQ", localAppUser.getId().toString());
    localQueryFilter.addSorted("diaryId", "desc");
    List localList = this.diaryService.getAll(localQueryFilter);
    getRequest().setAttribute("diaryList", localList);
    return "display";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.DiaryAction
 * JD-Core Version:    0.6.0
 */