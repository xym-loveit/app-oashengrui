package com.htsoft.oa.action.arch;

import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.arch.RollFileList;
import com.htsoft.oa.model.system.FileAttach;
import com.htsoft.oa.service.arch.RollFileListService;
import com.htsoft.oa.service.system.FileAttachService;
import flexjson.JSONSerializer;
import flexjson.transformer.DateTransformer;
import java.lang.reflect.Type;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;

public class RollFileListAction extends BaseAction
{

  @Resource
  private RollFileListService rollFileListService;
  private RollFileList rollFileList;

  @Resource
  private FileAttachService fileAttachService;
  private Long listId;

  public Long getListId()
  {
    return this.listId;
  }

  public void setListId(Long paramLong)
  {
    this.listId = paramLong;
  }

  public RollFileList getRollFileList()
  {
    return this.rollFileList;
  }

  public void setRollFileList(RollFileList paramRollFileList)
  {
    this.rollFileList = paramRollFileList;
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    List localList = this.rollFileListService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localJSONSerializer.exclude(new String[] { "rollFile", "fileAttach.createTime" }).transform(new DateTransformer("yyyy-MM-dd"), new String[] { "fileAttach.createTime", "createTime" });
    localStringBuffer.append(localJSONSerializer.serialize(localList));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("listIds");
    Object localObject;
    if ((arrayOfString1 != null) && (arrayOfString1.length > 0))
      for (String str : arrayOfString1)
      {
        if ((str == null) || (str.equals("")))
          continue;
        this.rollFileList = ((RollFileList)this.rollFileListService.get(new Long(str)));
        localObject = this.rollFileList.getFileAttach();
        this.rollFileListService.remove(this.rollFileList);
        this.fileAttachService.removeByPath(((FileAttach)localObject).getFilePath());
      }
    ??? = getRequest().getParameterValues("fileIds");
    if ((??? != null) && (???.length > 0))
      for (localObject : ???)
      {
        if ((localObject == null) || (((String)localObject).equals("")))
          continue;
        FileAttach localFileAttach = (FileAttach)this.fileAttachService.get(new Long((String)localObject));
        this.fileAttachService.removeByPath(localFileAttach.getFilePath());
      }
    this.jsonString = "{success:true}";
    return (String)"success";
  }

  public String get()
  {
    RollFileList localRollFileList = (RollFileList)this.rollFileListService.get(this.listId);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localJSONSerializer.exclude(new String[] { "rollFile" }).transform(new DateTransformer("yyyy-MM-dd"), new String[] { "fileAttach.createtime" });
    localStringBuffer.append(localJSONSerializer.serialize(localRollFileList));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    if (this.rollFileList.getListId() == null)
    {
      this.rollFileListService.save(this.rollFileList);
    }
    else
    {
      RollFileList localRollFileList = (RollFileList)this.rollFileListService.get(this.rollFileList.getListId());
      try
      {
        BeanUtil.copyNotNullProperties(localRollFileList, this.rollFileList);
        this.rollFileListService.save(localRollFileList);
      }
      catch (Exception localException)
      {
        this.logger.error(localException.getMessage());
      }
    }
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.arch.RollFileListAction
 * JD-Core Version:    0.6.0
 */