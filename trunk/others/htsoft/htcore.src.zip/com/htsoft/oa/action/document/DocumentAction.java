package com.htsoft.oa.action.document;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.util.AppUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.document.DocFolder;
import com.htsoft.oa.model.document.Document;
import com.htsoft.oa.model.document.DocumentFile;
import com.htsoft.oa.model.system.AppRole;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.Department;
import com.htsoft.oa.model.system.FileAttach;
import com.htsoft.oa.service.document.DocFolderService;
import com.htsoft.oa.service.document.DocPrivilegeService;
import com.htsoft.oa.service.document.DocumentService;
import com.htsoft.oa.service.iText.HtmlContentToPdf;
import com.htsoft.oa.service.iText.PdfToSwf;
import com.htsoft.oa.service.system.FileAttachService;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.commons.lang.StringUtils;
import org.jfree.util.Log;

public class DocumentAction extends BaseAction
{

  @Resource
  private DocumentService documentService;

  @Resource
  private FileAttachService fileAttachService;

  @Resource
  private DocFolderService docFolderService;

  @Resource
  private DocPrivilegeService docPrivilegeService;
  private Long docId;
  private AppUser appUser;
  private Document document;
  private Date from;
  private Date to;

  public AppUser getAppUser()
  {
    return this.appUser;
  }

  public void setAppUser(AppUser paramAppUser)
  {
    this.appUser = paramAppUser;
  }

  public Date getFrom()
  {
    return this.from;
  }

  public void setFrom(Date paramDate)
  {
    this.from = paramDate;
  }

  public Date getTo()
  {
    return this.to;
  }

  public void setTo(Date paramDate)
  {
    this.to = paramDate;
  }

  public Long getDocId()
  {
    return this.docId;
  }

  public void setDocId(Long paramLong)
  {
    this.docId = paramLong;
  }

  public Document getDocument()
  {
    return this.document;
  }

  public void setDocument(Document paramDocument)
  {
    this.document = paramDocument;
  }

  public String share()
  {
    HttpServletRequest localHttpServletRequest = getRequest();
    String str1 = localHttpServletRequest.getParameter("sharedUserIds");
    String str2 = localHttpServletRequest.getParameter("sharedDepIds");
    String str3 = localHttpServletRequest.getParameter("sharedRoleIds");
    String str4 = localHttpServletRequest.getParameter("docId");
    String str5 = localHttpServletRequest.getParameter("sharedUserNames");
    String str6 = localHttpServletRequest.getParameter("sharedDepNames");
    String str7 = localHttpServletRequest.getParameter("sharedRoleNames");
    Document localDocument;
    if ((StringUtils.isNotEmpty(str1)) || (StringUtils.isNotEmpty(str2)) || (StringUtils.isNotEmpty(str3)))
    {
      localDocument = (Document)this.documentService.get(new Long(str4));
      localDocument.setSharedUserIds(str1);
      localDocument.setSharedRoleIds(str3);
      localDocument.setSharedDepIds(str2);
      localDocument.setSharedUserNames(str5);
      localDocument.setSharedDepNames(str6);
      localDocument.setSharedRoleNames(str7);
      localDocument.setIsShared(Document.SHARED);
      this.documentService.save(localDocument);
    }
    else
    {
      localDocument = (Document)this.documentService.get(new Long(str4));
      localDocument.setSharedUserIds("");
      localDocument.setSharedRoleIds("");
      localDocument.setSharedDepIds("");
      localDocument.setSharedUserNames("");
      localDocument.setSharedDepNames("");
      localDocument.setSharedRoleNames("");
      localDocument.setIsShared(Document.NOT_SHARED);
      this.documentService.save(localDocument);
    }
    this.jsonString = "{success:true}";
    return "success";
  }

  public String unshare()
  {
    HttpServletRequest localHttpServletRequest = getRequest();
    String str = localHttpServletRequest.getParameter("docId");
    if (StringUtils.isNotEmpty(str))
    {
      Document localDocument = (Document)this.documentService.get(new Long(str));
      localDocument.setSharedUserIds("");
      localDocument.setSharedRoleIds("");
      localDocument.setSharedDepIds("");
      localDocument.setSharedUserNames("");
      localDocument.setSharedDepNames("");
      localDocument.setSharedRoleNames("");
      localDocument.setIsShared(Document.NOT_SHARED);
      this.documentService.save(localDocument);
    }
    this.jsonString = "{success:true}";
    return "success";
  }

  public String shareList()
  {
    PagingBean localPagingBean = getInitPagingBean();
    AppUser localAppUser = ContextUtil.getCurrentUser();
    Set localSet = localAppUser.getRoles();
    Long localLong = null;
    if (!localAppUser.getUserId().equals(AppUser.SUPER_USER))
    {
      localObject = localAppUser.getDepartment();
      localLong = ((Department)localObject).getDepId();
    }
    Object localObject = localSet.iterator();
    ArrayList localArrayList = new ArrayList();
    while (((Iterator)localObject).hasNext())
      localArrayList.add(((AppRole)((Iterator)localObject).next()).getRoleId());
    List localList = this.documentService.findByIsShared(this.document, this.from, this.to, localAppUser.getUserId(), localArrayList, localLong, localPagingBean);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localPagingBean.getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return (String)"success";
  }

  public String list()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_docFolder.appUser.userId_L_EQ", ContextUtil.getCurrentUserId().toString());
    String str1 = getRequest().getParameter("folderId");
    String str2 = null;
    if ((StringUtils.isNotEmpty(str1)) && (!"0".equals(str1)))
      str2 = ((DocFolder)this.docFolderService.get(new Long(str1))).getPath();
    if (str2 != null)
      localQueryFilter.addFilter("Q_docFolder.path_S_LK", str2 + "%");
    List localList = this.documentService.getAll(localQueryFilter);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localQueryFilter.getPagingBean().getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String publicList()
  {
    PagingBean localPagingBean = getInitPagingBean();
    String str1 = getRequest().getParameter("folderId");
    String str2 = null;
    if (StringUtils.isNotEmpty(str1))
    {
      localObject = new Long(str1);
      if (((Long)localObject).longValue() > 0L)
        str2 = ((DocFolder)this.docFolderService.get(new Long(str1))).getPath();
    }
    Object localObject = this.documentService.findByPublic(str2, this.document, this.from, this.to, ContextUtil.getCurrentUser(), localPagingBean);
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localPagingBean.getTotalItems()).append(",result:");
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    localStringBuffer.append(localGson.toJson(localObject, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return (String)"success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.documentService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    Document localDocument = (Document)this.documentService.get(this.docId);
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localDocument));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    String str1 = "{success:true}";
    String str2 = getRequest().getParameter("fileIds");
    String str3 = getRequest().getParameter("folderId");
    this.document.setSharedDepIds(this.document.getSharedDepIds());
    this.document.setSharedRoleIds(this.document.getSharedRoleIds());
    this.document.setSharedUserIds(this.document.getSharedUserIds());
    Object localObject;
    if (StringUtils.isNotEmpty(str2))
    {
      this.document.getAttachFiles().clear();
      localObject = str2.split(",");
      for (int i = 0; i < localObject.length; i++)
      {
        FileAttach localFileAttach = (FileAttach)this.fileAttachService.get(new Long(localObject[i]));
        this.document.getAttachFiles().add(localFileAttach);
      }
    }
    if ((StringUtils.isNotEmpty(str3)) && (!"0".equals(str3)))
    {
      localObject = (DocFolder)this.docFolderService.get(new Long(str3));
      this.document.setDocFolder((DocFolder)localObject);
    }
    if (this.document.getDocId() == null)
    {
      localObject = ContextUtil.getCurrentUser();
      this.document.setAppUser((AppUser)localObject);
      this.document.setFullname(((AppUser)localObject).getFullname());
      this.document.setCreatetime(new Date());
      this.document.setUpdatetime(new Date());
      this.document.setIsShared(Document.NOT_SHARED);
      if (this.document.getAttachFiles().size() > 0)
        this.document.setHaveAttach(Document.HAVE_ATTACH);
      else
        this.document.setHaveAttach(Document.NOT_HAVE_ATTACH);
      this.documentService.save(this.document);
    }
    else
    {
      localObject = (Document)this.documentService.get(this.document.getDocId());
      ((Document)localObject).setUpdatetime(new Date());
      ((Document)localObject).setDocName(this.document.getDocName());
      ((Document)localObject).setContent(this.document.getContent());
      ((Document)localObject).setAuthor(this.document.getAuthor());
      ((Document)localObject).setKeywords(this.document.getKeywords());
      ((Document)localObject).setDocFolder(this.document.getDocFolder());
      ((Document)localObject).setAttachFiles(this.document.getAttachFiles());
      if (this.document.getAttachFiles().size() > 0)
        ((Document)localObject).setHaveAttach(Document.HAVE_ATTACH);
      else
        ((Document)localObject).setHaveAttach(Document.NOT_HAVE_ATTACH);
      Document localDocument = (Document)this.documentService.save(localObject);
      if (localDocument != null)
      {
        this.docId = localDocument.getDocId();
        str1 = toSwf();
      }
    }
    setJsonString(str1);
    return (String)"success";
  }

  public String detail()
  {
    String str = getRequest().getParameter("docId");
    if (StringUtils.isNotEmpty(str))
    {
      Long localLong = Long.valueOf(Long.parseLong(str));
      this.document = ((Document)this.documentService.get(localLong));
    }
    return "detail";
  }

  public String publicDetail()
  {
    String str = getRequest().getParameter("docId");
    if (StringUtils.isNotEmpty(str))
    {
      Long localLong = Long.valueOf(Long.parseLong(str));
      this.document = ((Document)this.documentService.get(localLong));
    }
    return "publicDetail";
  }

  public String right()
  {
    String str1 = getRequest().getParameter("docId");
    Integer localInteger1 = Integer.valueOf(0);
    Document localDocument = new Document();
    AppUser localAppUser = ContextUtil.getCurrentUser();
    if (StringUtils.isNotEmpty(str1))
    {
      localObject = new Long(str1);
      localInteger1 = this.docPrivilegeService.getRightsByDocument(localAppUser, (Long)localObject);
      localDocument = (Document)this.documentService.get((Serializable)localObject);
    }
    Object localObject = Integer.valueOf(0);
    Integer localInteger2 = Integer.valueOf(0);
    String str2 = Integer.toBinaryString(localInteger1.intValue());
    char[] arrayOfChar = str2.toCharArray();
    if ((arrayOfChar.length == 2) && (arrayOfChar[0] == '1'))
      localInteger2 = Integer.valueOf(1);
    if (arrayOfChar.length == 3)
    {
      if (arrayOfChar[0] == '1')
        localObject = Integer.valueOf(1);
      if (arrayOfChar[1] == '1')
        localInteger2 = Integer.valueOf(1);
    }
    setJsonString("{success:true,rightM:'" + localInteger2 + "',rightD:'" + localObject + "',docName:'" + localDocument.getDocName() + "'}");
    return (String)"success";
  }

  public String search()
  {
    PagingBean localPagingBean = getInitPagingBean();
    String str = getRequest().getParameter("content");
    AppUser localAppUser = ContextUtil.getCurrentUser();
    List localList = this.documentService.searchDocument(localAppUser, str, localPagingBean);
    Gson localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
    Type localType = new TypeToken()
    {
    }
    .getType();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(localPagingBean.getTotalItems()).append(",result:");
    localStringBuffer.append(localGson.toJson(localList, localType));
    localStringBuffer.append("}");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String display()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_docFolder.appUser.userId_L_EQ", ContextUtil.getCurrentUserId().toString());
    List localList = this.documentService.getAll(localQueryFilter);
    getRequest().setAttribute("documentList", localList);
    return "display";
  }

  public String saveOnline()
  {
    String str1 = getRequest().getParameter("documentFileId");
    if (StringUtils.isNotEmpty(str1))
    {
      String str2 = getRequest().getParameter("folderId");
      Object localObject;
      if ((StringUtils.isNotEmpty(str2)) && (!"0".equals(str2)))
      {
        localObject = (DocFolder)this.docFolderService.get(new Long(str2));
        this.document.setDocFolder((DocFolder)localObject);
      }
      if (this.document.getDocId() == null)
      {
        localObject = (FileAttach)this.fileAttachService.get(new Long(str1));
        this.document.getAttachFiles().add(localObject);
        this.document.setIsShared(Document.ONLINE_DOCUMENT);
        this.document.setAuthor(ContextUtil.getCurrentUser().getFullname());
        this.document.setFullname(ContextUtil.getCurrentUser().getFullname());
        this.document.setCreatetime(new Date());
        this.document.setUpdatetime(new Date());
        this.documentService.save(this.document);
      }
      else
      {
        localObject = (Document)this.documentService.get(this.document.getDocId());
        ((Document)localObject).setDocName(this.document.getDocName());
        ((Document)localObject).setUpdatetime(new Date());
        ((Document)localObject).setDocFolder(this.document.getDocFolder());
        this.documentService.save(localObject);
      }
      setJsonString("{success:true}");
    }
    else
    {
      setJsonString("{success:false}");
    }
    return (String)"success";
  }

  public String onlineList()
  {
    QueryFilter localQueryFilter = new QueryFilter(getRequest());
    localQueryFilter.addFilter("Q_isShared_SN_EQ", Document.ONLINE_DOCUMENT.toString());
    List localList = this.documentService.getAll(localQueryFilter);
    ArrayList localArrayList = new ArrayList();
    Object localObject1 = localList.iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (Document)((Iterator)localObject1).next();
      localObject3 = new DocumentFile();
      Set localSet = ((Document)localObject2).getAttachFiles();
      FileAttach localFileAttach = (FileAttach)localSet.iterator().next();
      ((DocumentFile)localObject3).setFileId(((Document)localObject2).getDocId());
      ((DocumentFile)localObject3).setFileName(((Document)localObject2).getDocName());
      ((DocumentFile)localObject3).setFileSize(localFileAttach.getNote());
      ((DocumentFile)localObject3).setFileType("文档");
      ((DocumentFile)localObject3).setIsFolder(DocumentFile.NOT_FOLDER);
      ((DocumentFile)localObject3).setIsShared(((Document)localObject2).getIsShared());
      ((DocumentFile)localObject3).setAuthor(((Document)localObject2).getAuthor());
      ((DocumentFile)localObject3).setKeywords(((Document)localObject2).getKeywords());
      ((DocumentFile)localObject3).setUpdateTime(((Document)localObject2).getUpdatetime());
      localArrayList.add(localObject3);
    }
    localObject1 = new Gson();
    Object localObject2 = new TypeToken()
    {
    }
    .getType();
    Object localObject3 = new StringBuffer("{success:true,result:");
    ((StringBuffer)localObject3).append(((Gson)localObject1).toJson(localArrayList, (Type)localObject2));
    ((StringBuffer)localObject3).append("}");
    setJsonString(((StringBuffer)localObject3).toString());
    return (String)(String)(String)"success";
  }

  public String toSwf()
  {
    String str1 = "{success:true}";
    Document localDocument1 = (Document)this.documentService.get(this.docId);
    HtmlContentToPdf localHtmlContentToPdf = new HtmlContentToPdf();
    String str2 = AppUtil.getAppAbsolutePath().replace("\\", "/") + "pages/iText/fonts/SIMSUN.TTC";
    String str3 = getPropertiesOfValue("type", "windows");
    if (str3.equals("linux"))
      str2 = AppUtil.getAppAbsolutePath().replace("\\", "/") + "pages/iText/fonts/linux/gkai00mp.ttf";
    String str4 = getPath(localDocument1.getDocId(), true);
    String str5 = localHtmlContentToPdf.contentToPdf(localDocument1.getContent(), str2, str4);
    if (str5.equals("true"))
    {
      PdfToSwf localPdfToSwf = new PdfToSwf();
      String str6 = getPropertiesOfValue("swftools.exe.filepath", "C:/Program Files/SWFTools/pdf2swf.exe");
      String str7 = getPath(localDocument1.getDocId(), true);
      String str8 = getPath(localDocument1.getDocId(), false);
      String str9 = localPdfToSwf.start(str6, str7, str8);
      if (str9.equals("true"))
      {
        Document localDocument2 = (Document)this.documentService.get(this.docId);
        str8 = str8.substring(AppUtil.getAppAbsolutePath().length(), str8.length());
        localDocument2.setSwfPath(str8);
        Log.debug("生成pdf文档目录：" + str7);
        Log.debug("生成swf文件目录：" + str8);
        this.documentService.save(localDocument2);
        str1 = "{success:true}";
      }
      else
      {
        str1 = "{success:false,msg:'" + str9 + "'}";
      }
    }
    else
    {
      str1 = "{success:false,msg:'" + str5 + "'}";
    }
    return str1;
  }

  private String getPath(Long paramLong, boolean paramBoolean)
  {
    File localFile = null;
    try
    {
      StringBuffer localStringBuffer = new StringBuffer(AppUtil.getAppAbsolutePath().replace("\\", "/") + "attachFiles/iText/");
      localStringBuffer.append(paramBoolean ? "pdf" : "swf");
      localFile = new File(localStringBuffer.toString());
      if ((!localFile.exists()) && (!localFile.mkdir()))
        return "创建[" + localStringBuffer.toString() + "]目录失败，请重新操作！";
      localFile = null;
      localStringBuffer.append("/");
      Calendar localCalendar = Calendar.getInstance();
      int i = localCalendar.get(1);
      localStringBuffer.append(i);
      localFile = new File(localStringBuffer.toString());
      if ((!localFile.exists()) && (!localFile.mkdir()))
        return "创建[" + localStringBuffer.toString() + "]目录失败，请重新操作！";
      localFile = null;
      localStringBuffer.append("/");
      int j = localCalendar.get(2) + 1;
      localStringBuffer.append(j);
      localFile = new File(localStringBuffer.toString());
      if ((!localFile.exists()) && (!localFile.mkdir()))
        return "创建[" + localStringBuffer.toString() + "]目录失败，请重新添加！";
      localFile = null;
      localStringBuffer.append("/" + paramLong + ".");
      localStringBuffer.append(paramBoolean ? "pdf" : "swf");
      return localStringBuffer.toString();
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return "异常";
  }

  private String getPropertiesOfValue(String paramString1, String paramString2)
  {
    String str1 = "";
    Properties localProperties = new Properties();
    try
    {
      String str2 = getSession().getServletContext().getRealPath("/WEB-INF/classes");
      FileInputStream localFileInputStream = new FileInputStream(str2 + "/swftools.properties");
      InputStreamReader localInputStreamReader = new InputStreamReader(localFileInputStream, "UTF-8");
      localProperties.load(localInputStreamReader);
      if ((localProperties.getProperty(paramString1) != null) && (!localProperties.getProperty(paramString1).equals("")))
        str1 = localProperties.getProperty(paramString1);
      else
        str1 = localProperties.getProperty(paramString1, paramString2);
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
      Log.debug("读取swftools.properties文件异常！");
    }
    return str1;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.document.DocumentAction
 * JD-Core Version:    0.6.0
 */