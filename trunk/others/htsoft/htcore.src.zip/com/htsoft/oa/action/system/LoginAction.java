package com.htsoft.oa.action.system;

import com.htsoft.core.util.StringUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.SysConfig;
import com.htsoft.oa.service.system.AppUserService;
import com.htsoft.oa.service.system.SysConfigService;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import nl.captcha.Captcha;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.security.AuthenticationManager;
import org.springframework.security.context.SecurityContext;
import org.springframework.security.context.SecurityContextHolder;
import org.springframework.security.providers.UsernamePasswordAuthenticationToken;

public class LoginAction extends BaseAction
{
  private AppUser user;
  private String username;
  private String password;
  private String checkCode;
  private String key = "RememberAppUser";

  @Resource
  private AppUserService userService;

  @Resource
  private SysConfigService sysConfigService;

  @Resource(name="authenticationManager")
  private AuthenticationManager authenticationManager = null;

  public String login()
  {
    StringBuffer localStringBuffer = new StringBuffer("{msg:'");
    SysConfig localSysConfig = this.sysConfigService.findByKey("codeConfig");
    Captcha localCaptcha = (Captcha)getSession().getAttribute("simpleCaptcha");
    Boolean localBoolean = Boolean.valueOf(false);
    String str1 = null;
    if ((!"".equals(this.username)) && (this.username != null))
    {
      setUser(this.userService.findByUserName(this.username));
      if (this.user != null)
      {
        if (org.apache.commons.lang.StringUtils.isNotEmpty(this.password))
        {
          str1 = StringUtil.encryptSha256(this.password);
          if (this.user.getPassword().equalsIgnoreCase(str1))
          {
            if ((localSysConfig != null) && (localSysConfig.getDataValue().equals("1")))
            {
              if (localCaptcha == null)
                localStringBuffer.append("请刷新验证码再登录.'");
              else if (localCaptcha.isCorrect(this.checkCode))
                localBoolean = Boolean.valueOf(dyPwdCheck(localStringBuffer, localBoolean.booleanValue()));
              else
                localStringBuffer.append("验证码不正确.'");
            }
            else
              localBoolean = Boolean.valueOf(dyPwdCheck(localStringBuffer, localBoolean.booleanValue()));
          }
          else
            localStringBuffer.append("密码不正确.'");
        }
        else
        {
          localStringBuffer.append("密码不能为空.'");
        }
      }
      else
        localStringBuffer.append("用户不存在.'");
    }
    if (localBoolean.booleanValue())
    {
      UsernamePasswordAuthenticationToken localUsernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(this.username, this.password);
      SecurityContext localSecurityContext = SecurityContextHolder.getContext();
      localSecurityContext.setAuthentication(this.authenticationManager.authenticate(localUsernamePasswordAuthenticationToken));
      SecurityContextHolder.setContext(localSecurityContext);
      getSession().setAttribute("SPRING_SECURITY_LAST_USERNAME", this.username);
      String str2 = getRequest().getParameter("_spring_security_remember_me");
      if ((str2 != null) && (str2.equals("on")))
      {
        long l1 = 1209600L;
        long l2 = System.currentTimeMillis() + l1 * 1000L;
        String str3 = DigestUtils.md5Hex(this.username + ":" + l2 + ":" + this.user.getPassword() + ":" + this.key);
        String str4 = this.username + ":" + l2 + ":" + str3;
        String str5 = new String(Base64.encodeBase64(str4.getBytes()));
        getResponse().addCookie(makeValidCookie(l2, str5));
      }
      setJsonString("{success:true}");
      try
      {
        this.username = URLEncoder.encode(this.username, "UTF-8");
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
        localUnsupportedEncodingException.printStackTrace();
      }
      Cookie localCookie = new Cookie("jforumSSOCookieNameUser", this.username + "," + this.user.getPassword() + "," + this.user.getEmail());
      localCookie.setMaxAge(-1);
      localCookie.setPath("/");
      getResponse().addCookie(localCookie);
    }
    else
    {
      localStringBuffer.append(",failure:true}");
      setJsonString(localStringBuffer.toString());
    }
    return "success";
  }

  protected Cookie makeValidCookie(long paramLong, String paramString)
  {
    HttpServletRequest localHttpServletRequest = getRequest();
    Cookie localCookie = new Cookie("SPRING_SECURITY_REMEMBER_ME_COOKIE", paramString);
    localCookie.setMaxAge(157680000);
    localCookie.setPath(org.springframework.util.StringUtils.hasLength(localHttpServletRequest.getContextPath()) ? localHttpServletRequest.getContextPath() : "/");
    return localCookie;
  }

  public AppUser getUser()
  {
    return this.user;
  }

  public void setUser(AppUser paramAppUser)
  {
    this.user = paramAppUser;
  }

  public String getUsername()
  {
    return this.username;
  }

  public void setUsername(String paramString)
  {
    this.username = paramString;
  }

  public String getPassword()
  {
    return this.password;
  }

  public void setPassword(String paramString)
  {
    this.password = paramString;
  }

  public String getCheckCode()
  {
    return this.checkCode;
  }

  public void setCheckCode(String paramString)
  {
    this.checkCode = paramString;
  }

  private boolean dyPwdCheck(StringBuffer paramStringBuffer, boolean paramBoolean)
  {
    SysConfig localSysConfig = this.sysConfigService.findByKey("dynamicPwd");
    if ((localSysConfig != null) && (localSysConfig.getDataValue().equals("1")))
    {
      if (this.user.getUserId().longValue() == AppUser.SUPER_USER.longValue())
      {
        paramBoolean = true;
      }
      else if (org.apache.commons.lang.StringUtils.isEmpty(this.user.getDynamicPwd()))
      {
        paramStringBuffer.append("此用户未有令牌,请联系管理员.'");
      }
      else if (this.user.getDyPwdStatus().shortValue() == AppUser.DYNPWD_STATUS_UNBIND.shortValue())
      {
        paramStringBuffer.append("此用户令牌未绑定,请联系管理员.'");
      }
      else
      {
        String str1 = getRequest().getParameter("curDynamicPwd");
        HashMap localHashMap = new HashMap();
        localHashMap.put("app", "demoauthapp");
        localHashMap.put("user", this.user.getDynamicPwd());
        localHashMap.put("pw", str1);
        String str2 = this.userService.initDynamicPwd(localHashMap, "verify");
        if (str2.equals("ok"))
        {
          if (this.user.getStatus().shortValue() == 1)
            paramBoolean = true;
          else
            paramStringBuffer.append("此用户已被禁用.'");
        }
        else
          paramStringBuffer.append("令牌不正确,请重新输入.'");
      }
    }
    else if ((this.user.getStatus().shortValue() == 1) || (this.user.getUserId().longValue() == AppUser.SUPER_USER.longValue()))
      paramBoolean = true;
    else
      paramStringBuffer.append("此用户已被禁用.'");
    return paramBoolean;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.system.LoginAction
 * JD-Core Version:    0.6.0
 */