package com.htsoft.oa.action.mobile.flow;

import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.service.flow.ProDefinitionService;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class MobileProDefAction extends BaseAction
{

  @Resource
  private ProDefinitionService proDefinitionService;

  public String list()
  {
    List localList = this.proDefinitionService.getAll(getInitPagingBean());
    getRequest().setAttribute("proDefList", localList);
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.mobile.flow.MobileProDefAction
 * JD-Core Version:    0.6.0
 */