package com.htsoft.oa.action.bpm;

import com.htsoft.core.util.XmlUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.service.bpm.ILog.factory.BpmFactory;
import java.io.PrintStream;
import java.util.Iterator;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.dom4j.Document;
import org.dom4j.Element;

public class BpmXMLAction extends BaseAction
{
  public String change()
  {
    String str1 = getRequest().getParameter("xmlString");
    String str2 = "";
    if ((str1 != null) && (!str1.equals("")))
    {
      Document localDocument = XmlUtil.stringToDocument(str1);
      Element localElement1 = localDocument.getRootElement();
      BpmFactory localBpmFactory = new BpmFactory(localDocument);
      Iterator localIterator = localElement1.elements().iterator();
      String str3;
      for (str2 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?> \n <process name=\"test\" xmlns=\"http://jbpm.org/4.4/jpdl\">"; localIterator.hasNext(); str2 = str2 + str3)
      {
        Element localElement2 = (Element)localIterator.next();
        str3 = localBpmFactory.getInfo(localElement2, localElement2.getName());
      }
      str2 = str2 + "</process>";
      System.out.println(str2);
    }
    else
    {
      System.out.println("没有执行这个方法");
    }
    setJsonString("{success:true,jbpmXML:'" + str2 + "'}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.bpm.BpmXMLAction
 * JD-Core Version:    0.6.0
 */