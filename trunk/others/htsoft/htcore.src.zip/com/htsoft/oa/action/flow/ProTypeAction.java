package com.htsoft.oa.action.flow;

import com.google.gson.Gson;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.flow.ProType;
import com.htsoft.oa.service.flow.ProTypeService;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

public class ProTypeAction extends BaseAction
{

  @Resource
  private ProTypeService proTypeService;
  private ProType proType;
  private Long typeId;

  public Long getTypeId()
  {
    return this.typeId;
  }

  public void setTypeId(Long paramLong)
  {
    this.typeId = paramLong;
  }

  public ProType getProType()
  {
    return this.proType;
  }

  public void setProType(ProType paramProType)
  {
    this.proType = paramProType;
  }

  public String list()
  {
    List localList = this.proTypeService.getAll();
    StringBuffer localStringBuffer = new StringBuffer("[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      ProType localProType = (ProType)localIterator.next();
      localStringBuffer.append("{id:'").append(localProType.getTypeId()).append("',text:'").append(localProType.getTypeName()).append("',leaf:true},");
    }
    if (!localList.isEmpty())
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String root()
  {
    List localList = this.proTypeService.getAll();
    StringBuffer localStringBuffer = new StringBuffer("[{id:'0',text:'流程分类',leaf:false,expanded:true,children:[");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      ProType localProType = (ProType)localIterator.next();
      localStringBuffer.append("{id:'").append(localProType.getTypeId()).append("',text:'").append(localProType.getTypeName()).append("',leaf:true},");
    }
    if (!localList.isEmpty())
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]}]");
    this.jsonString = localStringBuffer.toString();
    return "success";
  }

  public String multiDel()
  {
    String[] arrayOfString1 = getRequest().getParameterValues("ids");
    if (arrayOfString1 != null)
      for (String str : arrayOfString1)
        this.proTypeService.remove(new Long(str));
    this.jsonString = "{success:true}";
    return "success";
  }

  public String remove()
  {
    this.proTypeService.remove(this.typeId);
    this.jsonString = "{success:true}";
    return "success";
  }

  public String get()
  {
    ProType localProType = (ProType)this.proTypeService.get(this.typeId);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer("{success:true,data:");
    localStringBuffer.append(localGson.toJson(localProType));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String save()
  {
    this.proTypeService.save(this.proType);
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.flow.ProTypeAction
 * JD-Core Version:    0.6.0
 */