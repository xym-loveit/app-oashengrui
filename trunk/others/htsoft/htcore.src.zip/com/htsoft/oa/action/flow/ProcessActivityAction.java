package com.htsoft.oa.action.flow;

import com.google.gson.Gson;
import com.htsoft.core.model.DynaModel;
import com.htsoft.core.service.DynamicService;
import com.htsoft.core.util.AppUtil;
import com.htsoft.core.util.BeanUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.util.FunctionsUtil;
import com.htsoft.core.util.JsonUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.oa.model.flow.FieldRights;
import com.htsoft.oa.model.flow.FormDef;
import com.htsoft.oa.model.flow.FormDefMapping;
import com.htsoft.oa.model.flow.FormField;
import com.htsoft.oa.model.flow.FormTable;
import com.htsoft.oa.model.flow.FormTemplate;
import com.htsoft.oa.model.flow.ProDefinition;
import com.htsoft.oa.model.flow.ProcessRun;
import com.htsoft.oa.model.flow.TaskSignData;
import com.htsoft.oa.model.flow.Transform;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.flow.FieldRightsService;
import com.htsoft.oa.service.flow.FlowFormService;
import com.htsoft.oa.service.flow.FormDefMappingService;
import com.htsoft.oa.service.flow.FormDefService;
import com.htsoft.oa.service.flow.FormTemplateService;
import com.htsoft.oa.service.flow.JbpmService;
import com.htsoft.oa.service.flow.ProDefinitionService;
import com.htsoft.oa.service.flow.ProcessRunService;
import com.htsoft.oa.service.flow.ProcessService;
import com.htsoft.oa.service.flow.RunDataService;
import com.htsoft.oa.service.flow.TaskSignDataService;
import com.htsoft.oa.service.info.ShortMessageService;
import com.htsoft.oa.service.system.AppUserService;
import com.htsoft.oa.util.FlowUtil;
import flexjson.JSONSerializer;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.velocity.app.VelocityEngine;
import org.jbpm.api.ProcessDefinition;
import org.jbpm.api.model.Activity;
import org.jbpm.api.model.Transition;
import org.jbpm.api.task.Task;
import org.jbpm.pvm.internal.model.ExecutionImpl;
import org.jbpm.pvm.internal.task.TaskImpl;
import org.springframework.ui.velocity.VelocityEngineUtils;

public class ProcessActivityAction extends BaseAction
{

  @Resource
  private ProDefinitionService proDefinitionService;

  @Resource
  private ProcessRunService processRunService;

  @Resource
  private JbpmService jbpmService;

  @Resource
  private RunDataService runDataService;

  @Resource
  private ProcessService processService;

  @Resource
  private FormDefMappingService formDefMappingService;

  @Resource
  private FieldRightsService fieldRightsService;

  @Resource
  private FormDefService formDefService;

  @Resource
  private VelocityEngine flowVelocityEngine;

  @Resource
  private TaskSignDataService taskSignDataService;

  @Resource
  private FlowFormService flowFormService;

  @Resource
  private FormTemplateService formTemplateService;

  @Resource
  private AppUserService appUserService;

  @Resource
  private ShortMessageService shortMessageService;
  private String activityName;
  private Long runId;
  private Long taskId;
  private Long defId;

  public Long getTaskId()
  {
    return this.taskId;
  }

  public void setTaskId(Long paramLong)
  {
    this.taskId = paramLong;
  }

  public Long getRunId()
  {
    return this.runId;
  }

  public void setRunId(Long paramLong)
  {
    this.runId = paramLong;
  }

  public String getActivityName()
  {
    return this.activityName;
  }

  public void setActivityName(String paramString)
  {
    this.activityName = paramString;
  }

  public Long getDefId()
  {
    return this.defId;
  }

  public void setDefId(Long paramLong)
  {
    this.defId = paramLong;
  }

  public String get()
    throws Exception
  {
    HttpServletRequest localHttpServletRequest = getRequest();
    String str1 = null;
    ProcessRun localProcessRun = null;
    HashMap localHashMap = new HashMap();
    ProDefinition localProDefinition = null;
    FormDef localFormDef = null;
    String str2 = this.activityName;
    Object localObject6;
    Object localObject7;
    if (this.taskId != null)
    {
      str1 = this.jbpmService.getProcessDefinitionByTaskId(this.taskId.toString()).getDeploymentId();
      localHttpServletRequest.setAttribute("taskId", this.taskId);
      localObject1 = (ExecutionImpl)this.jbpmService.getProcessInstanceByTaskId(this.taskId.toString());
      localObject2 = ((ExecutionImpl)localObject1).getId();
      if (((ExecutionImpl)localObject1).getSuperProcessExecution() != null)
        localObject2 = ((ExecutionImpl)localObject1).getSuperProcessExecution().getId();
      localProcessRun = this.processRunService.getByPiId((String)localObject2);
      if (localProcessRun.getFormDefId() != null)
        localFormDef = (FormDef)this.formDefService.get(localProcessRun.getFormDefId());
      localObject3 = localProcessRun.getEntityId();
      localObject4 = localProcessRun.getEntityName();
      if (localObject4 != null)
      {
        localObject5 = BeanUtil.getDynamicServiceBean((String)localObject4);
        localObject6 = (DynaModel)FlowUtil.DynaModelMap.get(localObject4);
        if (localObject3 != null)
        {
          localObject7 = ((DynamicService)localObject5).get(new Long(localObject3.toString()));
          localHttpServletRequest.setAttribute("entityJson", JsonUtil.mapEntity2Json((Map)localObject7, (String)localObject4));
          localHttpServletRequest.setAttribute("pkValue", localObject3);
          if (localObject6 != null)
            localHttpServletRequest.setAttribute("pkName", ((DynaModel)localObject6).getPrimaryFieldName());
        }
      }
    }
    else
    {
      localHttpServletRequest.setAttribute("defId", this.defId);
      localProDefinition = (ProDefinition)this.proDefinitionService.get(this.defId);
      if (this.activityName == null)
        str2 = this.jbpmService.getStartNodeName(localProDefinition);
      str1 = localProDefinition.getDeployId();
    }
    Object localObject1 = this.formDefMappingService.getByDeployId(str1);
    Object localObject2 = new ArrayList();
    String str3;
    if (localObject1 != null)
    {
      localProDefinition = (ProDefinition)this.proDefinitionService.get(((FormDefMapping)localObject1).getDefId());
      if (FormDefMapping.USE_TEMPLATE.equals(((FormDefMapping)localObject1).getUseTemplate()))
      {
        localHashMap.put("activityName", str2);
        if (this.taskId != null)
        {
          localObject3 = this.jbpmService.getVarsByTaskId(this.taskId.toString());
          localHashMap.putAll((Map)localObject3);
          if (localProcessRun != null)
          {
            localObject4 = this.runDataService.getMapByRunId(localProcessRun.getRunId());
            localHashMap.putAll((Map)localObject4);
          }
        }
        localObject3 = this.formTemplateService.getByMappingIdNodeName(((FormDefMapping)localObject1).getMappingId(), str2);
        if ((localObject3 != null) && (FormTemplate.TEMP_TYPE_URL.equals(((FormTemplate)localObject3).getTempType())))
        {
          localHttpServletRequest.setAttribute("formTemplate", localObject3);
          localHttpServletRequest.setAttribute("formVars", localHashMap);
          return "formUrl";
        }
        localObject4 = "/" + localProDefinition.getName() + "/" + ((FormDefMapping)localObject1).getVersionNo() + "/";
        localObject5 = null;
        localObject6 = (String)localObject4 + str2 + ".vm";
        localObject7 = (String)localObject4 + "Template.vm";
        str3 = AppUtil.getAppAbsolutePath() + "/WEB-INF/FlowForm";
        if (new File(str3 + (String)localObject6).exists())
        {
          localObject5 = VelocityEngineUtils.mergeTemplateIntoString(this.flowVelocityEngine, (String)localObject6, "UTF-8", localHashMap);
        }
        else if (new File(str3 + (String)localObject7).exists())
        {
          localObject5 = VelocityEngineUtils.mergeTemplateIntoString(this.flowVelocityEngine, (String)localObject7, "UTF-8", localHashMap);
        }
        else
        {
          String str4 = "/通用/表单.vm";
          localObject5 = VelocityEngineUtils.mergeTemplateIntoString(this.flowVelocityEngine, str4, "UTF-8", localHashMap);
        }
        localHttpServletRequest.setAttribute("formUiJs", localObject5);
        return "formExt";
      }
      if (localFormDef == null)
        localFormDef = ((FormDefMapping)localObject1).getFormDef();
      if (localFormDef == null)
        localFormDef = (FormDef)this.formDefService.get(FormDef.DEFAULT_FLOW_FORMID);
      localObject2 = this.fieldRightsService.getByMappingIdAndTaskName(((FormDefMapping)localObject1).getMappingId(), str2);
    }
    else
    {
      localFormDef = (FormDef)this.formDefService.get(FormDef.DEFAULT_FLOW_FORMID);
    }
    localHttpServletRequest.setAttribute("formRights", getRights((List)localObject2));
    Object localObject3 = localFormDef.getFormTables().iterator();
    Object localObject4 = new ArrayList();
    Object localObject5 = new ArrayList();
    while (((Iterator)localObject3).hasNext())
    {
      localObject6 = (FormTable)((Iterator)localObject3).next();
      if (FormTable.MAIN_TABLE.equals(((FormTable)localObject6).getIsMain()))
      {
        localHttpServletRequest.setAttribute("mainTable", localObject6);
      }
      else
      {
        localObject7 = (DynaModel)FlowUtil.DynaModelMap.get(((FormTable)localObject6).getEntityName());
        if (localObject7 != null)
          ((List)localObject4).add(localObject7);
        ((List)localObject5).add(localObject6);
        str3 = FunctionsUtil.makeFirstLetterUpperCase(((FormTable)localObject6).getEntityName()) + "s";
        localHttpServletRequest.setAttribute("subSetVarName", str3);
      }
    }
    localHttpServletRequest.setAttribute("subModels", localObject4);
    localHttpServletRequest.setAttribute("subTables", localObject5);
    localHttpServletRequest.setAttribute("formDef", localFormDef);
    return (String)(String)(String)(String)(String)(String)(String)"formHtml";
  }

  public String flowForm()
  {
    return "formHtml";
  }

  public String parentTrans()
  {
    if (this.taskId != null)
    {
      List localList = this.jbpmService.getTransitionsBySubFlowTaskId(this.taskId.toString());
      ArrayList localArrayList = new ArrayList();
      Object localObject1 = localList.iterator();
      while (((Iterator)localObject1).hasNext())
      {
        localObject2 = (Transition)((Iterator)localObject1).next();
        if ((localObject2 != null) && (((Transition)localObject2).getDestination() != null))
          localArrayList.add(new Transform((Transition)localObject2));
      }
      localObject1 = JsonUtil.getJSONSerializer();
      Object localObject2 = ((JSONSerializer)localObject1).serialize(localArrayList);
      setJsonString("{success:true,data:" + (String)localObject2 + "}");
    }
    return (String)(String)"success";
  }

  public String getForm()
  {
    HttpServletRequest localHttpServletRequest = getRequest();
    String str1 = localHttpServletRequest.getParameter("runId");
    String str2 = localHttpServletRequest.getParameter("defId");
    ProcessRun localProcessRun = (ProcessRun)this.processRunService.get(new Long(str1));
    if (StringUtils.isEmpty(str2))
      str2 = localProcessRun.getProDefinition().getDefId().toString();
    ProDefinition localProDefinition = (ProDefinition)this.proDefinitionService.get(new Long(str2));
    String str3 = localProDefinition.getDeployId();
    FormDefMapping localFormDefMapping = this.formDefMappingService.getByDeployId(str3);
    FormDef localFormDef = null;
    if ((localProcessRun != null) && (localProcessRun.getFormDefId() != null))
      localFormDef = (FormDef)this.formDefService.get(localProcessRun.getFormDefId());
    if (localFormDefMapping != null)
    {
      localProDefinition = (ProDefinition)this.proDefinitionService.get(localFormDefMapping.getDefId());
      if (FormDefMapping.USE_TEMPLATE.equals(localFormDefMapping.getUseTemplate()))
        return "formHtml";
      if (localFormDef == null)
        localFormDef = localFormDefMapping.getFormDef();
      if (localFormDef == null)
        localFormDef = (FormDef)this.formDefService.get(FormDef.DEFAULT_FLOW_FORMID);
    }
    else
    {
      localFormDef = (FormDef)this.formDefService.get(FormDef.DEFAULT_FLOW_FORMID);
    }
    String str4 = localProcessRun.getEntityId();
    String str5 = localProcessRun.getEntityName();
    if (str5 != null)
    {
      localObject1 = BeanUtil.getDynamicServiceBean(str5);
      localObject2 = (DynaModel)FlowUtil.DynaModelMap.get(str5);
      if (str4 != null)
      {
        localObject3 = ((DynamicService)localObject1).get(new Long(str4.toString()));
        localHttpServletRequest.setAttribute("entityJson", JsonUtil.mapEntity2Json((Map)localObject3, str5));
        localHttpServletRequest.setAttribute("pkValue", str4);
        if (localObject2 != null)
          localHttpServletRequest.setAttribute("pkName", ((DynaModel)localObject2).getPrimaryFieldName());
      }
    }
    Object localObject1 = localFormDef.getFormTables().iterator();
    Object localObject2 = new ArrayList();
    Object localObject3 = new ArrayList();
    while (((Iterator)localObject1).hasNext())
    {
      FormTable localFormTable = (FormTable)((Iterator)localObject1).next();
      if (FormTable.MAIN_TABLE.equals(localFormTable.getIsMain()))
      {
        localHttpServletRequest.setAttribute("mainTable", localFormTable);
      }
      else
      {
        DynaModel localDynaModel = (DynaModel)FlowUtil.DynaModelMap.get(localFormTable.getEntityName());
        if (localDynaModel != null)
        {
          localHttpServletRequest.setAttribute("subPkName", localDynaModel.getPrimaryFieldName());
          ((List)localObject2).add(localDynaModel);
        }
        ((List)localObject3).add(localFormTable);
        String str6 = FunctionsUtil.makeFirstLetterUpperCase(localFormTable.getEntityName()) + "s";
        localHttpServletRequest.setAttribute("subSetVarName", str6);
      }
    }
    localHttpServletRequest.setAttribute("subModels", localObject2);
    localHttpServletRequest.setAttribute("subTables", localObject3);
    localHttpServletRequest.setAttribute("defId", str2);
    localHttpServletRequest.setAttribute("runId", str1);
    localHttpServletRequest.setAttribute("formDef", localFormDef);
    return (String)(String)(String)"formHtml";
  }

  public String check()
  {
    Task localTask = this.jbpmService.getTaskById(String.valueOf(this.taskId));
    if (localTask != null)
    {
      String str = localTask.getAssignee();
      Long localLong = ContextUtil.getCurrentUserId();
      if (localLong.toString().equals(str))
      {
        this.jsonString = "{success:true,isValid:true,msg:''}";
      }
      else if (StringUtils.isNotEmpty(str))
      {
        this.jsonString = "{success:true,isValid:false,msg:'该任务已经被其他成员锁定执行！'}";
      }
      else
      {
        this.jbpmService.assignTask(localTask.getId(), localLong.toString());
        this.jsonString = "{success:true,isValid:true,msg:'该任务已经被您锁定执行!'}";
      }
    }
    else
    {
      this.jsonString = "{success:true,isValid:false,msg:'该任务已经完成了'}";
    }
    return "success";
  }

  public String save()
  {
    if (this.logger.isDebugEnabled())
      this.logger.info("start process..............");
    try
    {
      this.processService.doStartFlow(getRequest());
    }
    catch (Exception localException)
    {
      this.logger.error("error:" + localException.getMessage());
      localException.printStackTrace();
      setJsonString("{success:false}");
    }
    return "success";
  }

  public String next()
  {
    if (this.logger.isDebugEnabled())
      this.logger.info("process jump to next ..............");
    try
    {
      this.processService.doNextFlow(getRequest());
    }
    catch (Exception localException)
    {
      this.logger.error("error:" + localException.getMessage());
      localException.printStackTrace();
      setJsonString("{success:false}");
    }
    return "success";
  }

  public String allowBack()
  {
    if (this.logger.isDebugEnabled())
      this.logger.info("allown black ");
    boolean bool = this.jbpmService.isAllownBack(getRequest().getParameter("taskId"));
    setJsonString("{success:" + bool + "}");
    return "success";
  }

  public String startTrans()
  {
    ProDefinition localProDefinition = (ProDefinition)this.proDefinitionService.get(this.defId);
    if (localProDefinition != null)
    {
      List localList = this.jbpmService.getStartOutTransByDeployId(localProDefinition.getDeployId());
      ArrayList localArrayList = new ArrayList();
      Object localObject1 = localList.iterator();
      while (((Iterator)localObject1).hasNext())
      {
        localObject2 = (Transition)((Iterator)localObject1).next();
        if ((localObject2 != null) && (((Transition)localObject2).getDestination() != null))
          localArrayList.add(new Transform((Transition)localObject2));
      }
      localObject1 = JsonUtil.getJSONSerializer();
      Object localObject2 = ((JSONSerializer)localObject1).serialize(localArrayList);
      setJsonString("{success:true,data:" + (String)localObject2 + "}");
    }
    return (String)(String)"success";
  }

  public String freeTrans()
  {
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("[");
    List localList = this.jbpmService.getFreeTransitionsByTaskId(this.taskId.toString());
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Transition localTransition = (Transition)localIterator.next();
      localStringBuffer.append("[").append(localGson.toJson(localTransition.getName())).append(",").append(localGson.toJson(localTransition.getDestination().getName())).append(",").append(localGson.toJson(localTransition.getDestination().getType())).append("],");
    }
    if (localList.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]");
    setJsonString(localStringBuffer.toString());
    return "success";
  }

  public String outerTrans()
  {
    ProcessDefinition localProcessDefinition = null;
    if (this.taskId != null)
    {
      str = getRequest().getParameter("isParentFlow");
      if ("true".equals(str))
      {
        localObject = (TaskImpl)this.jbpmService.getTaskById(this.taskId.toString());
        localProcessDefinition = this.jbpmService.getProcessDefinitionByPdId(((TaskImpl)localObject).getExecution().getSuperProcessExecution().getProcessDefinitionId());
      }
      else
      {
        localProcessDefinition = this.jbpmService.getProcessDefinitionByTaskId(this.taskId.toString());
      }
    }
    else
    {
      localProcessDefinition = this.jbpmService.getProcessDefinitionByDefId(this.defId);
    }
    String str = getRequest().getParameter("nodeName");
    Object localObject = this.jbpmService.getNodeOuterTrans(localProcessDefinition, str);
    Gson localGson = new Gson();
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("[");
    Iterator localIterator = ((List)localObject).iterator();
    while (localIterator.hasNext())
    {
      Transition localTransition = (Transition)localIterator.next();
      localStringBuffer.append("[").append(localGson.toJson(localTransition.getName())).append(",").append(localGson.toJson(localTransition.getDestination().getName())).append(",").append(localGson.toJson(localTransition.getDestination().getType())).append(",").append(getUsers(localProcessDefinition, localTransition.getDestination().getName())).append("],");
    }
    if (((List)localObject).size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("]");
    setJsonString(localStringBuffer.toString());
    return (String)"success";
  }

  private String getUsers(ProcessDefinition paramProcessDefinition, String paramString)
  {
    Set localSet = null;
    if (this.taskId != null)
    {
      localObject = this.jbpmService.getFlowStartUserId(this.taskId.toString());
      localSet = this.jbpmService.getNodeHandlerUsers(paramProcessDefinition, paramString, (Long)localObject);
    }
    else
    {
      localSet = this.jbpmService.getNodeHandlerUsers(paramProcessDefinition, paramString, ContextUtil.getCurrentUserId());
    }
    Object localObject = new StringBuffer();
    StringBuffer localStringBuffer = new StringBuffer();
    Iterator localIterator = localSet.iterator();
    for (int i = 0; localIterator.hasNext(); i++)
    {
      AppUser localAppUser = (AppUser)localIterator.next();
      if (i > 0)
      {
        ((StringBuffer)localObject).append(",");
        localStringBuffer.append(",");
      }
      ((StringBuffer)localObject).append(localAppUser.getUserId());
      localStringBuffer.append(localAppUser.getFullname());
    }
    return (String)("\"" + ((StringBuffer)localObject).toString() + "\",\"" + localStringBuffer.toString() + "\"");
  }

  public String users()
  {
    ProcessDefinition localProcessDefinition = null;
    Set localSet = null;
    if (this.taskId != null)
    {
      localObject1 = getRequest().getParameter("isParentFlow");
      if ("true".equals(localObject1))
      {
        localObject2 = (TaskImpl)this.jbpmService.getTaskById(this.taskId.toString());
        localProcessDefinition = this.jbpmService.getProcessDefinitionByPdId(((TaskImpl)localObject2).getExecution().getSuperProcessExecution().getProcessDefinitionId());
      }
      else
      {
        localProcessDefinition = this.jbpmService.getProcessDefinitionByTaskId(this.taskId.toString());
      }
      localObject2 = this.jbpmService.getFlowStartUserId(this.taskId.toString());
      localSet = this.jbpmService.getNodeHandlerUsers(localProcessDefinition, this.activityName, (Long)localObject2);
    }
    else
    {
      localProcessDefinition = this.jbpmService.getProcessDefinitionByDefId(this.defId);
      localSet = this.jbpmService.getNodeHandlerUsers(localProcessDefinition, this.activityName, ContextUtil.getCurrentUserId());
    }
    Object localObject1 = new StringBuffer();
    Object localObject2 = new StringBuffer();
    Iterator localIterator = localSet.iterator();
    for (int i = 0; localIterator.hasNext(); i++)
    {
      AppUser localAppUser = (AppUser)localIterator.next();
      if (i > 0)
      {
        ((StringBuffer)localObject1).append(",");
        ((StringBuffer)localObject2).append(",");
      }
      ((StringBuffer)localObject1).append(localAppUser.getUserId());
      ((StringBuffer)localObject2).append(localAppUser.getFullname());
    }
    this.jsonString = ("{success:true,userIds:'" + ((StringBuffer)localObject1).toString() + "',userNames:'" + ((StringBuffer)localObject2).toString() + "'}");
    return (String)(String)"success";
  }

  public String trans()
  {
    String str = this.jbpmService.getPreTask(this.taskId.toString());
    if (str == null)
      str = "";
    boolean bool = this.jbpmService.isSignTask(this.taskId.toString());
    ArrayList localArrayList = new ArrayList();
    List localList = this.jbpmService.getTransitionsByTaskId(this.taskId.toString());
    Object localObject1 = localList.iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (Transition)((Iterator)localObject1).next();
      if ((localObject2 != null) && (((Transition)localObject2).getDestination() != null))
        localArrayList.add(new Transform((Transition)localObject2));
    }
    localObject1 = JsonUtil.getJSONSerializer();
    Object localObject2 = ((JSONSerializer)localObject1).serialize(localArrayList);
    setJsonString("{success:true,preTaskName:'" + str + "',isSignTask:" + bool + ",data:" + (String)localObject2 + "}");
    return (String)(String)"success";
  }

  public String signList()
  {
    Task localTask = this.jbpmService.getParentTask(this.taskId.toString());
    List localList1 = this.taskSignDataService.getByTaskId(localTask.getId());
    List localList2 = this.jbpmService.getAssigneeByTaskId(localTask.getId());
    Iterator localIterator = localList2.iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      TaskSignData localTaskSignData = new TaskSignData();
      AppUser localAppUser = (AppUser)this.appUserService.get(new Long(str));
      localTaskSignData.setVoteName(localAppUser.getFullname());
      localList1.add(localTaskSignData);
    }
    getRequest().setAttribute("signDataList", localList1);
    return "signList";
  }

  protected ProDefinition getProDefinition()
  {
    ProDefinition localProDefinition = null;
    ProcessRun localProcessRun;
    if (this.runId != null)
    {
      localProcessRun = (ProcessRun)this.processRunService.get(this.runId);
      localProDefinition = localProcessRun.getProDefinition();
    }
    else if (this.defId != null)
    {
      localProDefinition = (ProDefinition)this.proDefinitionService.get(this.defId);
    }
    else
    {
      localProcessRun = this.processRunService.getByTaskId(this.taskId.toString());
      localProDefinition = localProcessRun.getProDefinition();
    }
    return localProDefinition;
  }

  protected String getRights(List<FieldRights> paramList)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("{");
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      FieldRights localFieldRights = (FieldRights)localIterator.next();
      localStringBuffer.append("'").append(localFieldRights.getFormField().getFieldName()).append("':'").append(localFieldRights.getReadWrite()).append("',");
    }
    if (paramList.size() > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("}");
    return localStringBuffer.toString();
  }

  public String delItems()
  {
    String str1 = getRequest().getParameter("ids");
    String str2 = getRequest().getParameter("tableId");
    this.flowFormService.deleteItems(str1, new Long(str2));
    setJsonString("{success:true}");
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.flow.ProcessActivityAction
 * JD-Core Version:    0.6.0
 */