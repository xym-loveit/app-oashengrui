package com.htsoft.oa.action.info;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.web.action.BaseAction;
import com.htsoft.core.web.paging.PagingBean;
import com.htsoft.oa.model.info.InMessage;
import com.htsoft.oa.model.info.ShortMessage;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.info.InMessageService;
import com.htsoft.oa.service.info.ShortMessageService;
import com.htsoft.oa.service.system.AppUserService;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;

public class ShortMessageAction extends BaseAction
{
  static short NOT_DELETE = 0;
  private ShortMessage shortMessage;
  private Date from;
  private Date to;
  private List<InMessage> inList = new ArrayList();

  @Resource
  private ShortMessageService shortMessageService;

  @Resource
  private InMessageService inMessageService;

  @Resource
  private AppUserService appUserService;

  public List<InMessage> getInList()
  {
    return this.inList;
  }

  public void setInList(List<InMessage> paramList)
  {
    this.inList = paramList;
  }

  public Date getFrom()
  {
    return this.from;
  }

  public void setFrom(Date paramDate)
  {
    this.from = paramDate;
  }

  public Date getTo()
  {
    return this.to;
  }

  public void setTo(Date paramDate)
  {
    this.to = paramDate;
  }

  public ShortMessage getShortMessage()
  {
    return this.shortMessage;
  }

  public void setShortMessage(ShortMessage paramShortMessage)
  {
    this.shortMessage = paramShortMessage;
  }

  public String list()
  {
    PagingBean localPagingBean = getInitPagingBean();
    AppUser localAppUser = ContextUtil.getCurrentUser();
    List localList = this.shortMessageService.searchShortMessage(localAppUser.getUserId(), this.shortMessage, this.from, this.to, localPagingBean, null);
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':" + localPagingBean.getTotalItems() + ",result:");
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < localList.size(); i++)
    {
      localObject = (InMessage)((Object[])localList.get(i))[0];
      localArrayList.add(localObject);
    }
    Gson localGson = new Gson();
    Object localObject = new TypeToken()
    {
    }
    .getType();
    localStringBuffer.append(localGson.toJson(localArrayList, (Type)localObject));
    localStringBuffer.append("}");
    setJsonString(localStringBuffer.toString());
    return (String)"success";
  }

  public String send()
  {
    String str1 = getRequest().getParameter("userId");
    String str2 = getRequest().getParameter("content");
    AppUser localAppUser1 = ContextUtil.getCurrentUser();
    if ((StringUtils.isNotEmpty(str1)) && (StringUtils.isNotEmpty(str2)))
    {
      String[] arrayOfString = str1.split(",");
      ShortMessage localShortMessage = new ShortMessage();
      localShortMessage.setContent(str2);
      localShortMessage.setMsgType(Short.valueOf(1));
      localShortMessage.setSenderId(localAppUser1.getUserId());
      localShortMessage.setSender(localAppUser1.getFullname());
      localShortMessage.setSendTime(new Date());
      this.shortMessageService.save(localShortMessage);
      for (int i = 0; i < arrayOfString.length; i++)
      {
        InMessage localInMessage = new InMessage();
        localInMessage.setUserId(Long.valueOf(Long.parseLong(arrayOfString[i])));
        AppUser localAppUser2 = (AppUser)this.appUserService.get(Long.valueOf(Long.parseLong(arrayOfString[i])));
        localInMessage.setUserFullname(localAppUser2.getFullname());
        localInMessage.setDelFlag(Short.valueOf(NOT_DELETE));
        localInMessage.setReadFlag(Short.valueOf(0));
        localInMessage.setShortMessage(localShortMessage);
        this.inMessageService.save(localInMessage);
      }
      setJsonString("{success:true}");
    }
    else
    {
      setJsonString("{success:false}");
    }
    return "success";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.action.info.ShortMessageAction
 * JD-Core Version:    0.6.0
 */