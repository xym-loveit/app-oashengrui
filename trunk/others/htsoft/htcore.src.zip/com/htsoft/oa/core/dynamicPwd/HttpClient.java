package com.htsoft.oa.core.dynamicPwd;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class HttpClient
{
  private URI base_uri;
  private String encoding = "UTF8";

  public HttpClient(URI paramURI)
  {
    this.base_uri = paramURI;
  }

  public String getEncoding()
  {
    return this.encoding;
  }

  public void setEncoding(String paramString)
  {
    this.encoding = paramString;
  }

  protected String makeQueryString(Map<String, String> paramMap)
    throws UnsupportedEncodingException
  {
    StringBuffer localStringBuffer = new StringBuffer();
    Iterator localIterator = paramMap.keySet().iterator();
    int i = 1;
    while (localIterator.hasNext())
    {
      if (i != 0)
        i = 0;
      else
        localStringBuffer.append("&");
      String str1 = (String)localIterator.next();
      String str2 = (String)paramMap.get(str1);
      localStringBuffer.append(URLEncoder.encode(str1, getEncoding()) + "=" + URLEncoder.encode(str2, getEncoding()));
    }
    return localStringBuffer.toString();
  }

  public YooeResponse call_api(String paramString, Map<String, String> paramMap)
    throws IOException, Exception
  {
    String str1 = makeQueryString(paramMap);
    URI localURI = this.base_uri.resolve(URI.create(paramString + "/?" + str1));
    URL localURL = localURI.toURL();
    HttpURLConnection localHttpURLConnection = (HttpURLConnection)localURL.openConnection();
    int i = localHttpURLConnection.getResponseCode();
    if (i != 200)
    {
      localObject = "Error:" + i;
      throw new Exception((String)localObject);
    }
    Object localObject = new BufferedReader(new InputStreamReader(localHttpURLConnection.getInputStream()));
    LinkedList localLinkedList = new LinkedList();
    String str2;
    while ((str2 = ((BufferedReader)localObject).readLine()) != null)
    {
      String str3 = str2.trim();
      if (!str3.isEmpty())
        localLinkedList.add(str3);
    }
    return (YooeResponse)new YooeResponse(localLinkedList);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.core.dynamicPwd.HttpClient
 * JD-Core Version:    0.6.0
 */