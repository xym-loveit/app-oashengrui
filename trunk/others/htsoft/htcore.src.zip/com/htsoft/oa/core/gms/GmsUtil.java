package com.htsoft.oa.core.gms;

import com.htsoft.core.util.AppUtil;
import java.io.PrintStream;
import java.util.Map;
import org.smslib.IOutboundMessageNotification;
import org.smslib.OutboundMessage;
import org.smslib.Service;
import org.smslib.modem.SerialModemGateway;

public class GmsUtil
{
  private static Object sign = new Object();
  private static Service service = null;

  private static void init()
  {
    service = new Service();
    1 local1 = new IOutboundMessageNotification()
    {
      public void process(String paramString, OutboundMessage paramOutboundMessage)
      {
        System.out.println("Outbound handler called from Gateway: " + paramString);
        System.out.println(paramOutboundMessage);
      }
    };
    Map localMap = AppUtil.getSysConfig();
    String str = (String)localMap.get("deviceName");
    Integer localInteger = Integer.valueOf(Integer.parseInt((String)localMap.get("baudRate")));
    SerialModemGateway localSerialModemGateway = new SerialModemGateway("modem.com3", str, localInteger.intValue(), "wavecom", "");
    localSerialModemGateway.setInbound(true);
    localSerialModemGateway.setOutbound(true);
    localSerialModemGateway.setSimPin("0000");
    localSerialModemGateway.setOutboundNotification(local1);
    service.addGateway(localSerialModemGateway);
  }

  public static Service getGmsService()
  {
    if (service == null)
      synchronized (sign)
      {
        init();
      }
    return service;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.core.gms.GmsUtil
 * JD-Core Version:    0.6.0
 */