package com.htsoft.oa.core.dynamicPwd;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class YooeResponse
{
  protected static final String RET_CMD_OK = "OK";
  protected static final String RET_CMD_ERR = "ERR";
  protected static final String[] RET_CMD = { "OK", "ERR" };
  private String ret_cmd;
  private HashMap<String, String> vars_dict;
  private List<String> response;

  private void parse_response()
    throws Exception
  {
    if (this.response.isEmpty())
      throw new Exception();
    Iterator localIterator = this.response.iterator();
    this.ret_cmd = ((String)localIterator.next());
    if (!Arrays.asList(RET_CMD).contains(this.ret_cmd))
      throw new Exception();
    this.vars_dict = new HashMap();
    while (localIterator.hasNext())
    {
      String[] arrayOfString = ((String)localIterator.next()).split(":", 2);
      if (arrayOfString.length < 2)
        this.vars_dict.put(arrayOfString[0].trim(), "");
      else
        this.vars_dict.put(arrayOfString[0].trim(), arrayOfString[1].trim());
    }
  }

  public String getRetCmd()
    throws Exception
  {
    if (this.ret_cmd == null)
      parse_response();
    return this.ret_cmd;
  }

  public HashMap<String, String> getVarsDict()
    throws Exception
  {
    if (this.ret_cmd == null)
      parse_response();
    return this.vars_dict;
  }

  public YooeResponse(List<String> paramList)
  {
    this.response = paramList;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.oa.core.dynamicPwd.YooeResponse
 * JD-Core Version:    0.6.0
 */