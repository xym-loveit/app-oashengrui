package com.htsoft.core.web.action;

public class DynamicAction
{
  private String jsonString = "{success:true}";
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.web.action.DynamicAction
 * JD-Core Version:    0.6.0
 */