package com.htsoft.core.web.listener;

import com.htsoft.core.util.AppUtil;
import javax.servlet.ServletContextEvent;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.context.ContextLoaderListener;

public class StartupListener extends ContextLoaderListener
{
  private static Log logger = LogFactory.getLog(StartupListener.class);

  public void contextInitialized(ServletContextEvent paramServletContextEvent)
  {
    super.contextInitialized(paramServletContextEvent);
    AppUtil.init(paramServletContextEvent.getServletContext());
    boolean bool = AppUtil.getIsSynMenu();
    if (bool)
      AppUtil.synMenu();
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.web.listener.StartupListener
 * JD-Core Version:    0.6.0
 */