package com.htsoft.core.web.action;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.htsoft.core.engine.MailEngine;
import com.htsoft.core.web.paging.PagingBean;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.ServletActionContext;
import org.springframework.mail.MailSender;

public class BaseAction
{
  public static final String SUCCESS = "success";
  public static final String INPUT = "input";
  private String successResultValue = "/jsonString.jsp";
  public static final String JSON_SUCCESS = "{success:true}";
  protected String dir;
  protected String sort;
  protected Integer limit = Integer.valueOf(25);
  protected Integer start = Integer.valueOf(0);
  protected String jsonString = "{success:true}";
  private static final long serialVersionUID = 1L;
  protected final transient Log logger = LogFactory.getLog(getClass());
  protected MailEngine mailEngine;
  protected MailSender mailSender;
  public final String CANCEL = "cancel";
  public final String VIEW = "view";

  public String getSuccessResultValue()
  {
    return this.successResultValue;
  }

  public void setSuccessResultValue(String paramString)
  {
    this.successResultValue = paramString;
  }

  public void setJsonString(String paramString)
  {
    this.jsonString = paramString;
  }

  public String getJsonString()
  {
    return this.jsonString;
  }

  protected HttpServletRequest getRequest()
  {
    return ServletActionContext.getRequest();
  }

  protected HttpServletResponse getResponse()
  {
    return ServletActionContext.getResponse();
  }

  protected HttpSession getSession()
  {
    return getRequest().getSession();
  }

  protected PagingBean getInitPagingBean()
  {
    PagingBean localPagingBean = new PagingBean(this.start.intValue(), this.limit.intValue());
    return localPagingBean;
  }

  public void setMailEngine(MailEngine paramMailEngine)
  {
    this.mailEngine = paramMailEngine;
  }

  public MailEngine getMailEngine()
  {
    return this.mailEngine;
  }

  public String list()
  {
    return "success";
  }

  public String edit()
  {
    return "input";
  }

  public String save()
  {
    return "input";
  }

  public String delete()
  {
    return "success";
  }

  public String multiDelete()
  {
    return "success";
  }

  public String multiSave()
  {
    return "success";
  }

  public String getDir()
  {
    return this.dir;
  }

  public void setDir(String paramString)
  {
    this.dir = paramString;
  }

  public String getSort()
  {
    return this.sort;
  }

  public void setSort(String paramString)
  {
    this.sort = paramString;
  }

  public Integer getLimit()
  {
    return this.limit;
  }

  public void setLimit(Integer paramInteger)
  {
    this.limit = paramInteger;
  }

  public Integer getStart()
  {
    return this.start;
  }

  public void setStart(Integer paramInteger)
  {
    this.start = paramInteger;
  }

  public String execute()
    throws Exception
  {
    HttpServletRequest localHttpServletRequest = getRequest();
    String str1 = localHttpServletRequest.getRequestURI();
    String str2 = str1.substring(localHttpServletRequest.getContextPath().length());
    str2 = str2.replace(".do", ".jsp");
    str2 = "/pages" + str2;
    if (this.logger.isInfoEnabled())
      this.logger.info("forward url:" + str2);
    setSuccessResultValue(str2);
    return "success";
  }

  public String gsonFormat(List paramList, int paramInt, boolean paramBoolean)
  {
    StringBuffer localStringBuffer = new StringBuffer("{success:true,'totalCounts':").append(paramInt).append(",result:");
    Gson localGson = null;
    if (paramBoolean)
      localGson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    else
      localGson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
    localStringBuffer.append(localGson.toJson(paramList));
    localStringBuffer.append("}");
    return localStringBuffer.toString();
  }

  public String gsonFormat(List paramList, int paramInt)
  {
    return gsonFormat(paramList, paramInt, false);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.web.action.BaseAction
 * JD-Core Version:    0.6.0
 */