package com.htsoft.core.web.servlet;

import com.htsoft.core.util.AppUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.util.FileUtil;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.FileAttach;
import com.htsoft.oa.service.system.FileAttachService;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipFile;

public class JasperUploadServlet extends HttpServlet
{
  private Log logger = LogFactory.getLog(FileUploadServlet.class);
  private ServletConfig servletConfig = null;
  private FileAttachService fileAttachService = (FileAttachService)AppUtil.getBean("fileAttachService");
  private String uploadPath = "";
  private String tempPath = "";
  private String fileCat = "others";
  private String filePath = "";

  protected void doPost(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
    throws ServletException, IOException
  {
    paramHttpServletRequest.setCharacterEncoding("UTF-8");
    paramHttpServletResponse.setCharacterEncoding("UTF-8");
    String str1 = paramHttpServletRequest.getParameter("extractZip");
    try
    {
      DiskFileItemFactory localDiskFileItemFactory = new DiskFileItemFactory();
      localDiskFileItemFactory.setSizeThreshold(4096);
      localDiskFileItemFactory.setRepository(new File(this.tempPath));
      ServletFileUpload localServletFileUpload = new ServletFileUpload(localDiskFileItemFactory);
      List localList = localServletFileUpload.parseRequest(paramHttpServletRequest);
      Iterator localIterator = localList.iterator();
      FileItem localFileItem;
      while (localIterator.hasNext())
      {
        localFileItem = (FileItem)localIterator.next();
        if ("file_cat".equals(localFileItem.getFieldName()))
          this.fileCat = localFileItem.getString();
        if ("file_path".equals(localFileItem.getFieldName()))
          this.filePath = localFileItem.getString();
      }
      localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        localFileItem = (FileItem)localIterator.next();
        String str2 = localFileItem.getContentType();
        if ((str2 == null) || (localFileItem.getContentType() == null))
          continue;
        String str3 = localFileItem.getName();
        int i = str3.lastIndexOf("\\");
        String str4 = str3.substring(i + 1);
        String str5 = null;
        String str6 = FileUtil.generateFilename(str4);
        int j = str6.lastIndexOf("/");
        int k = str6.lastIndexOf(".");
        String str7 = str6.substring(j + 1, k);
        str6 = str6.substring(0, j) + "/" + str7 + "/" + str6.substring(j + 1, str6.length());
        if (!"".equals(this.filePath))
          str5 = this.filePath;
        else
          str5 = this.fileCat + "/" + str6;
        int m = str5.lastIndexOf("/");
        File localFile1 = new File(this.uploadPath + "/" + str5.substring(0, m + 1));
        if (!localFile1.exists())
          localFile1.mkdirs();
        File localFile2 = new File(this.uploadPath + "/" + str5);
        localFileItem.write(localFile2);
        if (str2.equals("application/zip"))
        {
          localObject1 = new byte[1024];
          ZipFile localZipFile = new ZipFile(localFile2);
          Enumeration localEnumeration = localZipFile.getEntries();
          ZipEntry localZipEntry = null;
          while (localEnumeration.hasMoreElements())
          {
            localZipEntry = (ZipEntry)localEnumeration.nextElement();
            if (localZipEntry.getName().endsWith(".jasper"))
            {
              int i2 = str5.lastIndexOf("/");
              str5 = str5.substring(0, i2);
              str5 = str5 + "/" + localZipEntry.getName();
            }
            File localFile3 = new File(localFile1 + "/" + localZipEntry.getName());
            if (localZipEntry.isDirectory())
            {
              localFile3.mkdirs();
            }
            else
            {
              if (!localFile3.getParentFile().exists())
                localFile3.getParentFile().mkdirs();
              FileOutputStream localFileOutputStream = new FileOutputStream(localFile3);
              InputStream localInputStream = localZipFile.getInputStream(localZipEntry);
              int n;
              while ((n = localInputStream.read(localObject1)) > 0)
                localFileOutputStream.write(localObject1, 0, n);
              localFileOutputStream.close();
              localInputStream.close();
            }
          }
          localZipFile.close();
          localFile2.delete();
        }
        Object localObject1 = null;
        if (!"".equals(this.filePath))
          localObject1 = this.fileAttachService.getByPath(this.filePath);
        if (localObject1 == null)
        {
          this.logger.debug("relativeFullPath=" + str5);
          localObject1 = new FileAttach();
          ((FileAttach)localObject1).setCreatetime(new Date());
          localObject2 = ContextUtil.getCurrentUser();
          if (localObject2 != null)
            ((FileAttach)localObject1).setCreator(((AppUser)localObject2).getFullname());
          else
            ((FileAttach)localObject1).setCreator("UNKown");
          int i1 = str4.lastIndexOf(".");
          ((FileAttach)localObject1).setExt(str4.substring(i1 + 1));
          ((FileAttach)localObject1).setFileName(str4);
          ((FileAttach)localObject1).setFilePath(str5);
          ((FileAttach)localObject1).setFileType(this.fileCat);
          ((FileAttach)localObject1).setNote(localFileItem.getSize() + " bytes");
          ((FileAttach)localObject1).setTotalBytes(Long.valueOf(localFileItem.getSize()));
          this.fileAttachService.save(localObject1);
        }
        Object localObject2 = new StringBuffer("{success:true");
        ((StringBuffer)localObject2).append(",fileId:").append(((FileAttach)localObject1).getFileId()).append(",fileName:'").append(((FileAttach)localObject1).getFileName()).append("',filePath:'").append(((FileAttach)localObject1).getFilePath()).append("',message:'upload file success.(" + localFileItem.getSize() + " bytes)'");
        ((StringBuffer)localObject2).append("}");
        paramHttpServletResponse.setContentType("text/html;charset=UTF-8");
        PrintWriter localPrintWriter = paramHttpServletResponse.getWriter();
        localPrintWriter.println(((StringBuffer)localObject2).toString());
      }
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      paramHttpServletResponse.getWriter().write("{'success':false,'message':'error..." + localException.getMessage() + "'}");
    }
  }

  public static String make8859toGB(String paramString)
  {
    try
    {
      String str = new String(paramString.getBytes("8859_1"), "GB2312");
      return str;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      localUnsupportedEncodingException.printStackTrace();
    }
    return paramString;
  }

  public void init(ServletConfig paramServletConfig)
    throws ServletException
  {
    super.init(paramServletConfig);
    this.servletConfig = paramServletConfig;
  }

  public void init()
    throws ServletException
  {
    this.uploadPath = getServletContext().getRealPath("/attachFiles/");
    File localFile1 = new File(this.uploadPath);
    if (!localFile1.exists())
      localFile1.mkdirs();
    this.tempPath = (this.uploadPath + "/temp");
    File localFile2 = new File(this.tempPath);
    if (!localFile2.exists())
      localFile2.mkdirs();
  }

  public boolean saveFileToDisk(String paramString)
  {
    File localFile = null;
    Object localObject = null;
    int i = 1;
    try
    {
      if ((!"".equalsIgnoreCase(paramString)) && (localObject != null))
      {
        localFile = new File(this.uploadPath + paramString);
        localObject.write(localFile);
      }
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      i = 0;
    }
    return i;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.web.servlet.JasperUploadServlet
 * JD-Core Version:    0.6.0
 */