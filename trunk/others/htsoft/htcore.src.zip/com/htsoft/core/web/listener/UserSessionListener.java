package com.htsoft.core.web.listener;

import com.htsoft.core.util.AppUtil;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

public class UserSessionListener
  implements HttpSessionListener
{
  public void sessionCreated(HttpSessionEvent paramHttpSessionEvent)
  {
  }

  public void sessionDestroyed(HttpSessionEvent paramHttpSessionEvent)
  {
    String str = paramHttpSessionEvent.getSession().getId();
    AppUtil.removeOnlineUser(str);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.web.listener.UserSessionListener
 * JD-Core Version:    0.6.0
 */