package com.htsoft.core.web.paging;

public class PagingBean
{
  public static final String PAGING_BEAN = "_paging_bean";
  public static Integer DEFAULT_PAGE_SIZE = Integer.valueOf(25);
  public static final int SHOW_PAGES = 6;
  public Integer start;
  private Integer pageSize;
  private Integer totalItems;

  public PagingBean(int paramInt1, int paramInt2)
  {
    this.pageSize = Integer.valueOf(paramInt2);
    this.start = Integer.valueOf(paramInt1);
  }

  public Integer getPageSize()
  {
    return this.pageSize;
  }

  public void setPageSize(int paramInt)
  {
    this.pageSize = Integer.valueOf(paramInt);
  }

  public int getTotalItems()
  {
    return this.totalItems.intValue();
  }

  public Integer getStart()
  {
    return this.start;
  }

  public void setStart(Integer paramInteger)
  {
    this.start = paramInteger;
  }

  public void setTotalItems(Integer paramInteger)
  {
    this.totalItems = paramInteger;
  }

  public void setTotalItems(int paramInt)
  {
    this.totalItems = Integer.valueOf(paramInt);
  }

  public int getFirstResult()
  {
    return this.start.intValue();
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.web.paging.PagingBean
 * JD-Core Version:    0.6.0
 */