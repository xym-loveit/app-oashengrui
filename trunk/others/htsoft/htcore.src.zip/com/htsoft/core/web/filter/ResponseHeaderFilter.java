package com.htsoft.core.web.filter;

import java.io.IOException;
import java.util.Enumeration;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

public class ResponseHeaderFilter
  implements Filter
{
  private FilterConfig fc;

  public void doFilter(ServletRequest paramServletRequest, ServletResponse paramServletResponse, FilterChain paramFilterChain)
    throws IOException, ServletException
  {
    HttpServletResponse localHttpServletResponse = (HttpServletResponse)paramServletResponse;
    Enumeration localEnumeration = this.fc.getInitParameterNames();
    while (localEnumeration.hasMoreElements())
    {
      String str = (String)localEnumeration.nextElement();
      localHttpServletResponse.addHeader(str, this.fc.getInitParameter(str));
    }
    paramFilterChain.doFilter(paramServletRequest, localHttpServletResponse);
  }

  public void init(FilterConfig paramFilterConfig)
  {
    this.fc = paramFilterConfig;
  }

  public void destroy()
  {
    this.fc = null;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.web.filter.ResponseHeaderFilter
 * JD-Core Version:    0.6.0
 */