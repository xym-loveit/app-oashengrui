package com.htsoft.core.web.servlet;

import com.htsoft.core.util.AppUtil;
import com.htsoft.core.util.ContextUtil;
import com.htsoft.core.util.FileUtil;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.FileAttach;
import com.htsoft.oa.service.system.FileAttachService;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class FileUploadServlet extends HttpServlet
{
  private Log logger = LogFactory.getLog(FileUploadServlet.class);
  private ServletConfig servletConfig = null;
  private FileAttachService fileAttachService = (FileAttachService)AppUtil.getBean("fileAttachService");
  private String uploadPath = "";
  private String tempPath = "";
  private String fileCat = "others";

  protected void doPost(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
    throws ServletException, IOException
  {
    String str1 = "";
    String str2 = "";
    paramHttpServletRequest.setCharacterEncoding("UTF-8");
    paramHttpServletResponse.setCharacterEncoding("UTF-8");
    try
    {
      DiskFileItemFactory localDiskFileItemFactory = new DiskFileItemFactory();
      localDiskFileItemFactory.setSizeThreshold(4096);
      localDiskFileItemFactory.setRepository(new File(this.tempPath));
      ServletFileUpload localServletFileUpload = new ServletFileUpload(localDiskFileItemFactory);
      List localList = localServletFileUpload.parseRequest(paramHttpServletRequest);
      Iterator localIterator = localList.iterator();
      FileItem localFileItem;
      while (localIterator.hasNext())
      {
        localFileItem = (FileItem)localIterator.next();
        if ("file_cat".equals(localFileItem.getFieldName()))
          this.fileCat = localFileItem.getString();
        if ("file_path".equals(localFileItem.getFieldName()))
          str1 = localFileItem.getString();
        if ("fileId".equals(localFileItem.getFieldName()))
          str2 = localFileItem.getString();
      }
      this.logger.info("fileId:" + str2);
      localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        localFileItem = (FileItem)localIterator.next();
        if (localFileItem.getContentType() == null)
          continue;
        String str3 = localFileItem.getName();
        int i = str3.lastIndexOf("\\");
        String str4 = str3.substring(i + 1);
        String str5 = null;
        if (!"".equals(str1))
        {
          str5 = str1;
        }
        else if (!"".equals(str2))
        {
          FileAttach localFileAttach1 = (FileAttach)this.fileAttachService.get(new Long(str2));
          str5 = localFileAttach1.getFilePath();
          this.logger.info("exist filePath:" + str5);
        }
        else
        {
          str5 = this.fileCat + "/" + FileUtil.generateFilename(str4);
        }
        int j = str5.lastIndexOf("/");
        File localFile = new File(this.uploadPath + "/" + str5.substring(0, j + 1));
        if (!localFile.exists())
          localFile.mkdirs();
        localFileItem.write(new File(this.uploadPath + "/" + str5));
        FileAttach localFileAttach2 = null;
        if (!"".equals(str1))
        {
          localFileAttach2 = this.fileAttachService.getByPath(str1);
          localFileAttach2.setTotalBytes(Long.valueOf(localFileItem.getSize()));
          localFileAttach2.setNote(getStrFileSize(localFileItem.getSize()));
          this.fileAttachService.save(localFileAttach2);
        }
        if (!"".equals(str2))
        {
          localFileAttach2 = (FileAttach)this.fileAttachService.get(new Long(str2));
          localFileAttach2.setTotalBytes(Long.valueOf(localFileItem.getSize()));
          localFileAttach2.setNote(getStrFileSize(localFileItem.getSize()));
          this.fileAttachService.save(localFileAttach2);
        }
        if (localFileAttach2 == null)
        {
          localFileAttach2 = new FileAttach();
          localFileAttach2.setCreatetime(new Date());
          localObject = ContextUtil.getCurrentUser();
          if (localObject != null)
          {
            localFileAttach2.setCreator(((AppUser)localObject).getFullname());
            localFileAttach2.setCreatorId(((AppUser)localObject).getUserId());
          }
          else
          {
            localFileAttach2.setCreator("UNKown");
          }
          int k = str4.lastIndexOf(".");
          localFileAttach2.setExt(str4.substring(k + 1));
          localFileAttach2.setFileName(str4);
          localFileAttach2.setFilePath(str5);
          localFileAttach2.setFileType(this.fileCat);
          localFileAttach2.setTotalBytes(Long.valueOf(localFileItem.getSize()));
          localFileAttach2.setNote(getStrFileSize(localFileItem.getSize()));
          localFileAttach2.setCreatorId(ContextUtil.getCurrentUserId());
          localFileAttach2.setDelFlag(FileAttach.FLAG_NOT_DEL);
          this.fileAttachService.save(localFileAttach2);
        }
        Object localObject = new StringBuffer("{success:true");
        ((StringBuffer)localObject).append(",fileId:").append(localFileAttach2.getFileId()).append(",fileName:'").append(localFileAttach2.getFileName()).append("',filePath:'").append(localFileAttach2.getFilePath()).append("',message:'upload file success.(" + localFileItem.getSize() + " bytes)'");
        ((StringBuffer)localObject).append("}");
        paramHttpServletResponse.setContentType("text/html;charset=UTF-8");
        PrintWriter localPrintWriter = paramHttpServletResponse.getWriter();
        localPrintWriter.println(((StringBuffer)localObject).toString());
      }
    }
    catch (Exception localException)
    {
      paramHttpServletResponse.getWriter().write("{'success':false,'message':'error..." + localException.getMessage() + "'}");
    }
  }

  public void init(ServletConfig paramServletConfig)
    throws ServletException
  {
    super.init(paramServletConfig);
    this.servletConfig = paramServletConfig;
  }

  public void init()
    throws ServletException
  {
    this.uploadPath = getServletContext().getRealPath("/attachFiles/");
    File localFile1 = new File(this.uploadPath);
    if (!localFile1.exists())
      localFile1.mkdirs();
    this.tempPath = (this.uploadPath + "/temp");
    File localFile2 = new File(this.tempPath);
    if (!localFile2.exists())
      localFile2.mkdirs();
  }

  public boolean saveFileToDisk(String paramString)
  {
    File localFile = null;
    Object localObject = null;
    int i = 1;
    try
    {
      if ((!"".equalsIgnoreCase(paramString)) && (localObject != null))
      {
        localFile = new File(this.uploadPath + paramString);
        localObject.write(localFile);
      }
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      i = 0;
    }
    return i;
  }

  private String getStrFileSize(double paramDouble)
  {
    DecimalFormat localDecimalFormat = new DecimalFormat("0.00");
    double d;
    if (paramDouble > 1048576.0D)
    {
      d = paramDouble / 1048576.0D;
      return localDecimalFormat.format(d) + " M";
    }
    if (paramDouble > 1024.0D)
    {
      d = paramDouble / 1024.0D;
      return localDecimalFormat.format(d) + " KB";
    }
    return paramDouble + " bytes";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.web.servlet.FileUploadServlet
 * JD-Core Version:    0.6.0
 */