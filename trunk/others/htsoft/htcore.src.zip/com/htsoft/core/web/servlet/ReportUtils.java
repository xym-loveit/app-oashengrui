package com.htsoft.core.web.servlet;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import net.sf.jasperreports.engine.JRAbstractExporter;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JExcelApiExporter;
import net.sf.jasperreports.engine.export.JRHtmlExporter;
import net.sf.jasperreports.engine.export.JRHtmlExporterParameter;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRRtfExporter;
import net.sf.jasperreports.engine.export.JRXmlExporter;
import net.sf.jasperreports.engine.util.JRLoader;

public class ReportUtils
{
  private HttpServletRequest request;
  private HttpServletResponse response;
  private HttpSession session;

  public ReportUtils(HttpServletRequest paramHttpServletRequest)
  {
    this.request = paramHttpServletRequest;
    this.session = paramHttpServletRequest.getSession();
  }

  public ReportUtils(HttpServletResponse paramHttpServletResponse)
  {
    this.response = paramHttpServletResponse;
  }

  public ReportUtils(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
  {
    this(paramHttpServletRequest);
    this.response = paramHttpServletResponse;
  }

  public JasperPrint getJasperPrint(String paramString, Map paramMap, JRDataSource paramJRDataSource)
    throws JRException
  {
    JasperReport localJasperReport = null;
    try
    {
      localJasperReport = (JasperReport)JRLoader.loadObject(paramString);
      return JasperFillManager.fillReport(localJasperReport, paramMap, paramJRDataSource);
    }
    catch (JRException localJRException)
    {
      localJRException.printStackTrace();
    }
    return null;
  }

  public JasperPrint getPrintWithBeanList(String paramString, Map paramMap, List paramList)
    throws JRException
  {
    JRBeanCollectionDataSource localJRBeanCollectionDataSource = new JRBeanCollectionDataSource(paramList);
    return getJasperPrint(paramString, paramMap, localJRBeanCollectionDataSource);
  }

  public JRAbstractExporter getJRExporter(DocType paramDocType)
  {
    Object localObject = null;
    switch (1.$SwitchMap$com$htsoft$core$web$servlet$ReportUtils$DocType[paramDocType.ordinal()])
    {
    case 1:
      localObject = new JRPdfExporter();
      break;
    case 2:
      localObject = new JRHtmlExporter();
      break;
    case 3:
      localObject = new JExcelApiExporter();
      break;
    case 4:
      localObject = new JRXmlExporter();
      break;
    case 5:
      localObject = new JRRtfExporter();
    }
    return (JRAbstractExporter)localObject;
  }

  public void setAttrToPage(JasperPrint paramJasperPrint, String paramString1, String paramString2)
  {
    this.session.setAttribute("REPORT_JASPERPRINT", paramJasperPrint);
    this.session.setAttribute("REPORT_FILENAME", paramString1);
    this.session.setAttribute("REPORT_TYPE", paramString2);
  }

  public void complieJaxml(String paramString1, String paramString2)
    throws JRException
  {
    JasperCompileManager.compileReportToFile(paramString1, paramString2);
  }

  public void servletExportPDF(String paramString1, Map paramMap, List paramList, String paramString2)
    throws JRException, IOException, ServletException
  {
    servletExportDocument(DocType.PDF, paramString1, paramMap, paramList, paramString2);
  }

  public void servletExportHTML(String paramString1, Map paramMap, List paramList, String paramString2)
    throws JRException, IOException, ServletException
  {
    this.response.setContentType("text/html");
    this.response.setCharacterEncoding("UTF-8");
    JRAbstractExporter localJRAbstractExporter = getJRExporter(DocType.HTML);
    JasperPrint localJasperPrint = getPrintWithBeanList(paramString1, paramMap, paramList);
    this.session.setAttribute("net.sf.jasperreports.j2ee.jasper_print", localJasperPrint);
    PrintWriter localPrintWriter = this.response.getWriter();
    localJRAbstractExporter.setParameter(JRExporterParameter.JASPER_PRINT, localJasperPrint);
    localJRAbstractExporter.setParameter(JRExporterParameter.OUTPUT_WRITER, localPrintWriter);
    localJRAbstractExporter.setParameter(JRHtmlExporterParameter.IMAGES_URI, paramString2);
    localJRAbstractExporter.exportReport();
  }

  public void servletExportExcel(String paramString1, Map paramMap, List paramList, String paramString2)
    throws JRException, IOException, ServletException
  {
    servletExportDocument(DocType.XLS, paramString1, paramMap, paramList, paramString2);
  }

  public void servletExportDocument(DocType paramDocType, String paramString1, Map paramMap, List paramList, String paramString2)
    throws JRException, IOException, ServletException
  {
    if (paramDocType == DocType.HTML)
    {
      servletExportHTML(paramString1, paramMap, paramList, paramString2);
      return;
    }
    JRAbstractExporter localJRAbstractExporter = getJRExporter(paramDocType);
    String str1 = paramDocType.toString().toLowerCase();
    if (!paramString2.toLowerCase().endsWith(str1))
      paramString2 = paramString2 + "." + str1;
    String str2 = "application/";
    if (str1.equals("xls"))
      str1 = "excel";
    else if (str1.equals("xml"))
      str2 = "text/";
    str2 = str2 + str1;
    this.response.setContentType(str2);
    this.response.setHeader("Content-Disposition", "attachment; filename=\"" + URLEncoder.encode(paramString2, "UTF-8") + "\"");
    localJRAbstractExporter.setParameter(JRExporterParameter.JASPER_PRINT, getPrintWithBeanList(paramString1, paramMap, paramList));
    ServletOutputStream localServletOutputStream = this.response.getOutputStream();
    localJRAbstractExporter.setParameter(JRExporterParameter.OUTPUT_STREAM, localServletOutputStream);
    try
    {
      localJRAbstractExporter.exportReport();
    }
    catch (JRException localJRException)
    {
      throw new ServletException(localJRException);
    }
    finally
    {
      if (localServletOutputStream != null)
        try
        {
          localServletOutputStream.close();
        }
        catch (IOException localIOException2)
        {
        }
    }
  }

  public static enum DocType
  {
    PDF, HTML, XLS, XML, RTF;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.web.servlet.ReportUtils
 * JD-Core Version:    0.6.0
 */