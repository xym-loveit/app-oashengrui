package com.htsoft.core.security;

import com.htsoft.oa.model.system.AppRole;
import com.htsoft.oa.service.system.AppRoleService;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class SecurityDataSource
{
  private AppRoleService appRoleService;
  private HashSet<String> anonymousUrls = null;
  private HashSet<String> publicUrls = null;

  public void setAppRoleService(AppRoleService paramAppRoleService)
  {
    this.appRoleService = paramAppRoleService;
  }

  public Set<String> getAnonymousUrls()
  {
    return this.anonymousUrls;
  }

  public void setAnonymousUrls(Set<String> paramSet)
  {
    this.anonymousUrls = ((HashSet)paramSet);
  }

  public HashSet<String> getPublicUrls()
  {
    return this.publicUrls;
  }

  public void setPublicUrls(HashSet<String> paramHashSet)
  {
    this.publicUrls = paramHashSet;
  }

  public HashMap<String, Set<String>> getDataSource()
  {
    HashMap localHashMap = this.appRoleService.getSecurityDataSource();
    localHashMap.put(AppRole.ROLE_ANONYMOUS, this.anonymousUrls);
    localHashMap.put(AppRole.ROLE_PUBLIC, this.publicUrls);
    return localHashMap;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.security.SecurityDataSource
 * JD-Core Version:    0.6.0
 */