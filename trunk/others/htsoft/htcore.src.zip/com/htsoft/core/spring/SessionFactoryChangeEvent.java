package com.htsoft.core.spring;

import org.springframework.context.ApplicationEvent;

public class SessionFactoryChangeEvent extends ApplicationEvent
{
  private static final long serialVersionUID = 1L;

  public SessionFactoryChangeEvent(Object paramObject)
  {
    super(paramObject);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.spring.SessionFactoryChangeEvent
 * JD-Core Version:    0.6.0
 */