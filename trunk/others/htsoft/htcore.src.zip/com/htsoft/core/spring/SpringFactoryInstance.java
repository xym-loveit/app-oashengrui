package com.htsoft.core.spring;

import flex.messaging.FactoryInstance;
import flex.messaging.FlexContext;
import flex.messaging.FlexFactory;
import flex.messaging.config.ConfigMap;
import javax.servlet.ServletConfig;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class SpringFactoryInstance extends FactoryInstance
{
  private Log log = LogFactory.getLog(getClass());

  SpringFactoryInstance(FlexFactory paramFlexFactory, String paramString, ConfigMap paramConfigMap)
  {
    super(paramFlexFactory, paramString, paramConfigMap);
  }

  public Object lookup()
  {
    WebApplicationContext localWebApplicationContext = WebApplicationContextUtils.getRequiredWebApplicationContext(FlexContext.getServletConfig().getServletContext());
    String str = getSource();
    try
    {
      this.log.info("Lookup bean from Spring ApplicationContext: " + str);
    }
    catch (NoSuchBeanDefinitionException localNoSuchBeanDefinitionException)
    {
    }
    catch (BeansException localBeansException)
    {
    }
    catch (Exception localException)
    {
    }
    return localWebApplicationContext.getBean(str);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.spring.SpringFactoryInstance
 * JD-Core Version:    0.6.0
 */