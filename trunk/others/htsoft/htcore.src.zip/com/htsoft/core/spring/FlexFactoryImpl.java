package com.htsoft.core.spring;

import flex.messaging.FactoryInstance;
import flex.messaging.FlexFactory;
import flex.messaging.config.ConfigMap;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class FlexFactoryImpl
  implements FlexFactory
{
  private Log log = LogFactory.getLog(getClass());

  public FactoryInstance createFactoryInstance(String paramString, ConfigMap paramConfigMap)
  {
    this.log.info("Create FactoryInstance.");
    SpringFactoryInstance localSpringFactoryInstance = new SpringFactoryInstance(this, paramString, paramConfigMap);
    localSpringFactoryInstance.setSource(paramConfigMap.getPropertyAsString("source", localSpringFactoryInstance.getId()));
    return localSpringFactoryInstance;
  }

  public Object lookup(FactoryInstance paramFactoryInstance)
  {
    this.log.info("Lookup service object.");
    return paramFactoryInstance.lookup();
  }

  public void initialize(String paramString, ConfigMap paramConfigMap)
  {
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.spring.FlexFactoryImpl
 * JD-Core Version:    0.6.0
 */