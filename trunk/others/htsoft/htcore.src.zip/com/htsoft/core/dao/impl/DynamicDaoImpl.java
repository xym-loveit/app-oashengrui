package com.htsoft.core.dao.impl;

import com.htsoft.core.command.CriteriaCommand;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.command.SortCommandImpl;
import com.htsoft.core.dao.DynamicDao;
import com.htsoft.core.web.paging.PagingBean;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.hql.ast.QueryTranslatorImpl;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class DynamicDaoImpl
  implements DynamicDao
{
  private String entityClassName;
  private SessionFactory sessionFactory;
  private HibernateTemplate hibernateTemplate;

  public DynamicDaoImpl(String paramString)
  {
    this.entityClassName = paramString;
  }

  public DynamicDaoImpl()
  {
  }

  public String getEntityClassName()
  {
    return this.entityClassName;
  }

  public void setEntityClassName(String paramString)
  {
    this.entityClassName = paramString;
  }

  public SessionFactory getSessionFactory()
  {
    return this.sessionFactory;
  }

  public void setSessionFactory(SessionFactory paramSessionFactory)
  {
    this.sessionFactory = paramSessionFactory;
  }

  public HibernateTemplate getHibernateTemplate()
  {
    if (this.hibernateTemplate == null)
      this.hibernateTemplate = new HibernateTemplate(this.sessionFactory);
    return this.hibernateTemplate;
  }

  public void setHibernateTemplate(HibernateTemplate paramHibernateTemplate)
  {
    this.hibernateTemplate = paramHibernateTemplate;
  }

  public Object save(Object paramObject)
  {
    getHibernateTemplate().save(this.entityClassName, paramObject);
    return paramObject;
  }

  public Object merge(Object paramObject)
  {
    getHibernateTemplate().merge(this.entityClassName, paramObject);
    return paramObject;
  }

  public Object get(Serializable paramSerializable)
  {
    return getHibernateTemplate().load(this.entityClassName, paramSerializable);
  }

  public void remove(Serializable paramSerializable)
  {
    getHibernateTemplate().delete(this.entityClassName, get(paramSerializable));
  }

  public void remove(Object paramObject)
  {
    getHibernateTemplate().delete(this.entityClassName, paramObject);
  }

  public void evict(Object paramObject)
  {
    getHibernateTemplate().evict(paramObject);
  }

  public Long getTotalItems(String paramString, Object[] paramArrayOfObject)
  {
    int i = paramString.toUpperCase().indexOf(" ORDER BY ");
    if (i != -1)
      paramString = paramString.substring(0, i);
    QueryTranslatorImpl localQueryTranslatorImpl = new QueryTranslatorImpl(paramString, paramString, Collections.EMPTY_MAP, (SessionFactoryImplementor)getSessionFactory());
    localQueryTranslatorImpl.compile(Collections.EMPTY_MAP, false);
    String str = "select count(1) from (" + localQueryTranslatorImpl.getSQLString() + ") tmp_count_t";
    Object localObject = getHibernateTemplate().execute(new HibernateCallback(str, paramArrayOfObject)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        SQLQuery localSQLQuery = paramSession.createSQLQuery(this.val$sql);
        if (this.val$values != null)
          for (int i = 0; i < this.val$values.length; i++)
            localSQLQuery.setParameter(i, this.val$values[i]);
        return localSQLQuery.uniqueResult();
      }
    });
    return new Long(localObject.toString());
  }

  public List<Object> getAll()
  {
    return (List)getHibernateTemplate().execute(new HibernateCallback()
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        String str = "from " + DynamicDaoImpl.this.entityClassName;
        Query localQuery = paramSession.createQuery(str);
        return localQuery.list();
      }
    });
  }

  public List<Object> getAll(PagingBean paramPagingBean)
  {
    String str = "from " + this.entityClassName;
    int i = getTotalItems(str, null).intValue();
    paramPagingBean.setTotalItems(i);
    return (List)getHibernateTemplate().execute(new HibernateCallback(str, paramPagingBean)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Query localQuery = paramSession.createQuery(this.val$hql);
        localQuery.setFirstResult(this.val$pb.getFirstResult()).setFetchSize(this.val$pb.getPageSize().intValue());
        localQuery.setMaxResults(this.val$pb.getPageSize().intValue());
        return localQuery.list();
      }
    });
  }

  public List<Object> getAll(QueryFilter paramQueryFilter)
  {
    int i = getCountByFilter(paramQueryFilter);
    paramQueryFilter.getPagingBean().setTotalItems(i);
    List localList = (List)getHibernateTemplate().execute(new HibernateCallback(paramQueryFilter)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Criteria localCriteria = paramSession.createCriteria(DynamicDaoImpl.this.entityClassName);
        this.val$queryFilter.getAliasSet().clear();
        DynamicDaoImpl.this.setCriteriaByQueryFilter(localCriteria, this.val$queryFilter);
        return localCriteria.list();
      }
    });
    return localList;
  }

  protected int getCountByFilter(QueryFilter paramQueryFilter)
  {
    Object localObject = getHibernateTemplate().execute(new HibernateCallback(paramQueryFilter)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Criteria localCriteria = paramSession.createCriteria(DynamicDaoImpl.this.entityClassName);
        for (int i = 0; i < this.val$filter.getCommands().size(); i++)
        {
          CriteriaCommand localCriteriaCommand = (CriteriaCommand)this.val$filter.getCommands().get(i);
          if ((localCriteriaCommand instanceof SortCommandImpl))
            continue;
          localCriteria = localCriteriaCommand.execute(localCriteria);
        }
        localCriteria.setProjection(Projections.rowCount());
        return localCriteria.uniqueResult();
      }
    });
    if (localObject == null)
      return new Integer(0).intValue();
    return new Integer(localObject.toString()).intValue();
  }

  private Criteria setCriteriaByQueryFilter(Criteria paramCriteria, QueryFilter paramQueryFilter)
  {
    for (int i = 0; i < paramQueryFilter.getCommands().size(); i++)
      paramCriteria = ((CriteriaCommand)paramQueryFilter.getCommands().get(i)).execute(paramCriteria);
    paramCriteria.setFirstResult(paramQueryFilter.getPagingBean().getFirstResult());
    paramCriteria.setMaxResults(paramQueryFilter.getPagingBean().getPageSize().intValue());
    return paramCriteria;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.dao.impl.DynamicDaoImpl
 * JD-Core Version:    0.6.0
 */