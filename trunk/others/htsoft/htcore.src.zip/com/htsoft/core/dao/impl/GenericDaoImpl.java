package com.htsoft.core.dao.impl;

import com.htsoft.core.command.CriteriaCommand;
import com.htsoft.core.command.FieldCommandImpl;
import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.command.SortCommandImpl;
import com.htsoft.core.dao.GenericDao;
import com.htsoft.core.web.paging.PagingBean;
import java.io.Serializable;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.hql.ast.QueryTranslatorImpl;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public abstract class GenericDaoImpl<T, PK extends Serializable> extends HibernateDaoSupport
  implements GenericDao<T, PK>
{
  protected Log logger = LogFactory.getLog(GenericDaoImpl.class);
  protected JdbcTemplate jdbcTemplate;
  protected Class persistType;
  protected Map<String, String> querys = new HashMap();

  public void setJdbcTemplate(JdbcTemplate paramJdbcTemplate)
  {
    this.jdbcTemplate = paramJdbcTemplate;
  }

  public void setPersistType(Class paramClass)
  {
    this.persistType = paramClass;
  }

  public GenericDaoImpl(Class paramClass)
  {
    this.persistType = paramClass;
  }

  public T get(PK paramPK)
  {
    return getHibernateTemplate().get(this.persistType, paramPK);
  }

  public T save(T paramT)
  {
    getHibernateTemplate().saveOrUpdate(paramT);
    return paramT;
  }

  public T merge(T paramT)
  {
    getHibernateTemplate().merge(paramT);
    return paramT;
  }

  public void evict(T paramT)
  {
    getHibernateTemplate().evict(paramT);
  }

  public List find(String paramString, Object[] paramArrayOfObject, int paramInt1, int paramInt2)
  {
    return (List)getHibernateTemplate().execute(new HibernateCallback(paramString, paramArrayOfObject, paramInt2, paramInt1)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Query localQuery = paramSession.createQuery(this.val$queryString);
        if (this.val$values != null)
          for (int i = 0; i < this.val$values.length; i++)
            localQuery.setParameter(i, this.val$values[i]);
        if (this.val$pageSize > 0)
          localQuery.setFirstResult(this.val$firstResult).setMaxResults(this.val$pageSize).setFetchSize(this.val$pageSize);
        return localQuery.list();
      }
    });
  }

  public List<T> getAll()
  {
    return (List)getHibernateTemplate().execute(new HibernateCallback()
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        String str = "from " + GenericDaoImpl.this.persistType.getName();
        Query localQuery = paramSession.createQuery(str);
        return localQuery.list();
      }
    });
  }

  public List<T> getAll(PagingBean paramPagingBean)
  {
    String str = "from " + this.persistType.getName();
    int i = getTotalItems(str, null).intValue();
    paramPagingBean.setTotalItems(i);
    return (List)getHibernateTemplate().execute(new HibernateCallback(str, paramPagingBean)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Query localQuery = paramSession.createQuery(this.val$hql);
        localQuery.setFirstResult(this.val$pb.getFirstResult()).setFetchSize(this.val$pb.getPageSize().intValue());
        localQuery.setMaxResults(this.val$pb.getPageSize().intValue());
        return localQuery.list();
      }
    });
  }

  public Long getTotalItems(String paramString, Object[] paramArrayOfObject)
  {
    int i = paramString.toUpperCase().indexOf(" ORDER BY ");
    if (i != -1)
      paramString = paramString.substring(0, i);
    QueryTranslatorImpl localQueryTranslatorImpl = new QueryTranslatorImpl(paramString, paramString, Collections.EMPTY_MAP, (SessionFactoryImplementor)getSessionFactory());
    localQueryTranslatorImpl.compile(Collections.EMPTY_MAP, false);
    String str = "select count(*) from (" + localQueryTranslatorImpl.getSQLString() + ") tmp_count_t";
    Object localObject = getHibernateTemplate().execute(new HibernateCallback(str, paramArrayOfObject)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        SQLQuery localSQLQuery = paramSession.createSQLQuery(this.val$sql);
        if (this.val$values != null)
          for (int i = 0; i < this.val$values.length; i++)
            localSQLQuery.setParameter(i, this.val$values[i]);
        return localSQLQuery.uniqueResult();
      }
    });
    return new Long(localObject.toString());
  }

  public List<T> findByHql(String paramString, Object[] paramArrayOfObject)
  {
    return (List)getHibernateTemplate().execute(new HibernateCallback(paramString, paramArrayOfObject)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Query localQuery = paramSession.createQuery(this.val$hql);
        if (this.val$objs != null)
          for (int i = 0; i < this.val$objs.length; i++)
            localQuery.setParameter(i, this.val$objs[i]);
        return localQuery.list();
      }
    });
  }

  public List<T> findByHql(String paramString, Object[] paramArrayOfObject, int paramInt1, int paramInt2)
  {
    return (List)getHibernateTemplate().execute(new HibernateCallback(paramString, paramInt1, paramInt2, paramArrayOfObject)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Query localQuery = paramSession.createQuery(this.val$hql);
        localQuery.setFirstResult(this.val$firstResult).setMaxResults(this.val$pageSize);
        if (this.val$objs != null)
          for (int i = 0; i < this.val$objs.length; i++)
            localQuery.setParameter(i, this.val$objs[i]);
        return localQuery.list();
      }
    });
  }

  public List<T> findByHql(String paramString, Object[] paramArrayOfObject, PagingBean paramPagingBean)
  {
    int i = getTotalItems(paramString, paramArrayOfObject).intValue();
    paramPagingBean.setTotalItems(i);
    return findByHql(paramString, paramArrayOfObject, paramPagingBean.getFirstResult(), paramPagingBean.getPageSize().intValue());
  }

  public List find(String paramString, Object[] paramArrayOfObject, PagingBean paramPagingBean)
  {
    int i = getTotalItems(paramString, paramArrayOfObject).intValue();
    paramPagingBean.setTotalItems(i);
    return find(paramString, paramArrayOfObject, paramPagingBean.getFirstResult(), paramPagingBean.getPageSize().intValue());
  }

  public List<T> findByHql(String paramString)
  {
    return findByHql(paramString, null);
  }

  public void remove(PK paramPK)
  {
    getHibernateTemplate().delete(get(paramPK));
  }

  public void remove(T paramT)
  {
    getHibernateTemplate().delete(paramT);
  }

  public Object findUnique(String paramString, Object[] paramArrayOfObject)
  {
    return getHibernateTemplate().execute(new HibernateCallback(paramString, paramArrayOfObject)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Query localQuery = paramSession.createQuery(this.val$hql);
        if (this.val$values != null)
          for (int i = 0; i < this.val$values.length; i++)
            localQuery.setParameter(i, this.val$values[i]);
        return localQuery.uniqueResult();
      }
    });
  }

  public int getCountByFilter(QueryFilter paramQueryFilter)
  {
    Integer localInteger = (Integer)getHibernateTemplate().execute(new HibernateCallback(paramQueryFilter)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Criteria localCriteria = paramSession.createCriteria(GenericDaoImpl.this.persistType);
        for (int i = 0; i < this.val$filter.getCommands().size(); i++)
        {
          CriteriaCommand localCriteriaCommand = (CriteriaCommand)this.val$filter.getCommands().get(i);
          if ((localCriteriaCommand instanceof SortCommandImpl))
            continue;
          localCriteria = localCriteriaCommand.execute(localCriteria);
        }
        localCriteria.setProjection(Projections.rowCount());
        return localCriteria.uniqueResult();
      }
    });
    if (localInteger == null)
      return new Integer(0).intValue();
    return localInteger.intValue();
  }

  public List getAll(QueryFilter paramQueryFilter)
  {
    if (StringUtils.isNotEmpty(paramQueryFilter.getFilterName()))
      return getAll2(paramQueryFilter);
    int i = getCountByFilter(paramQueryFilter);
    paramQueryFilter.getPagingBean().setTotalItems(i);
    List localList = (List)getHibernateTemplate().execute(new HibernateCallback(paramQueryFilter)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Criteria localCriteria = paramSession.createCriteria(GenericDaoImpl.this.persistType);
        this.val$queryFilter.getAliasSet().clear();
        GenericDaoImpl.this.setCriteriaByQueryFilter(localCriteria, this.val$queryFilter);
        return localCriteria.list();
      }
    });
    if (paramQueryFilter.isExport())
    {
      SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyyMMddhhmmssSSS");
      String str = localSimpleDateFormat.format(new Date());
      paramQueryFilter.getRequest().setAttribute("fileName", str);
      paramQueryFilter.getRequest().setAttribute("__exportList", localList);
    }
    return localList;
  }

  public List getAll2(QueryFilter paramQueryFilter)
  {
    String str1 = ((String)this.querys.get(paramQueryFilter.getFilterName())).trim();
    String str2 = null;
    String str3 = null;
    String str4 = null;
    int i = str1.toUpperCase().indexOf(" ORDER BY ");
    int j = str1.toUpperCase().indexOf(" WHERE ");
    if (i < 0)
      i = str1.length();
    if (j < 0)
      j = str1.length();
    if (j < 0)
    {
      str3 = " where 1=1 ";
    }
    else
    {
      str3 = str1.substring(j + 7, i);
      this.logger.debug("condition:" + str3);
      localObject1 = Pattern.compile(" GROUP BY [\\w|.]+");
      Matcher localMatcher = ((Pattern)localObject1).matcher(str3.toUpperCase());
      if (localMatcher.find())
      {
        str4 = str3.substring(localMatcher.start(), localMatcher.end());
        str3 = str3.replace(str4, " ");
      }
      str3 = " where (" + str3 + ")";
    }
    Object localObject1 = "";
    Object localObject2;
    for (int k = 0; k < paramQueryFilter.getCommands().size(); k++)
    {
      localObject2 = (CriteriaCommand)paramQueryFilter.getCommands().get(k);
      if ((localObject2 instanceof FieldCommandImpl))
      {
        str3 = str3 + " and " + ((FieldCommandImpl)localObject2).getPartHql();
      }
      else
      {
        if (!(localObject2 instanceof SortCommandImpl))
          continue;
        if (!"".equals(localObject1))
          localObject1 = (String)localObject1 + ",";
        localObject1 = (String)localObject1 + ((SortCommandImpl)localObject2).getPartHql();
      }
    }
    str2 = str1.substring(0, j);
    if (paramQueryFilter.getAliasSet().size() > 0)
    {
      k = str2.indexOf(" FROM ");
      localObject2 = null;
      if (k > 0)
      {
        str5 = str2.substring(k + 6);
        localObject3 = str5.split("[ ]");
        if ((localObject3.length > 1) && (!localObject3[1].toUpperCase().equals("ORDER")) && (!localObject3[1].toUpperCase().equals("JOIN")))
          localObject2 = localObject3[1];
        if (localObject2 == null)
        {
          localObject2 = "vo";
          str2 = str2.replace(localObject3[0], localObject3[0] + " " + (String)localObject2);
        }
      }
      String str5 = "";
      Object localObject3 = paramQueryFilter.getAliasSet().iterator();
      while (((Iterator)localObject3).hasNext())
      {
        String str6 = (String)((Iterator)localObject3).next();
        str5 = str5 + " join " + (String)localObject2 + "." + str6 + " " + str6;
      }
      if (!"".equals(str5))
        str2 = str2 + str5;
    }
    str2 = str2 + str3;
    if (str4 != null)
      str2 = str2 + str4 + " ";
    if (!"".equals(localObject1))
      str2 = str2 + " order by " + (String)localObject1;
    else
      str2 = str2 + str1.substring(i);
    Object[] arrayOfObject = paramQueryFilter.getParamValueList().toArray();
    int m = getTotalItems(str2, arrayOfObject).intValue();
    paramQueryFilter.getPagingBean().setTotalItems(m);
    if (this.logger.isDebugEnabled())
      this.logger.debug("new hql:" + str2);
    return (List)(List)(List)find(str2, arrayOfObject, paramQueryFilter.getPagingBean().getFirstResult(), paramQueryFilter.getPagingBean().getPageSize().intValue());
  }

  public void flush()
  {
    getHibernateTemplate().flush();
  }

  private Criteria setCriteriaByQueryFilter(Criteria paramCriteria, QueryFilter paramQueryFilter)
  {
    for (int i = 0; i < paramQueryFilter.getCommands().size(); i++)
      paramCriteria = ((CriteriaCommand)paramQueryFilter.getCommands().get(i)).execute(paramCriteria);
    paramCriteria.setFirstResult(paramQueryFilter.getPagingBean().getFirstResult());
    paramCriteria.setMaxResults(paramQueryFilter.getPagingBean().getPageSize().intValue());
    return paramCriteria;
  }

  public void setQuerys(Map<String, String> paramMap)
  {
    this.querys = paramMap;
  }

  public Long update(String paramString, Object[] paramArrayOfObject)
  {
    return (Long)getHibernateTemplate().execute(new HibernateCallback(paramString, paramArrayOfObject)
    {
      public Object doInHibernate(Session paramSession)
        throws HibernateException, SQLException
      {
        Query localQuery = paramSession.createQuery(this.val$hql);
        int i = 0;
        for (Object localObject2 : this.val$params)
          localQuery.setParameter(i++, localObject2);
        ??? = Integer.valueOf(localQuery.executeUpdate());
        return new Long(((Integer)???).intValue());
      }
    });
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.dao.impl.GenericDaoImpl
 * JD-Core Version:    0.6.0
 */