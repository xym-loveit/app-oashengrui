package com.htsoft.core.dao;

public abstract interface BaseDao<T> extends GenericDao<T, Long>
{
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.dao.BaseDao
 * JD-Core Version:    0.6.0
 */