package com.htsoft.core.dao.impl;

import com.htsoft.core.dao.BaseDao;

public class BaseDaoImpl<T> extends GenericDaoImpl<T, Long>
  implements BaseDao<T>
{
  public BaseDaoImpl(Class paramClass)
  {
    super(paramClass);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.dao.impl.BaseDaoImpl
 * JD-Core Version:    0.6.0
 */