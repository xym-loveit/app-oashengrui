package com.htsoft.core.DataInit;

import com.htsoft.core.model.BaseModel;
import com.htsoft.core.service.BaseService;
import com.htsoft.core.util.AppUtil;
import com.htsoft.core.util.XmlUtil;
import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map<Ljava.lang.Object;Ljava.lang.Object;>;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Document;
import org.dom4j.Element;

public class DataInit
{
  private static Log logger = LogFactory.getLog(DataInit.class);
  private static SimpleDateFormat df = new SimpleDateFormat("yyyy-mm-dd");

  public static void init(String paramString)
  {
    String str1 = paramString + "/WEB-INF/classes/conf";
    String str2 = str1 + "/data-init.xml";
    Document localDocument = XmlUtil.load(str2);
    if (localDocument != null)
    {
      Element localElement = localDocument.getRootElement();
      initNode(localElement, null);
    }
  }

  public static void initNode(Element paramElement, Object paramObject)
  {
    if (paramElement != null)
    {
      Iterator localIterator1 = paramElement.elementIterator();
      while (localIterator1.hasNext())
      {
        Element localElement1 = (Element)localIterator1.next();
        String str1 = localElement1.attributeValue("class");
        String str2 = localElement1.attributeValue("service");
        String str3 = localElement1.attributeValue("description");
        if (str3 != null)
          logger.info(str3);
        List localList1 = localElement1.selectNodes("property");
        Iterator localIterator2 = localList1.iterator();
        List localList2 = localElement1.selectNodes("set");
        Iterator localIterator3 = localList2.iterator();
        try
        {
          BaseModel localBaseModel = (BaseModel)Class.forName(str1).newInstance();
          BaseService localBaseService = (BaseService)AppUtil.getBean(str2);
          Map localMap1 = convertNodeToMap(localIterator2, paramObject);
          localBaseModel = (BaseModel)convertMapToBean(Class.forName(str1), localMap1);
          localBaseModel = (BaseModel)localBaseService.save(localBaseModel);
          localBaseService.flush();
          String str4 = localElement1.attributeValue("primary-key");
          String str5 = localElement1.attributeValue("key-type");
          Map localMap2 = convertBeanToMap(localBaseModel);
          Object localObject = localMap2.get(str4);
          while (localIterator3.hasNext())
          {
            Element localElement2 = (Element)localIterator3.next();
            initNode(localElement2, localObject);
          }
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
        }
      }
    }
  }

  private static Map<Object, Object> convertNodeToMap(Iterator<Element> paramIterator, Object paramObject)
  {
    HashMap localHashMap = new HashMap();
    if (paramIterator != null)
      while (paramIterator.hasNext())
      {
        Element localElement = (Element)paramIterator.next();
        String str1 = localElement.attributeValue("name");
        String str2 = localElement.attributeValue("value");
        String str3 = localElement.attributeValue("foreign-key");
        String str4 = localElement.attributeValue("today-value");
        String str5 = localElement.attributeValue("date-format");
        if (str5 != null)
          df.applyPattern(str5);
        Object localObject = null;
        if ((str3 != null) && (str3.equals("true")))
          localObject = paramObject;
        else if ((str4 != null) && (str4.equals("true")))
          localObject = df.format(new Date());
        else
          localObject = str2;
        localHashMap.put(str1, localObject);
      }
    return (Map<Object, Object>)localHashMap;
  }

  private static <T> Map<Object, Object> convertBeanToMap(Object paramObject)
    throws IntrospectionException
  {
    Class localClass = paramObject.getClass();
    HashMap localHashMap = new HashMap();
    BeanInfo localBeanInfo = Introspector.getBeanInfo(localClass);
    PropertyDescriptor[] arrayOfPropertyDescriptor = localBeanInfo.getPropertyDescriptors();
    for (int i = 0; i < arrayOfPropertyDescriptor.length; i++)
    {
      PropertyDescriptor localPropertyDescriptor = arrayOfPropertyDescriptor[i];
      String str = localPropertyDescriptor.getName();
      if (str.equals("class"))
        continue;
      Method localMethod = localPropertyDescriptor.getReadMethod();
      try
      {
        Object localObject = localMethod.invoke(paramObject, new Object[0]);
        localHashMap.put(str, localObject);
      }
      catch (Exception localException)
      {
        logger.debug("解析方法名:" + localMethod + ",有误!");
      }
    }
    return localHashMap;
  }

  private static <T> T convertMapToBean(Class<T> paramClass, Map<Object, Object> paramMap)
    throws IntrospectionException, InstantiationException, IllegalAccessException
  {
    BeanInfo localBeanInfo = Introspector.getBeanInfo(paramClass);
    Object localObject = paramClass.newInstance();
    for (PropertyDescriptor localPropertyDescriptor : localBeanInfo.getPropertyDescriptors())
    {
      String str1 = localPropertyDescriptor.getName();
      if (!paramMap.containsKey(str1))
        continue;
      String str2 = ConvertUtils.convert(paramMap.get(str1));
      Object[] arrayOfObject = new Object[1];
      try
      {
        arrayOfObject[0] = df.parse(str2);
      }
      catch (ParseException localParseException)
      {
        arrayOfObject[0] = ConvertUtils.convert(str2, localPropertyDescriptor.getPropertyType());
      }
      try
      {
        localPropertyDescriptor.getWriteMethod().invoke(localObject, arrayOfObject);
      }
      catch (IllegalArgumentException localIllegalArgumentException)
      {
        localIllegalArgumentException.printStackTrace();
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        localInvocationTargetException.printStackTrace();
      }
    }
    return localObject;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.DataInit.DataInit
 * JD-Core Version:    0.6.0
 */