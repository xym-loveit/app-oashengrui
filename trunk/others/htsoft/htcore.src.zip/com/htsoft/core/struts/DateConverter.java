package com.htsoft.core.struts;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.util.StrutsTypeConverter;

public class DateConverter extends StrutsTypeConverter
{
  private static final Log logger = LogFactory.getLog(DateConverter.class);
  public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";
  public static final String[] ACCEPT_DATE_FORMATS = { "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd" };

  public Object convertFromString(Map paramMap, String[] paramArrayOfString, Class paramClass)
  {
    if (logger.isDebugEnabled())
    {
      logger.debug("converFromString....");
      if (paramArrayOfString != null)
        logger.debug("convert from  :" + paramArrayOfString[0]);
    }
    if ((paramArrayOfString[0] == null) || (paramArrayOfString[0].trim().equals("")))
      return null;
    String str = paramArrayOfString[0];
    str = str.replace("T", " ");
    try
    {
      return DateUtils.parseDate(str, ACCEPT_DATE_FORMATS);
    }
    catch (Exception localException)
    {
      logger.debug("parse date error:" + localException.getMessage());
    }
    return null;
  }

  public String convertToString(Map paramMap, Object paramObject)
  {
    if ((paramObject instanceof Date))
    {
      SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
      try
      {
        return localSimpleDateFormat.format((Date)paramObject);
      }
      catch (RuntimeException localRuntimeException)
      {
        return "";
      }
    }
    return "";
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.struts.DateConverter
 * JD-Core Version:    0.6.0
 */