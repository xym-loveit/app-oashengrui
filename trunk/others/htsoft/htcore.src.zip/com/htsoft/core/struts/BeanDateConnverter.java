package com.htsoft.core.struts;

import org.apache.commons.beanutils.Converter;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class BeanDateConnverter
  implements Converter
{
  private static final Log logger = LogFactory.getLog(DateConverter.class);
  public static final String[] ACCEPT_DATE_FORMATS = { "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd" };

  public Object convert(Class paramClass, Object paramObject)
  {
    logger.debug("conver " + paramObject + " to date object");
    String str = paramObject.toString();
    str = str.replace("T", " ");
    try
    {
      return DateUtils.parseDate(str, ACCEPT_DATE_FORMATS);
    }
    catch (Exception localException)
    {
      logger.debug("parse date error:" + localException.getMessage());
    }
    return null;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.struts.BeanDateConnverter
 * JD-Core Version:    0.6.0
 */