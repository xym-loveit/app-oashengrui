package com.htsoft.core.service.impl;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.dao.DynamicDao;
import com.htsoft.core.service.DynamicService;
import com.htsoft.core.web.paging.PagingBean;
import java.io.Serializable;
import java.util.List;

public class DynamicServiceImpl
  implements DynamicService
{
  private DynamicDao dynamicDao;

  public DynamicServiceImpl()
  {
  }

  public DynamicServiceImpl(DynamicDao paramDynamicDao)
  {
    this.dynamicDao = paramDynamicDao;
  }

  public Object save(Object paramObject)
  {
    return this.dynamicDao.save(paramObject);
  }

  public Object merge(Object paramObject)
  {
    return this.dynamicDao.merge(paramObject);
  }

  public Object get(Serializable paramSerializable)
  {
    return this.dynamicDao.get(paramSerializable);
  }

  public void remove(Serializable paramSerializable)
  {
    this.dynamicDao.remove(paramSerializable);
  }

  public void remove(Object paramObject)
  {
    this.dynamicDao.remove(paramObject);
  }

  public void evict(Object paramObject)
  {
    this.dynamicDao.evict(paramObject);
  }

  public List<Object> getAll()
  {
    return this.dynamicDao.getAll();
  }

  public List<Object> getAll(PagingBean paramPagingBean)
  {
    return this.dynamicDao.getAll(paramPagingBean);
  }

  public List<Object> getAll(QueryFilter paramQueryFilter)
  {
    return this.dynamicDao.getAll(paramQueryFilter);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.service.impl.DynamicServiceImpl
 * JD-Core Version:    0.6.0
 */