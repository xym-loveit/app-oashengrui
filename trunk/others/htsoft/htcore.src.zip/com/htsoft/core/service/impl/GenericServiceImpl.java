package com.htsoft.core.service.impl;

import com.htsoft.core.command.QueryFilter;
import com.htsoft.core.dao.GenericDao;
import com.htsoft.core.service.GenericService;
import com.htsoft.core.web.paging.PagingBean;
import java.io.Serializable;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class GenericServiceImpl<T, PK extends Serializable>
  implements GenericService<T, PK>
{
  protected Log logger = LogFactory.getLog(GenericServiceImpl.class);
  protected GenericDao<T, Serializable> dao = null;

  public void setDao(GenericDao paramGenericDao)
  {
    this.dao = paramGenericDao;
  }

  public GenericServiceImpl(GenericDao paramGenericDao)
  {
    this.dao = paramGenericDao;
  }

  public T get(PK paramPK)
  {
    return this.dao.get(paramPK);
  }

  public T save(T paramT)
  {
    return this.dao.save(paramT);
  }

  public T merge(T paramT)
  {
    return this.dao.merge(paramT);
  }

  public void evict(T paramT)
  {
    this.dao.evict(paramT);
  }

  public List<T> getAll()
  {
    return this.dao.getAll();
  }

  public List<T> getAll(PagingBean paramPagingBean)
  {
    return this.dao.getAll(paramPagingBean);
  }

  public List<T> getAll(QueryFilter paramQueryFilter)
  {
    return this.dao.getAll(paramQueryFilter);
  }

  public void remove(PK paramPK)
  {
    this.dao.remove(paramPK);
  }

  public void remove(T paramT)
  {
    this.dao.remove(paramT);
  }

  public void flush()
  {
    this.dao.flush();
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.service.impl.GenericServiceImpl
 * JD-Core Version:    0.6.0
 */