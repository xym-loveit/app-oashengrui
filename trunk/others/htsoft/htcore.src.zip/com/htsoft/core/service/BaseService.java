package com.htsoft.core.service;

public abstract interface BaseService<T> extends GenericService<T, Long>
{
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.service.BaseService
 * JD-Core Version:    0.6.0
 */