package com.htsoft.core.service.impl;

import com.htsoft.core.dao.GenericDao;
import com.htsoft.core.service.BaseService;

public class BaseServiceImpl<T> extends GenericServiceImpl<T, Long>
  implements BaseService<T>
{
  public BaseServiceImpl(GenericDao paramGenericDao)
  {
    super(paramGenericDao);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.service.impl.BaseServiceImpl
 * JD-Core Version:    0.6.0
 */