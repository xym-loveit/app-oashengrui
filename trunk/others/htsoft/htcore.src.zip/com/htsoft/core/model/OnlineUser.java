package com.htsoft.core.model;

public class OnlineUser
{
  private String sessionId;
  private Long userId;
  private String username;
  private String fullname;
  private String depPath;
  private String roleIds;
  private Short title;

  public String getSessionId()
  {
    return this.sessionId;
  }

  public void setSessionId(String paramString)
  {
    this.sessionId = paramString;
  }

  public Long getUserId()
  {
    return this.userId;
  }

  public void setUserId(Long paramLong)
  {
    this.userId = paramLong;
  }

  public String getUsername()
  {
    return this.username;
  }

  public void setUsername(String paramString)
  {
    this.username = paramString;
  }

  public String getFullname()
  {
    return this.fullname;
  }

  public void setFullname(String paramString)
  {
    this.fullname = paramString;
  }

  public String getDepPath()
  {
    return this.depPath;
  }

  public void setDepPath(String paramString)
  {
    this.depPath = paramString;
  }

  public String getRoleIds()
  {
    return this.roleIds;
  }

  public void setRoleIds(String paramString)
  {
    this.roleIds = paramString;
  }

  public Short getTitle()
  {
    return this.title;
  }

  public void setTitle(Short paramShort)
  {
    this.title = paramShort;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.model.OnlineUser
 * JD-Core Version:    0.6.0
 */