package com.htsoft.core.model;

import com.htsoft.oa.model.flow.FormField;
import com.htsoft.oa.model.flow.FormTable;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.apache.commons.lang.StringUtils;

public class DynaModel
{
  private String primaryFieldName;
  private String subjectFieldName;
  private String entityName;
  private Map<String, Object> datas = new HashMap();
  private Map<String, Class> types = new HashMap();
  private Map<String, String> formats = new HashMap();
  private Map<String, String> labels = new HashMap();

  public DynaModel()
  {
  }

  public DynaModel(String paramString)
  {
    this.entityName = paramString;
  }

  public DynaModel(FormTable paramFormTable)
  {
    this.entityName = paramFormTable.getEntityName();
    Iterator localIterator = paramFormTable.getFormFields().iterator();
    while (localIterator.hasNext())
    {
      FormField localFormField = (FormField)localIterator.next();
      this.types.put(localFormField.getFieldName(), localFormField.getFieldJavaClass());
      this.labels.put(localFormField.getFieldName(), localFormField.getFieldLabel());
      if (StringUtils.isNotEmpty(localFormField.getShowFormat()))
        this.formats.put(localFormField.getFieldName(), localFormField.getShowFormat());
      if (FormField.FLOW_TITLE.equals(localFormField.getIsFlowTitle()))
        this.subjectFieldName = localFormField.getFieldName();
      if (FormField.PRIMARY_KEY.equals(localFormField.getIsPrimary()))
        this.primaryFieldName = localFormField.getFieldName();
    }
  }

  public static void main(String[] paramArrayOfString)
  {
  }

  public String getPrimaryFieldName()
  {
    return this.primaryFieldName;
  }

  public void setPrimaryFieldName(String paramString)
  {
    this.primaryFieldName = paramString;
  }

  public String getEntityName()
  {
    return this.entityName;
  }

  public void setEntityName(String paramString)
  {
    this.entityName = paramString;
  }

  public Map<String, Object> getDatas()
  {
    return this.datas;
  }

  public void setDatas(Map<String, Object> paramMap)
  {
    this.datas = paramMap;
  }

  public Map<String, Class> getTypes()
  {
    return this.types;
  }

  public void setTypes(Map<String, Class> paramMap)
  {
    this.types = paramMap;
  }

  public Map<String, String> getFormats()
  {
    return this.formats;
  }

  public void setFormats(Map<String, String> paramMap)
  {
    this.formats = paramMap;
  }

  public Object get(String paramString)
  {
    return this.datas.get(paramString);
  }

  public void set(String paramString, Object paramObject)
  {
    this.datas.put(paramString, paramObject);
  }

  public Class getType(String paramString)
  {
    return (Class)this.types.get(paramString);
  }

  public void setType(String paramString, Class paramClass)
  {
    this.types.put(paramString, paramClass);
  }

  public void setFormat(String paramString1, String paramString2)
  {
    this.formats.put(paramString1, paramString2);
  }

  public String getFormat(String paramString)
  {
    return (String)this.formats.get(paramString);
  }

  public String getSubjectFieldName()
  {
    return this.subjectFieldName;
  }

  public void setSubjectFieldName(String paramString)
  {
    this.subjectFieldName = paramString;
  }

  public Map<String, String> getLabels()
  {
    return this.labels;
  }

  public void setLabels(Map<String, String> paramMap)
  {
    this.labels = paramMap;
  }

  public String getLabel(String paramString)
  {
    return (String)this.labels.get(paramString);
  }

  public void setLabel(String paramString1, String paramString2)
  {
    this.labels.put(paramString2, paramString2);
  }

  public Serializable getPkValue()
  {
    return (Serializable)this.datas.get(this.primaryFieldName);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.model.DynaModel
 * JD-Core Version:    0.6.0
 */