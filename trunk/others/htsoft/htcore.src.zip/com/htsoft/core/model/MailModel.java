package com.htsoft.core.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

public class MailModel
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private String subject;
  private String from;
  private String to;
  private Date sendDate;
  private String content;
  private String mailTemplate;
  private Map mailData = null;

  public String getSubject()
  {
    return this.subject;
  }

  public void setSubject(String paramString)
  {
    this.subject = paramString;
  }

  public String getFrom()
  {
    return this.from;
  }

  public void setFrom(String paramString)
  {
    this.from = paramString;
  }

  public String getTo()
  {
    return this.to;
  }

  public void setTo(String paramString)
  {
    this.to = paramString;
  }

  public Date getSendDate()
  {
    return this.sendDate;
  }

  public void setSendDate(Date paramDate)
  {
    this.sendDate = paramDate;
  }

  public String getContent()
  {
    return this.content;
  }

  public void setContent(String paramString)
  {
    this.content = paramString;
  }

  public String getMailTemplate()
  {
    return this.mailTemplate;
  }

  public void setMailTemplate(String paramString)
  {
    this.mailTemplate = paramString;
  }

  public Map getMailData()
  {
    return this.mailData;
  }

  public void setMailData(Map paramMap)
  {
    this.mailData = paramMap;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.model.MailModel
 * JD-Core Version:    0.6.0
 */