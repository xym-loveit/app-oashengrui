package com.htsoft.core.model;

import flexjson.JSON;
import java.io.Serializable;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class BaseModel
  implements Serializable
{
  protected Log logger = LogFactory.getLog(BaseModel.class);
  private Integer version;

  @JSON(include=false)
  public Integer getVersion()
  {
    return this.version;
  }

  public void setVersion(Integer paramInteger)
  {
    this.version = paramInteger;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.model.BaseModel
 * JD-Core Version:    0.6.0
 */