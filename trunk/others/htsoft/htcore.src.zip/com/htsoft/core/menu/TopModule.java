package com.htsoft.core.menu;

import java.io.Serializable;
import org.apache.commons.lang.builder.HashCodeBuilder;

public class TopModule
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private String id;
  private String title;
  private String iconCls;
  private boolean isPublic = false;
  private Integer sn = null;

  public TopModule()
  {
  }

  public TopModule(String paramString1, String paramString2, String paramString3, String paramString4, Integer paramInteger)
  {
    this.id = paramString1;
    this.title = paramString2;
    this.iconCls = paramString3;
    this.isPublic = ("true".equals(paramString4));
    this.sn = paramInteger;
  }

  public String getId()
  {
    return this.id;
  }

  public void setId(String paramString)
  {
    this.id = paramString;
  }

  public String getIconCls()
  {
    return this.iconCls;
  }

  public void setIconCls(String paramString)
  {
    this.iconCls = paramString;
  }

  public String getTitle()
  {
    return this.title;
  }

  public void setTitle(String paramString)
  {
    this.title = paramString;
  }

  public boolean isPublic()
  {
    return this.isPublic;
  }

  public void setPublic(boolean paramBoolean)
  {
    this.isPublic = paramBoolean;
  }

  public int hashCode()
  {
    return new HashCodeBuilder(-82280557, -700257973).append(this.id).append(this.title).append(this.iconCls).toHashCode();
  }

  public Integer getSn()
  {
    return this.sn;
  }

  public void setSn(Integer paramInteger)
  {
    this.sn = paramInteger;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.menu.TopModule
 * JD-Core Version:    0.6.0
 */