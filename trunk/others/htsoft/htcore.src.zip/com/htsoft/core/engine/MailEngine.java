package com.htsoft.core.engine;

import com.htsoft.core.util.AppUtil;
import java.io.File;
import java.util.Map;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.exception.VelocityException;
import org.htmlparser.Parser;
import org.htmlparser.visitors.HtmlPage;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.ui.velocity.VelocityEngineUtils;

public class MailEngine
{
  private final Log logger = LogFactory.getLog(MailEngine.class);
  private JavaMailSender mailSender;
  private VelocityEngine velocityEngine;
  private String defaultFrom;

  public void setMailSender(JavaMailSender paramJavaMailSender)
  {
    this.mailSender = paramJavaMailSender;
  }

  public void setVelocityEngine(VelocityEngine paramVelocityEngine)
  {
    this.velocityEngine = paramVelocityEngine;
  }

  public void setFrom(String paramString)
  {
    this.defaultFrom = paramString;
  }

  public void sendMessage(SimpleMailMessage paramSimpleMailMessage, String paramString, Map paramMap)
  {
    String str = null;
    try
    {
      str = VelocityEngineUtils.mergeTemplateIntoString(this.velocityEngine, paramString, paramMap);
    }
    catch (VelocityException localVelocityException)
    {
      localVelocityException.printStackTrace();
      this.logger.error(localVelocityException.getMessage());
    }
    paramSimpleMailMessage.setText(str);
    send(paramSimpleMailMessage);
  }

  public void send(SimpleMailMessage paramSimpleMailMessage)
    throws MailException
  {
    try
    {
      this.mailSender.send(paramSimpleMailMessage);
    }
    catch (MailException localMailException)
    {
      this.logger.error(localMailException.getMessage());
      throw localMailException;
    }
  }

  public void sendMessage(String[] paramArrayOfString, String paramString1, ClassPathResource paramClassPathResource, String paramString2, String paramString3, String paramString4)
    throws MessagingException
  {
    MimeMessage localMimeMessage = ((JavaMailSenderImpl)this.mailSender).createMimeMessage();
    MimeMessageHelper localMimeMessageHelper = new MimeMessageHelper(localMimeMessage, true);
    localMimeMessageHelper.setTo(paramArrayOfString);
    if (paramString1 == null)
      localMimeMessageHelper.setFrom(this.defaultFrom);
    else
      localMimeMessageHelper.setFrom(paramString1);
    localMimeMessageHelper.setText(paramString2);
    localMimeMessageHelper.setSubject(paramString3);
    localMimeMessageHelper.addAttachment(paramString4, paramClassPathResource);
    ((JavaMailSenderImpl)this.mailSender).send(localMimeMessage);
  }

  public String sendMimeMessage(String paramString1, String[] paramArrayOfString1, String paramString2, String paramString3, String paramString4, String paramString5, String[] paramArrayOfString2, File[] paramArrayOfFile, boolean paramBoolean)
  {
    if ((paramArrayOfString1 == null) || (paramArrayOfString1.length == 0) || (paramArrayOfString1[0] == null) || ("".equals(paramArrayOfString1[0])))
    {
      if (this.logger.isErrorEnabled())
        this.logger.error("Recipient found empty while sending a email, no further processing. Mail subject is:" + paramString4);
      return "Recipient is empty";
    }
    JavaMailSenderImpl localJavaMailSenderImpl = (JavaMailSenderImpl)AppUtil.getBean("mailSender");
    MimeMessage localMimeMessage = localJavaMailSenderImpl.createMimeMessage();
    try
    {
      MimeMessageHelper localMimeMessageHelper = new MimeMessageHelper(localMimeMessage, paramArrayOfFile != null);
      localMimeMessageHelper.setFrom(paramString1 == null ? this.defaultFrom : paramString1);
      localMimeMessageHelper.setTo(paramArrayOfString1);
      if ((paramString2 != null) && (!"".equals(paramString2)))
        localMimeMessageHelper.setCc(paramString2);
      if ((paramString3 != null) && (!"".equals(paramString3)))
        localMimeMessageHelper.setReplyTo(paramString3);
      localMimeMessageHelper.setSubject(paramString4);
      localMimeMessageHelper.setText(paramString5, true);
      if (paramArrayOfFile != null)
      {
        int i;
        if (paramBoolean)
          for (i = 0; i < paramArrayOfFile.length; i++)
            localMimeMessageHelper.addInline(paramArrayOfString2[i], paramArrayOfFile[i]);
        else
          for (i = 0; i < paramArrayOfFile.length; i++)
            localMimeMessageHelper.addAttachment(paramArrayOfString2[i], paramArrayOfFile[i]);
      }
      localJavaMailSenderImpl.send(localMimeMessage);
      if (this.logger.isDebugEnabled())
        this.logger.debug("A email has been sent successfully to: " + StringUtils.join(paramArrayOfString1, ','));
    }
    catch (Throwable localThrowable)
    {
      this.logger.error("Error occured when sending email.", localThrowable);
      return "Error occured when sending email." + localThrowable.getMessage();
    }
    return null;
  }

  public String sendTemplateMail(String paramString1, Map<String, Object> paramMap, String paramString2, String paramString3, String[] paramArrayOfString1, String paramString4, String paramString5, String[] paramArrayOfString2, File[] paramArrayOfFile, boolean paramBoolean)
  {
    String str1 = null;
    String str2 = paramString2;
    try
    {
      str1 = VelocityEngineUtils.mergeTemplateIntoString(this.velocityEngine, paramString1, paramMap);
      if (paramString2 == null)
      {
        Parser localParser = Parser.createParser(str1, "UTF-8");
        HtmlPage localHtmlPage = new HtmlPage(localParser);
        localParser.visitAllNodesWith(localHtmlPage);
        str2 = localHtmlPage.getTitle();
      }
    }
    catch (Throwable localThrowable)
    {
      throw new RuntimeException("Email template processing error, Check log for detail infomation. Template path: " + paramString1, localThrowable);
    }
    return sendMimeMessage(paramString3, paramArrayOfString1, paramString4, paramString5, str2, str1, paramArrayOfString2, paramArrayOfFile, paramBoolean);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.engine.MailEngine
 * JD-Core Version:    0.6.0
 */