package com.htsoft.core.jms;

import com.htsoft.core.engine.MailEngine;
import com.htsoft.core.model.MailModel;
import javax.annotation.Resource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class MailMessageConsumer
{
  private static final Log logger = LogFactory.getLog(MailMessageConsumer.class);

  @Resource
  MailEngine mailEngine;

  public void sendMail(MailModel paramMailModel)
  {
    logger.debug("send mail now " + paramMailModel.getSubject());
    this.mailEngine.sendTemplateMail(paramMailModel.getMailTemplate(), paramMailModel.getMailData(), paramMailModel.getSubject(), null, new String[] { paramMailModel.getTo() }, null, null, null, null, true);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.jms.MailMessageConsumer
 * JD-Core Version:    0.6.0
 */