package com.htsoft.core.jms;

import com.htsoft.oa.model.communicate.SmsMobile;
import com.htsoft.oa.service.communicate.SmsMobileService;
import javax.annotation.Resource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class MobileMessageConsumer
{
  private static final Log logger = LogFactory.getLog(MobileMessageConsumer.class);

  @Resource
  private SmsMobileService smsMobileService;

  public void sendMobileMsg(SmsMobile paramSmsMobile)
  {
    logger.debug("send the sms mobile message now for :" + paramSmsMobile.getPhoneNumber());
    this.smsMobileService.sendOneSms(paramSmsMobile);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.jms.MobileMessageConsumer
 * JD-Core Version:    0.6.0
 */