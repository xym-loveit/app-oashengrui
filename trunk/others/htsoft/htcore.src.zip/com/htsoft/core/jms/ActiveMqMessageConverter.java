package com.htsoft.core.jms;

import com.htsoft.core.model.MailModel;
import com.htsoft.oa.model.communicate.SmsMobile;
import java.io.Serializable;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Session;
import org.springframework.jms.support.converter.MessageConverter;

public class ActiveMqMessageConverter
  implements MessageConverter
{
  public Message toMessage(Object paramObject, Session paramSession)
    throws JMSException
  {
    ObjectMessage localObjectMessage;
    if ((paramObject instanceof MailModel))
    {
      localObjectMessage = paramSession.createObjectMessage();
      localObjectMessage.setObject((MailModel)paramObject);
      return localObjectMessage;
    }
    if ((paramObject instanceof SmsMobile))
    {
      localObjectMessage = paramSession.createObjectMessage();
      localObjectMessage.setObject((SmsMobile)paramObject);
      return localObjectMessage;
    }
    throw new JMSException("Object:[" + paramObject + "] is not legal message");
  }

  public Object fromMessage(Message paramMessage)
    throws JMSException
  {
    if ((paramMessage instanceof ObjectMessage))
    {
      ObjectMessage localObjectMessage = (ObjectMessage)paramMessage;
      Serializable localSerializable = localObjectMessage.getObject();
      if ((localSerializable instanceof MailModel))
        return (MailModel)localObjectMessage.getObject();
      if ((localSerializable instanceof SmsMobile))
        return (SmsMobile)localObjectMessage.getObject();
      throw new JMSException("Msg:[" + paramMessage + "] is not legal message");
    }
    throw new JMSException("Msg:[" + paramMessage + "] is not ObjectMessage");
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.jms.ActiveMqMessageConverter
 * JD-Core Version:    0.6.0
 */