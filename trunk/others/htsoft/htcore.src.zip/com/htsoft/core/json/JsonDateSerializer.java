package com.htsoft.core.json;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;
import java.util.Date;

public class JsonDateSerializer
  implements JsonSerializer<Date>
{
  public JsonElement serialize(Date paramDate, Type paramType, JsonSerializationContext paramJsonSerializationContext)
  {
    return new JsonPrimitive(Long.valueOf(paramDate.getTime()));
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.json.JsonDateSerializer
 * JD-Core Version:    0.6.0
 */