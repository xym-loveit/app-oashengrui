package com.htsoft.core.util;

import java.io.PrintStream;
import java.util.UUID;

public class UUIDGenerator
{
  public static String getUUID()
  {
    String str = UUID.randomUUID().toString();
    return str.substring(0, 8) + str.substring(9, 13) + str.substring(14, 18) + str.substring(19, 23) + str.substring(24);
  }

  public static String[] getUUID(int paramInt)
  {
    if (paramInt < 1)
      return null;
    String[] arrayOfString = new String[paramInt];
    for (int i = 0; i < paramInt; i++)
      arrayOfString[i] = getUUID();
    return arrayOfString;
  }

  public static void main(String[] paramArrayOfString)
  {
    String[] arrayOfString = UUID.randomUUID().toString().split("-");
    for (int i = 0; i < arrayOfString.length; i++)
    {
      System.out.println("ok:" + arrayOfString[i]);
      long l = Long.valueOf(arrayOfString[i], 16).longValue();
      System.out.println("ok:===" + l);
    }
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.util.UUIDGenerator
 * JD-Core Version:    0.6.0
 */