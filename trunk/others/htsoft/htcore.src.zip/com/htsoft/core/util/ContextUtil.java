package com.htsoft.core.util;

import com.htsoft.oa.model.system.AppUser;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.Authentication;
import org.springframework.security.context.SecurityContext;
import org.springframework.security.context.SecurityContextHolder;

public class ContextUtil
{
  private static final Log logger = LogFactory.getLog(ContextUtil.class);

  public static AppUser getCurrentUser()
  {
    SecurityContext localSecurityContext = SecurityContextHolder.getContext();
    if (localSecurityContext != null)
    {
      Authentication localAuthentication = localSecurityContext.getAuthentication();
      if (localAuthentication != null)
      {
        Object localObject = localAuthentication.getPrincipal();
        if ((localObject instanceof AppUser))
          return (AppUser)localObject;
      }
      else
      {
        logger.warn("WARN: securityContext cannot be lookuped using SecurityContextHolder.");
      }
    }
    return null;
  }

  public static Long getCurrentUserId()
  {
    AppUser localAppUser = getCurrentUser();
    if (localAppUser != null)
      return localAppUser.getUserId();
    return null;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.util.ContextUtil
 * JD-Core Version:    0.6.0
 */