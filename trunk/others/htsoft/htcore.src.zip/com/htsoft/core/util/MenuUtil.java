package com.htsoft.core.util;

import com.htsoft.core.menu.TopModule;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

public class MenuUtil
{
  private static Log logger = LogFactory.getLog(MenuUtil.class);

  public static Map<String, Document> getAllOrgMenus()
  {
    LinkedHashMap localLinkedHashMap = new LinkedHashMap();
    String str1 = AppUtil.getMenuAbDir();
    Document localDocument1 = XmlUtil.load(str1 + "/menu-all.xml");
    Element localElement1 = localDocument1.getRootElement();
    Iterator localIterator = localElement1.elementIterator();
    while (localIterator.hasNext())
    {
      Element localElement2 = (Element)localIterator.next();
      String str2 = localElement2.attributeValue("name");
      String str3 = localElement2.attributeValue("file");
      if (logger.isDebugEnabled())
        logger.debug("name:" + str2 + " file=" + str3);
      if ((str2 != null) && (str3 != null))
      {
        logger.info("load the menu config:" + str1 + "/" + str3);
        Document localDocument2 = XmlUtil.load(str1 + "/" + str3);
        if (localDocument2 != null)
          localLinkedHashMap.put(str2, localDocument2);
      }
    }
    return localLinkedHashMap;
  }

  public static Map<String, Document> convertByXsl(Map<String, Document> paramMap, String paramString)
  {
    LinkedHashMap localLinkedHashMap = new LinkedHashMap();
    Iterator localIterator = paramMap.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      Document localDocument1 = (Document)paramMap.get(str);
      try
      {
        Document localDocument2 = XmlUtil.styleDocument(localDocument1, paramString);
        localLinkedHashMap.put(str, localDocument2);
      }
      catch (Exception localException)
      {
        logger.error(localException.getMessage());
      }
    }
    return localLinkedHashMap;
  }

  public static Map<String, Document> getAllItemsMenus(Map<String, Document> paramMap)
  {
    String str = AppUtil.getMenuXslDir() + "/menu-items.xsl";
    return convertByXsl(paramMap, str);
  }

  public static Map<String, Document> getAllGrantedMenus(Map<String, Document> paramMap)
  {
    String str = AppUtil.getMenuXslDir() + "/menu-grant.xsl";
    return convertByXsl(paramMap, str);
  }

  public static Document mergeOneDoc(Map<String, Document> paramMap)
  {
    Document localDocument1 = DocumentHelper.createDocument();
    Element localElement1 = localDocument1.addElement("Modules");
    Iterator localIterator = paramMap.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      Document localDocument2 = (Document)paramMap.get(str);
      Element localElement2 = localDocument2.getRootElement();
      if (localElement2 != null)
        localElement1.add(localElement2.createCopy());
    }
    if (logger.isDebugEnabled());
    return localDocument1;
  }

  public static Map<String, TopModule> getTopModules(Document paramDocument)
  {
    LinkedHashMap localLinkedHashMap = new LinkedHashMap();
    Element localElement1 = paramDocument.getRootElement();
    Iterator localIterator = localElement1.elementIterator();
    int i = 1;
    while (localIterator.hasNext())
    {
      Element localElement2 = (Element)localIterator.next();
      String str1 = localElement2.attributeValue("id");
      String str2 = localElement2.attributeValue("text");
      String str3 = localElement2.attributeValue("iconCls");
      String str4 = localElement2.attributeValue("isPublic");
      TopModule localTopModule = new TopModule(str1, str2, str3, str4, Integer.valueOf(i++));
      localLinkedHashMap.put(str1, localTopModule);
    }
    return localLinkedHashMap;
  }

  public static Map<String, TopModule> getPublicTopModules(Map<String, TopModule> paramMap)
  {
    HashMap localHashMap = new HashMap();
    Iterator localIterator = paramMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      if (((TopModule)localEntry.getValue()).isPublic())
        localHashMap.put(localEntry.getKey(), localEntry.getValue());
    }
    return localHashMap;
  }

  public static void main(String[] paramArrayOfString)
  {
    Map localMap1 = getAllOrgMenus();
    Map localMap2 = getAllItemsMenus(localMap1);
    Document localDocument = mergeOneDoc(localMap2);
    System.out.println(localDocument.asXML());
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.util.MenuUtil
 * JD-Core Version:    0.6.0
 */