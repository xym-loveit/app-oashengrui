package com.htsoft.core.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class FileUtil
{
  private static Log logger = LogFactory.getLog(FileUtil.class);

  public static String generateFilename(String paramString)
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyyMM");
    String str1 = localSimpleDateFormat.format(new Date());
    String str2 = "";
    int i = paramString.lastIndexOf('.');
    if (i != -1)
      str2 = paramString.substring(i);
    String str3 = str1 + "/" + UUIDGenerator.getUUID() + str2;
    return str3;
  }

  public static void writeFile(String paramString1, String paramString2)
  {
    FileOutputStream localFileOutputStream = null;
    OutputStreamWriter localOutputStreamWriter = null;
    try
    {
      localFileOutputStream = new FileOutputStream(new File(paramString1));
      localOutputStreamWriter = new OutputStreamWriter(localFileOutputStream, "UTF-8");
      localOutputStreamWriter.write(paramString2);
    }
    catch (Exception localException3)
    {
      logger.error(localException2.getMessage());
    }
    finally
    {
      try
      {
        if (localOutputStreamWriter != null)
          localOutputStreamWriter.close();
        if (localFileOutputStream != null)
          localFileOutputStream.close();
      }
      catch (Exception localException4)
      {
      }
    }
  }

  public static String readFile(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    try
    {
      File localFile = new File(paramString);
      FileInputStream localFileInputStream = null;
      BufferedReader localBufferedReader = null;
      try
      {
        localFileInputStream = new FileInputStream(localFile);
        InputStreamReader localInputStreamReader = new InputStreamReader(localFileInputStream, "UTF-8");
        localBufferedReader = new BufferedReader(localInputStreamReader);
        String str;
        while ((str = localBufferedReader.readLine()) != null)
        {
          localStringBuffer.append(str);
          localStringBuffer.append("\r\n");
        }
        localBufferedReader.close();
        localInputStreamReader.close();
        localFileInputStream.close();
      }
      catch (FileNotFoundException localFileNotFoundException)
      {
        logger.error(localFileNotFoundException.getMessage());
      }
      catch (IOException localIOException)
      {
        logger.error(localIOException.getMessage());
      }
    }
    catch (Exception localException)
    {
      logger.error(localException.getMessage());
    }
    return localStringBuffer.toString();
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.util.FileUtil
 * JD-Core Version:    0.6.0
 */