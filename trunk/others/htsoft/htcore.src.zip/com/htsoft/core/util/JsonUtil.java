package com.htsoft.core.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.htsoft.core.json.SqlTimestampConverter;
import com.htsoft.core.model.DynaModel;
import com.htsoft.oa.util.FlowUtil;
import flexjson.JSONSerializer;
import flexjson.transformer.DateTransformer;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.hibernate.collection.PersistentBag;
import org.hibernate.proxy.map.MapProxy;

public class JsonUtil
{
  public static JSONSerializer getJSONSerializer(String[] paramArrayOfString)
  {
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localJSONSerializer.exclude(new String[] { "*.class" });
    localJSONSerializer.transform(new DateTransformer("yyyy-MM-dd HH:mm:ss"), paramArrayOfString);
    return localJSONSerializer;
  }

  public static JSONSerializer getJSONSerializer()
  {
    JSONSerializer localJSONSerializer = new JSONSerializer();
    localJSONSerializer.exclude(new String[] { "*.class" });
    localJSONSerializer.transform(new DateTransformer("yyyy-MM-dd HH:mm:ss"), new Class[] { Date.class });
    return localJSONSerializer;
  }

  public static String listEntity2Json(List<Map<String, Object>> paramList, String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer("[");
    if ((paramList != null) && (paramList.size() > 0))
    {
      for (int i = 0; i < paramList.size(); i++)
      {
        Map localMap = (Map)paramList.get(i);
        String str = mapEntity2Json(localMap, paramString);
        localStringBuffer.append(str).append(",");
      }
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    }
    localStringBuffer.append("]");
    return localStringBuffer.toString();
  }

  public static String mapEntity2Json(Map<String, Object> paramMap, String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer("{");
    Gson localGson = new GsonBuilder().serializeNulls().create();
    DynaModel localDynaModel = (DynaModel)FlowUtil.DynaModelMap.get(paramString);
    Iterator localIterator = paramMap.entrySet().iterator();
    for (int i = 0; localIterator.hasNext(); i++)
    {
      label54: Map.Entry localEntry = (Map.Entry)localIterator.next();
      String str1 = (String)localEntry.getKey();
      Object localObject1 = localEntry.getValue();
      if ((str1.equals(paramString)) || ((localObject1 instanceof MapProxy)) || ((localObject1 instanceof Map)))
        break label54;
      Object localObject2;
      Object localObject3;
      if ((localObject1 instanceof PersistentBag))
      {
        int j = 0;
        localObject2 = str1.substring(0, str1.length() - 1);
        localStringBuffer.append(str1).append(":[");
        localObject3 = ((PersistentBag)localObject1).iterator();
        while (((Iterator)localObject3).hasNext())
        {
          if (j++ > 0)
            localStringBuffer.append(",");
          Map localMap = (Map)((Iterator)localObject3).next();
          localStringBuffer.append(mapEntity2Json(localMap, (String)localObject2));
        }
        localStringBuffer.append("],");
      }
      else if ((localObject1 instanceof Date))
      {
        String str2 = localDynaModel.getFormat(str1);
        if (str2 == null)
          str2 = "yyyy-MM-dd HH:mm:ss";
        localObject2 = new SimpleDateFormat(str2);
        localObject3 = ((SimpleDateFormat)localObject2).format((Date)localObject1);
        localStringBuffer.append(str1).append(":").append(localGson.toJson(localObject3)).append(",");
      }
      else
      {
        localStringBuffer.append(str1).append(":").append(localGson.toJson(localObject1)).append(",");
      }
    }
    if (i > 0)
      localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
    localStringBuffer.append("}");
    return (String)(String)localStringBuffer.toString();
  }

  public static Gson getGson()
  {
    GsonBuilder localGsonBuilder = new GsonBuilder().serializeNulls().setDateFormat("yyyy-MM-dd HH:mm:ss");
    localGsonBuilder.registerTypeAdapter(Timestamp.class, new SqlTimestampConverter());
    Gson localGson = localGsonBuilder.create();
    return localGson;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.util.JsonUtil
 * JD-Core Version:    0.6.0
 */