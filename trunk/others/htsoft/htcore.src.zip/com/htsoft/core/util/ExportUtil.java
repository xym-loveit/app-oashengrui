package com.htsoft.core.util;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.List;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Workbook;

public class ExportUtil
{
  public static void ExportXls(List paramList, OutputStream paramOutputStream, String paramString1, String paramString2)
  {
    HSSFWorkbook localHSSFWorkbook = new HSSFWorkbook();
    HSSFSheet localHSSFSheet = (HSSFSheet)localHSSFWorkbook.createSheet("sheet1");
    HSSFRow localHSSFRow = localHSSFSheet.createRow(0);
    HSSFCell localHSSFCell = null;
    CellStyle localCellStyle = localHSSFWorkbook.createCellStyle();
    localCellStyle.setAlignment(1);
    localCellStyle.setAlignment(2);
    org.apache.poi.ss.usermodel.Font localFont = localHSSFWorkbook.createFont();
    localFont.setBoldweight(700);
    localCellStyle.setFont(localFont);
    String[] arrayOfString1 = paramString2.split(",");
    for (int i = 0; i < arrayOfString1.length; i++)
    {
      localHSSFCell = localHSSFRow.createCell(i);
      localHSSFCell.setCellStyle(localCellStyle);
      localHSSFCell.setCellValue(arrayOfString1[i]);
    }
    if ((paramList != null) && (paramList.size() > 0))
    {
      localCellStyle = localHSSFWorkbook.createCellStyle();
      localCellStyle.setAlignment(1);
      localCellStyle.setAlignment(2);
      localFont = localHSSFWorkbook.createFont();
      localFont.setBoldweight(400);
      localCellStyle.setFont(localFont);
      String[] arrayOfString2 = paramString1.split(",");
      Object localObject1 = null;
      String str = "";
      for (int j = 0; j < paramList.size(); j++)
      {
        localHSSFRow = localHSSFSheet.createRow((short)j + 1);
        Object localObject2 = paramList.get(j);
        for (int k = 0; k < arrayOfString2.length; k++)
        {
          str = getValue(arrayOfString2[k], localObject2);
          localHSSFCell = localHSSFRow.createCell(k);
          localHSSFCell.setCellStyle(localCellStyle);
          localHSSFCell.setCellValue(str);
          localHSSFSheet.autoSizeColumn((short)k);
          str = "";
        }
      }
    }
    try
    {
      localHSSFWorkbook.write(paramOutputStream);
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
  }

  public static void ExportPdf(List<Object> paramList, OutputStream paramOutputStream, String paramString1, String paramString2)
  {
    Document localDocument = new Document();
    try
    {
      PdfWriter.getInstance(localDocument, paramOutputStream);
      localDocument.open();
      BaseFont localBaseFont = BaseFont.createFont("STSong-Light", "UniGB-UCS2-H", false);
      com.lowagie.text.Font localFont = new com.lowagie.text.Font(localBaseFont, 8.0F, 1);
      String[] arrayOfString1 = paramString1.split(",");
      String[] arrayOfString2 = paramString2.split(",");
      PdfPTable localPdfPTable = new PdfPTable(arrayOfString1.length);
      localPdfPTable.setWidthPercentage(100.0F);
      localPdfPTable.setHorizontalAlignment(0);
      PdfPCell localPdfPCell = new PdfPCell();
      localPdfPCell.setHorizontalAlignment(1);
      for (int i = 0; i < arrayOfString2.length; i++)
      {
        localPdfPCell.setPhrase(new Paragraph(arrayOfString2[i], localFont));
        localPdfPTable.addCell(localPdfPCell);
      }
      localFont = new com.lowagie.text.Font(localBaseFont, 8.0F, 0);
      if ((paramList != null) && (paramList.size() > 0))
      {
        Object localObject1 = null;
        String str = "";
        for (int j = 0; j < paramList.size(); j++)
        {
          Object localObject2 = paramList.get(j);
          for (int k = 0; k < arrayOfString1.length; k++)
          {
            str = getValue(arrayOfString1[k], localObject2);
            localPdfPCell.setPhrase(new Paragraph(str, localFont));
            localPdfPTable.addCell(localPdfPCell);
            str = "";
          }
        }
      }
      localDocument.add(localPdfPTable);
    }
    catch (DocumentException localDocumentException)
    {
      localDocumentException.printStackTrace();
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
    finally
    {
      localDocument.close();
    }
  }

  public static String getValue(String paramString, Object paramObject)
  {
    String str1 = "";
    String str2 = "";
    Method localMethod = null;
    try
    {
      if (paramString.indexOf("javaRenderer") == -1)
      {
        str2 = "get" + paramString.substring(0, 1).toUpperCase() + paramString.substring(1, paramString.length());
        localMethod = paramObject.getClass().getMethod(str2, null);
        if (localMethod != null)
        {
          String str3 = localMethod.getReturnType().getName();
          if (str3.indexOf("Date") != -1)
          {
            SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            str1 = localSimpleDateFormat.format(localMethod.invoke(paramObject, null));
          }
          else
          {
            str1 = String.valueOf(localMethod.invoke(paramObject, null));
          }
        }
      }
      else
      {
        str2 = paramString.split("javaRenderer")[1];
        localMethod = paramObject.getClass().getMethod(str2, null);
        str1 = String.valueOf(localMethod.invoke(paramObject, null));
      }
    }
    catch (SecurityException localSecurityException)
    {
      localSecurityException.printStackTrace();
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      localNoSuchMethodException.printStackTrace();
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      localInvocationTargetException.printStackTrace();
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      localIllegalAccessException.printStackTrace();
    }
    return str1;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.util.ExportUtil
 * JD-Core Version:    0.6.0
 */