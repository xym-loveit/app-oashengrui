package com.htsoft.core.util;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

public class FunctionsUtil
  implements Serializable
{
  public static char[] crchar = { '\r', '\n' };
  public static String crlf = new String(crchar);
  public static char cr = '\r';
  public static char lf = '\n';
  public static char[] quchar = { '"' };
  public static char[] quBlank = { '"', '"' };
  public static String quote = new String(quchar);
  public static String blankQuote = new String(quBlank);
  public static String fs = File.separator;
  private static char[] hex40 = null;

  public static String chopstr(String paramString, int paramInt)
  {
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString, " ", true);
    int i = 0;
    int j = 1;
    String str1 = "";
    while (localStringTokenizer.hasMoreTokens())
    {
      String str2 = localStringTokenizer.nextToken();
      i += str2.length();
      if (((i <= paramInt ? 1 : 0) | j) != 0)
      {
        str1 = str1 + str2;
      }
      else
      {
        str1 = str1 + crlf + str2;
        i = str2.length();
      }
      if (j != 0)
        j = 0;
    }
    return str1;
  }

  public static String firstToUpperCase(String paramString)
  {
    String str1 = paramString.substring(1, paramString.length());
    String str2 = ("" + paramString.charAt(0)).toUpperCase();
    return str2 + str1;
  }

  public static void copyAppend(String paramString1, String paramString2)
    throws IOException
  {
    PrintWriter localPrintWriter = new PrintWriter(new FileWriter(paramString2, true));
    BufferedReader localBufferedReader = new BufferedReader(new FileReader(paramString1));
    String str;
    while ((str = localBufferedReader.readLine()) != null)
      localPrintWriter.println(str);
    localPrintWriter.close();
    localBufferedReader.close();
  }

  public static String d2x(String paramString, int paramInt1, int paramInt2)
  {
    String str1 = "";
    String str2 = "";
    String str3 = "";
    String str4 = "";
    int i = 0;
    if (paramString.indexOf("-") >= 0)
      str2 = "D";
    else
      str2 = "C";
    int j = paramString.length();
    for (int k = 0; k < j; k++)
    {
      char c = paramString.charAt(k);
      if ((c == '+') || (c == '-'))
        continue;
      if (c == '.')
        i = 1;
      else if (i != 0)
        str4 = str4 + c;
      else
        str3 = str3 + c;
    }
    k = paramInt1 - paramInt2;
    if (str3.length() < k)
      str3 = Pad(str3, '0', -1 * k);
    if (paramInt1 % 2 == 0)
      str3 = "0" + str3;
    if (str4.length() < paramInt2)
      str4 = Pad(str4, '0', paramInt2);
    str1 = s2x(str3 + str4 + str2);
    return str1;
  }

  public static int exp(int paramInt1, int paramInt2)
  {
    int i = paramInt1;
    if (paramInt2 > 0)
      for (int j = 1; j < paramInt2; j++)
        i *= paramInt1;
    else
      i = 1;
    return i;
  }

  public static String getArg(String[] paramArrayOfString, int paramInt)
  {
    return (paramInt >= 0) && (paramInt < paramArrayOfString.length) ? paramArrayOfString[paramInt].toUpperCase() : "";
  }

  public static String getArg(String[] paramArrayOfString, int paramInt, boolean paramBoolean)
  {
    String str = "";
    str = getArg(paramArrayOfString, paramInt);
    if ((paramBoolean) && (paramInt >= 0))
      for (int i = paramInt + 1; i < paramArrayOfString.length; i++)
        str = str + " " + paramArrayOfString[i];
    return str.toUpperCase();
  }

  public static String getFmtString(String paramString1, String paramString2)
  {
    int i = 0;
    int j = 0;
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString2, " (),");
    String str = "";
    int k = 1;
    while (localStringTokenizer.hasMoreTokens())
    {
      str = localStringTokenizer.nextToken().trim();
      try
      {
        Integer localInteger = new Integer(str);
        if (k != 0)
        {
          i = localInteger.intValue();
          k = 0;
        }
        else
        {
          j = localInteger.intValue();
        }
      }
      catch (Exception localException)
      {
      }
    }
    return getFmtString(paramString1, i, j);
  }

  public static String getFmtString(String paramString, int paramInt1, int paramInt2)
  {
    int i = paramInt1 - paramInt2;
    StringBuffer localStringBuffer = new StringBuffer("");
    int j = 0;
    for (int k = 0; k < i; k++)
    {
      if (j == 3)
      {
        localStringBuffer.insert(0, ",");
        j = 0;
      }
      if (k == 0)
        localStringBuffer.insert(0, "0");
      else
        localStringBuffer.insert(0, "#");
      j++;
    }
    for (k = 0; k < paramInt2; k++)
      if (k == 0)
        localStringBuffer.append(".0");
      else
        localStringBuffer.append("0");
    return "   private static String " + paramString + "Fmt " + " = " + quote + localStringBuffer.toString() + quote + ";";
  }

  public static String getFmtString(String paramString1, String paramString2, String paramString3)
  {
    int i = new Integer(paramString2).intValue();
    int j = new Integer(paramString3).intValue();
    return getFmtString(paramString1, i, j);
  }

  public static String getOpt(String paramString1, String paramString2)
  {
    String str = "";
    int i = paramString1.indexOf(paramString2);
    if (i >= 0)
    {
      int j = paramString1.length();
      int k = i + paramString2.length();
      int m = paramString1.indexOf(32, k);
      if ((m >= 0) && (m < j))
        j = m;
      m = paramString1.indexOf(47, k);
      if ((m >= 0) && (m < j))
        j = m;
      str = paramString1.substring(k, j);
    }
    return str;
  }

  public static String getParameter(String paramString1, String paramString2, String paramString3)
  {
    String str1 = "";
    if ((paramString2 == null) || (paramString1 == null))
      return str1;
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString1, paramString3);
    while (localStringTokenizer.hasMoreTokens())
    {
      String str2 = localStringTokenizer.nextToken().trim();
      if (str2.equals(paramString2))
      {
        if (!localStringTokenizer.hasMoreTokens())
          break;
        str1 = localStringTokenizer.nextToken().trim();
        break;
      }
    }
    return str1;
  }

  public static String getScale(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer("");
    int i = 0;
    int j = 0;
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString, " (),");
    String str = "";
    int k = 1;
    while (localStringTokenizer.hasMoreTokens())
    {
      str = localStringTokenizer.nextToken().trim();
      try
      {
        Integer localInteger1 = new Integer(str);
        if (k != 0)
        {
          i = localInteger1.intValue();
          k = 0;
        }
        else
        {
          j = localInteger1.intValue();
        }
      }
      catch (Exception localException)
      {
      }
    }
    Integer localInteger2 = new Integer(j);
    return localInteger2.toString();
  }

  public static void globalChange(String paramString1, String paramString2, String paramString3, boolean paramBoolean)
    throws Exception
  {
    File localFile1 = new File(paramString1);
    if (localFile1.isFile())
    {
      searchReplace(paramString1, paramString2, paramString3, "");
    }
    else if (localFile1.isDirectory())
    {
      String[] arrayOfString = localFile1.list();
      for (int i = 0; i < arrayOfString.length; i++)
      {
        File localFile2 = new File(localFile1, arrayOfString[i]);
        if ((!localFile2.isFile()) && (!paramBoolean))
          continue;
        globalChange(localFile2.getAbsolutePath(), paramString2, paramString3, paramBoolean);
      }
    }
    else
    {
      throw new Exception("Error in reading " + paramString1);
    }
  }

  public static int hexval(char paramChar)
  {
    int i = paramChar;
    if (i < 58)
      i = paramChar & 0xF;
    else
      i = (paramChar & 0xF) + '\t';
    return i;
  }

  public static String i2x(String paramString, int paramInt)
  {
    Integer localInteger = new Integer(paramString);
    int i = localInteger.intValue();
    String str1 = Integer.toHexString(i);
    str1 = str1.toUpperCase();
    int j = str1.length();
    int k = paramInt * 2;
    if (j < k)
      str1 = Pad(str1, '0', -1 * k);
    else if (j > k)
      str1 = str1.substring(j - k);
    String str2 = s2x(str1);
    return str2;
  }

  public static void searchReplace(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    String str1 = paramString4.toUpperCase();
    int i = str1.indexOf("/D") >= 0 ? 1 : 0;
    int j = str1.indexOf("/A") >= 0 ? 1 : 0;
    try
    {
      File localFile1 = new File(paramString1);
      String str2 = paramString1;
      if (str2.indexOf(".") > 0)
      {
        localObject = new StringTokenizer(str2, ".");
        str2 = ((StringTokenizer)localObject).nextToken().trim();
      }
      Object localObject = str2 + ".BAK";
      File localFile2 = new File((String)localObject);
      if (paramString1.equals(localObject))
        return;
      if (localFile2.exists())
        localFile2.delete();
      localFile1.renameTo(localFile2);
      PrintWriter localPrintWriter = new PrintWriter(new FileWriter(paramString1));
      BufferedReader localBufferedReader = new BufferedReader(new FileReader((String)localObject));
      String str3 = localBufferedReader.readLine();
      int k = 0;
      while (str3 != null)
      {
        int m = str3.indexOf(paramString2);
        if (m >= 0)
        {
          k++;
          if (i != 0)
            str3 = paramString3;
          else
            str3 = replaceString(str3, paramString2, paramString3);
        }
        localPrintWriter.println(str3);
        str3 = localBufferedReader.readLine();
      }
      if ((j != 0) && (k == 0) && (!paramString3.equals("")))
        localPrintWriter.println(paramString3);
      localBufferedReader.close();
      localPrintWriter.close();
    }
    catch (Exception localException)
    {
      System.out.println("Error in jsrchrepl  --> " + crlf + localException.toString());
      localException.printStackTrace();
      System.exit(12);
    }
  }

  public static void logMsg(String paramString1, String paramString2)
    throws IOException
  {
    PrintWriter localPrintWriter = new PrintWriter(new FileWriter(paramString2, true));
    localPrintWriter.println(paramString1);
    localPrintWriter.close();
  }

  public static String makeBusName(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer("");
    String str1 = " _/.,#'%-";
    String str2 = "0123456789";
    int i = paramString.length();
    char[] arrayOfChar = new char[1];
    int j = 1;
    for (int k = 0; k < i; k++)
    {
      arrayOfChar[0] = paramString.charAt(k);
      String str3 = new String(arrayOfChar);
      if (str1.indexOf(str3) >= 0)
      {
        if (str3.equals("'"))
          j = 0;
        else
          j = 1;
        localStringBuffer.append(str3);
      }
      else if (j != 0)
      {
        localStringBuffer.append(str3.toUpperCase());
        j = 0;
      }
      else
      {
        localStringBuffer.append(str3.toLowerCase());
      }
    }
    if (str2.indexOf(String.valueOf(localStringBuffer.charAt(0))) >= 0)
      localStringBuffer = localStringBuffer.insert(0, 'X');
    return localStringBuffer.toString();
  }

  public static String makeClassName(String paramString)
  {
    return makeFirstLetterUpperCase(makeVarName(paramString));
  }

  public static String makeFirstLetterLowerCase(String paramString)
  {
    if (paramString.length() == 0)
      return paramString;
    char[] arrayOfChar = new char[1];
    arrayOfChar[0] = paramString.charAt(0);
    String str = new String(arrayOfChar);
    return str.toLowerCase() + paramString.substring(1);
  }

  public static String makeFirstLetterUpperCase(String paramString)
  {
    if (paramString.length() == 0)
      return paramString;
    char[] arrayOfChar = new char[1];
    arrayOfChar[0] = paramString.charAt(0);
    String str = new String(arrayOfChar);
    return str.toUpperCase() + paramString.substring(1);
  }

  public static String makeVarName(String paramString)
  {
    int i = 1;
    StringBuffer localStringBuffer = new StringBuffer("");
    String str1 = " _/.,#'%-";
    String str2 = "0123456789";
    int j = paramString.length();
    char[] arrayOfChar = new char[1];
    int k = 0;
    int m = 1;
    for (int n = 0; n < j; n++)
    {
      arrayOfChar[0] = paramString.charAt(n);
      String str3 = new String(arrayOfChar);
      if (i == 0)
        str3 = str3.toLowerCase();
      if (str1.indexOf(str3) >= 0)
      {
        if (str3.equals("'"))
          k = 0;
        else
          k = 1;
      }
      else if (k != 0)
      {
        if (m == 0)
          localStringBuffer.append(str3.toUpperCase());
        else
          localStringBuffer.append(str3);
        m = 0;
        k = 0;
      }
      else
      {
        localStringBuffer.append(str3);
        m = 0;
      }
    }
    if (str2.indexOf(String.valueOf(localStringBuffer.charAt(0))) >= 0)
      localStringBuffer = localStringBuffer.insert(0, 'x');
    return localStringBuffer.toString();
  }

  public static String ovly(String paramString1, String paramString2, int paramInt1, int paramInt2)
  {
    int i = paramString2.length();
    int j = paramInt2;
    int k = paramString1.length();
    int m = 0;
    String str = paramString1;
    if (j == 0)
      j = paramString2.length();
    if (j == -1)
      j = -1 * paramString2.length();
    if (j >= 0)
      m = j + paramInt1 - 1;
    if (m > k)
      k = m;
    char[] arrayOfChar = new char[k];
    arrayOfChar = paramString1.toCharArray();
    for (int n = 0; n < i; n++)
    {
      int i1;
      if (j > 0)
      {
        i1 = paramInt1 + n - 1;
        if (((i1 >= 0 ? 1 : 0) & (i1 < k ? 1 : 0)) != 0)
          arrayOfChar[i1] = paramString2.charAt(n);
      }
      else if (j < 0)
      {
        i1 = i - n - 1;
        int i2 = paramInt1 - 1 - n;
        if (((i2 >= 0 ? 1 : 0) & (i2 < k ? 1 : 0)) != 0)
          arrayOfChar[i2] = paramString2.charAt(i1);
      }
      str = new String(arrayOfChar);
    }
    return str;
  }

  public static String Pad(String paramString, char paramChar, int paramInt)
  {
    int i = paramInt;
    if (i < 0)
      i = -1 * i;
    int j = i - paramString.length();
    String str = paramString;
    if (j > 0)
      for (int k = 0; k < j; k++)
        if (paramInt >= 0)
          str = str + paramChar;
        else
          str = paramChar + str;
    else
      str = paramString.substring(0, i);
    return str;
  }

  public static String PadHex40(String paramString, int paramInt)
  {
    int i = paramString.length();
    int j = paramInt - i;
    int k = hex40.length;
    if ((j <= k) && (j > 0))
      return paramString + new String(hex40, 0, j);
    char c = '@';
    return Pad(paramString, c, paramInt);
  }

  public static String Padn(String paramString, char paramChar, int paramInt)
  {
    int i = paramInt;
    if (paramInt < 0)
      i = paramInt * -1;
    if (paramString.length() > i)
      return paramString;
    return Pad(paramString, paramChar, paramInt);
  }

  public static final Hashtable parseStringToHashtable(String paramString1, String paramString2)
  {
    Hashtable localHashtable = new Hashtable();
    if (paramString1 == null)
      return localHashtable;
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString1, paramString2);
    while (localStringTokenizer.hasMoreTokens())
    {
      String str = localStringTokenizer.nextToken().trim();
      if (!str.equals(""))
        localHashtable.put(str, "");
    }
    return localHashtable;
  }

  public static boolean patternMatch(String paramString1, String paramString2)
  {
    if (paramString2.equals("*"))
      return true;
    if (paramString2.startsWith("*"))
    {
      String str1 = paramString2.substring(1);
      for (int j = 0; j < paramString1.length(); j++)
        if (patternMatch(paramString1.substring(j), str1))
          return true;
      return false;
    }
    int i = paramString2.indexOf("*");
    if (i < 0)
      return paramString1.equals(paramString2);
    String str2 = paramString2.substring(0, i);
    return (paramString1.startsWith(str2)) && (patternMatch(paramString1.substring(i), paramString2.substring(i)));
  }

  public static String replaceString(String paramString1, String paramString2, String paramString3)
  {
    int i = paramString1.indexOf(paramString2);
    if ((i < 0) || (paramString2.length() == 0))
      return paramString1;
    return paramString1.substring(0, i) + paramString3 + replaceString(paramString1.substring(i + paramString2.length()), paramString2, paramString3);
  }

  public static String s2x(String paramString)
  {
    String str = "";
    int i = paramString.length();
    for (int m = 0; m < i; m++)
    {
      int k = hexval(paramString.charAt(m)) * 16;
      m++;
      int j;
      if (m >= i)
        j = 0;
      else
        j = hexval(paramString.charAt(m));
      str = str + (char)(k + j);
    }
    return str;
  }

  public static String getCurrentDate()
  {
    Date localDate = new Date();
    return localDate.toString();
  }

  public static void sortStringArray(String[] paramArrayOfString)
  {
    Collator localCollator = Collator.getInstance();
    localCollator.setStrength(0);
    int i = paramArrayOfString.length;
    for (int j = i; j > 1; j--)
      for (int k = 0; k < j - 1; k++)
      {
        if (localCollator.compare(paramArrayOfString[k], paramArrayOfString[(k + 1)]) <= 0)
          continue;
        String str = paramArrayOfString[k];
        paramArrayOfString[k] = paramArrayOfString[(k + 1)];
        paramArrayOfString[(k + 1)] = str;
      }
  }

  public static String stripspecial(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer("");
    String str1 = " _/.,#'-%";
    int i = paramString.length();
    char[] arrayOfChar = new char[1];
    for (int j = 0; j < i; j++)
    {
      arrayOfChar[0] = paramString.charAt(j);
      String str2 = new String(arrayOfChar);
      if (str1.indexOf(str2) >= 0)
        continue;
      localStringBuffer.append(str2);
    }
    return localStringBuffer.toString();
  }

  public static String stripzero(String paramString)
  {
    String str = "";
    int i = 1;
    int j = paramString.length();
    for (int k = 0; k < j; k++)
    {
      char c = paramString.charAt(k);
      if ((i != 0) && (c == '0'))
        continue;
      str = str + c;
      i = 0;
    }
    if (str.equals(""))
      str = "0";
    return str;
  }

  public static String x2d(ByteArrayInputStream paramByteArrayInputStream, int paramInt1, int paramInt2)
  {
    String str1 = "";
    String str2 = "";
    String str3 = "";
    int i = paramInt1 % 2;
    if (i == 1)
      i = 0;
    else
      i = 1;
    int j = -1 * (paramInt1 + paramInt2);
    int k = paramInt1 - paramInt2;
    String str4 = x2s(paramByteArrayInputStream);
    int m = str4.length();
    str3 = str4.substring(m - 1);
    if (str3.equals("D"))
      str2 = "-";
    str4 = str4.substring(0, m - 1);
    if (k > 0)
      str1 = str4.substring(0, k + i);
    if (paramInt2 > 0)
      str1 = str1 + "." + str4.substring(k + i);
    str1 = str2 + stripzero(str1);
    return str1;
  }

  public static String x2d(String paramString, int paramInt1, int paramInt2)
  {
    String str1 = "";
    String str2 = "";
    String str3 = "";
    int i = paramInt1 % 2;
    if (i == 1)
      i = 0;
    else
      i = 1;
    int j = -1 * (paramInt1 + paramInt2);
    int k = paramInt1 - paramInt2;
    String str4 = x2s(paramString);
    int m = str4.length();
    str3 = str4.substring(m - 1);
    if (str3.equals("D"))
      str2 = "-";
    str4 = str4.substring(0, m - 1);
    if (k > 0)
      str1 = str4.substring(0, k + i);
    if (paramInt2 > 0)
      str1 = str1 + "." + str4.substring(k + i);
    str1 = str2 + stripzero(str1);
    return str1;
  }

  public static String x2i(ByteArrayInputStream paramByteArrayInputStream, boolean paramBoolean)
  {
    String str1 = "";
    try
    {
      String str2 = x2s(paramByteArrayInputStream);
      int i = str2.length();
      int j = 0;
      long l = 0L;
      for (int k = 0; k < i; k++)
      {
        int m = i - k - 1;
        int n = hexval(str2.charAt(m));
        j = n * exp(16, k);
        l += j;
      }
      if (paramBoolean)
      {
        if (l > 32767L)
          l -= 65536L;
      }
      else if (l > 2147483647L)
        l -= 4294967296L;
      Long localLong = new Long(l);
      str1 = localLong.toString();
    }
    catch (Exception localException)
    {
      return "Error: " + localException;
    }
    return str1;
  }

  public static String x2i(String paramString, boolean paramBoolean)
  {
    String str1 = "";
    try
    {
      String str2 = x2s(paramString);
      int i = str2.length();
      int j = 0;
      long l = 0L;
      for (int k = 0; k < i; k++)
      {
        int m = i - k - 1;
        int n = hexval(str2.charAt(m));
        j = n * exp(16, k);
        l += j;
      }
      if (paramBoolean)
      {
        if (l > 32767L)
          l -= 65536L;
      }
      else if (l > 2147483647L)
        l -= 4294967296L;
      Long localLong = new Long(l);
      str1 = localLong.toString();
    }
    catch (Exception localException)
    {
      return "Error: " + localException;
    }
    return str1;
  }

  public static String x2s(ByteArrayInputStream paramByteArrayInputStream)
  {
    String str1 = "";
    int i = paramByteArrayInputStream.available();
    int j = i * 2;
    String str2 = "";
    for (int k = 0; k < i; k++)
    {
      int m = paramByteArrayInputStream.read();
      str2 = Integer.toHexString(m);
      if (str2.length() == 1)
        str1 = str1 + "0" + str2;
      else
        str1 = str1 + str2;
    }
    return str1.toUpperCase();
  }

  public static Properties extractProperties(Properties paramProperties, String paramString)
  {
    Properties localProperties = new Properties();
    Enumeration localEnumeration = paramProperties.keys();
    while (localEnumeration.hasMoreElements())
    {
      String str1 = (String)localEnumeration.nextElement();
      if ((str1 != null) && (str1.indexOf(paramString) >= 0))
      {
        String str2 = paramProperties.getProperty(str1);
        localProperties.put(str1, str2);
      }
    }
    return localProperties;
  }

  public static List extractPropertyValues(Properties paramProperties)
  {
    ArrayList localArrayList = new ArrayList();
    Enumeration localEnumeration = paramProperties.elements();
    while (localEnumeration.hasMoreElements())
      localArrayList.add(localEnumeration.nextElement());
    return localArrayList;
  }

  public static void createDir(File paramFile)
  {
    if (paramFile.exists())
      return;
    File localFile = new File(paramFile.getParent());
    if (!localFile.isDirectory())
      localFile.mkdirs();
  }

  public static boolean hasMask(String paramString1, String paramString2)
  {
    int i = paramString1.toUpperCase().indexOf(paramString2.toUpperCase()) >= 0 ? 1 : 0;
    return i;
  }

  public static String makeLowerCase(String paramString)
  {
    return paramString.toLowerCase();
  }

  public static String makeUpperCase(String paramString)
  {
    return paramString.toUpperCase();
  }

  public static String x2s(String paramString)
  {
    String str1 = "";
    int i = paramString.length();
    int j = i * 2;
    String str2 = "";
    for (int k = 0; k < i; k++)
    {
      int m = paramString.charAt(k);
      str2 = Integer.toHexString(m);
      if (str2.length() == 1)
        str1 = str1 + "0" + str2;
      else
        str1 = str1 + str2;
    }
    return str1.toUpperCase();
  }

  public static String quote(String paramString)
  {
    return quote + paramString + quote;
  }

  static
  {
    hex40 = new char[4000];
    for (int i = 0; i < 4000; i++)
      hex40[i] = '@';
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.util.FunctionsUtil
 * JD-Core Version:    0.6.0
 */