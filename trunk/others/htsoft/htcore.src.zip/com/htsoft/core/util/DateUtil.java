package com.htsoft.core.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class DateUtil
{
  private static final Log logger = LogFactory.getLog(DateUtil.class);

  public static Calendar setStartDay(Calendar paramCalendar)
  {
    paramCalendar.set(11, 0);
    paramCalendar.set(12, 0);
    paramCalendar.set(13, 0);
    return paramCalendar;
  }

  public static Calendar setEndDay(Calendar paramCalendar)
  {
    paramCalendar.set(11, 23);
    paramCalendar.set(12, 59);
    paramCalendar.set(13, 59);
    return paramCalendar;
  }

  public static void copyYearMonthDay(Calendar paramCalendar1, Calendar paramCalendar2)
  {
    paramCalendar1.set(1, paramCalendar2.get(1));
    paramCalendar1.set(2, paramCalendar2.get(2));
    paramCalendar1.set(5, paramCalendar2.get(5));
  }

  public static String formatEnDate(Date paramDate)
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
    return localSimpleDateFormat.format(paramDate).replaceAll("上午", "AM").replaceAll("下午", "PM");
  }

  public static Date parseDate(String paramString)
  {
    Date localDate = null;
    try
    {
      localDate = DateUtils.parseDate(paramString, new String[] { "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd" });
    }
    catch (Exception localException)
    {
      logger.error("Pase the Date(" + paramString + ") occur errors:" + localException.getMessage());
    }
    return localDate;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.util.DateUtil
 * JD-Core Version:    0.6.0
 */