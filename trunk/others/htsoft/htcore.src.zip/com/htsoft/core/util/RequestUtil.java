package com.htsoft.core.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.servlet.http.HttpServletRequest;

public class RequestUtil
{
  public static final String getErrorUrl(HttpServletRequest paramHttpServletRequest)
  {
    String str = (String)paramHttpServletRequest.getAttribute("javax.servlet.error.request_uri");
    if (str == null)
      str = (String)paramHttpServletRequest.getAttribute("javax.servlet.forward.request_uri");
    if (str == null)
      str = (String)paramHttpServletRequest.getAttribute("javax.servlet.include.request_uri");
    if (str == null)
      str = paramHttpServletRequest.getRequestURL().toString();
    return str;
  }

  public static final StringBuilder getErrorInfoFromRequest(HttpServletRequest paramHttpServletRequest, boolean paramBoolean)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    String str = getErrorUrl(paramHttpServletRequest);
    localStringBuilder.append(StringUtil.formatMsg("Error processing url: %1, Referrer: %2, Error message: %3.\n", new Object[] { str, paramHttpServletRequest.getHeader("REFERER"), paramHttpServletRequest.getAttribute("javax.servlet.error.message") }));
    Throwable localThrowable = (Throwable)paramHttpServletRequest.getAttribute("exception");
    if (localThrowable == null)
      localThrowable = (Throwable)paramHttpServletRequest.getAttribute("javax.servlet.error.exception");
    if (localThrowable != null)
      localStringBuilder.append(StringUtil.formatMsg("Exception stack trace: \n", new Object[] { localThrowable }));
    return localStringBuilder;
  }

  public static final String getHtml(String paramString)
    throws IOException
  {
    URL localURL = new URL(paramString);
    HttpURLConnection localHttpURLConnection = (HttpURLConnection)localURL.openConnection();
    InputStream localInputStream = localHttpURLConnection.getInputStream();
    StringWriter localStringWriter = new StringWriter();
    if (localInputStream != null)
    {
      char[] arrayOfChar = new char[1024];
      try
      {
        BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(localInputStream, "UTF-8"));
        int i;
        while ((i = localBufferedReader.read(arrayOfChar)) != -1)
          localStringWriter.write(arrayOfChar, 0, i);
      }
      finally
      {
        localInputStream.close();
      }
    }
    return localStringWriter.toString();
  }

  public static void main(String[] paramArrayOfString)
    throws IOException
  {
    String str1 = "http://www.baidu.com";
    String str2 = getHtml(str1);
    System.out.println(new StringBuilder().append("ss:").append(str2).toString());
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.util.RequestUtil
 * JD-Core Version:    0.6.0
 */