package com.htsoft.core.util;

import com.htsoft.core.DataInit.DataInit;
import com.htsoft.core.jbpm.jpdl.ProcessInit;
import com.htsoft.core.menu.TopModule;
import com.htsoft.core.model.OnlineUser;
import com.htsoft.core.web.filter.SecurityInterceptorFilter;
import com.htsoft.oa.model.system.AppFunction;
import com.htsoft.oa.model.system.AppRole;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.Company;
import com.htsoft.oa.model.system.Department;
import com.htsoft.oa.model.system.FunUrl;
import com.htsoft.oa.model.system.SysConfig;
import com.htsoft.oa.service.system.AppFunctionService;
import com.htsoft.oa.service.system.CompanyService;
import com.htsoft.oa.service.system.FunUrlService;
import com.htsoft.oa.service.system.SysConfigService;
import com.htsoft.oa.util.FlowUtil;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import javax.servlet.ServletContext;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class AppUtil
  implements ApplicationContextAware
{
  private static Log logger = LogFactory.getLog(AppUtil.class);
  private static Map configMap = new HashMap();
  private static ServletContext servletContext = null;
  private static Map<String, OnlineUser> onlineUsers = new LinkedHashMap();
  private static ApplicationContext appContext;
  private static Map<String, Document> orgMenus = null;
  private static Map<String, Document> itemsMenus = null;
  private static Map<String, TopModule> allTopModels = null;
  private static Document menuDocument = null;
  public static Map<String, TopModule> publicTopModules = null;
  private static Set<String> publicMenuIds = null;

  public void setApplicationContext(ApplicationContext paramApplicationContext)
    throws BeansException
  {
    appContext = paramApplicationContext;
  }

  public static Map<String, Document> getOrgMenus()
  {
    return orgMenus;
  }

  public static Map<String, Document> getItemsMenus()
  {
    return itemsMenus;
  }

  public static Map<String, TopModule> getAllTopModels()
  {
    return allTopModels;
  }

  public static Document getMenuDocument()
  {
    return menuDocument;
  }

  public static void setPublicMenuIds(Set<String> paramSet)
  {
    publicMenuIds = paramSet;
  }

  public static Map<String, TopModule> getPublicTopModules()
  {
    return publicTopModules;
  }

  public static void setPublicTopModules(Map<String, TopModule> paramMap)
  {
    publicTopModules = paramMap;
  }

  public static Object getBean(String paramString)
  {
    return appContext.getBean(paramString);
  }

  public static Map<String, OnlineUser> getOnlineUsers()
  {
    return onlineUsers;
  }

  public static void removeOnlineUser(String paramString)
  {
    onlineUsers.remove(paramString);
  }

  public static void addOnlineUser(String paramString, AppUser paramAppUser)
  {
    if (!onlineUsers.containsKey(paramString))
    {
      OnlineUser localOnlineUser = new OnlineUser();
      localOnlineUser.setFullname(paramAppUser.getFullname());
      localOnlineUser.setSessionId(paramString);
      localOnlineUser.setUsername(paramAppUser.getUsername());
      localOnlineUser.setUserId(paramAppUser.getUserId());
      if (!paramAppUser.getUserId().equals(AppUser.SUPER_USER))
        localOnlineUser.setDepPath("." + paramAppUser.getDepartment().getPath());
      Set localSet = paramAppUser.getRoles();
      StringBuffer localStringBuffer = new StringBuffer(",");
      Iterator localIterator = localSet.iterator();
      while (localIterator.hasNext())
      {
        AppRole localAppRole = (AppRole)localIterator.next();
        localStringBuffer.append(localAppRole.getRoleId() + ",");
      }
      localOnlineUser.setRoleIds(localStringBuffer.toString());
      localOnlineUser.setTitle(paramAppUser.getTitle());
      onlineUsers.put(paramString, localOnlineUser);
    }
  }

  public static String getAppAbsolutePath()
  {
    return servletContext.getRealPath("/");
  }

  public static String getMenuAbDir()
  {
    return getAppAbsolutePath() + "/js/menu/xml/";
  }

  public static String getMenuXslDir()
  {
    return getAppAbsolutePath() + "/js/menu/";
  }

  public static String getFlowFormAbsolutePath()
  {
    String str = (String)configMap.get("app.flowFormPath");
    if (str == null)
      str = "/WEB-INF/FlowForm/";
    return getAppAbsolutePath() + str;
  }

  public static String getMobileFlowFlowAbsPath()
  {
    return getAppAbsolutePath() + "/mobile/flow/FlowForm/";
  }

  public static void reloadSecurityDataSource()
  {
    SecurityInterceptorFilter localSecurityInterceptorFilter = (SecurityInterceptorFilter)getBean("securityInterceptorFilter");
    localSecurityInterceptorFilter.loadDataSource();
  }

  public static void init(ServletContext paramServletContext)
  {
    servletContext = paramServletContext;
    String str1 = servletContext.getRealPath("/WEB-INF/classes/conf/");
    String str2 = str1 + "/config.properties";
    Properties localProperties = new Properties();
    Object localObject2;
    try
    {
      FileInputStream localFileInputStream = new FileInputStream(str2);
      localObject1 = new InputStreamReader(localFileInputStream, "UTF-8");
      localProperties.load((Reader)localObject1);
      localObject2 = localProperties.keySet().iterator();
      while (((Iterator)localObject2).hasNext())
      {
        String str3 = (String)((Iterator)localObject2).next();
        configMap.put(str3, localProperties.get(str3));
      }
    }
    catch (Exception localException)
    {
      logger.error(localException.getMessage());
    }
    reloadSysConfig();
    CompanyService localCompanyService = (CompanyService)getBean("companyService");
    Object localObject1 = localCompanyService.findCompany();
    if (((List)localObject1).size() > 0)
    {
      localObject2 = (Company)((List)localObject1).get(0);
      configMap.put("app.logoPath", ((Company)localObject2).getLogo());
      configMap.put("app.companyName", ((Company)localObject2).getCompanyName());
    }
    if (isSetupMode())
    {
      logger.info("开始初始化系统的缺省流程...");
      ProcessInit.initFlows(getAppAbsolutePath());
      logger.info("结束初始化系统的缺省流程...");
      logger.info("初始化数据~\t开始...");
      DataInit.init(getAppAbsolutePath());
      logger.info("初始化数据~\t结束...");
      logger.info("更改安装模式为false");
      PropertiesUtil.writeKey(str2, "setupMode", "false");
    }
    reloadMenu();
    logger.info("加载流程动态表单动态实体的结构映射到静态变量... ");
    FlowUtil.initDynModel();
  }

  public static void reloadMenu()
  {
    orgMenus = MenuUtil.getAllOrgMenus();
    itemsMenus = MenuUtil.getAllItemsMenus(orgMenus);
    menuDocument = MenuUtil.mergeOneDoc(orgMenus);
    allTopModels = MenuUtil.getTopModules(menuDocument);
    publicTopModules = MenuUtil.getPublicTopModules(allTopModels);
  }

  public static void synMenu()
  {
    AppFunctionService localAppFunctionService = (AppFunctionService)getBean("appFunctionService");
    FunUrlService localFunUrlService = (FunUrlService)getBean("funUrlService");
    Iterator localIterator = orgMenus.keySet().iterator();
    while (localIterator.hasNext())
    {
      Document localDocument = (Document)orgMenus.get(localIterator.next());
      List localList1 = localDocument.getRootElement().selectNodes("/Menus/Items//Item/Function");
      for (int i = 0; i < localList1.size(); i++)
      {
        Element localElement = (Element)localList1.get(i);
        String str1 = localElement.attributeValue("id");
        String str2 = localElement.attributeValue("text");
        AppFunction localAppFunction = localAppFunctionService.getByKey(str1);
        if (localAppFunction == null)
          localAppFunction = new AppFunction(str1, str2);
        else
          localAppFunction.setFunName(str2);
        List localList2 = localElement.selectNodes("./url");
        localAppFunctionService.save(localAppFunction);
        for (int j = 0; j < localList2.size(); j++)
        {
          Node localNode = (Node)localList2.get(j);
          String str3 = localNode.getText();
          FunUrl localFunUrl = localFunUrlService.getByPathFunId(str3, localAppFunction.getFunctionId());
          if (localFunUrl != null)
            continue;
          localFunUrl = new FunUrl();
          localFunUrl.setUrlPath(str3);
          localFunUrl.setAppFunction(localAppFunction);
          localFunUrlService.save(localFunUrl);
        }
      }
    }
  }

  public static Document getGrantMenuDocument()
  {
    String str = servletContext.getRealPath("/js/menu") + "/menu-grant.xsl";
    Document localDocument = null;
    try
    {
      localDocument = XmlUtil.styleDocument(menuDocument, str);
    }
    catch (Exception localException)
    {
      logger.error("menu-grant.xsl transform has error:" + localException.getMessage());
    }
    return localDocument;
  }

  public static boolean getIsSynMenu()
  {
    String str = (String)configMap.get("isSynMenu");
    return "true".equals(str);
  }

  public static Map getSysConfig()
  {
    return configMap;
  }

  public static void reloadSysConfig()
  {
    SysConfigService localSysConfigService = (SysConfigService)getBean("sysConfigService");
    List localList = localSysConfigService.getAll();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      SysConfig localSysConfig = (SysConfig)localIterator.next();
      configMap.put(localSysConfig.getConfigKey(), localSysConfig.getDataValue());
    }
  }

  public static String getCompanyLogo()
  {
    String str1 = "/images/ht-logo.png";
    String str2 = (String)configMap.get("app.logoPath");
    if (StringUtils.isNotEmpty(str2))
      str1 = "/attachFiles/" + str2;
    return str1;
  }

  public static String getCompanyName()
  {
    Object localObject = "广州市宏天软件有限公司";
    String str = (String)configMap.get("app.companyName");
    if (StringUtils.isNotEmpty(str))
      localObject = str;
    return (String)localObject;
  }

  public static boolean getSmsPort()
  {
    String str = (String)configMap.get("smsPort");
    return "true".equals(str);
  }

  public static boolean isSetupMode()
  {
    String str = (String)configMap.get("setupMode");
    return "true".equals(str);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.util.AppUtil
 * JD-Core Version:    0.6.0
 */