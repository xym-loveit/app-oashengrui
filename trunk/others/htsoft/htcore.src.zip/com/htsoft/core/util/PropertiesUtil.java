package com.htsoft.core.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Properties;

public class PropertiesUtil
{
  public static Properties getFromFile(String paramString1, String paramString2)
  {
    FileInputStream localFileInputStream = null;
    Properties localProperties = new Properties();
    InputStreamReader localInputStreamReader = null;
    try
    {
      localFileInputStream = new FileInputStream(paramString1);
      localInputStreamReader = new InputStreamReader(localFileInputStream, paramString2);
      localProperties.load(localInputStreamReader);
    }
    catch (Exception localException3)
    {
      localException2.printStackTrace();
    }
    finally
    {
      try
      {
        if (localInputStreamReader != null)
          localInputStreamReader.close();
        if (localFileInputStream != null)
          localFileInputStream.close();
      }
      catch (Exception localException4)
      {
      }
    }
    return localProperties;
  }

  public static Properties getFromFile(String paramString)
  {
    return getFromFile(paramString, "UTF-8");
  }

  public static void writeKey(String paramString1, String paramString2, String paramString3)
  {
    Properties localProperties = getFromFile(paramString1);
    localProperties.setProperty(paramString2, paramString3);
    try
    {
      FileOutputStream localFileOutputStream = new FileOutputStream(new File(paramString1));
      localProperties.store(localFileOutputStream, "set");
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.util.PropertiesUtil
 * JD-Core Version:    0.6.0
 */