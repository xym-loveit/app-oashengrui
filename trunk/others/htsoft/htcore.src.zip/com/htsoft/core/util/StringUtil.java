package com.htsoft.core.util;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.security.MessageDigest;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.codec.binary.Base64;

public class StringUtil
{
  public static boolean isNumeric(String paramString)
  {
    int i = paramString.length();
    while (true)
    {
      i--;
      if (i < 0)
        break;
      if (!Character.isDigit(paramString.charAt(i)))
        return false;
    }
    return true;
  }

  public static StringBuilder formatMsg(CharSequence paramCharSequence, boolean paramBoolean, Object[] paramArrayOfObject)
  {
    int i = paramArrayOfObject.length;
    int j = 0;
    StringBuilder localStringBuilder = new StringBuilder(paramCharSequence);
    if (i > 0)
    {
      for (int k = 0; k < i; k++)
      {
        String str = new StringBuilder().append("%").append(k + 1).toString();
        for (int m = localStringBuilder.indexOf(str); m >= 0; m = localStringBuilder.indexOf(str))
        {
          j = 1;
          localStringBuilder.replace(m, m + 2, toString(paramArrayOfObject[k], paramBoolean));
        }
      }
      if ((paramArrayOfObject[(i - 1)] instanceof Throwable))
      {
        StringWriter localStringWriter = new StringWriter();
        ((Throwable)paramArrayOfObject[(i - 1)]).printStackTrace(new PrintWriter(localStringWriter));
        localStringBuilder.append("\n").append(localStringWriter.toString());
      }
      else if ((i == 1) && (j == 0))
      {
        localStringBuilder.append(paramArrayOfObject[(i - 1)].toString());
      }
    }
    return localStringBuilder;
  }

  public static StringBuilder formatMsg(String paramString, Object[] paramArrayOfObject)
  {
    return formatMsg(new StringBuilder(paramString), true, paramArrayOfObject);
  }

  public static String toString(Object paramObject, boolean paramBoolean)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    if (paramObject == null)
    {
      localStringBuilder.append("NULL");
    }
    else if ((paramObject instanceof Object[]))
    {
      for (int i = 0; i < ((Object[])(Object[])paramObject).length; i++)
        localStringBuilder.append(((Object[])(Object[])paramObject)[i]).append(", ");
      if (localStringBuilder.length() > 0)
        localStringBuilder.delete(localStringBuilder.length() - 2, localStringBuilder.length());
    }
    else
    {
      localStringBuilder.append(paramObject.toString());
    }
    if ((paramBoolean) && (localStringBuilder.length() > 0) && ((localStringBuilder.charAt(0) != '[') || (localStringBuilder.charAt(localStringBuilder.length() - 1) != ']')) && ((localStringBuilder.charAt(0) != '{') || (localStringBuilder.charAt(localStringBuilder.length() - 1) != '}')))
      localStringBuilder.insert(0, "[").append("]");
    return localStringBuilder.toString();
  }

  public static String convertQuot(String paramString)
  {
    return paramString.replace("'", "\\'").replace("\"", "\\\"");
  }

  public static synchronized String encryptSha256(String paramString)
  {
    try
    {
      MessageDigest localMessageDigest = MessageDigest.getInstance("SHA-256");
      byte[] arrayOfByte = localMessageDigest.digest(paramString.getBytes("UTF-8"));
      return new String(Base64.encodeBase64(arrayOfByte));
    }
    catch (Exception localException)
    {
    }
    return null;
  }

  public static String htmlEntityToString(String paramString)
  {
    int i = 0;
    int j = 0;
    StringBuffer localStringBuffer = new StringBuffer();
    while (i > -1)
    {
      int k = 10;
      if (i == 0)
      {
        int m = paramString.indexOf("&#");
        if (i != m)
          i = m;
      }
      j = paramString.indexOf(";", i + 2);
      String str = "";
      char c;
      if (j != -1)
      {
        str = paramString.substring(i + 2, j);
        c = str.charAt(0);
        if ((c == 'x') || (c == 'X'))
        {
          k = 16;
          str = str.substring(1);
        }
      }
      try
      {
        c = (char)Integer.parseInt(str, k);
        localStringBuffer.append(new Character(c).toString());
      }
      catch (NumberFormatException localNumberFormatException)
      {
        localNumberFormatException.printStackTrace();
      }
      i = paramString.indexOf("&#", j);
      if (i - j > 1)
        localStringBuffer.append(paramString.substring(j + 1, i));
      if (i == -1)
      {
        int n = paramString.length();
        if (j + 1 != n)
          localStringBuffer.append(paramString.substring(j + 1, n));
      }
    }
    return localStringBuffer.toString();
  }

  public static String stringToHtmlEntity(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 0; i < paramString.length(); i++)
    {
      char c = paramString.charAt(i);
      switch (c)
      {
      case '\n':
        localStringBuffer.append(c);
        break;
      case '<':
        localStringBuffer.append("&lt;");
        break;
      case '>':
        localStringBuffer.append("&gt;");
        break;
      case '&':
        localStringBuffer.append("&amp;");
        break;
      case '\'':
        localStringBuffer.append("&apos;");
        break;
      case '"':
        localStringBuffer.append("&quot;");
        break;
      default:
        if ((c < ' ') || (c > '~'))
        {
          localStringBuffer.append("&#x");
          localStringBuffer.append(Integer.toString(c, 16));
          localStringBuffer.append(';');
        }
        else
        {
          localStringBuffer.append(c);
        }
      }
    }
    return localStringBuffer.toString();
  }

  public static String stringToUnicode(String paramString)
  {
    String str = "";
    char[] arrayOfChar = new char[paramString.length()];
    for (int i = 0; i < arrayOfChar.length; i++)
    {
      arrayOfChar[i] = paramString.charAt(i);
      str = new StringBuilder().append(str).append("\\u").append(Integer.toString(arrayOfChar[i], 16)).toString();
    }
    return str;
  }

  public static String unicodeToString(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    String[] arrayOfString = paramString.toUpperCase().split("\\\\U");
    for (int i = 0; i < arrayOfString.length; i++)
    {
      if (arrayOfString[i].equals(""))
        continue;
      char c = (char)Integer.parseInt(arrayOfString[i].trim(), 16);
      localStringBuffer.append(c);
    }
    return localStringBuffer.toString();
  }

  public static void main(String[] paramArrayOfString)
  {
    String str = "123";
    System.out.println(encryptSha256(str));
  }

  public static String html2Text(String paramString)
  {
    String str1 = paramString;
    String str2 = "";
    try
    {
      String str3 = "<[\\s]*?script[^>]*?>[\\s\\S]*?<[\\s]*?\\/[\\s]*?script[\\s]*?>";
      String str4 = "<[\\s]*?style[^>]*?>[\\s\\S]*?<[\\s]*?\\/[\\s]*?style[\\s]*?>";
      String str5 = "<[^>]+>";
      Pattern localPattern1 = Pattern.compile(str3, 2);
      Matcher localMatcher1 = localPattern1.matcher(str1);
      str1 = localMatcher1.replaceAll("");
      Pattern localPattern2 = Pattern.compile(str4, 2);
      Matcher localMatcher2 = localPattern2.matcher(str1);
      str1 = localMatcher2.replaceAll("");
      Pattern localPattern3 = Pattern.compile(str5, 2);
      Matcher localMatcher3 = localPattern3.matcher(str1);
      str1 = localMatcher3.replaceAll("");
      str2 = str1;
    }
    catch (Exception localException)
    {
      System.err.println(new StringBuilder().append("Html2Text: ").append(localException.getMessage()).toString());
    }
    return str2;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.util.StringUtil
 * JD-Core Version:    0.6.0
 */