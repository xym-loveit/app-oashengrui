package com.htsoft.core.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.List;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.DocumentResult;
import org.dom4j.io.DocumentSource;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

public class XmlUtil
{
  private static final Log logger = LogFactory.getLog(XmlUtil.class);

  public static String docToString(Document paramDocument)
  {
    String str = "";
    try
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      OutputFormat localOutputFormat = new OutputFormat("  ", true, "UTF-8");
      XMLWriter localXMLWriter = new XMLWriter(localByteArrayOutputStream, localOutputFormat);
      localXMLWriter.write(paramDocument);
      str = localByteArrayOutputStream.toString("UTF-8");
    }
    catch (Exception localException)
    {
      logger.error("docToString error:" + localException.getMessage());
    }
    return str;
  }

  public static Document stringToDocument(String paramString)
  {
    Document localDocument = null;
    try
    {
      localDocument = DocumentHelper.parseText(paramString);
    }
    catch (Exception localException)
    {
      logger.error("stringToDocument error:" + localException.getMessage());
    }
    return localDocument;
  }

  public static boolean docToXmlFile(Document paramDocument, String paramString)
  {
    int i = 1;
    try
    {
      OutputFormat localOutputFormat = OutputFormat.createPrettyPrint();
      localOutputFormat.setEncoding("UTF-8");
      XMLWriter localXMLWriter = new XMLWriter(new FileOutputStream(new File(paramString)), localOutputFormat);
      localXMLWriter.write(paramDocument);
      localXMLWriter.close();
    }
    catch (Exception localException)
    {
      i = 0;
      logger.error("docToXmlFile error:" + localException.getMessage());
    }
    return i;
  }

  public static boolean stringToXmlFile(String paramString1, String paramString2)
  {
    boolean bool = true;
    try
    {
      Document localDocument = DocumentHelper.parseText(paramString1);
      bool = docToXmlFile(localDocument, paramString2);
    }
    catch (Exception localException)
    {
      bool = false;
      logger.error("stringToXmlFile error:" + localException.getMessage());
    }
    return bool;
  }

  public static Document load(String paramString)
  {
    return load(new File(paramString));
  }

  public static Document load(File paramFile)
  {
    Document localDocument = null;
    try
    {
      SAXReader localSAXReader = new SAXReader();
      localSAXReader.setEncoding("UTF-8");
      localDocument = localSAXReader.read(paramFile);
    }
    catch (Exception localException)
    {
      logger.error("load XML File error:" + localException.getMessage());
    }
    return localDocument;
  }

  public static Document load(String paramString1, String paramString2)
  {
    Document localDocument = null;
    try
    {
      SAXReader localSAXReader = new SAXReader();
      localSAXReader.setEncoding("encode");
      localDocument = localSAXReader.read(new File(paramString1));
    }
    catch (Exception localException)
    {
      logger.error("load XML File error:" + localException.getMessage());
    }
    return localDocument;
  }

  public static Document load(InputStream paramInputStream)
  {
    Document localDocument = null;
    try
    {
      SAXReader localSAXReader = new SAXReader();
      localSAXReader.setEncoding("UTF-8");
      localDocument = localSAXReader.read(paramInputStream);
    }
    catch (Exception localException)
    {
      logger.error("load XML File error:" + localException.getMessage());
    }
    return localDocument;
  }

  public static Document load(InputStream paramInputStream, String paramString)
  {
    Document localDocument = null;
    try
    {
      SAXReader localSAXReader = new SAXReader();
      localSAXReader.setEncoding(paramString);
      localDocument = localSAXReader.read(paramInputStream);
    }
    catch (Exception localException)
    {
      logger.error("load XML File error:" + localException.getMessage());
    }
    return localDocument;
  }

  public static Document styleDocument(Document paramDocument, String paramString)
    throws Exception
  {
    TransformerFactory localTransformerFactory = TransformerFactory.newInstance();
    Transformer localTransformer = localTransformerFactory.newTransformer(new StreamSource(paramString));
    DocumentSource localDocumentSource = new DocumentSource(paramDocument);
    DocumentResult localDocumentResult = new DocumentResult();
    localTransformer.transform(localDocumentSource, localDocumentResult);
    Document localDocument = localDocumentResult.getDocument();
    return localDocument;
  }

  public static void main(String[] paramArrayOfString)
  {
    String str1 = "L:/devtools/workspace/eoffice/web/js/menu.xml";
    String str2 = "L:/devtools/workspace/eoffice/web/js/menu-public.xsl";
    Document localDocument1 = load(str1);
    try
    {
      Document localDocument2 = styleDocument(localDocument1, str2);
      System.out.println("xml:" + localDocument2.asXML());
      Document localDocument3 = localDocument2;
      Element localElement1 = localDocument3.getRootElement();
      List localList = localElement1.selectNodes("/Menus//*");
      System.out.println("size:" + localList.size());
      for (int i = 0; i < localList.size(); i++)
      {
        Element localElement2 = (Element)localList.get(i);
        Attribute localAttribute = localElement2.attribute("id");
        if (localAttribute == null)
          continue;
        System.out.println("attr:" + localAttribute.getValue());
      }
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.util.XmlUtil
 * JD-Core Version:    0.6.0
 */