package com.htsoft.core.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class CertUtil
{
  public static Log logger = LogFactory.getLog(CertUtil.class);
  private static final char[] HEXDIGITS = "0123456789abcdef".toCharArray();

  public static File get(String paramString, int paramInt)
  {
    try
    {
      char[] arrayOfChar = "changeit".toCharArray();
      File localFile1 = new File("jssecacerts");
      if (!localFile1.isFile())
      {
        char c = File.separatorChar;
        localObject = new File(new StringBuilder().append(System.getProperty("java.home")).append(c).append("lib").append(c).append("security").toString());
        localFile1 = new File((File)localObject, "jssecacerts");
        if (!localFile1.isFile())
          localFile1 = new File((File)localObject, "cacerts");
      }
      FileInputStream localFileInputStream = new FileInputStream(localFile1);
      Object localObject = KeyStore.getInstance(KeyStore.getDefaultType());
      ((KeyStore)localObject).load(localFileInputStream, arrayOfChar);
      localFileInputStream.close();
      SSLContext localSSLContext = SSLContext.getInstance("TLS");
      TrustManagerFactory localTrustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
      localTrustManagerFactory.init((KeyStore)localObject);
      X509TrustManager localX509TrustManager = (X509TrustManager)localTrustManagerFactory.getTrustManagers()[0];
      SavingTrustManager localSavingTrustManager = new SavingTrustManager(localX509TrustManager);
      localSSLContext.init(null, new TrustManager[] { localSavingTrustManager }, null);
      SSLSocketFactory localSSLSocketFactory = localSSLContext.getSocketFactory();
      logger.debug(new StringBuilder().append("Opening connection to ").append(paramString).append(":").append(paramInt).append("...").toString());
      SSLSocket localSSLSocket = (SSLSocket)localSSLSocketFactory.createSocket(paramString, paramInt);
      localSSLSocket.setSoTimeout(10000);
      if (localSSLSocket != null)
      {
        localSSLSocket.startHandshake();
        localSSLSocket.close();
      }
      X509Certificate[] arrayOfX509Certificate = localSavingTrustManager.chain;
      if (arrayOfX509Certificate == null)
        return null;
      MessageDigest localMessageDigest1 = MessageDigest.getInstance("SHA1");
      MessageDigest localMessageDigest2 = MessageDigest.getInstance("MD5");
      for (int i = 0; i < arrayOfX509Certificate.length; i++)
      {
        localX509Certificate = arrayOfX509Certificate[i];
        localMessageDigest1.update(localX509Certificate.getEncoded());
        localMessageDigest2.update(localX509Certificate.getEncoded());
      }
      i = 1;
      X509Certificate localX509Certificate = arrayOfX509Certificate[i];
      String str = new StringBuilder().append(paramString).append("-").append(i + 1).toString();
      ((KeyStore)localObject).setCertificateEntry(str, localX509Certificate);
      File localFile2 = new File("jssecacerts");
      FileOutputStream localFileOutputStream = new FileOutputStream(localFile2);
      ((KeyStore)localObject).store(localFileOutputStream, arrayOfChar);
      localFileOutputStream.close();
      logger.debug(new StringBuilder().append("Added certificate to keystore 'jssecacerts' using alias '").append(str).append("'").toString());
      return localFile2;
    }
    catch (SSLException localSSLException)
    {
      logger.debug(new StringBuilder().append("明文连接,javax.net.ssl.SSLException:").append(localSSLException.getMessage()).toString());
      return null;
    }
    catch (KeyStoreException localKeyStoreException)
    {
      localKeyStoreException.printStackTrace();
      return null;
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      localFileNotFoundException.printStackTrace();
      return null;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      localNoSuchAlgorithmException.printStackTrace();
      return null;
    }
    catch (CertificateException localCertificateException)
    {
      localCertificateException.printStackTrace();
      return null;
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
      return null;
    }
    catch (KeyManagementException localKeyManagementException)
    {
      localKeyManagementException.printStackTrace();
    }
    return (File)null;
  }

  private static String toHexString(byte[] paramArrayOfByte)
  {
    StringBuilder localStringBuilder = new StringBuilder(paramArrayOfByte.length * 3);
    for (int k : paramArrayOfByte)
    {
      k &= 255;
      localStringBuilder.append(HEXDIGITS[(k >> 4)]);
      localStringBuilder.append(HEXDIGITS[(k & 0xF)]);
      localStringBuilder.append(' ');
    }
    return localStringBuilder.toString();
  }

  private static class SavingTrustManager
    implements X509TrustManager
  {
    private final X509TrustManager tm;
    private X509Certificate[] chain;

    SavingTrustManager(X509TrustManager paramX509TrustManager)
    {
      this.tm = paramX509TrustManager;
    }

    public X509Certificate[] getAcceptedIssuers()
    {
      throw new UnsupportedOperationException();
    }

    public void checkClientTrusted(X509Certificate[] paramArrayOfX509Certificate, String paramString)
      throws CertificateException
    {
      throw new UnsupportedOperationException();
    }

    public void checkServerTrusted(X509Certificate[] paramArrayOfX509Certificate, String paramString)
      throws CertificateException
    {
      this.chain = paramArrayOfX509Certificate;
      this.tm.checkServerTrusted(paramArrayOfX509Certificate, paramString);
    }
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.util.CertUtil
 * JD-Core Version:    0.6.0
 */