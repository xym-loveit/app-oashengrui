package com.htsoft.core.util;

import com.htsoft.core.dao.impl.DynamicDaoImpl;
import com.htsoft.core.model.DynaModel;
import com.htsoft.core.service.DynamicService;
import com.htsoft.core.service.impl.DynamicServiceImpl;
import com.htsoft.core.struts.BeanDateConnverter;
import com.htsoft.oa.util.FlowUtil;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.beanutils.BeanUtilsBean;
import org.apache.commons.beanutils.ConvertUtilsBean;
import org.apache.commons.beanutils.Converter;
import org.apache.commons.beanutils.DynaBean;
import org.apache.commons.beanutils.DynaClass;
import org.apache.commons.beanutils.DynaProperty;
import org.apache.commons.beanutils.PropertyUtilsBean;
import org.apache.commons.beanutils.converters.LongConverter;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;
import org.hibernate.collection.PersistentBag;
import org.hibernate.proxy.map.MapProxy;
import org.springframework.orm.hibernate3.LocalSessionFactoryBean;

public class BeanUtil
{
  private static Log logger = LogFactory.getLog(BeanUtil.class);
  public static ConvertUtilsBean convertUtilsBean = new ConvertUtilsBean();

  public static void copyNotNullProperties(Object paramObject1, Object paramObject2)
    throws IllegalAccessException, InvocationTargetException
  {
    BeanUtilsBean localBeanUtilsBean = BeanUtilsBean.getInstance();
    if (paramObject1 == null)
      throw new IllegalArgumentException("No destination bean specified");
    if (paramObject2 == null)
      throw new IllegalArgumentException("No origin bean specified");
    if (logger.isDebugEnabled())
      logger.debug("BeanUtils.copyProperties(" + paramObject1 + ", " + paramObject2 + ")");
    Object localObject1;
    String str;
    Object localObject2;
    if ((paramObject2 instanceof DynaBean))
    {
      localObject1 = ((DynaBean)paramObject2).getDynaClass().getDynaProperties();
      for (int i = 0; i < localObject1.length; i++)
      {
        str = localObject1[i].getName();
        if ((!localBeanUtilsBean.getPropertyUtils().isReadable(paramObject2, str)) || (!localBeanUtilsBean.getPropertyUtils().isWriteable(paramObject1, str)))
          continue;
        localObject2 = ((DynaBean)paramObject2).get(str);
        localBeanUtilsBean.copyProperty(paramObject1, str, localObject2);
      }
    }
    else if ((paramObject2 instanceof Map))
    {
      localObject1 = ((Map)paramObject2).entrySet().iterator();
      while (((Iterator)localObject1).hasNext())
      {
        Map.Entry localEntry = (Map.Entry)((Iterator)localObject1).next();
        str = (String)localEntry.getKey();
        if (localBeanUtilsBean.getPropertyUtils().isWriteable(paramObject1, str))
          localBeanUtilsBean.copyProperty(paramObject1, str, localEntry.getValue());
      }
    }
    else
    {
      localObject1 = localBeanUtilsBean.getPropertyUtils().getPropertyDescriptors(paramObject2);
      for (int j = 0; j < localObject1.length; j++)
      {
        str = localObject1[j].getName();
        if (("class".equals(str)) || (!localBeanUtilsBean.getPropertyUtils().isReadable(paramObject2, str)) || (!localBeanUtilsBean.getPropertyUtils().isWriteable(paramObject1, str)))
          continue;
        try
        {
          localObject2 = localBeanUtilsBean.getPropertyUtils().getSimpleProperty(paramObject2, str);
          if (localObject2 != null)
            localBeanUtilsBean.copyProperty(paramObject1, str, localObject2);
        }
        catch (NoSuchMethodException localNoSuchMethodException)
        {
        }
      }
    }
  }

  public static String mapEntity2Html(Map<String, Object> paramMap, String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer("<ul>");
    DynaModel localDynaModel = (DynaModel)FlowUtil.DynaModelMap.get(paramString);
    Iterator localIterator = paramMap.entrySet().iterator();
    for (int i = 0; localIterator.hasNext(); i++)
    {
      label39: Map.Entry localEntry = (Map.Entry)localIterator.next();
      String str1 = (String)localEntry.getKey();
      String str2 = localDynaModel.getLabel(str1);
      if (str2 == null)
        str2 = str1;
      str2 = "<b>" + str2 + "</b>";
      Object localObject1 = localEntry.getValue();
      if ((str1.equals("$type$")) || (str1.equals("runId")) || (str1.equals(localDynaModel.getPrimaryFieldName())) || (str1.equals(paramString)) || ((localObject1 instanceof MapProxy)) || ((localObject1 instanceof Map)))
        break label39;
      String str3;
      Object localObject2;
      Object localObject3;
      if ((localObject1 instanceof PersistentBag))
      {
        str3 = str1.substring(0, str1.length() - 1);
        localStringBuffer.append("<ol><i>明细：</i>");
        localObject2 = ((PersistentBag)localObject1).iterator();
        while (((Iterator)localObject2).hasNext())
        {
          localObject3 = (Map)((Iterator)localObject2).next();
          localStringBuffer.append("<li>").append(mapEntity2Html((Map)localObject3, str3)).append("</li><hr/>");
        }
        localStringBuffer.append("</ol>");
      }
      else if ((localObject1 instanceof Date))
      {
        str3 = localDynaModel.getFormat(str1);
        if (str3 == null)
          str3 = "yyyy-MM-dd HH:mm:ss";
        localObject2 = new SimpleDateFormat(str3);
        localObject3 = ((SimpleDateFormat)localObject2).format((Date)localObject1);
        localStringBuffer.append("<li>").append(str2).append(":").append((String)localObject3).append("</li>");
      }
      else
      {
        localStringBuffer.append("<li>").append(str2).append(":").append(localObject1).append("</li>");
      }
    }
    localStringBuffer.append("</ul>");
    return (String)(String)localStringBuffer.toString();
  }

  public static Map<String, Object> populateEntity(HttpServletRequest paramHttpServletRequest, DynaModel paramDynaModel)
  {
    Map localMap = paramHttpServletRequest.getParameterMap();
    return populateEntity(localMap, paramDynaModel);
  }

  public static Map<String, Object> populateEntity(Map paramMap, DynaModel paramDynaModel)
  {
    Iterator localIterator = paramDynaModel.getTypes().entrySet().iterator();
    HashMap localHashMap = new HashMap();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      String str = (String)localEntry.getKey();
      Class localClass = (Class)localEntry.getValue();
      Object localObject = paramMap.get(str);
      if (localObject != null)
        localHashMap.put(str, convertValue(convertUtilsBean, localObject, localClass));
    }
    return localHashMap;
  }

  public static Object populateEntity(HttpServletRequest paramHttpServletRequest, Object paramObject, String paramString)
    throws IllegalAccessException, InvocationTargetException
  {
    HashMap localHashMap = new HashMap();
    Enumeration localEnumeration = paramHttpServletRequest.getParameterNames();
    while (localEnumeration.hasMoreElements())
    {
      String str1 = (String)localEnumeration.nextElement();
      String str2 = str1;
      if (StringUtils.isNotEmpty(paramString))
        str2 = str2.replace(paramString + ".", "");
      localHashMap.put(str2, paramHttpServletRequest.getParameterValues(str1));
    }
    getBeanUtils().populate(paramObject, localHashMap);
    return paramObject;
  }

  public static DynamicService getDynamicServiceBean(String paramString)
  {
    LocalSessionFactoryBean localLocalSessionFactoryBean = (LocalSessionFactoryBean)AppUtil.getBean("&sessionFactory");
    DynamicDaoImpl localDynamicDaoImpl = new DynamicDaoImpl(paramString);
    localDynamicDaoImpl.setSessionFactory((SessionFactory)localLocalSessionFactoryBean.getObject());
    localDynamicDaoImpl.setEntityClassName(paramString);
    DynamicServiceImpl localDynamicServiceImpl = new DynamicServiceImpl(localDynamicDaoImpl);
    return localDynamicServiceImpl;
  }

  public static Object convertValue(ConvertUtilsBean paramConvertUtilsBean, Object paramObject, Class paramClass)
  {
    Converter localConverter = paramConvertUtilsBean.lookup(paramClass);
    if (localConverter == null)
      return paramObject;
    Object localObject = null;
    if ((paramObject instanceof String))
      localObject = localConverter.convert(paramClass, (String)paramObject);
    else if ((paramObject instanceof String[]))
      localObject = localConverter.convert(paramClass, ((String[])(String[])paramObject)[0]);
    else
      localObject = localConverter.convert(paramClass, paramObject);
    return localObject;
  }

  public static BeanUtilsBean getBeanUtils()
  {
    BeanUtilsBean localBeanUtilsBean = new BeanUtilsBean(convertUtilsBean, new PropertyUtilsBean());
    return localBeanUtilsBean;
  }

  public static Map getMapFromRequest(HttpServletRequest paramHttpServletRequest)
  {
    Map localMap = paramHttpServletRequest.getParameterMap();
    HashMap localHashMap = new HashMap();
    Iterator localIterator = localMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      String str = (String)localEntry.getKey();
      String[] arrayOfString = (String[])(String[])localEntry.getValue();
      if (arrayOfString.length == 1)
        localHashMap.put(str, arrayOfString[0]);
      else
        localHashMap.put(str, arrayOfString);
    }
    return localHashMap;
  }

  static
  {
    convertUtilsBean.register(new BeanDateConnverter(), Date.class);
    convertUtilsBean.register(new LongConverter(null), Long.class);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.util.BeanUtil
 * JD-Core Version:    0.6.0
 */