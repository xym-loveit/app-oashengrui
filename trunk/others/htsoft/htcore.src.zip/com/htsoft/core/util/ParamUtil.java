package com.htsoft.core.util;

import java.math.BigDecimal;
import java.util.Calendar;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ParamUtil
{
  private static Log logger = LogFactory.getLog(ParamUtil.class);

  public static Object convertObject(String paramString1, String paramString2)
  {
    if (StringUtils.isEmpty(paramString2))
      return null;
    Object localObject = null;
    try
    {
      if ("S".equals(paramString1))
      {
        localObject = paramString2;
      }
      else if ("L".equals(paramString1))
      {
        localObject = new Long(paramString2);
      }
      else if ("N".equals(paramString1))
      {
        localObject = new Integer(paramString2);
      }
      else if ("BD".equals(paramString1))
      {
        localObject = new BigDecimal(paramString2);
      }
      else if ("FT".equals(paramString1))
      {
        localObject = new Float(paramString2);
      }
      else if ("SN".equals(paramString1))
      {
        localObject = new Short(paramString2);
      }
      else if ("D".equals(paramString1))
      {
        localObject = DateUtils.parseDate(paramString2, new String[] { "yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss" });
      }
      else
      {
        Calendar localCalendar;
        if ("DL".equals(paramString1))
        {
          localCalendar = Calendar.getInstance();
          localCalendar.setTime(DateUtils.parseDate(paramString2, new String[] { "yyyy-MM-dd" }));
          localObject = DateUtil.setStartDay(localCalendar).getTime();
        }
        else if ("DG".equals(paramString1))
        {
          localCalendar = Calendar.getInstance();
          localCalendar.setTime(DateUtils.parseDate(paramString2, new String[] { "yyyy-MM-dd" }));
          localObject = DateUtil.setEndDay(localCalendar).getTime();
        }
        else
        {
          localObject = paramString2;
        }
      }
    }
    catch (Exception localException)
    {
      logger.error("the data value is not right for the query filed type:" + localException.getMessage());
    }
    return localObject;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.util.ParamUtil
 * JD-Core Version:    0.6.0
 */