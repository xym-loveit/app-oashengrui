package com.htsoft.core.jbpm.pv;

import java.io.Serializable;
import java.util.Date;

public class ProcessParam
  implements Serializable
{
  public static final String PARAM_NAME = "_pp";
  private static final long serialVersionUID = 1L;
  private UserInfo user;
  private Date createtime;
  private String processName;
  private String activityName;
  private ProcessForm processForm;

  public UserInfo getUser()
  {
    return this.user;
  }

  public void setUser(UserInfo paramUserInfo)
  {
    this.user = paramUserInfo;
  }

  public Date getCreatetime()
  {
    return this.createtime;
  }

  public void setCreatetime(Date paramDate)
  {
    this.createtime = paramDate;
  }

  public String getProcessName()
  {
    return this.processName;
  }

  public void setProcessName(String paramString)
  {
    this.processName = paramString;
  }

  public ProcessForm getProcessForm()
  {
    return this.processForm;
  }

  public void setProcessForm(ProcessForm paramProcessForm)
  {
    this.processForm = paramProcessForm;
  }

  public String getActivityName()
  {
    return this.activityName;
  }

  public void setActivityName(String paramString)
  {
    this.activityName = paramString;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.jbpm.pv.ProcessParam
 * JD-Core Version:    0.6.0
 */