package com.htsoft.core.jbpm.jpdl;

import java.awt.Point;
import java.awt.Rectangle;

public class GeometryUtils
{
  public static double getSlope(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    return (paramInt4 - paramInt2) / (paramInt3 - paramInt1);
  }

  public static double getYIntercep(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    return paramInt2 - paramInt1 * getSlope(paramInt1, paramInt2, paramInt3, paramInt4);
  }

  public static Point getRectangleCenter(Rectangle paramRectangle)
  {
    return new Point((int)paramRectangle.getCenterX(), (int)paramRectangle.getCenterY());
  }

  public static Point getRectangleLineCrossPoint(Rectangle paramRectangle, Point paramPoint, int paramInt)
  {
    Rectangle localRectangle = paramRectangle.getBounds();
    localRectangle.grow(paramInt, paramInt);
    Point localPoint = getRectangleCenter(localRectangle);
    if (paramPoint.x == localPoint.x)
    {
      if (paramPoint.y < localPoint.y)
        return new Point(localPoint.x, localRectangle.y);
      return new Point(localPoint.x, localRectangle.y + localRectangle.height);
    }
    if (paramPoint.y == localPoint.y)
    {
      if (paramPoint.x < localPoint.x)
        return new Point(localRectangle.x, localPoint.y);
      return new Point(localRectangle.x + localRectangle.width, localPoint.y);
    }
    double d1 = getSlope(localPoint.x, localPoint.y, localRectangle.x, localRectangle.y);
    double d2 = getSlope(localPoint.x, localPoint.y, paramPoint.x, paramPoint.y);
    double d3 = getYIntercep(localPoint.x, localPoint.y, paramPoint.x, paramPoint.y);
    if (Math.abs(d2) > d1 - 0.01D)
    {
      if (paramPoint.y < localRectangle.y)
        return new Point((int)Math.round((localRectangle.y - d3) / d2), localRectangle.y);
      return new Point((int)Math.round((localRectangle.y + localRectangle.height - d3) / d2), localRectangle.y + localRectangle.height);
    }
    if (paramPoint.x < localRectangle.x)
      return new Point(localRectangle.x, (int)Math.round(d2 * localRectangle.x + d3));
    return new Point(localRectangle.x + localRectangle.width, (int)Math.round(d2 * (localRectangle.x + localRectangle.width) + d3));
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.jbpm.jpdl.GeometryUtils
 * JD-Core Version:    0.6.0
 */