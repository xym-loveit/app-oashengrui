package com.htsoft.core.jbpm.pv;

import java.io.Serializable;

public class ParamInfo
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private String label;
  private String name;
  private Object value;
  private boolean isShow;

  public String getLabel()
  {
    return this.label;
  }

  public void setLabel(String paramString)
  {
    this.label = paramString;
  }

  public String getName()
  {
    return this.name;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public Object getValue()
  {
    return this.value;
  }

  public void setValue(Object paramObject)
  {
    this.value = paramObject;
  }

  public boolean isShow()
  {
    return this.isShow;
  }

  public void setShow(boolean paramBoolean)
  {
    this.isShow = paramBoolean;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.jbpm.pv.ParamInfo
 * JD-Core Version:    0.6.0
 */