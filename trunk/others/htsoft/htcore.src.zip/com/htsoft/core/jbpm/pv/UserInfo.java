package com.htsoft.core.jbpm.pv;

import java.io.Serializable;

public class UserInfo
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private Long userId;
  private String username;
  private String fullname;

  public Long getUserId()
  {
    return this.userId;
  }

  public void setUserId(Long paramLong)
  {
    this.userId = paramLong;
  }

  public String getUsername()
  {
    return this.username;
  }

  public void setUsername(String paramString)
  {
    this.username = paramString;
  }

  public String getFullname()
  {
    return this.fullname;
  }

  public void setFullname(String paramString)
  {
    this.fullname = paramString;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.jbpm.pv.UserInfo
 * JD-Core Version:    0.6.0
 */