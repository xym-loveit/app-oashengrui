package com.htsoft.core.jbpm.jpdl;

public class AnchorArea
{
  private Integer startX;
  private Integer startY;
  private Integer endX;
  private Integer endY;
  private String activityName;
  private String nodeType;

  public AnchorArea()
  {
  }

  public AnchorArea(Integer paramInteger1, Integer paramInteger2, Integer paramInteger3, Integer paramInteger4, String paramString1, String paramString2)
  {
    this.startX = paramInteger1;
    this.startY = paramInteger2;
    this.endX = paramInteger3;
    this.endY = paramInteger4;
    this.activityName = paramString1;
    this.nodeType = paramString2;
  }

  public Integer getStartX()
  {
    return this.startX;
  }

  public void setStartX(Integer paramInteger)
  {
    this.startX = paramInteger;
  }

  public Integer getStartY()
  {
    return this.startY;
  }

  public void setStartY(Integer paramInteger)
  {
    this.startY = paramInteger;
  }

  public Integer getEndX()
  {
    return this.endX;
  }

  public void setEndX(Integer paramInteger)
  {
    this.endX = paramInteger;
  }

  public Integer getEndY()
  {
    return this.endY;
  }

  public void setEndY(Integer paramInteger)
  {
    this.endY = paramInteger;
  }

  public String getActivityName()
  {
    return this.activityName;
  }

  public void setActivityName(String paramString)
  {
    this.activityName = paramString;
  }

  public String getNodeType()
  {
    return this.nodeType;
  }

  public void setNodeType(String paramString)
  {
    this.nodeType = paramString;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.jbpm.jpdl.AnchorArea
 * JD-Core Version:    0.6.0
 */