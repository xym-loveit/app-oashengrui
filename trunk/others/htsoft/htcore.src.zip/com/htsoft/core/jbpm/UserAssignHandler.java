package com.htsoft.core.jbpm;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jbpm.api.model.OpenExecution;
import org.jbpm.api.task.Assignable;
import org.jbpm.api.task.AssignmentHandler;

public class UserAssignHandler
  implements AssignmentHandler
{
  private Log logger = LogFactory.getLog(UserAssignHandler.class);
  String userIds;
  String groupIds;

  public void assign(Assignable paramAssignable, OpenExecution paramOpenExecution)
    throws Exception
  {
    String str1 = (String)paramOpenExecution.getVariable("flowAssignId");
    this.logger.info("assignId:===========>" + str1);
    if (StringUtils.isNotEmpty(str1))
    {
      paramAssignable.setAssignee(str1);
      return;
    }
    String str2 = (String)paramOpenExecution.getVariable("signUserIds");
    if (str2 != null);
    this.logger.debug("Enter UserAssignHandler assign method~~~~");
    String[] arrayOfString1;
    String str3;
    if (this.userIds != null)
    {
      arrayOfString1 = this.userIds.split("[,]");
      if ((arrayOfString1 != null) && (arrayOfString1.length > 1))
        for (str3 : arrayOfString1)
          paramAssignable.addCandidateUser(str3);
      else
        paramAssignable.setAssignee(this.userIds);
    }
    if (this.groupIds != null)
    {
      arrayOfString1 = this.userIds.split("[,]");
      if ((arrayOfString1 != null) && (arrayOfString1.length > 1))
        for (str3 : arrayOfString1)
          paramAssignable.addCandidateGroup(str3);
      else
        paramAssignable.addCandidateGroup(this.groupIds);
    }
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.jbpm.UserAssignHandler
 * JD-Core Version:    0.6.0
 */