package com.htsoft.core.jbpm.servlet;

import com.htsoft.core.jbpm.jpdl.AnchorArea;
import com.htsoft.core.jbpm.jpdl.JpdlModel;
import com.htsoft.core.jbpm.jpdl.JpdlModelDrawer;
import com.htsoft.core.util.AppUtil;
import com.htsoft.oa.model.flow.ProDefinition;
import com.htsoft.oa.model.flow.ProcessRun;
import com.htsoft.oa.service.flow.JbpmService;
import com.htsoft.oa.service.flow.ProcessRunService;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jbpm.api.ProcessInstance;
import org.jbpm.pvm.internal.model.ExecutionImpl;
import org.jbpm.pvm.internal.task.TaskImpl;

public class JpdlImageServlet extends HttpServlet
{
  private Log logger = LogFactory.getLog(JpdlImageServlet.class);
  private JbpmService jbpmService = (JbpmService)AppUtil.getBean("jbpmService");
  private ProcessRunService processRunService = (ProcessRunService)AppUtil.getBean("processRunService");

  public String getProcessDefintionXml(HttpServletRequest paramHttpServletRequest)
  {
    String str1 = paramHttpServletRequest.getParameter("taskId");
    String str2 = paramHttpServletRequest.getParameter("isSubFlow");
    if (StringUtils.isNotEmpty(str2))
    {
      localObject1 = (TaskImpl)this.jbpmService.getTaskById(str1);
      localObject2 = ((TaskImpl)localObject1).getProcessInstance().getSuperProcessExecution();
      return this.jbpmService.getDefinitionXmlByPiId(((ProcessInstance)localObject2).getId());
    }
    if (StringUtils.isNotEmpty(str1))
    {
      localObject1 = this.jbpmService.getProcessInstanceByTaskId(str1);
      return this.jbpmService.getDefinitionXmlByPiId(((ProcessInstance)localObject1).getId());
    }
    Object localObject1 = paramHttpServletRequest.getParameter("deployId");
    if (StringUtils.isNotEmpty((String)localObject1))
      return this.jbpmService.getDefinitionXmlByDpId((String)localObject1);
    Object localObject2 = paramHttpServletRequest.getParameter("runId");
    if (StringUtils.isNotEmpty((String)localObject2))
    {
      localObject3 = (ProcessRun)this.processRunService.get(new Long((String)localObject2));
      if (((ProcessRun)localObject3).getPiId() != null)
        return this.jbpmService.getDefinitionXmlByPiId(((ProcessRun)localObject3).getPiId());
      return this.jbpmService.getDefinitionXmlByDefId(((ProcessRun)localObject3).getProDefinition().getDefId());
    }
    Object localObject3 = paramHttpServletRequest.getParameter("piId");
    if ((StringUtils.isNotEmpty((String)localObject3)) && (!"null".equals(localObject3)))
      return this.jbpmService.getDefinitionXmlByPiId((String)localObject3);
    String str3 = paramHttpServletRequest.getParameter("defId");
    return (String)(String)(String)this.jbpmService.getDefinitionXmlByDefId(new Long(str3));
  }

  public void doGet(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
    throws IOException, ServletException
  {
    paramHttpServletResponse.setCharacterEncoding("UTF-8");
    String str1 = paramHttpServletRequest.getParameter("defId");
    String str2 = paramHttpServletRequest.getParameter("isSubFlow");
    String str3 = getProcessDefintionXml(paramHttpServletRequest);
    String str4 = paramHttpServletRequest.getParameter("genMap");
    try
    {
      JpdlModel localJpdlModel = new JpdlModel(str3);
      String str5 = paramHttpServletRequest.getParameter("taskId");
      String str6 = paramHttpServletRequest.getParameter("runId");
      Object localObject1 = null;
      if (("true".equals(str2)) && (StringUtils.isNotEmpty(str5)))
      {
        localObject2 = (TaskImpl)this.jbpmService.getTaskById(str5);
        localObject1 = ((TaskImpl)localObject2).getProcessInstance().getSuperProcessExecution();
      }
      else if (StringUtils.isNotEmpty(str5))
      {
        localObject1 = this.jbpmService.getProcessInstanceByTaskId(str5);
      }
      else if (StringUtils.isNotEmpty(str6))
      {
        localObject2 = (ProcessRun)this.processRunService.get(new Long(str6));
        if (((ProcessRun)localObject2).getPiId() != null)
          localObject1 = this.jbpmService.getProcessInstance(((ProcessRun)localObject2).getPiId());
      }
      else
      {
        localObject2 = paramHttpServletRequest.getParameter("piId");
        if (StringUtils.isNotEmpty((String)localObject2))
          localObject1 = this.jbpmService.getProcessInstance((String)localObject2);
      }
      if (localObject1 != null)
      {
        localObject2 = ((ProcessInstance)localObject1).findActiveActivityNames();
        if (localObject2 != null)
          localJpdlModel.setActivityNames((Set)localObject2);
      }
      Object localObject2 = new JpdlModelDrawer();
      if (!"true".equals(str4))
      {
        paramHttpServletResponse.setContentType("image/png");
        ImageIO.write(((JpdlModelDrawer)localObject2).draw(localJpdlModel), "png", paramHttpServletResponse.getOutputStream());
      }
      else if (StringUtils.isNotEmpty(str1))
      {
        List localList = ((JpdlModelDrawer)localObject2).getMaps(localJpdlModel);
        PrintWriter localPrintWriter = paramHttpServletResponse.getWriter();
        Iterator localIterator = localList.iterator();
        while (localIterator.hasNext())
        {
          AnchorArea localAnchorArea = (AnchorArea)localIterator.next();
          localPrintWriter.println("<area shape='rect' coords='" + localAnchorArea.getStartX() + "," + localAnchorArea.getStartY() + "," + localAnchorArea.getEndX() + "," + localAnchorArea.getEndY() + "'" + " href='#' onclick='javascript:ProDefinitionSetting.clickNode(" + str1 + ",\"" + localAnchorArea.getActivityName() + "\",\"" + localAnchorArea.getNodeType() + "\");'>");
        }
      }
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.jbpm.servlet.JpdlImageServlet
 * JD-Core Version:    0.6.0
 */