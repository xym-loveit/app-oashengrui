package com.htsoft.core.jbpm.jpdl;

import com.htsoft.core.util.XmlUtil;
import java.awt.Point;
import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.QName;

public class JpdlModel
{
  private Set<String> activityNames = new HashSet();
  private Map<String, Node> nodes = new LinkedHashMap();
  public static final int RECT_OFFSET_X = -4;
  public static final int RECT_OFFSET_Y = -8;
  public static final int DEFAULT_PIC_SIZE = 48;
  private static final Map<String, Object> nodeInfos = new HashMap();

  public JpdlModel(String paramString)
    throws Exception
  {
    this(XmlUtil.stringToDocument(paramString).getRootElement());
  }

  public JpdlModel(InputStream paramInputStream)
    throws Exception
  {
    this(XmlUtil.load(paramInputStream).getRootElement());
  }

  private JpdlModel(Element paramElement)
    throws Exception
  {
    Iterator localIterator = paramElement.elements().iterator();
    while (localIterator.hasNext())
    {
      Element localElement = (Element)localIterator.next();
      String str1 = localElement.getQName().getName();
      if (!nodeInfos.containsKey(str1))
        continue;
      String str2 = null;
      if (localElement.attribute("name") != null)
        str2 = localElement.attributeValue("name");
      String[] arrayOfString = localElement.attributeValue("g").split(",");
      int i = Integer.parseInt(arrayOfString[0]);
      int j = Integer.parseInt(arrayOfString[1]);
      int k = Integer.parseInt(arrayOfString[2]);
      int m = Integer.parseInt(arrayOfString[3]);
      if (nodeInfos.get(str1) != null)
      {
        k = 48;
        m = 48;
      }
      else
      {
        i += 4;
        j += 8;
        k -= 8;
        m -= 16;
      }
      Node localNode = new Node(str2, str1, i, j, k, m);
      parserTransition(localNode, localElement);
      this.nodes.put(str2, localNode);
    }
  }

  public Set<String> getActivityNames()
  {
    return this.activityNames;
  }

  public void setActivityNames(Set<String> paramSet)
  {
    this.activityNames = paramSet;
  }

  private void parserTransition(Node paramNode, Element paramElement)
  {
    Iterator localIterator = paramElement.elements("transition").iterator();
    while (localIterator.hasNext())
    {
      Element localElement = (Element)localIterator.next();
      String str1 = localElement.attributeValue("name");
      String str2 = localElement.attributeValue("to");
      Transition localTransition = new Transition(str1, str2);
      String str3 = localElement.attributeValue("g");
      if ((str3 != null) && (str3.length() > 0))
        if (str3.indexOf(":") < 0)
        {
          localTransition.setLabelPosition(getPoint(str3));
        }
        else
        {
          String[] arrayOfString1 = str3.split(":");
          localTransition.setLabelPosition(getPoint(arrayOfString1[1]));
          String[] arrayOfString2 = arrayOfString1[0].split(";");
          for (String str4 : arrayOfString2)
            localTransition.addLineTrace(getPoint(str4));
        }
      paramNode.addTransition(localTransition);
    }
  }

  private Point getPoint(String paramString)
  {
    if ((paramString == null) || (paramString.length() == 0))
      return null;
    String[] arrayOfString = paramString.split(",");
    return new Point(Integer.valueOf(arrayOfString[0]).intValue(), Integer.valueOf(arrayOfString[1]).intValue());
  }

  public Map<String, Node> getNodes()
  {
    return this.nodes;
  }

  public static Map<String, Object> getNodeInfos()
  {
    return nodeInfos;
  }

  static
  {
    nodeInfos.put("start", "start_event_empty.png");
    nodeInfos.put("end", "end_event_terminate.png");
    nodeInfos.put("end-cancel", "end_event_cancel.png");
    nodeInfos.put("end-error", "end_event_error.png");
    nodeInfos.put("decision", "gateway_exclusive.png");
    nodeInfos.put("fork", "gateway_parallel.png");
    nodeInfos.put("join", "gateway_parallel.png");
    nodeInfos.put("state", null);
    nodeInfos.put("hql", null);
    nodeInfos.put("sql", null);
    nodeInfos.put("java", null);
    nodeInfos.put("script", null);
    nodeInfos.put("task", null);
    nodeInfos.put("sub-process", null);
    nodeInfos.put("custom", null);
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.jbpm.jpdl.JpdlModel
 * JD-Core Version:    0.6.0
 */