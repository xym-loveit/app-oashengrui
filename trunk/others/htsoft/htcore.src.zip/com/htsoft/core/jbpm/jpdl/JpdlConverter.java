package com.htsoft.core.jbpm.jpdl;

import com.htsoft.core.util.XmlUtil;
import java.io.PrintStream;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map<Ljava.lang.String;Lorg.dom4j.Element;>;
import java.util.Set;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

public class JpdlConverter
{
  private static Log logger = LogFactory.getLog(JpdlConverter.class);

  public static void main(String[] paramArrayOfString)
  {
    String str1 = "D:/dev/workspace/joffice/web/file.xml";
    String str2 = XmlUtil.load(str1).asXML();
    String str3 = JpdlGen(str2, "test");
    System.out.println("lastXML:" + str3);
  }

  public static String JpdlGen(String paramString1, String paramString2)
  {
    if (logger.isDebugEnabled())
      logger.debug("drawXml:" + paramString1);
    Document localDocument1 = DocumentHelper.createDocument();
    localDocument1.setXMLEncoding(System.getProperty("file.encoding"));
    Element localElement1 = localDocument1.addElement("process");
    localElement1.addAttribute("name", paramString2);
    Document localDocument2 = XmlUtil.stringToDocument(paramString1);
    Element localElement2 = localDocument2.getRootElement();
    HashSet localHashSet = new HashSet();
    Map localMap = parseDrawXml(localHashSet, localElement2);
    Iterator localIterator1 = localMap.values().iterator();
    while (localIterator1.hasNext())
      System.out.println(((Element)localIterator1.next()).asXML());
    LinkedHashMap localLinkedHashMap = new LinkedHashMap();
    Iterator localIterator2 = localMap.keySet().iterator();
    Element localElement3;
    Object localObject2;
    String str1;
    Object localObject3;
    Object localObject4;
    Object localObject5;
    String str2;
    Object localObject6;
    while (localIterator2.hasNext())
    {
      localObject1 = (String)localIterator2.next();
      localElement3 = (Element)localMap.get(localObject1);
      localObject2 = localElement1.addElement(localElement3.getQualifiedName());
      str1 = localElement3.attributeValue("x");
      localObject3 = localElement3.attributeValue("y");
      localObject4 = localElement3.attributeValue("w");
      localObject5 = Integer.valueOf(new Integer((String)localObject4).intValue() + 10);
      str2 = localElement3.attributeValue("h");
      localObject6 = Integer.valueOf(new Integer(str2).intValue() + 10);
      ((Element)localObject2).addAttribute("name", localElement3.attributeValue("name"));
      ((Element)localObject2).addAttribute("g", str1 + "," + (String)localObject3 + "," + localObject5 + "," + localObject6);
      localLinkedHashMap.put(localObject1, localObject2);
    }
    Object localObject1 = localHashSet.iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localElement3 = (Element)((Iterator)localObject1).next();
      localObject2 = localElement3.attributeValue("g");
      str1 = localElement3.attributeValue("name");
      localObject3 = (Element)localElement3.selectSingleNode("./startConnector/rConnector/Owner/*");
      localObject4 = (Element)localElement3.selectSingleNode("./endConnector/rConnector/Owner/*");
      if ((localObject3 != null) && (localObject4 != null))
      {
        localObject5 = ((Element)localObject3).attributeValue("ref") != null ? ((Element)localObject3).attributeValue("ref") : ((Element)localObject3).attributeValue("id");
        str2 = ((Element)localObject4).attributeValue("ref") != null ? ((Element)localObject4).attributeValue("ref") : ((Element)localObject4).attributeValue("id");
        Element localElement4;
        Object localObject8;
        if ((localObject5 != null) && (str2 != null))
        {
          localObject6 = (Element)localLinkedHashMap.get(localObject5);
          localElement4 = (Element)localLinkedHashMap.get(str2);
        }
        else
        {
          localObject7 = ((Element)localObject3).attributeValue("id");
          localObject8 = ((Element)localObject3).attributeValue("id");
          localObject6 = (Element)localLinkedHashMap.get(localObject7);
          localElement4 = (Element)localLinkedHashMap.get(localObject8);
        }
        Object localObject7 = ((Element)localObject6).addElement("transition");
        ((Element)localObject7).addAttribute("name", str1);
        ((Element)localObject7).addAttribute("to", localElement4.attributeValue("name"));
        ((Element)localObject7).addAttribute("g", (String)localObject2);
        if ("decision".equals(((Element)localObject6).getQualifiedName()))
        {
          localObject8 = (Element)localElement2.selectSingleNode("/drawing/figures//decision/conditions/condition[@to='" + str1 + "']");
          if (localObject8 != null)
          {
            Element localElement5 = ((Element)localObject7).addElement("condition");
            localElement5.addAttribute("expr", ((Element)localObject8).attributeValue("expr"));
          }
        }
      }
    }
    if (logger.isDebugEnabled())
      logger.debug("after convter jbpm xml:" + localElement1.asXML());
    return (String)(String)(String)(String)(String)(String)(String)(String)localDocument1.asXML();
  }

  private static Map<String, Element> parseDrawXml(Set paramSet, Element paramElement)
  {
    LinkedHashMap localLinkedHashMap = new LinkedHashMap();
    List localList = paramElement.selectNodes("/drawing/figures/*");
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Element localElement1 = (Element)localIterator.next();
      String str1 = localElement1.attributeValue("id");
      String str2 = localElement1.attributeValue("ref");
      Object localObject;
      if ("transition".equals(localElement1.getQualifiedName()))
      {
        paramSet.add(localElement1);
        localObject = localElement1.selectNodes("./*/rConnector/Owner/task");
        for (int i = 0; i < ((List)localObject).size(); i++)
        {
          Element localElement2 = (Element)((List)localObject).get(i);
          String str3 = localElement2.attributeValue("id");
          if (str3 == null)
            continue;
          localLinkedHashMap.put(str3, localElement2);
        }
      }
      else if (str1 != null)
      {
        localLinkedHashMap.put(str1, localElement1);
      }
      else if (str2 != null)
      {
        localObject = paramElement.selectSingleNode("/drawing/figures//*[@id='" + str2 + "']");
        localLinkedHashMap.put(str2, (Element)localObject);
      }
    }
    return (Map<String, Element>)localLinkedHashMap;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.jbpm.jpdl.JpdlConverter
 * JD-Core Version:    0.6.0
 */