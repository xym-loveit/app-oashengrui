package com.htsoft.core.jbpm.pv;

import java.io.Serializable;
import java.util.LinkedList;

public class ProcessForm
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private String activityName;
  private LinkedList<ParamInfo> params = new LinkedList();

  public String getActivityName()
  {
    return this.activityName;
  }

  public void setActivityName(String paramString)
  {
    this.activityName = paramString;
  }

  public LinkedList<ParamInfo> getParams()
  {
    return this.params;
  }

  public void setParams(LinkedList<ParamInfo> paramLinkedList)
  {
    this.params = paramLinkedList;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.jbpm.pv.ProcessForm
 * JD-Core Version:    0.6.0
 */