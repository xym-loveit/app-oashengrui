package com.htsoft.core.jbpm.jpdl;

import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;

public class Node
{
  private String name;
  private String type;
  private Rectangle rectangle;
  private List<Transition> transitions = new ArrayList();
  private int x;
  private int y;
  private int width;
  private int height;

  public Node(String paramString1, String paramString2)
  {
    this.name = paramString1;
    this.type = paramString2;
  }

  public Node(String paramString1, String paramString2, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.name = paramString1;
    this.type = paramString2;
    this.x = paramInt1;
    this.y = paramInt2;
    this.width = paramInt3;
    this.height = paramInt4;
    this.rectangle = new Rectangle();
    this.rectangle.setBounds(paramInt1, paramInt2, paramInt3, paramInt4);
  }

  public int getCenterX()
  {
    return this.x + this.width / 2;
  }

  public int getCenterY()
  {
    return this.y + this.height / 2;
  }

  public int getX()
  {
    return this.x;
  }

  public void setX(int paramInt)
  {
    this.x = paramInt;
  }

  public int getY()
  {
    return this.y;
  }

  public void setY(int paramInt)
  {
    this.y = paramInt;
  }

  public int getWidth()
  {
    return this.width;
  }

  public void setWidth(int paramInt)
  {
    this.width = paramInt;
  }

  public int getHeight()
  {
    return this.height;
  }

  public void setHeight(int paramInt)
  {
    this.height = paramInt;
  }

  public void addTransition(Transition paramTransition)
  {
    this.transitions.add(paramTransition);
  }

  public String getName()
  {
    return this.name;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public String getType()
  {
    return this.type;
  }

  public void setType(String paramString)
  {
    this.type = paramString;
  }

  public Rectangle getRectangle()
  {
    return this.rectangle;
  }

  public void setRectangle(Rectangle paramRectangle)
  {
    this.rectangle = paramRectangle;
  }

  public List<Transition> getTransitions()
  {
    return this.transitions;
  }

  public void setTransitions(List<Transition> paramList)
  {
    this.transitions = paramList;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.jbpm.jpdl.Node
 * JD-Core Version:    0.6.0
 */