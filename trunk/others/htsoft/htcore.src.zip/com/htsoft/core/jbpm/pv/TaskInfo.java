package com.htsoft.core.jbpm.pv;

import java.util.Date;
import java.util.Set;
import org.jbpm.pvm.internal.model.ExecutionImpl;
import org.jbpm.pvm.internal.task.TaskImpl;

public class TaskInfo
{
  private String taskName;
  private String activityName;
  private String assignee;
  private Date createTime;
  private Date dueDate;
  private String executionId;
  private String piId;
  private Long taskId;
  private Short isMultipleTask = Short.valueOf(0);
  private String candidateUsers = "";
  private String candidateRoles = "";

  public TaskInfo()
  {
  }

  public TaskInfo(TaskImpl paramTaskImpl)
  {
    this.taskName = paramTaskImpl.getActivityName();
    this.activityName = paramTaskImpl.getActivityName();
    this.assignee = paramTaskImpl.getAssignee();
    this.dueDate = paramTaskImpl.getDuedate();
    this.createTime = paramTaskImpl.getCreateTime();
    if (paramTaskImpl.getSuperTask() != null)
    {
      this.piId = paramTaskImpl.getSuperTask().getProcessInstance().getId();
      this.executionId = paramTaskImpl.getSuperTask().getExecutionId();
    }
    else
    {
      this.piId = paramTaskImpl.getProcessInstance().getId();
      this.executionId = paramTaskImpl.getExecutionId();
    }
    this.taskId = Long.valueOf(paramTaskImpl.getDbid());
    if (paramTaskImpl.getParticipations().size() > 0)
      this.isMultipleTask = Short.valueOf(1);
  }

  public String getActivityName()
  {
    return this.activityName;
  }

  public void setActivityName(String paramString)
  {
    this.activityName = paramString;
  }

  public String getAssignee()
  {
    return this.assignee;
  }

  public void setAssignee(String paramString)
  {
    this.assignee = paramString;
  }

  public Date getCreateTime()
  {
    return this.createTime;
  }

  public void setCreateTime(Date paramDate)
  {
    this.createTime = paramDate;
  }

  public Date getDueDate()
  {
    return this.dueDate;
  }

  public void setDueDate(Date paramDate)
  {
    this.dueDate = paramDate;
  }

  public String getExecutionId()
  {
    return this.executionId;
  }

  public void setExecutionId(String paramString)
  {
    this.executionId = paramString;
  }

  public String getCandidateUsers()
  {
    return this.candidateUsers;
  }

  public void setCandidateUsers(String paramString)
  {
    this.candidateUsers = paramString;
  }

  public String getCandidateRoles()
  {
    return this.candidateRoles;
  }

  public void setCandidateRoles(String paramString)
  {
    this.candidateRoles = paramString;
  }

  public Long getTaskId()
  {
    return this.taskId;
  }

  public void setTaskId(Long paramLong)
  {
    this.taskId = paramLong;
  }

  public Short getIsMultipleTask()
  {
    return this.isMultipleTask;
  }

  public void setIsMultipleTask(Short paramShort)
  {
    this.isMultipleTask = paramShort;
  }

  public String getPiId()
  {
    return this.piId;
  }

  public void setPiId(String paramString)
  {
    this.piId = paramString;
  }

  public String getTaskName()
  {
    return this.taskName;
  }

  public void setTaskName(String paramString)
  {
    this.taskName = paramString;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.jbpm.pv.TaskInfo
 * JD-Core Version:    0.6.0
 */