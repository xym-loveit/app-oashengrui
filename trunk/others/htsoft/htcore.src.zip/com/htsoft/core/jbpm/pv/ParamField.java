package com.htsoft.core.jbpm.pv;

public class ParamField
{
  public static final String FIELD_TYPE_DATE = "date";
  public static final String FIELD_TYPE_DATETIME = "datetime";
  public static final String FIELD_TYPE_INT = "int";
  public static final String FIELD_TYPE_LONG = "long";
  public static final String FIELD_TYPE_DECIMAL = "decimal";
  public static final String FIELD_TYPE_VARCHAR = "varchar";
  public static final String FIELD_TYPE_BOOL = "bool";
  public static final String FIELD_TYPE_TEXT = "text";
  public static final String FIELD_TYPE_FILE = "file";
  private String name;
  private String type;
  private String label;
  private Integer length;
  private Short isShowed = Short.valueOf(1);
  private String value;

  public String getValue()
  {
    return this.value;
  }

  public void setValue(String paramString)
  {
    if ("bool".equals(this.type))
    {
      if (paramString != null)
        this.value = "1";
      else
        this.value = "0";
    }
    else
      this.value = paramString;
  }

  public ParamField(String paramString1, String paramString2, String paramString3, Integer paramInteger, Short paramShort)
  {
    this.name = paramString1;
    this.type = paramString2;
    this.label = paramString3;
    this.length = paramInteger;
    this.isShowed = paramShort;
  }

  public ParamField()
  {
  }

  public String getName()
  {
    return this.name;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public String getType()
  {
    return this.type;
  }

  public void setType(String paramString)
  {
    this.type = paramString;
  }

  public String getLabel()
  {
    return this.label;
  }

  public void setLabel(String paramString)
  {
    this.label = paramString;
  }

  public Integer getLength()
  {
    return this.length;
  }

  public void setLength(Integer paramInteger)
  {
    this.length = paramInteger;
  }

  public Short getIsShowed()
  {
    return this.isShowed;
  }

  public void setIsShowed(Short paramShort)
  {
    this.isShowed = paramShort;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.jbpm.pv.ParamField
 * JD-Core Version:    0.6.0
 */