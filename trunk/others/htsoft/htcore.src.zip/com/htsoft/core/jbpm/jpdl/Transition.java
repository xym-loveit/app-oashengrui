package com.htsoft.core.jbpm.jpdl;

import java.awt.Point;
import java.util.LinkedList;
import java.util.List;

public class Transition
{
  private Point labelPosition;
  private List<Point> lineTrace = new LinkedList();
  private String label;
  private String to;

  public Transition(String paramString1, String paramString2)
  {
    this.label = paramString1;
    this.to = paramString2;
  }

  public void addLineTrace(Point paramPoint)
  {
    if (paramPoint != null)
      this.lineTrace.add(paramPoint);
  }

  public Point getLabelPosition()
  {
    return this.labelPosition;
  }

  public void setLabelPosition(Point paramPoint)
  {
    this.labelPosition = paramPoint;
  }

  public List<Point> getLineTrace()
  {
    return this.lineTrace;
  }

  public void setLineTrace(List<Point> paramList)
  {
    this.lineTrace = paramList;
  }

  public String getLabel()
  {
    return this.label;
  }

  public void setLabel(String paramString)
  {
    this.label = paramString;
  }

  public String getTo()
  {
    return this.to;
  }

  public void setTo(String paramString)
  {
    this.to = paramString;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.jbpm.jpdl.Transition
 * JD-Core Version:    0.6.0
 */