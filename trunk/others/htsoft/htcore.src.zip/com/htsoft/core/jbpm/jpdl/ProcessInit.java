package com.htsoft.core.jbpm.jpdl;

import com.htsoft.core.util.AppUtil;
import com.htsoft.core.util.XmlUtil;
import com.htsoft.oa.model.flow.ProDefinition;
import com.htsoft.oa.service.flow.JbpmService;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.List<Lcom.htsoft.oa.model.flow.ProDefinition;>;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Document;
import org.dom4j.Element;

public class ProcessInit
{
  private static Log logger = LogFactory.getLog(ProcessInit.class);

  public static void initFlows(String paramString)
  {
    try
    {
      JbpmService localJbpmService = (JbpmService)AppUtil.getBean("jbpmService");
      List localList = getProDefinitions(paramString);
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        ProDefinition localProDefinition = (ProDefinition)localIterator.next();
        logger.debug("初始化系统流程:" + localProDefinition.getName());
        localJbpmService.saveOrUpdateDeploy(localProDefinition);
      }
    }
    catch (Exception localException)
    {
      logger.debug("init flows:" + localException.getMessage());
    }
  }

  public static List<ProDefinition> getProDefinitions(String paramString)
    throws IOException
  {
    String str1 = paramString + "/WEB-INF/classes/jpdl";
    String str2 = str1 + "/initFlow.xml";
    ArrayList localArrayList = new ArrayList();
    Document localDocument = XmlUtil.load(str2);
    if (localDocument != null)
    {
      Element localElement1 = localDocument.getRootElement();
      if (localElement1 != null)
      {
        Iterator localIterator = localElement1.elementIterator();
        while (localIterator.hasNext())
        {
          ProDefinition localProDefinition = new ProDefinition();
          Element localElement2 = (Element)localIterator.next();
          String str3 = localElement2.attributeValue("name");
          localProDefinition.setName(str3);
          localProDefinition.setCreatetime(new Date());
          Element localElement3 = (Element)localElement2.selectSingleNode("./description");
          if (localElement3 != null)
          {
            localObject = localElement3.getText();
            localProDefinition.setDescription((String)localObject);
            localProDefinition.setIsDefault(ProDefinition.IS_DEFAULT);
          }
          Object localObject = (Element)localElement2.selectSingleNode("./jpdlLocation");
          if (localObject != null)
          {
            String str4 = ((Element)localObject).getText().trim();
            File localFile1 = new File(str1 + "/" + str4);
            if (str4 != null)
            {
              File localFile2 = new File(str1 + "/" + str4.replace(".jpdl.xml", ".time"));
              int i = 0;
              if (!localFile2.exists())
              {
                localFile2.createNewFile();
                i = 1;
              }
              if ((i != 0) || (localFile1.lastModified() > localFile2.lastModified()))
              {
                String str5 = XmlUtil.load(localFile1).asXML();
                localProDefinition.setDefXml(str5);
                localArrayList.add(localProDefinition);
              }
              localFile2.setLastModified(localFile1.lastModified());
            }
          }
        }
      }
    }
    return (List<ProDefinition>)localArrayList;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.jbpm.jpdl.ProcessInit
 * JD-Core Version:    0.6.0
 */