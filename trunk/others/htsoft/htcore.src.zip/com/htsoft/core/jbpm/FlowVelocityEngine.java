package com.htsoft.core.jbpm;

import com.htsoft.core.util.AppUtil;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.exception.VelocityException;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.ui.velocity.CommonsLoggingLogSystem;

public class FlowVelocityEngine
  implements FactoryBean
{
  private Log logger = LogFactory.getLog(FlowVelocityEngine.class);
  private Properties velocityProperties;
  private String templatePath;

  public Properties getVelocityProperties()
  {
    return this.velocityProperties;
  }

  public void setVelocityProperties(Properties paramProperties)
  {
    this.velocityProperties = paramProperties;
  }

  public Object getObject()
    throws Exception
  {
    return createVelocityEngine();
  }

  public Class getObjectType()
  {
    return VelocityEngine.class;
  }

  public boolean isSingleton()
  {
    return true;
  }

  public VelocityEngine createVelocityEngine()
    throws IOException, VelocityException
  {
    if (this.logger.isDebugEnabled())
      this.logger.debug("create flowVelocityEngine... and the path is " + AppUtil.getAppAbsolutePath() + this.templatePath);
    VelocityEngine localVelocityEngine = new VelocityEngine();
    localVelocityEngine.setProperty("runtime.log.logsystem", new CommonsLoggingLogSystem());
    Iterator localIterator = this.velocityProperties.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      if (!(localEntry.getKey() instanceof String))
        throw new IllegalArgumentException("Illegal property key [" + localEntry.getKey() + "]: only Strings allowed");
      localVelocityEngine.setProperty((String)localEntry.getKey(), localEntry.getValue());
    }
    localVelocityEngine.setProperty("runtime.log.logsystem.class", "org.apache.velocity.runtime.log.Log4JLogChute");
    localVelocityEngine.setProperty("runtime.log.logsystem.log4j.logger", "velocity");
    localVelocityEngine.setProperty("file.resource.loader.path", AppUtil.getAppAbsolutePath() + this.templatePath);
    try
    {
      localVelocityEngine.init();
    }
    catch (IOException localIOException)
    {
      throw localIOException;
    }
    catch (VelocityException localVelocityException)
    {
      throw localVelocityException;
    }
    catch (RuntimeException localRuntimeException)
    {
      throw localRuntimeException;
    }
    catch (Exception localException)
    {
      this.logger.error("Why does VelocityEngine throw a generic checked exception, after all?", localException);
      throw new VelocityException(localException.toString());
    }
    return localVelocityEngine;
  }

  public String getTemplatePath()
  {
    return this.templatePath;
  }

  public void setTemplatePath(String paramString)
  {
    this.templatePath = paramString;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.jbpm.FlowVelocityEngine
 * JD-Core Version:    0.6.0
 */