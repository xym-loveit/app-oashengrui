package com.htsoft.core.jbpm.jpdl;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.font.FontRenderContext;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.imageio.ImageIO;

public class JpdlModelDrawer
{
  public static final int RECT_OFFSET_X = -4;
  public static final int RECT_OFFSET_Y = -8;
  public static final int RECT_ROUND = 25;
  public static final int DEFAULT_FONT_SIZE = 12;
  public static final Color DEFAULT_STROKE_COLOR = Color.decode("#03689A");
  public static final Stroke DEFAULT_STROKE = new BasicStroke(2.0F);
  public static final Color DEFAULT_LINE_STROKE_COLOR = Color.decode("#808080");
  public static final Stroke DEFAULT_LINE_STROKE = new BasicStroke(1.0F);
  public static final Color DEFAULT_FILL_COLOR = Color.decode("#F6F7FF");
  private static final Map<String, Object> nodeInfos = JpdlModel.getNodeInfos();
  private List<AnchorArea> links = new ArrayList();

  public BufferedImage draw(JpdlModel paramJpdlModel)
    throws IOException
  {
    Rectangle localRectangle = getCanvasDimension(paramJpdlModel);
    BufferedImage localBufferedImage = new BufferedImage(localRectangle.width, localRectangle.height, 2);
    Graphics2D localGraphics2D = localBufferedImage.createGraphics();
    localGraphics2D.setColor(Color.WHITE);
    localGraphics2D.fillRect(0, 0, localRectangle.width, localRectangle.height);
    localGraphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    Font localFont = new Font("宋体", 0, 12);
    localGraphics2D.setFont(localFont);
    Map localMap = paramJpdlModel.getNodes();
    Set localSet = paramJpdlModel.getActivityNames();
    drawNode(localMap, localSet, localGraphics2D, localFont);
    drawTransition(localMap, localGraphics2D);
    return localBufferedImage;
  }

  public List<AnchorArea> getMaps(JpdlModel paramJpdlModel)
  {
    Map localMap = paramJpdlModel.getNodes();
    Iterator localIterator = localMap.values().iterator();
    while (localIterator.hasNext())
    {
      Node localNode = (Node)localIterator.next();
      String str1 = localNode.getName();
      int i = localNode.getX();
      int j = localNode.getY();
      int k = localNode.getWidth();
      int m = localNode.getHeight();
      String str2 = localNode.getType();
      this.links.add(new AnchorArea(Integer.valueOf(i), Integer.valueOf(j), Integer.valueOf(i + k), Integer.valueOf(j + m), str1, str2));
    }
    return this.links;
  }

  public Rectangle getCanvasDimension(JpdlModel paramJpdlModel)
  {
    Rectangle localRectangle1 = new Rectangle();
    Rectangle localRectangle2 = new Rectangle();
    Iterator localIterator1 = paramJpdlModel.getNodes().values().iterator();
    while (localIterator1.hasNext())
    {
      Node localNode = (Node)localIterator1.next();
      localRectangle2 = localNode.getRectangle();
      if (localRectangle2.getMaxX() > localRectangle1.getMaxX())
        localRectangle1.width = (int)Math.round(localRectangle2.getMaxX());
      if (localRectangle2.getMaxY() > localRectangle1.getMaxY())
        localRectangle1.height = (int)Math.round(localRectangle2.getMaxY());
      Iterator localIterator2 = localNode.getTransitions().iterator();
      while (localIterator2.hasNext())
      {
        Transition localTransition = (Transition)localIterator2.next();
        List localList = localTransition.getLineTrace();
        Iterator localIterator3 = localList.iterator();
        while (localIterator3.hasNext())
        {
          Point localPoint = (Point)localIterator3.next();
          if (localRectangle1.getMaxX() < localPoint.x)
            localRectangle1.width = localPoint.x;
          if (localRectangle1.getMaxY() < localPoint.y)
            localRectangle1.height = localPoint.y;
        }
      }
    }
    localRectangle1.width += 60;
    localRectangle1.height += 20;
    return localRectangle1;
  }

  private void drawTransition(Map<String, Node> paramMap, Graphics2D paramGraphics2D)
    throws IOException
  {
    paramGraphics2D.setStroke(DEFAULT_LINE_STROKE);
    paramGraphics2D.setColor(DEFAULT_LINE_STROKE_COLOR);
    Iterator localIterator1 = paramMap.values().iterator();
    while (localIterator1.hasNext())
    {
      Node localNode1 = (Node)localIterator1.next();
      Iterator localIterator2 = localNode1.getTransitions().iterator();
      while (localIterator2.hasNext())
      {
        Transition localTransition = (Transition)localIterator2.next();
        String str1 = localTransition.getTo();
        Node localNode2 = (Node)paramMap.get(str1);
        List localList = localTransition.getLineTrace();
        int i = localList.size() + 2;
        localList.add(0, new Point(localNode1.getCenterX(), localNode1.getCenterY()));
        localList.add(new Point(localNode2.getCenterX(), localNode2.getCenterY()));
        int[] arrayOfInt1 = new int[i];
        int[] arrayOfInt2 = new int[i];
        for (int j = 0; j < i; j++)
        {
          arrayOfInt1[j] = ((Point)localList.get(j)).x;
          arrayOfInt2[j] = ((Point)localList.get(j)).y;
        }
        int k = 0;
        if (nodeInfos.get(localNode1.getType()) != null)
          k = -2;
        else
          k = 4;
        Point localPoint1 = GeometryUtils.getRectangleLineCrossPoint(localNode1.getRectangle(), new Point(arrayOfInt1[1], arrayOfInt2[1]), k);
        if (localPoint1 != null)
        {
          arrayOfInt1[0] = localPoint1.x;
          arrayOfInt2[0] = localPoint1.y;
        }
        if (nodeInfos.get(localNode2.getType()) != null)
          k = -2;
        else
          k = 4;
        localPoint1 = GeometryUtils.getRectangleLineCrossPoint(localNode2.getRectangle(), new Point(arrayOfInt1[(i - 2)], arrayOfInt2[(i - 2)]), k);
        if (localPoint1 != null)
        {
          arrayOfInt1[(i - 1)] = localPoint1.x;
          arrayOfInt2[(i - 1)] = localPoint1.y;
        }
        paramGraphics2D.drawPolyline(arrayOfInt1, arrayOfInt2, i);
        drawArrow(paramGraphics2D, arrayOfInt1[(i - 2)], arrayOfInt2[(i - 2)], arrayOfInt1[(i - 1)], arrayOfInt2[(i - 1)]);
        String str2 = localTransition.getLabel();
        if ((str2 != null) && (str2.length() > 0))
        {
          int m;
          int n;
          if (i % 2 == 0)
          {
            m = (arrayOfInt1[(i / 2 - 1)] + arrayOfInt1[(i / 2)]) / 2;
            n = (arrayOfInt2[(i / 2 - 1)] + arrayOfInt2[(i / 2)]) / 2;
          }
          else
          {
            m = arrayOfInt1[(i / 2)];
            n = arrayOfInt2[(i / 2)];
          }
          Point localPoint2 = localTransition.getLabelPosition();
          if (localPoint2 != null)
          {
            m += localPoint2.x;
            n += localPoint2.y;
          }
          n += 12;
          paramGraphics2D.setColor(Color.BLUE);
          paramGraphics2D.drawString(str2, m, n);
          paramGraphics2D.setColor(DEFAULT_LINE_STROKE_COLOR);
        }
      }
    }
  }

  private void drawArrow(Graphics2D paramGraphics2D, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    double d3 = Math.atan2(paramInt4 - paramInt2, paramInt3 - paramInt1);
    double d1 = paramInt3 + 2.0D * Math.cos(d3);
    double d2 = paramInt4 + 2.0D * Math.sin(d3);
    int i = (int)Math.round(d1);
    int j = (int)Math.round(d2);
    double d4 = Math.cos(d3);
    double d5 = Math.sin(d3);
    int[] arrayOfInt1 = { 0, i, 0 };
    int[] arrayOfInt2 = { 0, j, 0 };
    double d6 = 8.0D * d5;
    double d7 = 8.0D * d4;
    double d8 = 4.0D * d5;
    double d9 = 4.0D * d4;
    arrayOfInt1[0] = (int)Math.round(paramInt3 - (d7 + d8));
    arrayOfInt2[0] = (int)Math.round(paramInt4 - (d6 - d9));
    arrayOfInt1[2] = (int)Math.round(paramInt3 - (d7 - d8));
    arrayOfInt2[2] = (int)Math.round(paramInt4 - (d9 + d6));
    paramGraphics2D.fillPolygon(arrayOfInt1, arrayOfInt2, 3);
  }

  private void drawNode(Map<String, Node> paramMap, Set paramSet, Graphics2D paramGraphics2D, Font paramFont)
    throws IOException
  {
    Iterator localIterator = paramMap.values().iterator();
    while (localIterator.hasNext())
    {
      Node localNode = (Node)localIterator.next();
      String str = localNode.getName();
      if (nodeInfos.get(localNode.getType()) != null)
      {
        BufferedImage localBufferedImage = ImageIO.read(getClass().getResourceAsStream("/icons/48/" + nodeInfos.get(localNode.getType())));
        paramGraphics2D.drawImage(localBufferedImage, localNode.getX(), localNode.getY(), null);
      }
      else
      {
        int i = localNode.getX();
        int j = localNode.getY();
        int k = localNode.getWidth();
        int m = localNode.getHeight();
        this.links.add(new AnchorArea(Integer.valueOf(i), Integer.valueOf(j), Integer.valueOf(i + k), Integer.valueOf(j + m), str, localNode.getType()));
        paramGraphics2D.setColor(DEFAULT_FILL_COLOR);
        paramGraphics2D.fillRoundRect(i, j, k, m, 25, 25);
        if (paramSet.contains(str))
          paramGraphics2D.setColor(Color.RED);
        else
          paramGraphics2D.setColor(DEFAULT_STROKE_COLOR);
        paramGraphics2D.setStroke(DEFAULT_STROKE);
        paramGraphics2D.drawRoundRect(i, j, k, m, 25, 25);
        FontRenderContext localFontRenderContext = paramGraphics2D.getFontRenderContext();
        Rectangle2D localRectangle2D = paramFont.getStringBounds(str, localFontRenderContext);
        int n = (int)(localNode.getX() + (localNode.getWidth() - localRectangle2D.getWidth()) / 2.0D);
        int i1 = (int)(localNode.getY() + (localNode.getHeight() - localRectangle2D.getHeight()) / 2.0D - localRectangle2D.getY());
        paramGraphics2D.setStroke(DEFAULT_LINE_STROKE);
        paramGraphics2D.setColor(Color.black);
        paramGraphics2D.drawString(str, n, i1);
      }
    }
  }

  public List<AnchorArea> getLinks()
  {
    return this.links;
  }

  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    JpdlModel localJpdlModel = new JpdlModel(Thread.currentThread().getContextClassLoader().getResource("jpdl/buyCar.jpdl.xml").openStream());
    localJpdlModel.getActivityNames().add("经理审批");
    ImageIO.write(new JpdlModelDrawer().draw(localJpdlModel), "png", new File("d:/buyCar.png"));
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.jbpm.jpdl.JpdlModelDrawer
 * JD-Core Version:    0.6.0
 */