package com.htsoft.core.jbpm;

import com.htsoft.core.util.AppUtil;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.service.system.AppRoleService;
import com.htsoft.oa.service.system.AppUserService;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.jbpm.api.identity.Group;
import org.jbpm.api.identity.User;
import org.jbpm.pvm.internal.identity.spi.IdentitySession;

public class UserSession
  implements IdentitySession
{
  private AppUserService appUserService = (AppUserService)AppUtil.getBean("appUserService");
  private AppRoleService appRoleService = (AppRoleService)AppUtil.getBean("appRoleService");

  public String createGroup(String paramString1, String paramString2, String paramString3)
  {
    return null;
  }

  public void createMembership(String paramString1, String paramString2, String paramString3)
  {
  }

  public String createUser(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    return null;
  }

  public void deleteGroup(String paramString)
  {
  }

  public void deleteMembership(String paramString1, String paramString2, String paramString3)
  {
  }

  public void deleteUser(String paramString)
  {
  }

  public Group findGroupById(String paramString)
  {
    return (Group)this.appRoleService.get(new Long(paramString));
  }

  public List<Group> findGroupsByUser(String paramString)
  {
    AppUser localAppUser = (AppUser)this.appUserService.get(new Long(paramString));
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = localAppUser.getRoles().iterator();
    while (localIterator.hasNext())
      localArrayList.add((Group)localIterator.next());
    return localArrayList;
  }

  public List<Group> findGroupsByUserAndGroupType(String paramString1, String paramString2)
  {
    return findGroupsByUser(paramString1);
  }

  public User findUserById(String paramString)
  {
    return (User)this.appUserService.get(new Long(paramString));
  }

  public List<User> findUsers()
  {
    List localList = this.appUserService.getAll();
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      AppUser localAppUser = (AppUser)localIterator.next();
      localArrayList.add(localAppUser);
    }
    return localArrayList;
  }

  public List<User> findUsersByGroup(String paramString)
  {
    List localList = this.appUserService.findByRoleId(new Long(paramString));
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      AppUser localAppUser = (AppUser)localIterator.next();
      localArrayList.add(localAppUser);
    }
    return localArrayList;
  }

  public List<User> findUsersById(String[] paramArrayOfString)
  {
    return null;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.jbpm.UserSession
 * JD-Core Version:    0.6.0
 */