package com.htsoft.core.log;

import com.htsoft.core.util.ContextUtil;
import com.htsoft.oa.model.system.AppUser;
import com.htsoft.oa.model.system.SystemLog;
import com.htsoft.oa.service.system.SystemLogService;
import java.lang.reflect.Method;
import java.util.Date;
import javax.annotation.Resource;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;

public class LogAspect
{

  @Resource
  private SystemLogService systemLogService;
  private Log logger = LogFactory.getLog(LogAspect.class);

  public Object doSystemLog(ProceedingJoinPoint paramProceedingJoinPoint)
    throws Throwable
  {
    String str1 = paramProceedingJoinPoint.getSignature().getName();
    if ((StringUtils.isNotEmpty(str1)) && (!str1.startsWith("set")) && (!str1.startsWith("get")))
    {
      Class localClass = paramProceedingJoinPoint.getTarget().getClass();
      Method localMethod = localClass.getMethod(str1, new Class[0]);
      if (localMethod != null)
      {
        boolean bool = localMethod.isAnnotationPresent(Action.class);
        if (bool)
        {
          Action localAction = (Action)localMethod.getAnnotation(Action.class);
          String str2 = localAction.description();
          if (this.logger.isDebugEnabled())
            this.logger.debug("Action method:" + localMethod.getName() + " Description:" + str2);
          AppUser localAppUser = ContextUtil.getCurrentUser();
          if (localAppUser != null)
            try
            {
              SystemLog localSystemLog = new SystemLog();
              localSystemLog.setCreatetime(new Date());
              localSystemLog.setUserId(localAppUser.getUserId());
              localSystemLog.setUsername(localAppUser.getFullname());
              localSystemLog.setExeOperation(str2);
              this.systemLogService.save(localSystemLog);
            }
            catch (Exception localException)
            {
              this.logger.error(localException.getMessage());
            }
        }
      }
    }
    return paramProceedingJoinPoint.proceed();
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.log.LogAspect
 * JD-Core Version:    0.6.0
 */