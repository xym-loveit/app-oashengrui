package com.htsoft.core.command;

import java.util.List;
import java.util.Set;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;

public class FieldCommandImpl
  implements CriteriaCommand
{
  private static Log logger = LogFactory.getLog(CriteriaCommand.class);
  private String property;
  private Object value;
  private String operation;
  private QueryFilter filter;

  public FieldCommandImpl(String paramString1, Object paramObject, String paramString2, QueryFilter paramQueryFilter)
  {
    this.property = paramString1;
    this.value = paramObject;
    this.operation = paramString2;
    this.filter = paramQueryFilter;
  }

  public String getProperty()
  {
    return this.property;
  }

  public void setProperty(String paramString)
  {
    this.property = paramString;
  }

  public Object getValue()
  {
    return this.value;
  }

  public void setValue(Object paramObject)
  {
    this.value = paramObject;
  }

  public String getOperation()
  {
    return this.operation;
  }

  public void setOperation(String paramString)
  {
    this.operation = paramString;
  }

  public Criteria execute(Criteria paramCriteria)
  {
    String[] arrayOfString = this.property.split("[.]");
    if ((arrayOfString != null) && (arrayOfString.length > 1) && (!"vo".equals(arrayOfString[0])))
      for (int i = 0; i < arrayOfString.length - 1; i++)
      {
        if (this.filter.getAliasSet().contains(arrayOfString[i]))
          continue;
        paramCriteria.createAlias(arrayOfString[i], arrayOfString[i]);
        this.filter.getAliasSet().add(arrayOfString[i]);
      }
    if ("LT".equals(this.operation))
      paramCriteria.add(Restrictions.lt(this.property, this.value));
    else if ("GT".equals(this.operation))
      paramCriteria.add(Restrictions.gt(this.property, this.value));
    else if ("LE".equals(this.operation))
      paramCriteria.add(Restrictions.le(this.property, this.value));
    else if ("GE".equals(this.operation))
      paramCriteria.add(Restrictions.ge(this.property, this.value));
    else if ("LK".equals(this.operation))
      paramCriteria.add(Restrictions.like(this.property, "%" + this.value + "%").ignoreCase());
    else if ("LFK".equals(this.operation))
      paramCriteria.add(Restrictions.like(this.property, this.value + "%").ignoreCase());
    else if ("RHK".equals(this.operation))
      paramCriteria.add(Restrictions.like(this.property, "%" + this.value).ignoreCase());
    else if ("NULL".equals(this.operation))
      paramCriteria.add(Restrictions.isNull(this.property));
    else if ("NOTNULL".equals(this.operation))
      paramCriteria.add(Restrictions.isNotNull(this.property));
    else if ("EMP".equals(this.operation))
      paramCriteria.add(Restrictions.isEmpty(this.property));
    else if ("NOTEMP".equals(this.operation))
      paramCriteria.add(Restrictions.isNotEmpty(this.property));
    else if ("NEQ".equals(this.operation))
      paramCriteria.add(Restrictions.ne(this.property, this.value));
    else
      paramCriteria.add(Restrictions.eq(this.property, this.value));
    return paramCriteria;
  }

  public String getPartHql()
  {
    String[] arrayOfString = this.property.split("[.]");
    if ((arrayOfString != null) && (arrayOfString.length > 1) && (!"vo".equals(arrayOfString[0])) && (!this.filter.getAliasSet().contains(arrayOfString[0])))
      this.filter.getAliasSet().add(arrayOfString[0]);
    String str = "";
    if ("LT".equals(this.operation))
    {
      str = this.property + " < ? ";
      this.filter.getParamValueList().add(this.value);
    }
    else if ("GT".equals(this.operation))
    {
      str = this.property + " > ? ";
      this.filter.getParamValueList().add(this.value);
    }
    else if ("LE".equals(this.operation))
    {
      str = this.property + " <= ? ";
      this.filter.getParamValueList().add(this.value);
    }
    else if ("GE".equals(this.operation))
    {
      str = this.property + " >= ? ";
      this.filter.getParamValueList().add(this.value);
    }
    else if ("LK".equals(this.operation))
    {
      str = this.property + " like ? ";
      this.filter.getParamValueList().add("%" + this.value.toString() + "%");
    }
    else if ("LFK".equals(this.operation))
    {
      str = this.property + " like ? ";
      this.filter.getParamValueList().add(this.value.toString() + "%");
    }
    else if ("RHK".equals(this.operation))
    {
      str = this.property + " like ? ";
      this.filter.getParamValueList().add("%" + this.value.toString());
    }
    else if ("NULL".equals(this.operation))
    {
      str = this.property + " is null ";
    }
    else if ("NOTNULL".equals(this.operation))
    {
      str = this.property + " is not null ";
    }
    else if ((!"EMP".equals(this.operation)) && (!"NOTEMP".equals(this.operation)))
    {
      if ("NEQ".equals(this.operation))
      {
        str = this.property + " !=? ";
        this.filter.getParamValueList().add(this.value);
      }
      else
      {
        str = str + this.property + " =? ";
        this.filter.getParamValueList().add(this.value);
      }
    }
    return str;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.command.FieldCommandImpl
 * JD-Core Version:    0.6.0
 */