package com.htsoft.core.command;

import java.util.Set;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;

public class SortCommandImpl
  implements CriteriaCommand
{
  private String sortName;
  private String ascDesc;
  private QueryFilter filter;

  public Criteria execute(Criteria paramCriteria)
  {
    String[] arrayOfString = this.sortName.split("[.]");
    if ((arrayOfString != null) && (arrayOfString.length > 1))
      for (int i = 0; i < arrayOfString.length - 1; i++)
      {
        if (this.filter.getAliasSet().contains(arrayOfString[i]))
          continue;
        paramCriteria.createAlias(arrayOfString[i], arrayOfString[i]);
        this.filter.getAliasSet().add(arrayOfString[i]);
      }
    if ("desc".equalsIgnoreCase(this.ascDesc))
      paramCriteria.addOrder(Order.desc(this.sortName));
    else if ("asc".equalsIgnoreCase(this.ascDesc))
      paramCriteria.addOrder(Order.asc(this.sortName));
    return paramCriteria;
  }

  public SortCommandImpl(String paramString1, String paramString2, QueryFilter paramQueryFilter)
  {
    this.sortName = paramString1;
    this.ascDesc = paramString2;
    this.filter = paramQueryFilter;
  }

  public String getSortName()
  {
    return this.sortName;
  }

  public void setSortName(String paramString)
  {
    this.sortName = paramString;
  }

  public String getAscDesc()
  {
    return this.ascDesc;
  }

  public void setAscDesc(String paramString)
  {
    this.ascDesc = paramString;
  }

  public int hashCode()
  {
    return new HashCodeBuilder(-82280557, -700257973).append(this.sortName).append(this.ascDesc).toHashCode();
  }

  public String getPartHql()
  {
    return this.sortName + " " + this.ascDesc;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.command.SortCommandImpl
 * JD-Core Version:    0.6.0
 */