package com.htsoft.core.command;

import com.htsoft.core.util.ParamUtil;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

public class ReportFilter
{
  Map<String, Object> variables = new HashMap();

  public ReportFilter()
  {
  }

  public ReportFilter(HttpServletRequest paramHttpServletRequest)
  {
    Enumeration localEnumeration = paramHttpServletRequest.getParameterNames();
    while (localEnumeration.hasMoreElements())
    {
      String str1 = (String)localEnumeration.nextElement();
      if (str1.startsWith("Q_"))
      {
        String str2 = paramHttpServletRequest.getParameter(str1);
        addFilter(str1, str2);
      }
    }
  }

  public void addFilter(String paramString1, String paramString2)
  {
    String[] arrayOfString = paramString1.split("[_]");
    if (arrayOfString.length == 3)
      this.variables.put(arrayOfString[1], ParamUtil.convertObject(arrayOfString[2], paramString2));
  }

  public Map<String, Object> getVariables()
  {
    return this.variables;
  }

  public void setVariables(Map<String, Object> paramMap)
  {
    this.variables = paramMap;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.command.ReportFilter
 * JD-Core Version:    0.6.0
 */