package com.htsoft.core.command;

import org.hibernate.Criteria;
import org.hibernate.criterion.Example;

public class ExampleCommandImpl
  implements CriteriaCommand
{
  private Object pojoExample = null;

  public void setPojoExample(Object paramObject)
  {
    this.pojoExample = paramObject;
  }

  public ExampleCommandImpl(Object paramObject)
  {
    this.pojoExample = paramObject;
  }

  public Criteria execute(Criteria paramCriteria)
  {
    if (this.pojoExample != null)
    {
      Example localExample = Example.create(this.pojoExample);
      paramCriteria.add(localExample);
    }
    return paramCriteria;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.command.ExampleCommandImpl
 * JD-Core Version:    0.6.0
 */