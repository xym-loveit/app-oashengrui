package com.htsoft.core.command;

import com.htsoft.core.util.ParamUtil;
import com.htsoft.core.web.paging.PagingBean;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class QueryFilter
{
  private boolean isExport = false;
  public static final String ORDER_DESC = "desc";
  public static final String ORDER_ASC = "asc";
  public static final Log logger = LogFactory.getLog(QueryFilter.class);
  private HttpServletRequest request = null;
  private String filterName = null;
  private List<Object> paramValues = new ArrayList();
  private List<CriteriaCommand> commands = new ArrayList();
  private Set<String> aliasSet = new HashSet();
  private PagingBean pagingBean = null;

  public String getFilterName()
  {
    return this.filterName;
  }

  public void setFilterName(String paramString)
  {
    this.filterName = paramString;
  }

  public PagingBean getPagingBean()
  {
    return this.pagingBean;
  }

  public QueryFilter()
  {
  }

  public QueryFilter(HttpServletRequest paramHttpServletRequest)
  {
    this.request = paramHttpServletRequest;
    Enumeration localEnumeration = paramHttpServletRequest.getParameterNames();
    while (localEnumeration.hasMoreElements())
    {
      localObject1 = (String)localEnumeration.nextElement();
      if (((String)localObject1).startsWith("Q_"))
      {
        localObject2 = paramHttpServletRequest.getParameter((String)localObject1);
        addFilter((String)localObject1, (String)localObject2);
      }
    }
    Object localObject1 = Integer.valueOf(0);
    Object localObject2 = PagingBean.DEFAULT_PAGE_SIZE;
    String str1 = paramHttpServletRequest.getParameter("start");
    String str2 = paramHttpServletRequest.getParameter("limit");
    if (StringUtils.isNotEmpty(str1))
      localObject1 = new Integer(str1);
    if (StringUtils.isNotEmpty(str2))
      localObject2 = new Integer(str2);
    String str3 = paramHttpServletRequest.getParameter("sort");
    String str4 = paramHttpServletRequest.getParameter("dir");
    if ((StringUtils.isNotEmpty(str3)) && (StringUtils.isNotEmpty(str4)))
      addSorted(str3, str4);
    if ("true".equals(paramHttpServletRequest.getParameter("isExport")))
    {
      this.isExport = true;
      paramHttpServletRequest.setAttribute("colId", paramHttpServletRequest.getParameter("colId"));
      paramHttpServletRequest.setAttribute("colName", paramHttpServletRequest.getParameter("colName"));
      paramHttpServletRequest.setAttribute("exportType", paramHttpServletRequest.getParameter("exportType"));
    }
    paramHttpServletRequest.setAttribute("isExport", Boolean.valueOf(this.isExport));
    this.pagingBean = new PagingBean(((Integer)localObject1).intValue(), ((Integer)localObject2).intValue());
  }

  public void addFilter(String paramString1, String paramString2)
  {
    String[] arrayOfString = paramString1.split("[_]");
    Object localObject = null;
    FieldCommandImpl localFieldCommandImpl;
    if ((arrayOfString != null) && (arrayOfString.length == 4))
    {
      localObject = ParamUtil.convertObject(arrayOfString[2], paramString2);
      if (localObject != null)
      {
        localFieldCommandImpl = new FieldCommandImpl(arrayOfString[1], localObject, arrayOfString[3], this);
        this.commands.add(localFieldCommandImpl);
      }
    }
    else if ((arrayOfString != null) && (arrayOfString.length == 3))
    {
      localFieldCommandImpl = new FieldCommandImpl(arrayOfString[1], localObject, arrayOfString[2], this);
      this.commands.add(localFieldCommandImpl);
    }
    else
    {
      logger.error("Query param name [" + paramString1 + "] is not right format.");
    }
  }

  public void addParamValue(Object paramObject)
  {
    this.paramValues.add(paramObject);
  }

  public List getParamValueList()
  {
    return this.paramValues;
  }

  public void addSorted(String paramString1, String paramString2)
  {
    this.commands.add(new SortCommandImpl(paramString1, paramString2, this));
  }

  public void addExample(Object paramObject)
  {
    this.commands.add(new ExampleCommandImpl(paramObject));
  }

  public List<CriteriaCommand> getCommands()
  {
    return this.commands;
  }

  public Set<String> getAliasSet()
  {
    return this.aliasSet;
  }

  public boolean isExport()
  {
    return this.isExport;
  }

  public void setExport(boolean paramBoolean)
  {
    this.isExport = paramBoolean;
  }

  public HttpServletRequest getRequest()
  {
    return this.request;
  }
}

/* Location:           D:\x36zhao\workspace\joffice2\web\WEB-INF\lib\htcore.jar
 * Qualified Name:     com.htsoft.core.command.QueryFilter
 * JD-Core Version:    0.6.0
 */